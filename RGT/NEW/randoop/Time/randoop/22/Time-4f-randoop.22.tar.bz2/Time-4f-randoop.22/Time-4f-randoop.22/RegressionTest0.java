import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.joda.time.DateTimeField dateTimeField2 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test002");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        java.lang.StringBuffer stringBuffer3 = null;
//        org.joda.time.ReadablePartial readablePartial4 = null;
//        try {
//            dateTimeFormatter0.printTo(stringBuffer3, readablePartial4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365" + "'", str2.equals("1969365"));
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0.0d, (java.lang.Number) (-1L), (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 100L, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant(10L);
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) instant2, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test006");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone3);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        try {
//            java.lang.String str6 = dateTimeFormatter0.print(readablePartial5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365" + "'", str2.equals("1969365"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, (int) (short) 100, (int) (short) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1, 2000, 2000, (int) 'a', (int) (byte) 1, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '4', (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 84L + "'", long2 == 84L);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test011");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withDefaultYear(1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365" + "'", str2.equals("1969365"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((int) (byte) 100, 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 0, (int) (short) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for  must be in the range [100,32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldType0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Instant instant2 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.joda.time.Instant instant5 = instant2.plus((long) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime6 = instant2.toMutableDateTime();
        try {
            int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime6, "hi!", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("1969365");
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationField durationField2 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) -1, (-1), (int) (byte) 10, 1, (int) (short) -1, 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DurationFieldType durationFieldType10 = null;
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime9.withFieldAdded(durationFieldType10, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1969365");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.Chronology chronology0 = null;
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName(0L, locale4);
//        try {
//            org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime11.withDayOfMonth((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField1, dateTimeFieldType2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str3 = dateTimeFormatter1.print((long) 10);
//        try {
//            org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.parse("1970W013T160000-0800", dateTimeFormatter1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970W013T160000-0800\" is malformed at \"W013T160000-0800\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969365" + "'", str3.equals("1969365"));
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        java.io.Writer writer1 = null;
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(0L, locale5);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone3);
//        org.joda.time.LocalDate localDate9 = localDate7.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.LocalDate localDate12 = localDate9.withPeriodAdded(readablePeriod10, 0);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pacific Standard Time" + "'", str6.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(localDate12);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.dayOfYear();
//        try {
//            org.joda.time.LocalDate localDate13 = localDate7.withWeekOfWeekyear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) -1, 0, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("2018");
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField3 = buddhistChronology1.weekyears();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = buddhistChronology1.get(readablePeriod4, (long) (short) 100, (long) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now(dateTimeZone6);
        int[] intArray9 = new int[] {};
        try {
            int[] intArray11 = delegatedDateTimeField5.addWrapField((org.joda.time.ReadablePartial) localDate7, (int) (short) -1, intArray9, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology21);
//        org.joda.time.DurationField durationField23 = buddhistChronology21.weekyears();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, durationField23, dateTimeFieldType24, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(durationField23);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(2018, (int) (short) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 100, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField3 = buddhistChronology1.weekyears();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(4, (int) (byte) 10, 2018, (int) (byte) 10, (int) (short) -1, (int) (byte) 0, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        try {
//            org.joda.time.LocalDate localDate9 = localDate5.withCenturyOfEra((-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DurationField durationField4 = buddhistChronology2.weekyears();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField6 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField4, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        java.util.Date date12 = localDate11.toDate();
//        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
//        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
//        java.util.Locale locale27 = null;
//        try {
//            long long28 = skipUndoDateTimeField24.set((long) 100, "hi!", locale27);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for minuteOfHour is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) -1, 0, 2018);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        try {
//            long long22 = skipDateTimeField19.set(0L, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [1,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName(0L, locale7);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone5);
//        java.util.Date date10 = localDate9.toDate();
//        int[] intArray12 = buddhistChronology2.get((org.joda.time.ReadablePartial) localDate9, (long) (short) -1);
//        org.joda.time.DurationField durationField13 = buddhistChronology2.eras();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, durationField13, dateTimeFieldType14, 11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 'a');
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Pacific Standard Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Pacific Standard Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology8 = localDate7.getChronology();
//        java.lang.String str9 = localDate7.toString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        try {
//            org.joda.time.LocalDate localDate12 = localDate7.withField(dateTimeFieldType10, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2018-11-03" + "'", str9.equals("2018-11-03"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        java.util.Date date12 = localDate11.toDate();
//        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
//        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType25, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DurationField durationField6 = buddhistChronology2.weekyears();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        try {
//            org.joda.time.DateTime.Property property15 = dateTime11.property(dateTimeFieldType14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        try {
            long long9 = buddhistChronology1.getDateTimeMillis(11, 3, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.dayOfYear();
//        int int12 = property11.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        try {
//            org.joda.time.LocalDate localDate12 = localDate10.withYearOfEra(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long5 = copticChronology0.getDateTimeMillis((int) (byte) 0, (int) (byte) -1, (int) (short) -1, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.era();
        int int8 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(3, 0, (int) (short) -1, 11, 0, (int) (short) 0, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 100, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9700L + "'", long2 == 9700L);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        int int11 = localDate10.getWeekyear();
//        org.joda.time.LocalTime localTime12 = null;
//        try {
//            org.joda.time.LocalDateTime localDateTime13 = localDate10.toLocalDateTime(localTime12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2018 + "'", int11 == 2018);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        try {
//            org.joda.time.DateTime dateTime15 = property13.setCopy("1969365");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969365 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.DurationField durationField4 = buddhistChronology2.weekyears();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology6);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        java.util.Date date14 = localDate13.toDate();
//        int[] intArray16 = buddhistChronology6.get((org.joda.time.ReadablePartial) localDate13, (long) (short) -1);
//        org.joda.time.DurationField durationField17 = buddhistChronology6.eras();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField18 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField4, durationField17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        try {
//            int int16 = property13.compareTo(readablePartial15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = buddhistChronology0.get(readablePeriod1, (long) (-1), (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2018-11-03");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2018-11-03/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfEra(2018);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        try {
            java.lang.String str3 = dateTimeFormatter0.print((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray8 = localDate7.getFieldTypes();
//        int[] intArray9 = new int[] {};
//        try {
//            org.joda.time.Partial partial10 = new org.joda.time.Partial(dateTimeFieldTypeArray8, intArray9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray8);
//        org.junit.Assert.assertNotNull(intArray9);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        int int17 = dateTimeFormatter16.getDefaultYear();
//        java.lang.Integer int18 = dateTimeFormatter16.getPivotYear();
//        try {
//            java.lang.String str19 = dateTime15.toString(dateTimeFormatter16);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2000 + "'", int17 == 2000);
//        org.junit.Assert.assertNull(int18);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
//        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
//        try {
//            int int17 = localDate5.get(dateTimeFieldType16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray8 = localDate5.getFields();
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        try {
//            boolean boolean10 = localDate5.isAfter(readablePartial9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        int int10 = dateTime9.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57973 + "'", int10 == 57973);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        try {
//            int int25 = localDate20.getValue(4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 4");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pacific Standard Time" + "'", str17.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593386022000L) + "'", long23 == (-15593386022000L));
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        java.util.Date date12 = localDate11.toDate();
//        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
//        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
//        org.joda.time.DateTimeField dateTimeField25 = skipUndoDateTimeField24.getWrappedField();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 0, 2018);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        java.lang.Appendable appendable1 = null;
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(0L, locale5);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone3);
//        org.joda.time.LocalDate localDate9 = localDate7.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime10 = null;
//        org.joda.time.DateTime dateTime11 = localDate9.toDateTime(localTime10);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime11.withMinuteOfHour(1);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pacific Standard Time" + "'", str6.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 1);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime.Property property10 = dateTime9.era();
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime9.withEra((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        boolean boolean2 = dateTimeFormatter0.isParser();
//        java.lang.Appendable appendable3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName(0L, locale7);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate11 = localDate9.minusWeeks((int) ' ');
//        try {
//            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadablePartial) localDate11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate11);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 3L, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException4.prependMessage("1969365");
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969365" + "'", str7.equals("1969365"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(chronology2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone8.getName(0L, locale10);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone8);
//        java.util.Date date13 = localDate12.toDate();
//        int[] intArray15 = buddhistChronology5.get((org.joda.time.ReadablePartial) localDate12, (long) (short) -1);
//        org.joda.time.DurationField durationField16 = buddhistChronology5.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology18);
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, (org.joda.time.DateTimeField) delegatedDateTimeField22);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, (org.joda.time.DateTimeField) skipDateTimeField23, (int) (byte) 10);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipDateTimeField23);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology28.minuteOfHour();
//        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DurationField durationField32 = buddhistChronology28.weeks();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField26, durationField32, dateTimeFieldType33, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        try {
            int int3 = partial1.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
        java.util.Locale locale10 = null;
        try {
            long long11 = delegatedDateTimeField7.set((long) ' ', "", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DurationField durationField6 = buddhistChronology2.months();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField8 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException4.prependMessage("1969365");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
//        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime27 = null;
//        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
//        boolean boolean29 = localDate18.isAfter((org.joda.time.ReadablePartial) localDate26);
//        org.joda.time.LocalDate localDate31 = localDate18.plusYears((int) 'a');
//        boolean boolean32 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology34.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate38 = org.joda.time.LocalDate.now(dateTimeZone37);
//        org.joda.time.Chronology chronology39 = buddhistChronology34.withZone(dateTimeZone37);
//        try {
//            org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((java.lang.Object) boolean32, (org.joda.time.Chronology) buddhistChronology34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Pacific Standard Time" + "'", str23.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(chronology39);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime.Property property10 = dateTime9.era();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTime dateTime13 = property10.roundHalfCeilingCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology14);
//        try {
//            int int16 = property10.getDifference((org.joda.time.ReadableInstant) dateTime15);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AD" + "'", str12.equals("AD"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        boolean boolean4 = dateTime2.isAfter((long) 0);
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(84L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 84 + "'", int1 == 84);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10, 0, 57968, 0, (int) (byte) -1, (int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        org.joda.time.DateTime.Property property4 = dateTime1.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(84L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray8 = localDate5.getFields();
//        org.joda.time.DurationFieldType durationFieldType9 = null;
//        try {
//            org.joda.time.LocalDate localDate11 = localDate5.withFieldAdded(durationFieldType9, 365);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime dateTime14 = property12.addToCopy(0);
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime14);
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime14.withHourOfDay(57977);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57977 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(chronology2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone8.getName(0L, locale10);
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone8);
//        java.util.Date date13 = localDate12.toDate();
//        int[] intArray15 = buddhistChronology5.get((org.joda.time.ReadablePartial) localDate12, (long) (short) -1);
//        org.joda.time.DurationField durationField16 = buddhistChronology5.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology18);
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, (org.joda.time.DateTimeField) delegatedDateTimeField22);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, (org.joda.time.DateTimeField) skipDateTimeField23, (int) (byte) 10);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipDateTimeField23);
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate();
//        java.util.Locale locale28 = null;
//        try {
//            java.lang.String str29 = skipDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) localDate27, locale28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Pacific Standard Time" + "'", str11.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 57968);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57968");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 0, (-1), (int) ' ', (int) 'a', 100, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("PST", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(2018);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfWeek(84);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        long long3 = mutableDateTime2.getMillis();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getShortName((long) 'a', locale5);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
//        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(0L, 11, 0, (int) (byte) -1, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2512365" + "'", str5.equals("2512365"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now(dateTimeZone6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        int int9 = dateTimeZone6.getOffset(readableInstant8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(57973, 57973, 0, (int) (byte) 10, (int) '#', 57968, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57968 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
//        boolean boolean12 = property11.isLeap();
//        java.lang.String str13 = property11.toString();
//        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
//        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
//        try {
//            org.joda.time.LocalDate localDate18 = localDate16.withMonthOfYear(365);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate16);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(2000, (int) (short) 1, (int) (byte) 0, 57977, 365, 0, 2018);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57977 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        long long7 = delegatedDateTimeField5.roundCeiling(1L);
//        java.lang.String str9 = delegatedDateTimeField5.getAsText(0L);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getName(0L, locale13);
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks((int) ' ');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology20);
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName(0L, locale25);
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(dateTimeZone23);
//        java.util.Date date28 = localDate27.toDate();
//        int[] intArray30 = buddhistChronology20.get((org.joda.time.ReadablePartial) localDate27, (long) (short) -1);
//        java.util.Locale locale32 = null;
//        try {
//            int[] intArray33 = delegatedDateTimeField5.set((org.joda.time.ReadablePartial) localDate15, (int) (byte) 0, intArray30, "DateTimeField[minuteOfHour]", locale32);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[minuteOfHour]\" for minuteOfHour is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(intArray30);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone3);
//        try {
//            org.joda.time.DateTime dateTime6 = dateTimeFormatter4.parseDateTime("57977");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"57977\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365" + "'", str2.equals("1969365"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        boolean boolean6 = dateTimeZone1.isStandardOffset((long) '4');
//        org.joda.time.LocalDateTime localDateTime7 = null;
//        try {
//            boolean boolean8 = dateTimeZone1.isLocalDateTimeGap(localDateTime7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
//        org.joda.time.DateTime.Property property15 = dateTime14.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        try {
            long long6 = buddhistChronology0.getDateTimeMillis(2000, 2018, 4, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2018 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        try {
//            org.joda.time.DateTime.Property property16 = dateTime14.property(dateTimeFieldType15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.fromCalendarFields(calendar4);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(localDate5);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        long long15 = dateTimeZone7.getMillisKeepLocal(dateTimeZone9, (long) 3);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(4, 0, (int) (byte) -1, 57968, 0, 57977, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57968 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
//        boolean boolean12 = property11.isLeap();
//        java.lang.String str13 = property11.toString();
//        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
//        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
//        org.joda.time.LocalTime localTime17 = null;
//        try {
//            org.joda.time.LocalDateTime localDateTime18 = localDate16.toLocalDateTime(localTime17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate16);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(11);
//        org.joda.time.DurationFieldType durationFieldType16 = null;
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime15.withFieldAdded(durationFieldType16, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        int int11 = localDate7.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 44 + "'", int11 == 44);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "97");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 2, 2, (int) (short) 10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1970W013T160000-0800");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1970W013T160000-0800/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        java.util.Date date12 = localDate11.toDate();
//        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
//        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
//        int int26 = skipUndoDateTimeField24.get((long) 11);
//        try {
//            long long29 = skipUndoDateTimeField24.set(0L, 57973);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57973 for minuteOfHour must be in the range [2,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pacific Standard Time" + "'", str10.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology8 = localDate7.getChronology();
//        int int9 = localDate7.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 307 + "'", int9 == 307);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(57977);
        int int4 = dateTime3.getWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-2812) + "'", int4 == (-2812));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.Partial partial5 = partial1.withFieldAdded(durationFieldType3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.Partial partial4 = partial1.withPeriodAdded(readablePeriod2, 4);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Partial partial7 = partial4.withFieldAdded(durationFieldType5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.era();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, 57977);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundCeiling(1L);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField5.getRangeDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone5.getName(0L, locale7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone5);
        java.util.Date date10 = localDate9.toDate();
        int[] intArray12 = buddhistChronology2.get((org.joda.time.ReadablePartial) localDate9, (long) (short) -1);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        boolean boolean14 = localDate9.isSupported(durationFieldType13);
        org.joda.time.LocalDate localDate15 = localDate0.withFields((org.joda.time.ReadablePartial) localDate9);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate15);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        org.joda.time.LocalDate.Property property24 = localDate20.weekyear();
//        java.util.Locale locale25 = null;
//        int int26 = property24.getMaximumShortTextLength(locale25);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593472000000L) + "'", long23 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology1.dayOfYear();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593472000000L) + "'", long23 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(dateTimeField24);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 3, 100);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3L + "'", long5 == 3L);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        int int10 = dateTime9.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 134 + "'", int10 == 134);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.lang.StringBuffer stringBuffer2 = null;
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.DateTime dateTime12 = localDate10.toDateTime(localTime11);
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property13.getAsText(locale14);
        org.joda.time.DateTime dateTime16 = property13.roundHalfCeilingCopy();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AD" + "'", str15.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getName(0L, locale4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone2);
        long long9 = dateTimeZone2.convertLocalToUTC((long) '4', true);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(1L, dateTimeZone2);
        int int11 = localDate10.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((-15593386022000L), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-155933860220L) + "'", long2 == (-155933860220L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.Instant instant4 = instant1.plus((long) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime5 = instant1.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime6 = instant1.toMutableDateTime();
        long long7 = instant1.getMillis();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(1);
        boolean boolean8 = dateTime5.isBeforeNow();
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology3, (org.joda.time.ReadableDateTime) dateTime5, readableDateTime9);
        try {
            long long15 = limitChronology10.getDateTimeMillis(11, 2000, 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(limitChronology10);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
//        org.joda.time.LocalDate localDate13 = localDate7.withYearOfEra(10);
//        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) '4');
//        int int16 = localDate13.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 44 + "'", int16 == 44);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.era();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology5.minuteOfHour();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DurationField durationField9 = buddhistChronology5.months();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, durationField9, dateTimeFieldType10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            int int4 = mutableDateTime2.get(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName(0L, locale4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone2);
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime9 = null;
//        org.joda.time.DateTime dateTime10 = localDate8.toDateTime(localTime9);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property13 = dateTime12.monthOfYear();
//        org.joda.time.DateTime dateTime15 = property13.addToCopy(0);
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.Chronology chronology17 = dateTimeFormatter0.getChronolgy();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "23" + "'", str16.equals("23"));
//        org.junit.Assert.assertNull(chronology17);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.weekyear();
        org.joda.time.LocalDate localDate12 = localDate7.plusYears(57973);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray13 = localDate12.getFieldTypes();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray13);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("2512365");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2512365\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) 'a', 58020L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.junit.Assert.assertNotNull(localDate0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond(57982);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57982 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
//        int int15 = dateTime11.getSecondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime11.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime11.plusMonths(2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        try {
//            int int21 = dateTime11.get(dateTimeFieldType20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 83187 + "'", int15 == 83187);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(2018, (int) (short) 10, 0, 0, 307, 365, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 307 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalFieldValueException: 1969365: Value 1 for 1969365 must be in the range [-1.0,1]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalFieldValueException: 1969365: Value 1 for 1969365 must be in the range [-1.0,1]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
        java.util.Date date12 = localDate11.toDate();
        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
        int int25 = skipUndoDateTimeField24.getMinimumValue();
        try {
            long long28 = skipUndoDateTimeField24.set((long) 2018, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfHour must be in the range [2,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 100, dateTimeZone9);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(0, 0, 365, 2, (int) (short) 1, (-2812), 100, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2812 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology16.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now(dateTimeZone19);
        org.joda.time.Chronology chronology21 = buddhistChronology16.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime14.toDateTime(chronology21);
        int int23 = dateTime22.getDayOfYear();
        java.util.GregorianCalendar gregorianCalendar24 = dateTime22.toGregorianCalendar();
        long long25 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(gregorianCalendar24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 48L + "'", long25 == 48L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(100, (-1), 0, 59, (int) (byte) 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
//        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
//        long long3 = property1.remainder();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 83188324L + "'", long3 == 83188324L);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.days();
        org.joda.time.DurationField durationField2 = buddhistChronology0.months();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1970);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210696552000000L) + "'", long1 == (-210696552000000L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundCeiling(1L);
        java.lang.String str9 = delegatedDateTimeField5.getAsText(0L);
        java.lang.String str10 = delegatedDateTimeField5.toString();
        boolean boolean11 = delegatedDateTimeField5.isSupported();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str10.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 57975, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.LocalDate localDate30 = localDate27.withPeriodAdded(readablePeriod28, 0);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate30, 57977, locale32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) str33, dateTimeZone34);
        org.joda.time.DateTime.Property property36 = dateTime35.millisOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology38 = buddhistChronology37.withUTC();
        org.joda.time.Chronology chronology39 = buddhistChronology37.withUTC();
        org.joda.time.DateTime dateTime40 = dateTime35.withChronology(chronology39);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "57977" + "'", str33.equals("57977"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("+00:00", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalDate.Property property8 = localDate5.dayOfMonth();
        try {
            org.joda.time.DateTimeField dateTimeField10 = localDate5.getField(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.DateTime dateTime13 = property10.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime15 = dateTime13.plusMillis(4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AD" + "'", str12.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.withPeriodAdded(readablePeriod4, 0);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear(11);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        java.util.TimeZone timeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName(0L, locale27);
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone25);
//        org.joda.time.LocalDate localDate31 = localDate29.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime32 = null;
//        org.joda.time.DateTime dateTime33 = localDate31.toDateTime(localTime32);
//        org.joda.time.LocalDate.Property property34 = localDate31.yearOfCentury();
//        org.joda.time.LocalDate.Property property35 = localDate31.monthOfYear();
//        boolean boolean36 = property35.isLeap();
//        java.lang.String str37 = property35.toString();
//        org.joda.time.LocalDate localDate39 = property35.addToCopy(365);
//        org.joda.time.LocalDate localDate40 = property35.roundHalfFloorCopy();
//        java.util.TimeZone timeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = dateTimeZone42.getName(0L, locale44);
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate47 = localDate40.withFields((org.joda.time.ReadablePartial) localDate46);
//        int int48 = localDate20.compareTo((org.joda.time.ReadablePartial) localDate46);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593472000000L) + "'", long23 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Property[monthOfYear]" + "'", str37.equals("Property[monthOfYear]"));
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "+00:00" + "'", str45.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName(0L, locale4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone2);
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime9 = null;
//        org.joda.time.DateTime dateTime10 = localDate8.toDateTime(localTime9);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property13 = dateTime12.monthOfYear();
//        org.joda.time.DateTime dateTime15 = property13.addToCopy(0);
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime15);
//        java.util.Locale locale17 = dateTimeFormatter0.getLocale();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "23" + "'", str16.equals("23"));
//        org.junit.Assert.assertNull(locale17);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.Partial partial4 = partial1.withPeriodAdded(readablePeriod2, 4);
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            boolean boolean6 = partial4.isMatch(readablePartial5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) 0, dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        try {
            java.lang.String str3 = dateTime1.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        java.lang.String str6 = dateTimeZone1.getID();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        try {
            long long12 = julianChronology7.getDateTimeMillis(100, 84, (int) (short) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
        org.junit.Assert.assertNotNull(julianChronology7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        int int1 = localDate0.getEra();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate16.minus(readablePeriod17);
        org.joda.time.LocalDate localDate20 = localDate18.withYearOfEra(11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((org.joda.time.Chronology) gregorianChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime28 = null;
        org.joda.time.DateTime dateTime29 = localDate27.toDateTime(localTime28);
        org.joda.time.LocalDate.Property property30 = localDate27.yearOfCentury();
        org.joda.time.LocalDate.Property property31 = localDate27.monthOfYear();
        org.joda.time.LocalDate localDate33 = localDate27.withYearOfEra(10);
        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) '4');
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate33, (int) '4', locale37);
        try {
            org.joda.time.LocalDate localDate40 = localDate33.withYearOfCentury(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "52" + "'", str38.equals("52"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
        boolean boolean15 = dateTime14.isEqualNow();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((int) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime5.toDateTime(chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(57977);
        org.joda.time.DateTime dateTime5 = dateTime1.withYear((int) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        int int4 = dateTime2.getDayOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.era();
        int int4 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology2.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField7 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "23");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.minuteOfHour();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DurationField durationField8 = buddhistChronology4.weeks();
        org.joda.time.Chronology chronology9 = buddhistChronology4.withUTC();
        try {
            org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((-1), 57975, 3, chronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57975 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getShortName((long) 'a', locale5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.hourOfHalfday();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology8.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone11);
        org.joda.time.Chronology chronology13 = buddhistChronology8.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone11);
        java.lang.String str15 = dateTimeZone11.getID();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField17 = buddhistChronology16.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology19);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTimeZone22.getName(0L, locale24);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(dateTimeZone22);
        java.util.Date date27 = localDate26.toDate();
        int[] intArray29 = buddhistChronology19.get((org.joda.time.ReadablePartial) localDate26, (long) (short) -1);
        org.joda.time.DurationField durationField30 = buddhistChronology19.eras();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField31 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField17, durationField30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(1, 44, 0, 59, (int) 'a', 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Partial partial5 = partial1.withChronologyRetainFields((org.joda.time.Chronology) copticChronology4);
        try {
            long long13 = copticChronology4.getDateTimeMillis(57982, 57977, 19, 57977, (int) (short) 1, 1, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57977 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(partial5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getShortName((long) 'a', locale5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        java.util.TimeZone timeZone8 = dateTimeZone3.toTimeZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) 2, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 15");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1970, (int) (short) 100, 1970);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(19, 100, (int) (byte) 0, (int) (short) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(28800011L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(59, (int) (short) -1, 15, 57975, 57973, 57973);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57975 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "16");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(4, 10, 57968, 1970, 57973, 57973, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        int int16 = localDate5.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(83188324L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440588.462827824d + "'", double1 == 2440588.462827824d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(11);
        java.lang.Object obj16 = null;
        boolean boolean17 = dateTime11.equals(obj16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(1);
        boolean boolean8 = dateTime5.isBeforeNow();
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology3, (org.joda.time.ReadableDateTime) dateTime5, readableDateTime9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now(dateTimeZone21);
        org.joda.time.Chronology chronology23 = buddhistChronology18.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone21);
        java.lang.String str25 = dateTimeZone21.getID();
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.weekyear();
        try {
            org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((java.lang.Object) buddhistChronology3, (org.joda.time.Chronology) buddhistChronology26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long9 = delegatedDateTimeField7.roundFloor((long) 1);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getName(0L, locale13);
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology18 = localDate17.getChronology();
//        java.lang.String str19 = localDate17.toString();
//        int int20 = localDate17.size();
//        org.joda.time.LocalDate localDate22 = localDate17.withYearOfEra(2019);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology(chronology24);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(chronology25);
//        java.util.TimeZone timeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = dateTimeZone28.getName(0L, locale30);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone28);
//        org.joda.time.LocalDate localDate34 = localDate32.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime35 = null;
//        org.joda.time.DateTime dateTime36 = localDate34.toDateTime(localTime35);
//        boolean boolean37 = localDate26.isAfter((org.joda.time.ReadablePartial) localDate34);
//        int[] intArray38 = localDate26.getValues();
//        try {
//            int[] intArray40 = delegatedDateTimeField7.set((org.joda.time.ReadablePartial) localDate17, 0, intArray38, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2018-11-03" + "'", str19.equals("2018-11-03"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(intArray38);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.Partial partial4 = partial1.withFieldAdded(durationFieldType2, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(83186, 100, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField16 = buddhistChronology15.eras();
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField18 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withWeekOfWeekyear(307);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 307 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate12 = property10.addToCopy(84);
        try {
            org.joda.time.LocalDate localDate14 = localDate12.withYearOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.DateTimeField[] dateTimeFieldArray8 = localDate5.getFields();
        org.joda.time.DateTimeField[] dateTimeFieldArray9 = localDate5.getFields();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        long long10 = dateTimeZone7.adjustOffset((-15593472000000L), true);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-15593472000000L) + "'", long10 == (-15593472000000L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTimeZoneOffset("+00:00", "PST", true, 57975, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
        java.util.Date date12 = localDate11.toDate();
        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
        int int25 = skipUndoDateTimeField24.getMinimumValue();
        try {
            long long28 = skipUndoDateTimeField24.set(570L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [2,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(chronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone8.getName(0L, locale10);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone8);
        java.util.Date date13 = localDate12.toDate();
        int[] intArray15 = buddhistChronology5.get((org.joda.time.ReadablePartial) localDate12, (long) (short) -1);
        org.joda.time.DurationField durationField16 = buddhistChronology5.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, (org.joda.time.DateTimeField) delegatedDateTimeField22);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, (org.joda.time.DateTimeField) skipDateTimeField23, (int) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipDateTimeField23);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = dateTimeZone28.getName(0L, locale30);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone28);
        org.joda.time.LocalDate localDate34 = localDate32.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime35 = null;
        org.joda.time.DateTime dateTime36 = localDate34.toDateTime(localTime35);
        org.joda.time.LocalDate.Property property37 = localDate34.yearOfCentury();
        org.joda.time.LocalDate.Property property38 = localDate34.monthOfYear();
        org.joda.time.LocalDate localDate40 = localDate34.withYearOfEra(10);
        java.util.TimeZone timeZone42 = null;
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forTimeZone(timeZone42);
        java.util.Locale locale45 = null;
        java.lang.String str46 = dateTimeZone43.getName(0L, locale45);
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(dateTimeZone43);
        long long50 = dateTimeZone43.convertLocalToUTC((long) '4', true);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate(1L, dateTimeZone43);
        org.joda.time.Interval interval52 = localDate40.toInterval(dateTimeZone43);
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone43);
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getChronology(chronology55);
        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate(chronology56);
        java.util.TimeZone timeZone58 = null;
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forTimeZone(timeZone58);
        java.util.Locale locale61 = null;
        java.lang.String str62 = dateTimeZone59.getName(0L, locale61);
        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate(dateTimeZone59);
        org.joda.time.LocalDate localDate65 = localDate63.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime66 = null;
        org.joda.time.DateTime dateTime67 = localDate65.toDateTime(localTime66);
        boolean boolean68 = localDate57.isAfter((org.joda.time.ReadablePartial) localDate65);
        int[] intArray69 = localDate57.getValues();
        java.util.Locale locale71 = null;
        try {
            int[] intArray72 = skipDateTimeField23.set((org.joda.time.ReadablePartial) localDate53, (int) (short) 1, intArray69, "Pacific Standard Time", locale71);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+00:00" + "'", str46.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 52L + "'", long50 == 52L);
        org.junit.Assert.assertNotNull(interval52);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "+00:00" + "'", str62.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(intArray69);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        java.lang.String str6 = dateTimeZone1.getID();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        java.lang.Object obj8 = null;
        boolean boolean9 = julianChronology7.equals(obj8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
//        boolean boolean16 = fixedDateTimeZone15.isFixed();
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        org.joda.time.Interval interval18 = localDate7.toInterval((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.lang.String str19 = localDate7.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(interval18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2018-11-03" + "'", str19.equals("2018-11-03"));
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.era();
        int int11 = localDate7.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        try {
            int int4 = partial1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYearOfEra(2018);
        org.joda.time.DateMidnight dateMidnight6 = dateTime3.toDateMidnight();
        try {
            org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology8 = localDate7.getChronology();
//        java.lang.String str9 = localDate7.toString();
//        int int10 = localDate7.size();
//        org.joda.time.LocalDate localDate12 = localDate7.withYearOfEra(2019);
//        org.joda.time.LocalDate.Property property13 = localDate7.era();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2018-11-03" + "'", str9.equals("2018-11-03"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", 44);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("UTC", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes((int) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology5.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTime(chronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(4);
        org.joda.time.DateTime.Property property14 = dateTime11.centuryOfEra();
        try {
            org.joda.time.DateTime dateTime15 = property14.withMinimumValue();
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292268488 for yearOfEra must be in the range [-292268412,292279635]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes((int) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology5.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) ' ');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        boolean boolean17 = localDate5.isSupported(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime27 = null;
        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
        boolean boolean29 = localDate18.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.LocalDate localDate31 = localDate18.plusYears((int) 'a');
        boolean boolean32 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate31);
        java.util.Date date33 = localDate31.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 57982);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57982");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.Instant instant4 = instant1.plus((long) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime5 = instant1.toMutableDateTimeISO();
        boolean boolean6 = instant1.isBeforeNow();
        org.joda.time.Instant instant8 = instant1.plus(28800011L);
        org.joda.time.Instant instant9 = instant1.toInstant();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property12.getAsShortText(locale14);
        int int16 = property12.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Nov" + "'", str15.equals("Nov"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DurationField durationField6 = buddhistChronology2.weekyears();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField8 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        int int10 = dateTime9.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = dateTimeZone23.getName(0L, locale25);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(dateTimeZone23);
        java.util.Date date28 = localDate27.toDate();
        int[] intArray30 = buddhistChronology20.get((org.joda.time.ReadablePartial) localDate27, (long) (short) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate27, (int) 'a', locale32);
        org.joda.time.DateTime dateTime34 = dateTime9.withFields((org.joda.time.ReadablePartial) localDate27);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime9.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property36 = dateTime9.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(property36);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
//        int int15 = dateTime11.getSecondOfDay();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTime11.toString("307", locale17);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 83198 + "'", int15 == 83198);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "307" + "'", str18.equals("307"));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.weekyear();
        java.lang.String str11 = property10.getAsShortText();
        java.util.Locale locale13 = null;
        try {
            org.joda.time.LocalDate localDate14 = property10.setCopy("", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2018" + "'", str11.equals("2018"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        try {
            org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10, 57977);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57977");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        int int10 = dateTime9.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = dateTimeZone23.getName(0L, locale25);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(dateTimeZone23);
        java.util.Date date28 = localDate27.toDate();
        int[] intArray30 = buddhistChronology20.get((org.joda.time.ReadablePartial) localDate27, (long) (short) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate27, (int) 'a', locale32);
        org.joda.time.DateTime dateTime34 = dateTime9.withFields((org.joda.time.ReadablePartial) localDate27);
        org.joda.time.LocalDate localDate36 = localDate27.plusWeeks(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate36);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(83198);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-83198) + "'", int1 == (-83198));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.Partial partial4 = partial1.withPeriodAdded(readablePeriod2, 4);
        try {
            java.lang.String str6 = partial4.toString("(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        java.lang.String str3 = dateTimeZone2.getID();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean16 = fixedDateTimeZone15.isFixed();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.Interval interval18 = localDate7.toInterval((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.Chronology chronology20 = localDate19.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(interval18);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
        org.joda.time.LocalDate localDate22 = localDate20.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime23 = null;
        org.joda.time.DateTime dateTime24 = localDate22.toDateTime(localTime23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.minus(readableDuration28);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
        org.joda.time.Chronology chronology35 = gJChronology30.withZone(dateTimeZone32);
        java.lang.String str36 = dateTimeZone32.getID();
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UTC" + "'", str36.equals("UTC"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        org.joda.time.LocalDate localDate13 = localDate7.withYearOfEra(10);
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
        long long23 = dateTimeZone16.convertLocalToUTC((long) '4', true);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(1L, dateTimeZone16);
        org.joda.time.Interval interval25 = localDate13.toInterval(dateTimeZone16);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertNotNull(interval25);
        org.junit.Assert.assertNotNull(julianChronology26);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Nov");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865809600000L) + "'", long1 == (-210865809600000L));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.Interval interval2 = localDate1.toInterval();
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval2);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(interval2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "org.joda.time.IllegalFieldValueException: 1969365: Value 1 for 1969365 must be in the range [-1.0,1]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(10L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.era();
        java.util.Locale locale12 = null;
        try {
            org.joda.time.LocalDate localDate13 = property10.setCopy("", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getName(0L, locale4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime9 = null;
        org.joda.time.DateTime dateTime10 = localDate8.toDateTime(localTime9);
        org.joda.time.LocalDate.Property property11 = localDate8.yearOfCentury();
        org.joda.time.LocalDate.Property property12 = localDate8.monthOfYear();
        boolean boolean13 = property12.isLeap();
        java.lang.String str14 = property12.toString();
        org.joda.time.LocalDate localDate16 = property12.addToCopy(365);
        org.joda.time.DurationField durationField17 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField17, dateTimeFieldType18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[monthOfYear]" + "'", str14.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder0.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneOffset("1", true, (int) (short) -1, 57973);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        boolean boolean20 = skipDateTimeField19.isLenient();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipDateTimeField19.getAsShortText(3, locale22);
        boolean boolean24 = skipDateTimeField19.isSupported();
        try {
            long long27 = skipDateTimeField19.set((long) 20, 83190);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83190 for minuteOfHour must be in the range [1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "3" + "'", str23.equals("3"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getShortName((long) 'a', locale5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = gregorianChronology0.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.Instant instant8 = new org.joda.time.Instant((long) 1);
        org.joda.time.Instant instant10 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTime();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant8, (org.joda.time.ReadableInstant) mutableDateTime11);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) 'a', 83195, 307, 0, 11, 1386, 83195, chronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1386 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now(dateTimeZone13);
        org.joda.time.Chronology chronology15 = buddhistChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime8.toDateTime(chronology15);
        org.joda.time.DateTime dateTime18 = dateTime16.plusMinutes(4);
        int int19 = dateTime16.getWeekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField21 = gregorianChronology20.hours();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = dateTimeZone23.getShortName((long) 'a', locale25);
        org.joda.time.Chronology chronology27 = gregorianChronology20.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime28 = dateTime16.toDateTime(dateTimeZone23);
        try {
            org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(1386, 0, (int) (short) 100, 83190, 6, dateTimeZone23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83190 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        int int5 = dateTime2.getDayOfWeek();
        int int6 = dateTime2.getDayOfWeek();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial1.minus(readablePeriod4);
        org.joda.time.Chronology chronology6 = partial5.getChronology();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.Partial partial9 = partial5.withField(dateTimeFieldType7, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType6, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(48L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000005555d + "'", double1 == 2440587.5000005555d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology6.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (short) 10, (int) (short) -1, (int) ' ', 3, (int) (short) 1, (org.joda.time.Chronology) iSOChronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        int int10 = localDate7.getWeekyear();
        int int11 = localDate7.getMonthOfYear();
        org.joda.time.LocalDate.Property property12 = localDate7.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2018 + "'", int10 == 2018);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Nov");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException4.prependMessage("1969365");
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException12.prependMessage("1969365");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException20.prependMessage("1969365");
        java.lang.String str23 = illegalFieldValueException20.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        org.joda.time.DurationFieldType durationFieldType25 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNull(durationFieldType25);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey(28800011L);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = fixedDateTimeZone4.getOffset((long) 84);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.DateTime dateTime14 = property11.setCopy("16");
        try {
            org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime14, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.LocalDate localDate30 = localDate27.withPeriodAdded(readablePeriod28, 0);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate30, 57977, locale32);
        long long36 = skipDateTimeField19.add(0L, 9);
        java.util.Locale locale39 = null;
        long long40 = skipDateTimeField19.set(58020L, "1", locale39);
        java.lang.String str41 = skipDateTimeField19.toString();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "57977" + "'", str33.equals("57977"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 540000L + "'", long36 == 540000L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 118020L + "'", long40 == 118020L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str41.equals("DateTimeField[minuteOfHour]"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.clockhourOfHalfday();
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) partial17, (org.joda.time.Chronology) copticChronology18);
        org.joda.time.LocalDate.Property property21 = localDate20.era();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        int int10 = dateTime9.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = dateTimeZone23.getName(0L, locale25);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(dateTimeZone23);
        java.util.Date date28 = localDate27.toDate();
        int[] intArray30 = buddhistChronology20.get((org.joda.time.ReadablePartial) localDate27, (long) (short) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate27, (int) 'a', locale32);
        org.joda.time.DateTime dateTime34 = dateTime9.withFields((org.joda.time.ReadablePartial) localDate27);
        org.joda.time.MutableDateTime mutableDateTime35 = dateTime9.toMutableDateTimeISO();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.era();
        int int38 = gregorianChronology36.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime39 = dateTime9.toMutableDateTime((org.joda.time.Chronology) gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime39);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"[]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        boolean boolean4 = dateTime1.isBeforeNow();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime1.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(yearMonthDay5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(2018, 11, 20, 1, 57975, 8, 44, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57975 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(11);
        org.joda.time.DateTime dateTime17 = dateTime11.minusWeeks(83198);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology13.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now(dateTimeZone16);
        org.joda.time.Chronology chronology18 = buddhistChronology13.withZone(dateTimeZone16);
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime9.toMutableDateTime((org.joda.time.Chronology) buddhistChronology13);
        int int20 = mutableDateTime19.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2561 + "'", int20 == 2561);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 10, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond((int) 'a', (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        int int21 = delegatedDateTimeField18.getMaximumValue(28800052L);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getChronology(chronology22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(chronology23);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology(chronology26);
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(chronology27);
        java.util.TimeZone timeZone29 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forTimeZone(timeZone29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = dateTimeZone30.getName(0L, locale32);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(dateTimeZone30);
        org.joda.time.LocalDate localDate36 = localDate34.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime37 = null;
        org.joda.time.DateTime dateTime38 = localDate36.toDateTime(localTime37);
        boolean boolean39 = localDate28.isAfter((org.joda.time.ReadablePartial) localDate36);
        int[] intArray40 = localDate28.getValues();
        try {
            int[] intArray42 = delegatedDateTimeField18.add((org.joda.time.ReadablePartial) localDate24, 0, intArray40, 57968);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.Chronology chronology9 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = dateTimeZone18.getName(0L, locale20);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone18);
        org.joda.time.LocalDate localDate23 = localDate16.withFields((org.joda.time.ReadablePartial) localDate22);
        boolean boolean25 = localDate23.equals((java.lang.Object) "97");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        long long4 = durationField1.subtract((long) (-1), 59968L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-215884800001L) + "'", long4 == (-215884800001L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        int int5 = dateTime2.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = dateTime2.minusMillis((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime2.getZone();
        int int9 = dateTime2.getSecondOfDay();
        org.joda.time.Instant instant10 = dateTime2.toInstant();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
        org.junit.Assert.assertNotNull(instant10);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        org.joda.time.LocalDate.Property property24 = localDate20.weekyear();
//        org.joda.time.DateTimeField dateTimeField25 = property24.getField();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593472000000L) + "'", long23 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        java.lang.String str6 = dateTimeZone1.getID();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology7.getZone();
        try {
            long long13 = julianChronology7.getDateTimeMillis(0, 11, 57968, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.StringBuffer stringBuffer1 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getName(0L, locale5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone3);
        org.joda.time.LocalDate localDate9 = localDate7.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime10 = null;
        org.joda.time.DateTime dateTime11 = localDate9.toDateTime(localTime10);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long15 = delegatedDateTimeField13.roundCeiling(1L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology19);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTimeZone22.getName(0L, locale24);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(dateTimeZone22);
        java.util.Date date27 = localDate26.toDate();
        int[] intArray29 = buddhistChronology19.get((org.joda.time.ReadablePartial) localDate26, (long) (short) -1);
        org.joda.time.DurationField durationField30 = buddhistChronology19.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology32);
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology32.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34, dateTimeFieldType35);
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology19, (org.joda.time.DateTimeField) delegatedDateTimeField36);
        org.joda.time.ReadablePartial readablePartial38 = null;
        int[] intArray45 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
        int int46 = delegatedDateTimeField36.getMinimumValue(readablePartial38, intArray45);
        int[] intArray48 = delegatedDateTimeField13.add(readablePartial16, (int) '#', intArray45, 0);
        try {
            int[] intArray50 = offsetDateTimeField5.addWrapField(readablePartial6, 1, intArray48, 2561);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 60000L + "'", long15 == 60000L);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.clockhourOfHalfday();
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) partial17, (org.joda.time.Chronology) copticChronology18);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType22 = localDate20.getFieldType(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", 44);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Coordinated Universal Time", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.lang.String str21 = skipDateTimeField19.getAsShortText((long) (byte) 1);
        long long23 = skipDateTimeField19.roundFloor((long) 20);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException4.prependMessage("1969365");
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException12.prependMessage("1969365");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        java.lang.String str16 = illegalFieldValueException12.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        org.joda.time.DurationFieldType durationFieldType22 = illegalFieldValueException21.getDurationFieldType();
        illegalFieldValueException21.prependMessage("1970W013T160000-0800");
        illegalFieldValueException12.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.joda.time.IllegalFieldValueException: 1969365: Value 1 for 1969365 must be in the range [-1.0,1]" + "'", str16.equals("org.joda.time.IllegalFieldValueException: 1969365: Value 1 for 1969365 must be in the range [-1.0,1]"));
        org.junit.Assert.assertNull(durationFieldType22);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        org.joda.time.LocalDate.Property property24 = localDate20.weekyear();
//        org.joda.time.LocalTime localTime25 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        org.joda.time.DateTime dateTime28 = localDate20.toDateTime(localTime25, dateTimeZone27);
//        int int29 = dateTime28.getEra();
//        java.util.GregorianCalendar gregorianCalendar30 = dateTime28.toGregorianCalendar();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
//        try {
//            org.joda.time.DateTime.Property property32 = dateTime28.property(dateTimeFieldType31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593472000000L) + "'", long23 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(gregorianCalendar30);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("2512365");
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int10 = offsetDateTimeField5.getDifference((long) (-1), (long) 83196);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
        boolean boolean16 = dateTime14.isAfter((long) 57973);
        try {
            org.joda.time.DateTime dateTime18 = dateTime14.withWeekOfWeekyear(2561);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2561 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        boolean boolean3 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTime dateTime4 = localDate2.toDateTimeAtCurrentTime();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeField[] dateTimeFieldArray2 = partial1.getFields();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = partial1.isSupported(dateTimeFieldType3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = partial1.toString("1", locale6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int8 = offsetDateTimeField5.getMinimumValue();
        java.lang.String str10 = offsetDateTimeField5.getAsText((-155933860220L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "83200" + "'", str10.equals("83200"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        int int10 = dateTime9.getMonthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = dateTimeZone23.getName(0L, locale25);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(dateTimeZone23);
        java.util.Date date28 = localDate27.toDate();
        int[] intArray30 = buddhistChronology20.get((org.joda.time.ReadablePartial) localDate27, (long) (short) -1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate27, (int) 'a', locale32);
        org.joda.time.DateTime dateTime34 = dateTime9.withFields((org.joda.time.ReadablePartial) localDate27);
        boolean boolean36 = dateTime34.isEqual((long) 18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
        try {
            org.joda.time.LocalDate localDate3 = localDate1.withEra(9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(localDate1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-155933860220L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-9223372036854775808L) + "'", long1 == (-9223372036854775808L));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("16", "97");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.era();
        org.joda.time.LocalDate localDate11 = property10.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        int int6 = localDate5.size();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.Instant instant4 = instant1.plus((long) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime5 = instant1.toMutableDateTimeISO();
        org.joda.time.Instant instant7 = instant1.withMillis((-15593386022000L));
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        org.joda.time.LocalDate localDate16 = property11.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("1970W013T160000-0800");
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(durationFieldType8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
        int int9 = delegatedDateTimeField7.getMaximumValue(58020L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology2.withZone(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0L, dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(iSOChronology8);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withDayOfMonth((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime28 = null;
        org.joda.time.DateTime dateTime29 = localDate27.toDateTime(localTime28);
        org.joda.time.LocalDate.Property property30 = localDate27.yearOfCentury();
        org.joda.time.LocalDate.Property property31 = localDate27.monthOfYear();
        org.joda.time.LocalDate localDate33 = localDate27.withYearOfEra(10);
        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) '4');
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate33, (int) '4', locale37);
        long long40 = skipDateTimeField19.remainder((long) 57977);
        java.util.Locale locale42 = null;
        java.lang.String str43 = skipDateTimeField19.getAsShortText(10, locale42);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "52" + "'", str38.equals("52"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 57977L + "'", long40 == 57977L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10" + "'", str43.equals("10"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("307");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"307\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType7, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(chronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone8.getName(0L, locale10);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone8);
        java.util.Date date13 = localDate12.toDate();
        int[] intArray15 = buddhistChronology5.get((org.joda.time.ReadablePartial) localDate12, (long) (short) -1);
        org.joda.time.DurationField durationField16 = buddhistChronology5.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, (org.joda.time.DateTimeField) delegatedDateTimeField22);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, (org.joda.time.DateTimeField) skipDateTimeField23, (int) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipDateTimeField23);
        long long29 = skipDateTimeField23.add((long) 100, (int) ' ');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1920100L + "'", long29 == 1920100L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.DateTime dateTime12 = localDate10.toDateTime(localTime11);
        int int13 = localDate10.getWeekyear();
        int int14 = localDate10.getMonthOfYear();
        boolean boolean15 = gregorianChronology0.equals((java.lang.Object) localDate10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2018 + "'", int13 == 2018);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 11 + "'", int14 == 11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.DateTime dateTime12 = localDate10.toDateTime(localTime11);
        boolean boolean13 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate10);
        int[] intArray14 = localDate2.getValues();
        org.joda.time.LocalDate localDate16 = localDate2.minusDays(4);
        org.joda.time.LocalDate localDate18 = localDate2.minusYears(11);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (short) 1, 83204);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds((int) (byte) 0);
        org.joda.time.LocalTime localTime5 = dateTime2.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = localTime5.isSupported(dateTimeFieldType6);
        try {
            org.joda.time.DateTime dateTime8 = localDate0.toDateTime(localTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The chronology of the time does not match");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral('#');
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType4, 12, 83190);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(11);
//        org.joda.time.DateTime.Property property16 = dateTime15.secondOfMinute();
//        org.joda.time.DateTime dateTime18 = property16.addWrapFieldToCopy((int) (short) 1);
//        long long19 = property16.remainder();
//        org.joda.time.DateTime dateTime20 = property16.getDateTime();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 902L + "'", long19 == 902L);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology(chronology15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(chronology16);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = dateTimeZone19.getName(0L, locale21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.LocalDate localDate25 = localDate23.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime26 = null;
        org.joda.time.DateTime dateTime27 = localDate25.toDateTime(localTime26);
        boolean boolean28 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate25);
        org.joda.time.DateTime dateTime29 = dateTime14.withFields((org.joda.time.ReadablePartial) localDate25);
        try {
            org.joda.time.LocalDate localDate31 = localDate25.withEra((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(11);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.DateTime dateTime18 = dateTime11.withField(dateTimeFieldType16, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekyear();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.secondOfDay();
        org.joda.time.DurationField durationField18 = buddhistChronology15.hours();
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2);
        long long7 = dateTimeZone0.getMillisKeepLocal(dateTimeZone2, 52L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(chronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone8.getName(0L, locale10);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone8);
        java.util.Date date13 = localDate12.toDate();
        int[] intArray15 = buddhistChronology5.get((org.joda.time.ReadablePartial) localDate12, (long) (short) -1);
        org.joda.time.DurationField durationField16 = buddhistChronology5.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, (org.joda.time.DateTimeField) delegatedDateTimeField22);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, (org.joda.time.DateTimeField) skipDateTimeField23, (int) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipDateTimeField23);
        try {
            long long29 = skipDateTimeField26.set((long) (-83198), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfHour must be in the range [1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("2018", 83186, 0, 2018, 'a', (int) (byte) 0, 18, 83219, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        int int10 = localDate7.getEra();
        org.joda.time.LocalDate.Property property11 = localDate7.weekOfWeekyear();
        try {
            org.joda.time.Instant instant12 = new org.joda.time.Instant((java.lang.Object) property11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundCeiling(1L);
        java.lang.String str9 = delegatedDateTimeField5.getAsText(0L);
        java.lang.String str10 = delegatedDateTimeField5.toString();
        java.util.Locale locale11 = null;
        int int12 = delegatedDateTimeField5.getMaximumShortTextLength(locale11);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str10.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField5, 307, 11, 57968);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getName(0L, locale13);
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray18 = localDate15.getFields();
//        int int19 = localDate15.getDayOfMonth();
//        int int20 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate15);
//        int int22 = delegatedDateTimeField5.getLeapAmount((long) (short) 1);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes((int) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology5.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime3.toDateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        org.joda.time.DateTime dateTime16 = dateTime11.withDate(86399, (int) (byte) 10, 19);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
        java.util.Date date12 = localDate11.toDate();
        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
        int int25 = skipUndoDateTimeField24.getMinimumValue();
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField24.getAsShortText(57977, locale27);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "57977" + "'", str28.equals("57977"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        boolean boolean20 = skipDateTimeField19.isLenient();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-2812));
        int int23 = skipDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        java.util.Date date24 = localDate22.toDate();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate12 = property10.addToCopy(84);
        try {
            org.joda.time.LocalDate localDate14 = localDate12.withMonthOfYear((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int8 = offsetDateTimeField5.getMinimumValue();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate19 = localDate16.withPeriodAdded(readablePeriod17, 0);
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate19, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'clockhourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate19);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(2018);
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears((int) (short) 100);
        org.joda.time.LocalTime localTime7 = dateTime4.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            int int9 = dateTime4.get(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getShortName((long) 'a', locale5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        java.util.TimeZone timeZone8 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L);
        int int11 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone3);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond(2018);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2018 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("Nov");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Nov\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
        int int17 = property11.get();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 11 + "'", int17 == 11);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        boolean boolean20 = skipDateTimeField19.isLenient();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipDateTimeField19.getAsShortText(3, locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType24, 2018, 59, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "3" + "'", str23.equals("3"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes((int) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology6.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime4.toDateTime(chronology11);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime12.plusDays(59);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str6 = dateTimeFormatter4.print((long) 10);
        java.lang.String str8 = dateTimeFormatter4.print(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology10);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone13.getName(0L, locale15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone13);
        java.util.Date date18 = localDate17.toDate();
        int[] intArray20 = buddhistChronology10.get((org.joda.time.ReadablePartial) localDate17, (long) (short) -1);
        org.joda.time.DurationField durationField21 = buddhistChronology10.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        dateTimeFormatterBuilder23.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001" + "'", str6.equals("1970001"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001" + "'", str8.equals("1970001"));
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundCeiling(1L);
        long long9 = delegatedDateTimeField5.roundHalfFloor(0L);
        try {
            long long12 = delegatedDateTimeField5.set((long) (-83198), "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 9, "2018");
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException4.prependMessage("1969365");
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException12.prependMessage("1969365");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        boolean boolean16 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException12);
        illegalFieldValueException12.prependMessage("");
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
//        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime27 = null;
//        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
//        boolean boolean29 = localDate18.isAfter((org.joda.time.ReadablePartial) localDate26);
//        org.joda.time.LocalDate localDate31 = localDate18.plusYears((int) 'a');
//        boolean boolean32 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.LocalDate.Property property33 = localDate5.yearOfEra();
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.LocalDate localDate35 = localDate5.minus(readablePeriod34);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology37);
//        java.util.TimeZone timeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dateTimeZone40.getName(0L, locale42);
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone40);
//        java.util.Date date45 = localDate44.toDate();
//        int[] intArray47 = buddhistChronology37.get((org.joda.time.ReadablePartial) localDate44, (long) (short) -1);
//        org.joda.time.DurationField durationField48 = buddhistChronology37.eras();
//        java.util.TimeZone timeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forTimeZone(timeZone49);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = dateTimeZone50.getName(0L, locale52);
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate(dateTimeZone50);
//        org.joda.time.LocalDate localDate56 = localDate54.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology57 = localDate56.getChronology();
//        long long59 = buddhistChronology37.set((org.joda.time.ReadablePartial) localDate56, 0L);
//        org.joda.time.Interval interval60 = localDate56.toInterval();
//        boolean boolean61 = localDate35.equals((java.lang.Object) interval60);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(buddhistChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+00:00" + "'", str43.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "+00:00" + "'", str53.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-15593472000000L) + "'", long59 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(interval60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate12 = property10.addToCopy(84);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.dayOfMonth();
        org.joda.time.Partial partial15 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = partial15.getFormatter();
        try {
            int int17 = property10.compareTo((org.joda.time.ReadablePartial) partial15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNull(dateTimeFormatter16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str7 = dateTimeFormatter5.print((long) 10);
        java.lang.String str9 = dateTimeFormatter5.print(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology11);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
        java.util.Date date19 = localDate18.toDate();
        int[] intArray21 = buddhistChronology11.get((org.joda.time.ReadablePartial) localDate18, (long) (short) -1);
        org.joda.time.DurationField durationField22 = buddhistChronology11.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder4.append(dateTimeFormatter5);
        try {
            org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.parse("3", dateTimeFormatter5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"3\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970001" + "'", str7.equals("1970001"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970001" + "'", str9.equals("1970001"));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone3);
        boolean boolean5 = dateTimeFormatter0.isParser();
        java.io.Writer writer6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        try {
            dateTimeFormatter0.printTo(writer6, readableInstant7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001" + "'", str2.equals("1970001"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) (byte) 100, 0, 365, 83198, 86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean16 = fixedDateTimeZone15.isFixed();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.Interval interval18 = localDate7.toInterval((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        long long20 = fixedDateTimeZone15.previousTransition((long) 83195);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(interval18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 83195L + "'", long20 == 83195L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str1 = dateTimeZone0.getID();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYear(0, 18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendFractionOfDay(0, 307);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatterBuilder15.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendWeekOfWeekyear((int) 'a');
        boolean boolean23 = dateTimeFormatterBuilder20.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter30 = dateTimeFormatterBuilder29.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatterBuilder31.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatterBuilder31.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder20.append(dateTimePrinter30, dateTimeParser36);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatterBuilder45.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser50 = dateTimeFormatterBuilder45.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder44.append(dateTimeParser50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder52.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder55.appendWeekOfWeekyear((int) 'a');
        boolean boolean58 = dateTimeFormatterBuilder55.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder59.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter65 = dateTimeFormatterBuilder64.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder66.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatterBuilder66.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser71 = dateTimeFormatterBuilder66.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder55.append(dateTimePrinter65, dateTimeParser71);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray73 = new org.joda.time.format.DateTimeParser[] { dateTimeParser36, dateTimeParser39, dateTimeParser50, dateTimeParser71 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder9.append(dateTimePrinter16, dateTimeParserArray73);
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder9.appendDecimal(dateTimeFieldType75, 57973, 83198);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimePrinter30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeParser50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimePrinter65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(dateTimeParser71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
        org.junit.Assert.assertNotNull(dateTimeParserArray73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("83200");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"83200\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        boolean boolean1 = dateTimeFormatter0.isParser();
        try {
            java.lang.String str3 = dateTimeFormatter0.print((long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 57973, (-11L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-637703L) + "'", long2 == (-637703L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.hours();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getShortName((long) 'a', locale12);
        org.joda.time.Chronology chronology14 = gregorianChronology7.withZone(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(83190, 44, 59, 84, (int) (short) -1, 83219, (int) (short) 0, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
        org.joda.time.LocalDate localDate22 = localDate20.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime23 = null;
        org.joda.time.DateTime dateTime24 = localDate22.toDateTime(localTime23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.minus(readableDuration28);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
        org.joda.time.Chronology chronology35 = gJChronology30.withZone(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField36 = gJChronology30.weekyearOfCentury();
        try {
            long long41 = gJChronology30.getDateTimeMillis(100, 57977, (-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57977 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-2812));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property12.getAsShortText(locale14);
        org.joda.time.DateTime dateTime16 = property12.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Nov" + "'", str15.equals("Nov"));
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        org.joda.time.DateTime.Property property5 = dateTime2.monthOfYear();
        int int6 = property5.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        org.joda.time.LocalDate.Property property24 = localDate20.weekyear();
//        org.joda.time.LocalDate localDate25 = property24.withMinimumValue();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593472000000L) + "'", long23 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDate25);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime11.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.DateTime dateTime4 = property1.addToCopy((long) 11);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-155933860220L), (long) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        try {
            long long22 = skipDateTimeField19.getDifferenceAsLong((-9223372036854775808L), (long) 83190);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The minuend instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[AD])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.minuteOfHour();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) 0, chronology5);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime8 = dateTime6.plusSeconds(0);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        java.util.Locale locale10 = null;
        int int11 = property9.getMaximumTextLength(locale10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean16 = fixedDateTimeZone15.isFixed();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.Interval interval18 = localDate7.toInterval((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime28 = null;
        org.joda.time.DateTime dateTime29 = localDate27.toDateTime(localTime28);
        org.joda.time.LocalDate.Property property30 = localDate27.yearOfCentury();
        org.joda.time.LocalDate.Property property31 = localDate27.monthOfYear();
        org.joda.time.LocalDate localDate33 = localDate27.withYearOfEra(10);
        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) '4');
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray36 = localDate35.getFieldTypes();
        org.joda.time.LocalDate localDate38 = localDate35.withWeekyear((int) ' ');
        org.joda.time.DurationFieldType durationFieldType39 = null;
        boolean boolean40 = localDate35.isSupported(durationFieldType39);
        org.joda.time.LocalDate localDate42 = localDate35.withCenturyOfEra(19);
        org.joda.time.LocalDate localDate43 = localDate19.withFields((org.joda.time.ReadablePartial) localDate35);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(interval18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(localDate43);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 2018);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970W013T160000-0800");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str6 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(permissionCollection4);
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970W013T160000-0800" + "'", str6.equals("1970W013T160000-0800"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("ISOChronology[AD]", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        boolean boolean3 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalDate.Property property4 = localDate2.era();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.Instant instant4 = instant1.plus((long) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime5 = instant1.toMutableDateTime();
        org.joda.time.Instant instant8 = instant1.withDurationAdded((long) 3, 83204);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("16");
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        int int6 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        org.joda.time.LocalDate localDate13 = localDate7.withYearOfEra(10);
        try {
            org.joda.time.DateTimeField dateTimeField15 = localDate13.getField(86399);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 86399");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3, 3);
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = zonedChronology7.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("52", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getShortName((long) 'a', locale5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.hourOfHalfday();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        try {
            long long17 = gregorianChronology0.getDateTimeMillis(1970, 307, 2561, 2018, 44, (int) (byte) 0, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2018 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        long long21 = delegatedDateTimeField18.roundHalfFloor((long) (byte) 100);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField18.getWrappedField();
        java.util.TimeZone timeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone24.getName(0L, locale26);
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone24);
        org.joda.time.LocalDate localDate30 = localDate28.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime31 = null;
        org.joda.time.DateTime dateTime32 = localDate30.toDateTime(localTime31);
        org.joda.time.LocalDate.Property property33 = localDate30.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = localDate30.getFieldType(0);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField18, dateTimeFieldType35, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime27 = null;
        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
        boolean boolean29 = localDate18.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.LocalDate localDate31 = localDate18.plusYears((int) 'a');
        boolean boolean32 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.LocalDate.Property property33 = localDate5.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate5.minus(readablePeriod34);
        org.joda.time.LocalDate.Property property36 = localDate35.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(property36);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        org.joda.time.DurationField durationField16 = property11.getDurationField();
        long long19 = durationField16.subtract(0L, 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-26438400000L) + "'", long19 == (-26438400000L));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology13);
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
        java.util.Date date21 = localDate20.toDate();
        int[] intArray23 = buddhistChronology13.get((org.joda.time.ReadablePartial) localDate20, (long) (short) -1);
        org.joda.time.DurationField durationField24 = buddhistChronology13.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology26);
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology26.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType29);
        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField30);
        java.util.TimeZone timeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
        java.util.Locale locale35 = null;
        java.lang.String str36 = dateTimeZone33.getName(0L, locale35);
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone33);
        org.joda.time.LocalDate localDate39 = localDate37.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.LocalDate localDate42 = localDate39.withPeriodAdded(readablePeriod40, 0);
        java.util.Locale locale44 = null;
        java.lang.String str45 = skipDateTimeField31.getAsText((org.joda.time.ReadablePartial) localDate42, 57977, locale44);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((java.lang.Object) str45, dateTimeZone46);
        org.joda.time.DateTime.Property property48 = dateTime47.millisOfDay();
        org.joda.time.DateTime.Property property49 = dateTime47.era();
        int int50 = property11.getDifference((org.joda.time.ReadableInstant) dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+00:00" + "'", str36.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "57977" + "'", str45.equals("57977"));
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-671497) + "'", int50 == (-671497));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = localDate7.isSupported(dateTimeFieldType12);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        java.lang.String str20 = fixedDateTimeZone18.getNameKey(28800011L);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        int int23 = fixedDateTimeZone18.getOffset((long) 84);
        int int25 = fixedDateTimeZone18.getOffset(0L);
        org.joda.time.DateTime dateTime26 = localDate7.toDateTimeAtMidnight((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        java.util.TimeZone timeZone27 = fixedDateTimeZone18.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField5 = buddhistChronology1.months();
        org.joda.time.DurationField durationField6 = buddhistChronology1.millis();
        org.joda.time.DurationField durationField7 = buddhistChronology1.minutes();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970W013T160000-0800");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970W013T160000-0800" + "'", str3.equals("1970W013T160000-0800"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        boolean boolean20 = skipDateTimeField19.isLenient();
        int int22 = skipDateTimeField19.get(0L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            long long14 = gJChronology9.getDateTimeMillis(0, 9, 59, 1386);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology9);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = dateTimeZone12.getName(0L, locale14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone12);
        java.util.Date date17 = localDate16.toDate();
        int[] intArray19 = buddhistChronology9.get((org.joda.time.ReadablePartial) localDate16, (long) (short) -1);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDate16, (int) 'a', locale21);
        org.joda.time.DateTime dateTime23 = localDate16.toDateTimeAtMidnight();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Partial partial25 = new org.joda.time.Partial(chronology24);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray26 = partial25.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone27, 3);
        int int30 = copticChronology29.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology31 = copticChronology29.withUTC();
        int int32 = copticChronology29.getMinimumDaysInFirstWeek();
        org.joda.time.Partial partial33 = partial25.withChronologyRetainFields((org.joda.time.Chronology) copticChronology29);
        try {
            boolean boolean34 = localDate16.isEqual((org.joda.time.ReadablePartial) partial33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "97" + "'", str22.equals("97"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertNotNull(partial33);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.dayOfYear();
//        org.joda.time.LocalDate localDate12 = property11.withMinimumValue();
//        java.lang.String str13 = property11.getAsShortText();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.Partial partial15 = new org.joda.time.Partial(chronology14);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = partial15.getFieldTypes();
//        try {
//            int int17 = property11.compareTo((org.joda.time.ReadablePartial) partial15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "307" + "'", str13.equals("307"));
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 3600000L, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear(1386);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001" + "'", str2.equals("1970001"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getName(0L, locale5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone3);
        long long9 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (long) 3);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone2.getName(0L, locale4);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone2);
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime9 = null;
//        org.joda.time.DateTime dateTime10 = localDate8.toDateTime(localTime9);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property13 = dateTime12.monthOfYear();
//        org.joda.time.DateTime dateTime15 = property13.addToCopy(0);
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
//        java.lang.Appendable appendable19 = null;
//        try {
//            dateTimeFormatter18.printTo(appendable19, (-1L));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "23" + "'", str16.equals("23"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.String str2 = dateTimeFormatter0.print(1L);
        int int3 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00:00:00" + "'", str2.equals("00:00:00"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 83206);
        org.joda.time.DateTime dateTime4 = dateTime1.withDurationAdded((long) (short) 10, 57982);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        org.joda.time.LocalDate localDate16 = property11.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendWeekOfWeekyear((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
        org.joda.time.LocalDate localDate22 = localDate20.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime23 = null;
        org.joda.time.DateTime dateTime24 = localDate22.toDateTime(localTime23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.minus(readableDuration28);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
        org.joda.time.Chronology chronology35 = gJChronology30.withZone(dateTimeZone32);
        org.joda.time.Instant instant36 = gJChronology30.getGregorianCutover();
        org.joda.time.Instant instant38 = instant36.plus(100L);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(instant36);
        org.junit.Assert.assertNotNull(instant38);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray27 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
        int int28 = delegatedDateTimeField18.getMinimumValue(readablePartial20, intArray27);
        long long30 = delegatedDateTimeField18.roundHalfCeiling((long) 11);
        boolean boolean31 = delegatedDateTimeField18.isSupported();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.LocalDate localDate30 = localDate27.withPeriodAdded(readablePeriod28, 0);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate30, 57977, locale32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.era();
//        int int36 = gregorianChronology34.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 83195);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField39.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType40);
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone44);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone44);
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44, readableInstant47);
//        java.util.TimeZone timeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forTimeZone(timeZone49);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = dateTimeZone50.getName(0L, locale52);
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate(dateTimeZone50);
//        org.joda.time.LocalDate localDate56 = localDate54.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime57 = null;
//        org.joda.time.DateTime dateTime58 = localDate56.toDateTime(localTime57);
//        org.joda.time.DateTime dateTime60 = dateTime58.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property61 = dateTime60.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration62 = null;
//        org.joda.time.DateTime dateTime63 = dateTime60.minus(readableDuration62);
//        int int64 = dateTime60.getSecondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod65 = null;
//        org.joda.time.DateTime dateTime66 = dateTime60.plus(readablePeriod65);
//        boolean boolean67 = gJChronology48.equals((java.lang.Object) dateTime60);
//        try {
//            org.joda.time.Partial partial68 = new org.joda.time.Partial(dateTimeFieldType40, (-2812), (org.joda.time.Chronology) gJChronology48);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2812 for clockhourOfDay must not be smaller than 1");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "57977" + "'", str33.equals("57977"));
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "+00:00" + "'", str53.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 83218 + "'", int64 == 83218);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime15 = dateTime11.plusMinutes(134);
        try {
            org.joda.time.DateTime dateTime17 = dateTime11.withHourOfDay(1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
        java.util.Date date12 = localDate11.toDate();
        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
        int int26 = skipUndoDateTimeField24.get((long) 11);
        int int28 = skipUndoDateTimeField24.getLeapAmount((long) (short) 10);
        java.util.TimeZone timeZone29 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forTimeZone(timeZone29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = dateTimeZone30.getName(0L, locale32);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(dateTimeZone30);
        org.joda.time.LocalDate localDate36 = localDate34.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.LocalDate localDate39 = localDate36.withPeriodAdded(readablePeriod37, 0);
        int int40 = localDate39.getWeekyear();
        java.util.Date date41 = localDate39.toDate();
        org.joda.time.LocalDate localDate42 = org.joda.time.LocalDate.fromDateFields(date41);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.Partial partial45 = new org.joda.time.Partial(chronology44);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.Partial partial48 = partial45.withPeriodAdded(readablePeriod46, 4);
        int[] intArray49 = partial45.getValues();
        try {
            int[] intArray51 = skipUndoDateTimeField24.addWrapField((org.joda.time.ReadablePartial) localDate42, (int) '#', intArray49, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2018 + "'", int40 == 2018);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(partial48);
        org.junit.Assert.assertNotNull(intArray49);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfMonth();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField3, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[AD]" + "'", str2.equals("BuddhistChronology[AD]"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        int int21 = delegatedDateTimeField18.getLeapAmount((long) 57968);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 1386);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        int int5 = dateTimeFormatter4.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(2018);
        org.joda.time.DateTime dateTime6 = dateTime2.plusDays(2561);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime27 = null;
        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
        boolean boolean29 = localDate18.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.LocalDate localDate31 = localDate18.plusYears((int) 'a');
        boolean boolean32 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.LocalDate.Property property33 = localDate5.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.LocalDate localDate35 = localDate5.minus(readablePeriod34);
        org.joda.time.LocalDate localDate37 = localDate35.plusDays(2019);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(localDate37);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
        int int5 = property4.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getName(0L, locale4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 100, dateTimeZone2);
        org.joda.time.DateTime dateTime8 = dateTime6.minus((long) 57968);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        int int5 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.hourOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology2);
        int[] intArray12 = partial11.getValues();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType14 = partial11.getFieldType(11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 1439);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
        org.joda.time.Chronology chronology21 = localDate20.getChronology();
        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
        org.joda.time.LocalDate.Property property24 = localDate20.weekyear();
        org.joda.time.LocalTime localTime25 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime28 = localDate20.toDateTime(localTime25, dateTimeZone27);
        int int29 = dateTime28.getEra();
        java.util.GregorianCalendar gregorianCalendar30 = dateTime28.toGregorianCalendar();
        org.joda.time.DateTime.Property property31 = dateTime28.dayOfWeek();
        org.joda.time.DateTime dateTime33 = property31.addToCopy((long) 84);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-17154028800000L) + "'", long23 == (-17154028800000L));
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(gregorianCalendar30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology8.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone11);
        org.joda.time.Chronology chronology13 = buddhistChronology8.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone11);
        java.lang.String str15 = dateTimeZone11.getID();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.weekyear();
        org.joda.time.DurationField durationField18 = buddhistChronology16.days();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendEraText();
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology22);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName(0L, locale27);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone25);
        java.util.Date date30 = localDate29.toDate();
        int[] intArray32 = buddhistChronology22.get((org.joda.time.ReadablePartial) localDate29, (long) (short) -1);
        org.joda.time.DurationField durationField33 = buddhistChronology22.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology35);
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology35.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37, dateTimeFieldType38);
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology22, (org.joda.time.DateTimeField) delegatedDateTimeField39);
        java.util.TimeZone timeZone41 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
        java.util.Locale locale44 = null;
        java.lang.String str45 = dateTimeZone42.getName(0L, locale44);
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate(dateTimeZone42);
        org.joda.time.LocalDate localDate48 = localDate46.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.LocalDate localDate51 = localDate48.withPeriodAdded(readablePeriod49, 0);
        java.util.Locale locale53 = null;
        java.lang.String str54 = skipDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate51, 57977, locale53);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.era();
        int int57 = gregorianChronology55.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology55.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, 83195);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField60.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField40, dateTimeFieldType61);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType61);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField18, dateTimeFieldType61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "+00:00" + "'", str45.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "57977" + "'", str54.equals("57977"));
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "3");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int9 = offsetDateTimeField5.getMaximumValue((long) (short) 1);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField5.getWrappedField();
        java.util.Locale locale13 = null;
        try {
            long long14 = offsetDateTimeField5.set((long) 44, "10", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for clockhourOfDay must be in the range [83196,83219]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 83219 + "'", int9 == 83219);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str6 = dateTimeFormatter4.print((long) 10);
        java.lang.String str8 = dateTimeFormatter4.print(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology10);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone13.getName(0L, locale15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone13);
        java.util.Date date18 = localDate17.toDate();
        int[] intArray20 = buddhistChronology10.get((org.joda.time.ReadablePartial) localDate17, (long) (short) -1);
        org.joda.time.DurationField durationField21 = buddhistChronology10.eras();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        dateTimeFormatterBuilder23.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendSecondOfDay(134);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001" + "'", str6.equals("1970001"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001" + "'", str8.equals("1970001"));
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 1 + "'", number6.equals((short) 1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate.Property property3 = localDate2.dayOfMonth();
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 3, 100);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray7 = localDate6.getFieldTypes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3L + "'", long5 == 3L);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray7);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra(57977);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType5 = localDate3.getFieldType(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime28 = null;
        org.joda.time.DateTime dateTime29 = localDate27.toDateTime(localTime28);
        org.joda.time.LocalDate.Property property30 = localDate27.yearOfCentury();
        org.joda.time.LocalDate.Property property31 = localDate27.monthOfYear();
        org.joda.time.LocalDate localDate33 = localDate27.withYearOfEra(10);
        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) '4');
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate33, (int) '4', locale37);
        int int40 = skipDateTimeField19.getLeapAmount((long) 6);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "52" + "'", str38.equals("52"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }
}

