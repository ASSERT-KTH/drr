import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalDate.Property property8 = localDate5.dayOfMonth();
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime17 = null;
//        org.joda.time.DateTime dateTime18 = localDate16.toDateTime(localTime17);
//        org.joda.time.LocalDate.Property property19 = localDate16.weekyear();
//        org.joda.time.LocalDate localDate21 = property19.addWrapFieldToCopy((int) '#');
//        org.joda.time.LocalDate localDate22 = property19.roundHalfFloorCopy();
//        int int23 = property8.compareTo((org.joda.time.ReadablePartial) localDate22);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.weekyear();
//        org.joda.time.LocalDate localDate12 = property10.addWrapFieldToCopy((int) '#');
//        org.joda.time.LocalDate localDate13 = property10.roundHalfFloorCopy();
//        org.joda.time.LocalDate localDate14 = property10.withMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate14);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.era();
//        int int10 = gregorianChronology8.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 83195);
//        long long15 = offsetDateTimeField13.roundHalfCeiling((long) '#');
//        int int16 = offsetDateTimeField13.getMinimumValue();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone18.getName(0L, locale20);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone18);
//        org.joda.time.LocalDate localDate24 = localDate22.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray25 = localDate22.getFields();
//        int[] intArray26 = null;
//        int int27 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate22, intArray26);
//        java.util.Locale locale28 = null;
//        try {
//            java.lang.String str29 = delegatedDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDate22, locale28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 83196 + "'", int16 == 83196);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 83219 + "'", int27 == 83219);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYear(0, 18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendFractionOfDay(0, 307);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendMonthOfYear(57977);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusDays(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str6 = dateTimeFormatter4.print((long) 10);
//        java.lang.String str8 = dateTimeFormatter4.print(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology10);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName(0L, locale15);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone13);
//        java.util.Date date18 = localDate17.toDate();
//        int[] intArray20 = buddhistChronology10.get((org.joda.time.ReadablePartial) localDate17, (long) (short) -1);
//        org.joda.time.DurationField durationField21 = buddhistChronology10.eras();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) buddhistChronology10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder3.append(dateTimeFormatter24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder3.appendFractionOfDay(1386, 83196);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001" + "'", str6.equals("1970001"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001" + "'", str8.equals("1970001"));
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        int int11 = localDate10.getWeekyear();
//        org.joda.time.DurationFieldType durationFieldType12 = null;
//        boolean boolean13 = localDate10.isSupported(durationFieldType12);
//        int int14 = localDate10.getDayOfMonth();
//        int int15 = localDate10.getEra();
//        org.joda.time.LocalDate localDate17 = localDate10.withEra(0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 22 + "'", int14 == 22);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(localDate17);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate13 = localDate11.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime14 = null;
//        org.joda.time.DateTime dateTime15 = localDate13.toDateTime(localTime14);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property18 = dateTime17.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.minus(readableDuration19);
//        int int21 = dateTime17.getSecondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime17.plus(readablePeriod22);
//        boolean boolean24 = gJChronology5.equals((java.lang.Object) dateTime17);
//        java.lang.String str25 = gJChronology5.toString();
//        try {
//            long long33 = gJChronology5.getDateTimeMillis(2018, 0, 100, (int) ' ', (int) (byte) 0, 83204, 2019);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GJChronology[UTC]" + "'", str25.equals("GJChronology[UTC]"));
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str6 = dateTimeFormatter4.print((long) 10);
//        java.lang.String str8 = dateTimeFormatter4.print(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology10);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName(0L, locale15);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone13);
//        java.util.Date date18 = localDate17.toDate();
//        int[] intArray20 = buddhistChronology10.get((org.joda.time.ReadablePartial) localDate17, (long) (short) -1);
//        org.joda.time.DurationField durationField21 = buddhistChronology10.eras();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) buddhistChronology10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder3.append(dateTimeFormatter24);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap26 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendTwoDigitWeekyear(5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001" + "'", str6.equals("1970001"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001" + "'", str8.equals("1970001"));
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        int int5 = dateTime2.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = dateTime2.minusMillis((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        int int10 = dateTime9.getMonthOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology12);
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType17);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology20);
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone23.getName(0L, locale25);
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(dateTimeZone23);
//        java.util.Date date28 = localDate27.toDate();
//        int[] intArray30 = buddhistChronology20.get((org.joda.time.ReadablePartial) localDate27, (long) (short) -1);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = delegatedDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate27, (int) 'a', locale32);
//        org.joda.time.DateTime dateTime34 = dateTime9.withFields((org.joda.time.ReadablePartial) localDate27);
//        int int35 = dateTime9.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "97" + "'", str33.equals("97"));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 69 + "'", int35 == 69);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundCeiling(1L);
        int int9 = delegatedDateTimeField5.getMaximumValue(84L);
        try {
            org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((java.lang.Object) delegatedDateTimeField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.field.DelegatedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(22);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate13 = localDate11.minusWeeks((int) ' ');
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone15.getName(0L, locale17);
//        boolean boolean20 = dateTimeZone15.isStandardOffset((long) '4');
//        org.joda.time.DateTime dateTime21 = localDate11.toDateTimeAtStartOfDay(dateTimeZone15);
//        try {
//            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(365, 19, 69, 1439, (-83198), (int) '4', dateTimeZone15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField5 = buddhistChronology1.weekyears();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology1.year();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
//        java.lang.String str14 = dateTimeZone10.getID();
//        java.util.TimeZone timeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate22 = localDate20.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime23 = null;
//        org.joda.time.DateTime dateTime24 = localDate22.toDateTime(localTime23);
//        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.minus(readableDuration28);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
//        org.joda.time.Chronology chronology35 = gJChronology30.withZone(dateTimeZone32);
//        try {
//            long long41 = gJChronology30.getDateTimeMillis((long) 'a', 83204, 44, 22, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83204 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(chronology35);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 6, 307);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        java.util.Date date12 = localDate11.toDate();
//        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
//        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone24.getName(0L, locale26);
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(dateTimeZone24);
//        org.joda.time.LocalDate localDate30 = localDate28.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.LocalDate localDate33 = localDate30.withPeriodAdded(readablePeriod31, 0);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipDateTimeField22.getAsText((org.joda.time.ReadablePartial) localDate33, 57977, locale35);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.era();
//        int int39 = gregorianChronology37.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, 83195);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField42.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, dateTimeFieldType43);
//        try {
//            org.joda.time.Partial partial46 = partial1.with(dateTimeFieldType43, 83186);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83186 for clockhourOfDay must not be larger than 24");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "57977" + "'", str36.equals("57977"));
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundCeiling(1L);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
        org.junit.Assert.assertNull(durationField8);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        long long22 = skipDateTimeField19.add((long) 19, (-637703L));
//        try {
//            long long25 = skipDateTimeField19.set(0L, 2561);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2561 for minuteOfHour must be in the range [1,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-38262179981L) + "'", long22 == (-38262179981L));
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        java.lang.String str6 = dateTimeZone1.getID();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        long long9 = dateTimeZone1.convertUTCToLocal(3L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long9 = delegatedDateTimeField7.remainder((long) (byte) 1);
        java.lang.String str11 = delegatedDateTimeField7.getAsText((-38262179981L));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "37" + "'", str11.equals("37"));
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfDay((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now(dateTimeZone3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((java.lang.Object) dateTime2, dateTimeZone3);
//        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.dayOfYear();
//        org.joda.time.LocalDate.Property property12 = localDate7.dayOfMonth();
//        java.util.Locale locale13 = null;
//        int int14 = property12.getMaximumShortTextLength(locale13);
//        org.joda.time.DurationField durationField15 = property12.getRangeDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime.Property property10 = dateTime9.era();
//        java.lang.String str11 = property10.getName();
//        try {
//            org.joda.time.DateTime dateTime13 = property10.setCopy(83190);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83190 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "era" + "'", str11.equals("era"));
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime11 = null;
//        org.joda.time.DateTime dateTime12 = localDate10.toDateTime(localTime11);
//        boolean boolean13 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate10);
//        int[] intArray14 = localDate2.getValues();
//        org.joda.time.LocalDate localDate16 = localDate2.minusDays(4);
//        org.joda.time.Instant instant18 = new org.joda.time.Instant(10L);
//        org.joda.time.MutableDateTime mutableDateTime19 = instant18.toMutableDateTime();
//        org.joda.time.Instant instant21 = instant18.plus((long) (byte) -1);
//        org.joda.time.MutableDateTime mutableDateTime22 = instant18.toMutableDateTime();
//        org.joda.time.DateTime dateTime23 = localDate2.toDateTime((org.joda.time.ReadableInstant) instant18);
//        try {
//            org.joda.time.LocalDate localDate25 = localDate2.withEra(15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(instant21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology8 = localDate7.getChronology();
//        java.lang.String str9 = localDate7.toString();
//        int int10 = localDate7.size();
//        java.lang.String str11 = localDate7.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-05-22" + "'", str9.equals("1969-05-22"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969-05-22" + "'", str11.equals("1969-05-22"));
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1969-05-22");
        org.junit.Assert.assertNotNull(instant1);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        java.lang.String str21 = skipDateTimeField19.getAsShortText((long) (byte) 1);
//        long long23 = skipDateTimeField19.roundHalfFloor((long) (byte) 100);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName(0L, locale7);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate11 = localDate9.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime12 = null;
//        org.joda.time.DateTime dateTime13 = localDate11.toDateTime(localTime12);
//        org.joda.time.LocalDate.Property property14 = localDate11.yearOfCentury();
//        org.joda.time.LocalDate.Property property15 = localDate11.monthOfYear();
//        org.joda.time.LocalDate localDate17 = localDate11.withYearOfEra(10);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) '4');
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate19.getFieldTypes();
//        org.joda.time.LocalDate localDate22 = localDate19.withWeekyear((int) ' ');
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-2812));
//        boolean boolean25 = localDate19.isEqual((org.joda.time.ReadablePartial) localDate24);
//        long long27 = zonedChronology3.set((org.joda.time.ReadablePartial) localDate19, 59968L);
//        org.joda.time.Chronology chronology28 = zonedChronology3.withUTC();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-60513955140032L) + "'", long27 == (-60513955140032L));
//        org.junit.Assert.assertNotNull(chronology28);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfYear();
        long long6 = buddhistChronology0.add((long) '4', (long) (byte) 1, 57968);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9, 3);
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 57973, dateTimeZone12);
        org.joda.time.Chronology chronology14 = buddhistChronology0.withZone(dateTimeZone12);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 58020L + "'", long6 == 58020L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = buddhistChronology1.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7, 3);
//        org.joda.time.Chronology chronology10 = buddhistChronology1.withZone(dateTimeZone7);
//        org.joda.time.LocalDateTime localDateTime11 = null;
//        boolean boolean12 = dateTimeZone7.isLocalDateTimeGap(localDateTime11);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField16 = buddhistChronology15.eras();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.era();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        long long21 = buddhistChronology15.add(readablePeriod18, (long) 18, 4);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 18L + "'", long21 == 18L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
        long long5 = dateTimeZone0.convertLocalToUTC((long) 57973, false, (long) 59);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 57973L + "'", long5 == 57973L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException4.prependMessage("1969365");
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException4.getSuppressed();
        java.lang.String str9 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        org.joda.time.ReadableInstant readableInstant15 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, readableInstant15, 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1439");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
//        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime27 = null;
//        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
//        boolean boolean29 = localDate18.isAfter((org.joda.time.ReadablePartial) localDate26);
//        org.joda.time.LocalDate localDate31 = localDate18.plusYears((int) 'a');
//        boolean boolean32 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.LocalDate.Property property33 = localDate5.yearOfEra();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology37);
//        java.util.TimeZone timeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dateTimeZone40.getName(0L, locale42);
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone40);
//        java.util.Date date45 = localDate44.toDate();
//        int[] intArray47 = buddhistChronology37.get((org.joda.time.ReadablePartial) localDate44, (long) (short) -1);
//        org.joda.time.DurationField durationField48 = buddhistChronology37.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology50 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology50);
//        org.joda.time.DateTimeField dateTimeField52 = buddhistChronology50.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52, dateTimeFieldType53);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField55 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology37, (org.joda.time.DateTimeField) delegatedDateTimeField54);
//        java.util.TimeZone timeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forTimeZone(timeZone56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = dateTimeZone57.getName(0L, locale59);
//        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate(dateTimeZone57);
//        org.joda.time.LocalDate localDate63 = localDate61.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod64 = null;
//        org.joda.time.LocalDate localDate66 = localDate63.withPeriodAdded(readablePeriod64, 0);
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = skipDateTimeField55.getAsText((org.joda.time.ReadablePartial) localDate66, 57977, locale68);
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology70.era();
//        int int72 = gregorianChronology70.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology70.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField(dateTimeField73, 83195);
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = offsetDateTimeField75.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField77 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField55, dateTimeFieldType76);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder34.appendText(dateTimeFieldType76);
//        boolean boolean79 = localDate5.isSupported(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(buddhistChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+00:00" + "'", str43.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(buddhistChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+00:00" + "'", str60.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(localDate66);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "57977" + "'", str69.equals("57977"));
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 4 + "'", int72 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName(0L, locale7);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate11 = localDate9.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime12 = null;
//        org.joda.time.DateTime dateTime13 = localDate11.toDateTime(localTime12);
//        org.joda.time.LocalDate.Property property14 = localDate11.yearOfCentury();
//        org.joda.time.LocalDate.Property property15 = localDate11.monthOfYear();
//        org.joda.time.LocalDate localDate17 = localDate11.withYearOfEra(10);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) '4');
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate19.getFieldTypes();
//        org.joda.time.LocalDate localDate22 = localDate19.withWeekyear((int) ' ');
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-2812));
//        boolean boolean25 = localDate19.isEqual((org.joda.time.ReadablePartial) localDate24);
//        long long27 = zonedChronology3.set((org.joda.time.ReadablePartial) localDate19, 59968L);
//        try {
//            long long32 = zonedChronology3.getDateTimeMillis(18, (int) (short) 10, 69, 8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-60513955140032L) + "'", long27 == (-60513955140032L));
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L);
//        org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(1);
//        boolean boolean8 = dateTime5.isBeforeNow();
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology3, (org.joda.time.ReadableDateTime) dateTime5, readableDateTime9);
//        try {
//            long long15 = limitChronology10.getDateTimeMillis(0, 6, 44, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 44 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(limitChronology10);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 3, 100);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.clockhourOfDay();
        long long11 = gregorianChronology0.add((long) 57973, 52L, 83196);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3L + "'", long5 == 3L);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4384165L + "'", long11 == 4384165L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField5 = buddhistChronology1.months();
        org.joda.time.DurationField durationField6 = buddhistChronology1.millis();
        long long9 = durationField6.subtract((long) (byte) -1, (int) (short) 10);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-11L) + "'", long9 == (-11L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder0.toFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek((-671497));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYear(0, 18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendFractionOfDay(0, 307);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendMonthOfYear(57977);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GJChronology[UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.junit.Assert.assertNotNull(instant3);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property12.getAsShortText(locale13);
//        java.util.Locale locale15 = null;
//        int int16 = property12.getMaximumTextLength(locale15);
//        try {
//            org.joda.time.DateTime dateTime18 = property12.setCopy("0");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "May" + "'", str14.equals("May"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        int int3 = localDate2.getMonthOfYear();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField11 = julianChronology10.seconds();
        try {
            org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((java.lang.Object) fixedDateTimeZone7, (org.joda.time.Chronology) julianChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        long long7 = delegatedDateTimeField5.roundCeiling(1L);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology11);
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        java.util.Date date19 = localDate18.toDate();
//        int[] intArray21 = buddhistChronology11.get((org.joda.time.ReadablePartial) localDate18, (long) (short) -1);
//        org.joda.time.DurationField durationField22 = buddhistChronology11.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology24);
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology24.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology11, (org.joda.time.DateTimeField) delegatedDateTimeField28);
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        int[] intArray37 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
//        int int38 = delegatedDateTimeField28.getMinimumValue(readablePartial30, intArray37);
//        int[] intArray40 = delegatedDateTimeField5.add(readablePartial8, (int) '#', intArray37, 0);
//        java.lang.String str41 = delegatedDateTimeField5.getName();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(intArray21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "minuteOfHour" + "'", str41.equals("minuteOfHour"));
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        int int10 = dateTime9.getMonthOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime9.yearOfEra();
//        int int12 = property11.getLeapAmount();
//        java.util.Locale locale13 = null;
//        int int14 = property11.getMaximumShortTextLength(locale13);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName(0L, locale15);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone13);
//        org.joda.time.LocalDate localDate19 = localDate17.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime20 = null;
//        org.joda.time.DateTime dateTime21 = localDate19.toDateTime(localTime20);
//        org.joda.time.DateTime dateTime23 = dateTime21.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.minus(readableDuration25);
//        int int27 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime23.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime23.plusMonths(2);
//        org.joda.time.DateTime.Property property32 = dateTime31.weekyear();
//        boolean boolean33 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
//        int int8 = offsetDateTimeField5.getMinimumValue();
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray17 = localDate14.getFields();
//        int[] intArray18 = null;
//        int int19 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate14, intArray18);
//        boolean boolean20 = offsetDateTimeField5.isSupported();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology22);
//        java.util.TimeZone timeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getName(0L, locale27);
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone25);
//        java.util.Date date30 = localDate29.toDate();
//        int[] intArray32 = buddhistChronology22.get((org.joda.time.ReadablePartial) localDate29, (long) (short) -1);
//        org.joda.time.DurationField durationField33 = buddhistChronology22.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology35);
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology35.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37, dateTimeFieldType38);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology22, (org.joda.time.DateTimeField) delegatedDateTimeField39);
//        java.util.TimeZone timeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forTimeZone(timeZone41);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = dateTimeZone42.getName(0L, locale44);
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate(dateTimeZone42);
//        org.joda.time.LocalDate localDate48 = localDate46.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime49 = null;
//        org.joda.time.DateTime dateTime50 = localDate48.toDateTime(localTime49);
//        org.joda.time.LocalDate.Property property51 = localDate48.yearOfCentury();
//        org.joda.time.LocalDate.Property property52 = localDate48.monthOfYear();
//        org.joda.time.LocalDate localDate54 = localDate48.withYearOfEra(10);
//        org.joda.time.LocalDate localDate56 = localDate54.withYearOfCentury((int) '4');
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = skipDateTimeField40.getAsText((org.joda.time.ReadablePartial) localDate54, (int) '4', locale58);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology62 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology62);
//        org.joda.time.DateTimeField dateTimeField64 = buddhistChronology62.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField66 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField64, dateTimeFieldType65);
//        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField66, 307, 11, 57968);
//        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate((long) 44);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology74 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology74);
//        java.util.TimeZone timeZone76 = null;
//        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeZone.forTimeZone(timeZone76);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = dateTimeZone77.getName(0L, locale79);
//        org.joda.time.LocalDate localDate81 = new org.joda.time.LocalDate(dateTimeZone77);
//        java.util.Date date82 = localDate81.toDate();
//        int[] intArray84 = buddhistChronology74.get((org.joda.time.ReadablePartial) localDate81, (long) (short) -1);
//        int int85 = delegatedDateTimeField66.getMaximumValue((org.joda.time.ReadablePartial) localDate72, intArray84);
//        try {
//            int[] intArray87 = offsetDateTimeField5.add((org.joda.time.ReadablePartial) localDate54, 365, intArray84, 59);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 365");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83219 + "'", int19 == 83219);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(buddhistChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "+00:00" + "'", str45.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
//        org.junit.Assert.assertNotNull(buddhistChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(buddhistChronology74);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "+00:00" + "'", str80.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(intArray84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 59 + "'", int85 == 59);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        boolean boolean4 = dateTime2.isEqualNow();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
//        try {
//            org.joda.time.LocalDate localDate13 = localDate7.withMonthOfYear((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"10\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.LocalDate localDate30 = localDate27.withPeriodAdded(readablePeriod28, 0);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate30, 57977, locale32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.era();
//        int int36 = gregorianChronology34.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 83195);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField39.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType40);
//        boolean boolean43 = skipDateTimeField19.isLeap(0L);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "57977" + "'", str33.equals("57977"));
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", 44);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("3", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
//        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime13 = null;
//        org.joda.time.DateTime dateTime14 = localDate12.toDateTime(localTime13);
//        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (short) 0);
//        org.joda.time.DateTime dateTime18 = dateTime14.withMinuteOfHour(1);
//        int int19 = dateTime18.getMonthOfYear();
//        org.joda.time.DateTime dateTime21 = dateTime18.withCenturyOfEra(2);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime24 = dateTime22.withMillisOfDay((int) (byte) 100);
//        org.joda.time.DateTime dateTime26 = dateTime22.minusDays(0);
//        int int27 = dateTime26.getYearOfCentury();
//        org.joda.time.DateTime dateTime29 = dateTime26.withMillis((long) '4');
//        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime21, (org.joda.time.ReadableDateTime) dateTime26);
//        boolean boolean31 = dateTime21.isBeforeNow();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 70 + "'", int27 == 70);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(limitChronology30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        org.joda.time.LocalDate.Property property24 = localDate20.weekyear();
//        org.joda.time.LocalTime localTime25 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        org.joda.time.DateTime dateTime28 = localDate20.toDateTime(localTime25, dateTimeZone27);
//        int int29 = dateTime28.getEra();
//        java.util.GregorianCalendar gregorianCalendar30 = dateTime28.toGregorianCalendar();
//        org.joda.time.DateTime.Property property31 = dateTime28.dayOfWeek();
//        int int32 = property31.getMaximumValue();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-17154028800000L) + "'", long23 == (-17154028800000L));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(gregorianCalendar30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 7 + "'", int32 == 7);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) 'a');
        boolean boolean6 = dateTimeFormatterBuilder3.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(2018);
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears((int) (short) 100);
        org.joda.time.LocalTime localTime7 = dateTime4.toLocalTime();
        org.joda.time.DateTime dateTime9 = dateTime4.plusSeconds((-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("GJChronology[UTC,cutover=2018-11-03T23:06:43.391Z]", "1969-05-22", true, 6, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.minus(readableDuration5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property12.getAsShortText(locale13);
//        java.util.Locale locale15 = null;
//        int int16 = property12.getMaximumTextLength(locale15);
//        org.joda.time.DurationField durationField17 = property12.getLeapDurationField();
//        org.joda.time.DateTime dateTime18 = property12.roundCeilingCopy();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "May" + "'", str14.equals("May"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
//        org.joda.time.LocalDate localDate3 = localDate1.withCenturyOfEra(57977);
//        int int4 = localDate3.getDayOfMonth();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime28 = null;
//        org.joda.time.DateTime dateTime29 = localDate27.toDateTime(localTime28);
//        org.joda.time.LocalDate.Property property30 = localDate27.yearOfCentury();
//        org.joda.time.LocalDate.Property property31 = localDate27.monthOfYear();
//        org.joda.time.LocalDate localDate33 = localDate27.withYearOfEra(10);
//        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) '4');
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate33, (int) '4', locale37);
//        int int39 = localDate33.getEra();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "52" + "'", str38.equals("52"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str6 = dateTimeFormatter4.print((long) 10);
//        java.lang.String str8 = dateTimeFormatter4.print(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology10);
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName(0L, locale15);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone13);
//        java.util.Date date18 = localDate17.toDate();
//        int[] intArray20 = buddhistChronology10.get((org.joda.time.ReadablePartial) localDate17, (long) (short) -1);
//        org.joda.time.DurationField durationField21 = buddhistChronology10.eras();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) buddhistChronology10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder3.append(dateTimeFormatter24);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap26 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970001" + "'", str6.equals("1970001"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001" + "'", str8.equals("1970001"));
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Instant instant2 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 83217);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-83218) + "'", int6 == (-83218));
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
//        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
//        java.lang.String str17 = dateTimeZone9.getName((long) (-1));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 69, dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime dateTime14 = property12.addToCopy(0);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) (byte) 100);
//        int int18 = property12.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime17.withEra(5);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfDay((int) (byte) 100);
//        org.joda.time.DateTime dateTime4 = dateTime0.minusDays(0);
//        int int5 = dateTime4.getYearOfCentury();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusMillis(84);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        int int5 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.hourOfDay();
        try {
            long long11 = copticChronology2.getDateTimeMillis(134, 57977, 0, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57977 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.Instant instant4 = instant2.plus(9700L);
        org.joda.time.Chronology chronology5 = instant4.getChronology();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName(0L, locale7);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate11 = localDate9.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime12 = null;
//        org.joda.time.DateTime dateTime13 = localDate11.toDateTime(localTime12);
//        org.joda.time.LocalDate.Property property14 = localDate11.yearOfCentury();
//        org.joda.time.LocalDate.Property property15 = localDate11.monthOfYear();
//        org.joda.time.LocalDate localDate17 = localDate11.withYearOfEra(10);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) '4');
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate19.getFieldTypes();
//        org.joda.time.LocalDate localDate22 = localDate19.withWeekyear((int) ' ');
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-2812));
//        boolean boolean25 = localDate19.isEqual((org.joda.time.ReadablePartial) localDate24);
//        long long27 = zonedChronology3.set((org.joda.time.ReadablePartial) localDate19, 59968L);
//        org.joda.time.DurationField durationField28 = zonedChronology3.weeks();
//        try {
//            long long36 = zonedChronology3.getDateTimeMillis(84, 2018, 57977, 57977, 57973, 2561, 23);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57977 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-60513955140032L) + "'", long27 == (-60513955140032L));
//        org.junit.Assert.assertNotNull(durationField28);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
//        org.joda.time.LocalDate localDate13 = localDate7.withYearOfEra(10);
//        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) '4');
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = localDate15.getFieldTypes();
//        org.joda.time.LocalDate localDate18 = localDate15.withWeekyear((int) ' ');
//        org.joda.time.DurationFieldType durationFieldType19 = null;
//        boolean boolean20 = localDate15.isSupported(durationFieldType19);
//        org.joda.time.LocalDate localDate22 = localDate15.withCenturyOfEra(19);
//        org.joda.time.LocalDate localDate24 = localDate15.withDayOfMonth(1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(localDate24);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
//        int int8 = offsetDateTimeField5.getMinimumValue();
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray17 = localDate14.getFields();
//        int[] intArray18 = null;
//        int int19 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate14, intArray18);
//        boolean boolean20 = offsetDateTimeField5.isSupported();
//        int int22 = offsetDateTimeField5.getLeapAmount((-60499699140032L));
//        long long25 = offsetDateTimeField5.add(52L, 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83219 + "'", int19 == 83219);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
//        org.joda.time.LocalDate localDate13 = localDate7.withYearOfEra(10);
//        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) '4');
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = localDate15.getFieldTypes();
//        org.joda.time.LocalDate localDate18 = localDate15.withWeekyear((int) ' ');
//        org.joda.time.DurationFieldType durationFieldType19 = null;
//        boolean boolean20 = localDate15.isSupported(durationFieldType19);
//        org.joda.time.LocalDate localDate22 = localDate15.withCenturyOfEra(19);
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.Partial partial24 = new org.joda.time.Partial(chronology23);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray25 = partial24.getFieldTypes();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray26 = partial24.getFieldTypes();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.Partial partial28 = partial24.minus(readablePeriod27);
//        org.joda.time.Chronology chronology29 = partial28.getChronology();
//        java.lang.String str30 = partial28.toString();
//        int[] intArray31 = partial28.getValues();
//        try {
//            boolean boolean32 = localDate22.isBefore((org.joda.time.ReadablePartial) partial28);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray25);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray26);
//        org.junit.Assert.assertNotNull(partial28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[]" + "'", str30.equals("[]"));
//        org.junit.Assert.assertNotNull(intArray31);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        int int10 = localDate7.getEra();
//        org.joda.time.LocalDate localDate12 = localDate7.minusYears((int) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(localDate12);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        int int11 = localDate10.getWeekyear();
//        java.util.Date date12 = localDate10.toDate();
//        org.joda.time.LocalDate localDate14 = localDate10.withMonthOfYear(10);
//        try {
//            org.joda.time.LocalDate localDate16 = localDate10.withDayOfYear(86399);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(localDate14);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.Partial partial4 = partial1.withPeriodAdded(readablePeriod2, 4);
        int[] intArray5 = partial1.getValues();
        try {
            int int7 = partial1.getValue((-83198));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -83198");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        int int5 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.hourOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        org.joda.time.DurationField durationField11 = copticChronology2.years();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 540000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.withPeriodAdded(readablePeriod4, 0);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        org.joda.time.Interval interval8 = property7.toInterval();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(interval8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        boolean boolean8 = offsetDateTimeField5.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName(0L, locale7);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone5);
//        java.util.Date date10 = localDate9.toDate();
//        int[] intArray12 = buddhistChronology2.get((org.joda.time.ReadablePartial) localDate9, (long) (short) -1);
//        org.joda.time.DurationField durationField13 = buddhistChronology2.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField19);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = dateTimeZone22.getName(0L, locale24);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(dateTimeZone22);
//        org.joda.time.LocalDate localDate28 = localDate26.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.LocalDate localDate31 = localDate28.withPeriodAdded(readablePeriod29, 0);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipDateTimeField20.getAsText((org.joda.time.ReadablePartial) localDate31, 57977, locale33);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.era();
//        int int37 = gregorianChronology35.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, 83195);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField40.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType41);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "57977" + "'", str34.equals("57977"));
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.DateTime.Property property5 = dateTime3.property(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 52L, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.LocalDate localDate30 = localDate27.withPeriodAdded(readablePeriod28, 0);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate30, 57977, locale32);
//        long long36 = skipDateTimeField19.add(0L, 9);
//        long long38 = skipDateTimeField19.roundFloor((long) 10);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "57977" + "'", str33.equals("57977"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 540000L + "'", long36 == 540000L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        long long7 = delegatedDateTimeField5.roundCeiling(1L);
//        java.lang.String str9 = delegatedDateTimeField5.getAsText(0L);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getName(0L, locale13);
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime18 = null;
//        org.joda.time.DateTime dateTime19 = localDate17.toDateTime(localTime18);
//        org.joda.time.LocalDate.Property property20 = localDate17.yearOfCentury();
//        org.joda.time.LocalDate.Property property21 = localDate17.monthOfYear();
//        org.joda.time.LocalDate localDate23 = localDate17.withYearOfEra(10);
//        org.joda.time.LocalDate localDate25 = localDate23.withYearOfCentury((int) '4');
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray26 = localDate25.getFieldTypes();
//        org.joda.time.LocalDate localDate28 = localDate25.withWeekyear((int) ' ');
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (-2812));
//        boolean boolean31 = localDate25.isEqual((org.joda.time.ReadablePartial) localDate30);
//        java.util.TimeZone timeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = dateTimeZone33.getName(0L, locale35);
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(dateTimeZone33);
//        org.joda.time.LocalDate localDate39 = localDate37.minusWeeks((int) ' ');
//        java.util.TimeZone timeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forTimeZone(timeZone40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = dateTimeZone41.getName(0L, locale43);
//        boolean boolean46 = dateTimeZone41.isStandardOffset((long) '4');
//        org.joda.time.DateTime dateTime47 = localDate37.toDateTimeAtStartOfDay(dateTimeZone41);
//        java.util.TimeZone timeZone48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forTimeZone(timeZone48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dateTimeZone49.getName(0L, locale51);
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone49);
//        org.joda.time.LocalDate localDate55 = localDate53.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime56 = null;
//        org.joda.time.DateTime dateTime57 = localDate55.toDateTime(localTime56);
//        org.joda.time.LocalDate.Property property58 = localDate55.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = localDate55.getFieldType(0);
//        org.joda.time.LocalDate localDate62 = localDate37.withField(dateTimeFieldType60, 57968);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, (java.lang.Number) 1L, "97");
//        boolean boolean66 = localDate30.isSupported(dateTimeFieldType60);
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType60, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+00:00" + "'", str36.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "+00:00" + "'", str44.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "+00:00" + "'", str52.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        long long21 = delegatedDateTimeField18.roundHalfFloor((long) (byte) 100);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = delegatedDateTimeField18.getAsShortText((long) (-1), locale23);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getChronology(chronology25);
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(chronology26);
//        java.util.TimeZone timeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = dateTimeZone29.getName(0L, locale31);
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(dateTimeZone29);
//        org.joda.time.LocalDate localDate35 = localDate33.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime36 = null;
//        org.joda.time.DateTime dateTime37 = localDate35.toDateTime(localTime36);
//        boolean boolean38 = localDate27.isAfter((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.LocalDate localDate40 = localDate27.plusYears((int) 'a');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology42);
//        java.util.TimeZone timeZone44 = null;
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forTimeZone(timeZone44);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = dateTimeZone45.getName(0L, locale47);
//        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate(dateTimeZone45);
//        java.util.Date date50 = localDate49.toDate();
//        int[] intArray52 = buddhistChronology42.get((org.joda.time.ReadablePartial) localDate49, (long) (short) -1);
//        int int53 = delegatedDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate27, intArray52);
//        int int54 = delegatedDateTimeField18.getMinimumValue();
//        java.lang.String str56 = delegatedDateTimeField18.getAsText((long) 2018);
//        long long59 = delegatedDateTimeField18.getDifferenceAsLong(100L, (long) 83196);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "59" + "'", str24.equals("59"));
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+00:00" + "'", str32.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "+00:00" + "'", str48.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 59 + "'", int53 == 59);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-1L) + "'", long59 == (-1L));
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology16 = localDate15.getChronology();
//        java.lang.String str17 = localDate15.toString();
//        int int18 = localDate15.size();
//        org.joda.time.LocalDate localDate20 = localDate15.withYearOfEra(2019);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology23);
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology23.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        long long29 = delegatedDateTimeField27.roundCeiling(1L);
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology33);
//        java.util.TimeZone timeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone36.getName(0L, locale38);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(dateTimeZone36);
//        java.util.Date date41 = localDate40.toDate();
//        int[] intArray43 = buddhistChronology33.get((org.joda.time.ReadablePartial) localDate40, (long) (short) -1);
//        org.joda.time.DurationField durationField44 = buddhistChronology33.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology46);
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType49);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology33, (org.joda.time.DateTimeField) delegatedDateTimeField50);
//        org.joda.time.ReadablePartial readablePartial52 = null;
//        int[] intArray59 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
//        int int60 = delegatedDateTimeField50.getMinimumValue(readablePartial52, intArray59);
//        int[] intArray62 = delegatedDateTimeField27.add(readablePartial30, (int) '#', intArray59, 0);
//        int[] intArray64 = offsetDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) localDate20, (int) (byte) 10, intArray62, 0);
//        long long66 = offsetDateTimeField5.roundCeiling((long) (short) -1);
//        java.util.TimeZone timeZone67 = null;
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forTimeZone(timeZone67);
//        java.util.Locale locale70 = null;
//        java.lang.String str71 = dateTimeZone68.getName(0L, locale70);
//        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate(dateTimeZone68);
//        org.joda.time.LocalDate localDate74 = localDate72.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod75 = null;
//        org.joda.time.LocalDate localDate77 = localDate74.withPeriodAdded(readablePeriod75, 0);
//        int int78 = localDate77.getWeekyear();
//        java.util.Date date79 = localDate77.toDate();
//        org.joda.time.DateTimeFieldType dateTimeFieldType80 = null;
//        int int81 = localDate77.indexOf(dateTimeFieldType80);
//        org.joda.time.Chronology chronology83 = null;
//        org.joda.time.Partial partial84 = new org.joda.time.Partial(chronology83);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray85 = partial84.getFieldTypes();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray86 = partial84.getFieldTypes();
//        org.joda.time.ReadablePeriod readablePeriod87 = null;
//        org.joda.time.Partial partial88 = partial84.minus(readablePeriod87);
//        org.joda.time.Chronology chronology89 = partial88.getChronology();
//        java.lang.String str90 = partial88.toString();
//        int[] intArray91 = partial88.getValues();
//        try {
//            int[] intArray93 = offsetDateTimeField5.add((org.joda.time.ReadablePartial) localDate77, 12, intArray91, 83195);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-05-22" + "'", str17.equals("1969-05-22"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 60000L + "'", long29 == 60000L);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+00:00" + "'", str39.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "+00:00" + "'", str71.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate74);
//        org.junit.Assert.assertNotNull(localDate77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1969 + "'", int78 == 1969);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray85);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray86);
//        org.junit.Assert.assertNotNull(partial88);
//        org.junit.Assert.assertNotNull(chronology89);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "[]" + "'", str90.equals("[]"));
//        org.junit.Assert.assertNotNull(intArray91);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
//        int int15 = dateTime11.getSecondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime11.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime11.plusMonths(2);
//        int int20 = dateTime11.getDayOfWeek();
//        org.joda.time.DateTime dateTime22 = dateTime11.plusHours(18);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        java.util.Date date12 = localDate11.toDate();
//        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
//        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
//        java.util.Locale locale25 = null;
//        int int26 = skipDateTimeField22.getMaximumShortTextLength(locale25);
//        long long28 = skipDateTimeField22.roundCeiling((long) '4');
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 60000L + "'", long28 == 60000L);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((java.lang.Object) dateTime2, dateTimeZone3);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime2.withFieldAdded(durationFieldType6, 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(localDate4);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        org.joda.time.LocalDate localDate13 = localDate11.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime14 = null;
//        org.joda.time.DateTime dateTime15 = localDate13.toDateTime(localTime14);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property18 = dateTime17.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.minus(readableDuration19);
//        int int21 = dateTime17.getSecondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime17.plus(readablePeriod22);
//        boolean boolean24 = gJChronology5.equals((java.lang.Object) dateTime17);
//        java.lang.String str25 = gJChronology5.toString();
//        try {
//            long long33 = gJChronology5.getDateTimeMillis(83204, 83217, 83195, 15, (int) (short) 0, 3, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83217 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GJChronology[UTC]" + "'", str25.equals("GJChronology[UTC]"));
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
//        java.lang.String str14 = dateTimeZone10.getID();
//        java.util.TimeZone timeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate22 = localDate20.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime23 = null;
//        org.joda.time.DateTime dateTime24 = localDate22.toDateTime(localTime23);
//        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.minus(readableDuration28);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
//        org.joda.time.Chronology chronology35 = gJChronology30.withZone(dateTimeZone32);
//        long long40 = gJChronology30.getDateTimeMillis(83206, 3, 15, 134);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2563566883200134L + "'", long40 == 2563566883200134L);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
//        java.lang.String str3 = dateTimeZone0.getName(60000L);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 1386);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1386");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.era();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = property10.equals(obj11);
//        try {
//            org.joda.time.LocalDate localDate14 = property10.addToCopy(1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10, 22, 1, 2018, 59, 2561, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2018 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(0);
        boolean boolean6 = dateTimeFormatterBuilder0.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
//        int int15 = dateTime11.getSecondOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime18 = dateTime11.withCenturyOfEra(2018);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        java.lang.String str21 = skipDateTimeField19.getAsShortText((long) (byte) 1);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, 83196);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 'a');
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter2.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
//        try {
//            long long9 = zonedChronology3.getDateTimeMillis(10, (int) '#', 83204, 44);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendFractionOfMinute(0, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendMinuteOfHour(83195);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(2018);
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readablePeriod7);
        org.joda.time.Chronology chronology9 = dateTime6.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Integer int3 = dateTimeFormatter2.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatterBuilder11.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatterBuilder11.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder10.append(dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendWeekOfWeekyear((int) 'a');
        boolean boolean24 = dateTimeFormatterBuilder21.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter31 = dateTimeFormatterBuilder30.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatterBuilder32.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder32.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder21.append(dateTimePrinter31, dateTimeParser37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser40 = dateTimeFormatter39.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder44.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatterBuilder46.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatterBuilder46.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder45.append(dateTimeParser51);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray53 = new org.joda.time.format.DateTimeParser[] { dateTimeParser16, dateTimeParser37, dateTimeParser40, dateTimeParser51 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder0.append(dateTimePrinter5, dateTimeParserArray53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimePrinter31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeParser40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertNotNull(dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeParserArray53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
//        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        java.lang.String str4 = dateTime2.toString(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-16T00" + "'", str4.equals("2019-06-16T00"));
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
//        java.lang.String str14 = dateTimeZone10.getID();
//        java.util.TimeZone timeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate22 = localDate20.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime23 = null;
//        org.joda.time.DateTime dateTime24 = localDate22.toDateTime(localTime23);
//        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.minus(readableDuration28);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
//        org.joda.time.Chronology chronology35 = gJChronology30.withZone(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField36 = null;
//        try {
//            org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField(chronology35, dateTimeField36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(chronology35);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        boolean boolean12 = dateTime11.isBeforeNow();
//        int int13 = dateTime11.getEra();
//        org.joda.time.DateTime dateTime15 = dateTime11.plusMillis(2561);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 59);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException4.prependMessage("1969365");
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        java.lang.Throwable[] throwableArray9 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
//        org.joda.time.LocalDate localDate4 = localDate2.minusYears(9);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = null;
//        java.lang.String str6 = localDate2.toString(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-01-01" + "'", str6.equals("1970-01-01"));
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology16 = localDate15.getChronology();
//        java.lang.String str17 = localDate15.toString();
//        int int18 = localDate15.size();
//        org.joda.time.LocalDate localDate20 = localDate15.withYearOfEra(2019);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology23);
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology23.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        long long29 = delegatedDateTimeField27.roundCeiling(1L);
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology33);
//        java.util.TimeZone timeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone36.getName(0L, locale38);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(dateTimeZone36);
//        java.util.Date date41 = localDate40.toDate();
//        int[] intArray43 = buddhistChronology33.get((org.joda.time.ReadablePartial) localDate40, (long) (short) -1);
//        org.joda.time.DurationField durationField44 = buddhistChronology33.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology46);
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType49);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology33, (org.joda.time.DateTimeField) delegatedDateTimeField50);
//        org.joda.time.ReadablePartial readablePartial52 = null;
//        int[] intArray59 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
//        int int60 = delegatedDateTimeField50.getMinimumValue(readablePartial52, intArray59);
//        int[] intArray62 = delegatedDateTimeField27.add(readablePartial30, (int) '#', intArray59, 0);
//        int[] intArray64 = offsetDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) localDate20, (int) (byte) 10, intArray62, 0);
//        boolean boolean65 = offsetDateTimeField5.isLenient();
//        java.util.TimeZone timeZone66 = null;
//        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forTimeZone(timeZone66);
//        java.util.Locale locale69 = null;
//        java.lang.String str70 = dateTimeZone67.getName(0L, locale69);
//        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate(dateTimeZone67);
//        org.joda.time.LocalDate localDate73 = localDate71.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod74 = null;
//        org.joda.time.LocalDate localDate76 = localDate73.withPeriodAdded(readablePeriod74, 0);
//        java.util.Locale locale78 = null;
//        java.lang.String str79 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate73, 0, locale78);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2018-11-03" + "'", str17.equals("2018-11-03"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 60000L + "'", long29 == 60000L);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+00:00" + "'", str39.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "+00:00" + "'", str70.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate73);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "0" + "'", str79.equals("0"));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField5 = buddhistChronology1.weekyears();
        org.joda.time.DurationField durationField6 = buddhistChronology1.minutes();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
//        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime27 = null;
//        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
//        boolean boolean29 = localDate18.isAfter((org.joda.time.ReadablePartial) localDate26);
//        org.joda.time.LocalDate localDate31 = localDate18.plusYears((int) 'a');
//        boolean boolean32 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.LocalDate localDate34 = localDate5.plusWeeks((-1));
//        int int35 = localDate34.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 159 + "'", int35 == 159);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) '#');
//        int int14 = dateTime11.getSecondOfDay();
//        org.joda.time.Chronology chronology15 = dateTime11.getChronology();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 83236 + "'", int14 == 83236);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("37");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
//        boolean boolean12 = property11.isLeap();
//        java.lang.String str13 = property11.toString();
//        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
//        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
//        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray18 = localDate16.getFieldTypes();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray18);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime14 = property13.roundFloorCopy();
//        org.joda.time.DateTimeField dateTimeField15 = property13.getField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 3, 100);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.halfdayOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        org.joda.time.Chronology chronology14 = iSOChronology6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.util.TimeZone timeZone16 = fixedDateTimeZone13.toTimeZone();
        org.joda.time.Chronology chronology17 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3L + "'", long5 == 3L);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(chronology17);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        int int10 = dateTime9.getMonthOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime9.yearOfEra();
//        java.util.Locale locale12 = null;
//        int int13 = property11.getMaximumTextLength(locale12);
//        java.util.Locale locale14 = null;
//        int int15 = property11.getMaximumShortTextLength(locale14);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
//        java.lang.String str14 = dateTimeZone10.getID();
//        java.util.TimeZone timeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate22 = localDate20.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime23 = null;
//        org.joda.time.DateTime dateTime24 = localDate22.toDateTime(localTime23);
//        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.minus(readableDuration28);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
//        org.joda.time.Chronology chronology35 = gJChronology30.withZone(dateTimeZone32);
//        org.joda.time.Chronology chronology36 = gJChronology30.withUTC();
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(chronology36);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.LocalDate localDate30 = localDate27.withPeriodAdded(readablePeriod28, 0);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate30, 57977, locale32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.era();
//        int int36 = gregorianChronology34.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 83195);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField39.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType40);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology43);
//        org.joda.time.DateTimeField dateTimeField45 = buddhistChronology43.minuteOfHour();
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology43);
//        org.joda.time.DurationField durationField47 = buddhistChronology43.months();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField49 = buddhistChronology48.seconds();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField50 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType40, durationField47, durationField49);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "57977" + "'", str33.equals("57977"));
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(buddhistChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekyear();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology15, dateTimeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.minus(9700L);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundCeiling(1L);
        int int9 = delegatedDateTimeField5.getMaximumValue(84L);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
        org.junit.Assert.assertNull(durationField10);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
//        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
//        boolean boolean12 = property11.isLeap();
//        java.lang.String str13 = property11.toString();
//        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
//        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.LocalDate localDate18 = localDate16.minus(readablePeriod17);
//        int int19 = localDate16.getYearOfCentury();
//        org.joda.time.LocalDate localDate21 = localDate16.withDayOfWeek(2);
//        org.joda.time.DurationFieldType durationFieldType22 = null;
//        try {
//            org.joda.time.LocalDate localDate24 = localDate21.withFieldAdded(durationFieldType22, 159);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 18 + "'", int19 == 18);
//        org.junit.Assert.assertNotNull(localDate21);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
//        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime13 = null;
//        org.joda.time.DateTime dateTime14 = localDate12.toDateTime(localTime13);
//        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (short) 0);
//        org.joda.time.DateTime dateTime18 = dateTime14.withMinuteOfHour(1);
//        int int19 = dateTime18.getMonthOfYear();
//        org.joda.time.DateTime dateTime21 = dateTime18.withCenturyOfEra(2);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime24 = dateTime22.withMillisOfDay((int) (byte) 100);
//        org.joda.time.DateTime dateTime26 = dateTime22.minusDays(0);
//        int int27 = dateTime26.getYearOfCentury();
//        org.joda.time.DateTime dateTime29 = dateTime26.withMillis((long) '4');
//        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime21, (org.joda.time.ReadableDateTime) dateTime26);
//        java.lang.String str31 = limitChronology30.toString();
//        try {
//            long long37 = limitChronology30.getDateTimeMillis(84L, 83204, 57973, (int) (byte) 10, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83204 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(limitChronology30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "LimitChronology[BuddhistChronology[AD], 0218-11-03T23:01:17.182Z, 2019-06-15T23:07:17.184Z]" + "'", str31.equals("LimitChronology[BuddhistChronology[AD], 0218-11-03T23:01:17.182Z, 2019-06-15T23:07:17.184Z]"));
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        int int10 = dateTime9.getMonthOfYear();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.hours();
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getShortName((long) 'a', locale6);
//        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone4);
//        java.util.TimeZone timeZone9 = dateTimeZone4.toTimeZone();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(10L);
//        int int12 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 6, dateTimeZone4);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        int int8 = localDate7.getDayOfWeek();
//        org.joda.time.LocalDate localDate10 = localDate7.minusMonths((int) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(localDate10);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField5.getMaximumTextLength(locale6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField5.getAsText((long) 83204, locale9);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.String str2 = dateTimeFormatter0.print((-1L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "23:59:59Z" + "'", str2.equals("23:59:59Z"));
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfDay((int) (byte) 100);
//        org.joda.time.DateTime dateTime4 = dateTime0.minusDays(0);
//        int int5 = dateTime4.getYearOfCentury();
//        int int6 = dateTime4.getHourOfDay();
//        boolean boolean7 = dateTime4.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
//        java.lang.String str4 = copticChronology2.toString();
//        try {
//            long long12 = copticChronology2.getDateTimeMillis(57968, 57973, 8, 0, 159, 1386, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 159 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[AD,mdfw=3]" + "'", str4.equals("CopticChronology[AD,mdfw=3]"));
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime14 = property13.roundFloorCopy();
//        try {
//            org.joda.time.DateTime dateTime16 = property13.setCopy("16:00:00");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"16:00:00\" for minuteOfHour is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfMonth();
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = partial2.getFormatter();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial2.withFieldAddWrapped(durationFieldType4, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(dateTimeFormatter3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long9 = delegatedDateTimeField7.roundCeiling((long) 83206);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 120000L + "'", long9 == 120000L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology3);
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = dateTime4.toCalendar(locale5);
        int int7 = dateTime0.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property8 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime9 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime0.minusMonths(2561);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.era();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology6.add(readablePeriod8, (long) 3, 100);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology6.clockhourOfDay();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(0, 57973, (-2812), 7, 4, 18, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57973 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3L + "'", long11 == 3L);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0d) + "'", number5.equals((-1.0d)));
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 2561);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField5 = buddhistChronology1.weeks();
        org.joda.time.Chronology chronology6 = buddhistChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField(chronology6, dateTimeField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property12.getAsShortText(locale14);
//        org.joda.time.DateTime dateTime16 = property12.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Nov" + "'", str15.equals("Nov"));
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = partial1.isMatch(readableInstant4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = partial1.toString("307", locale7);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.clockhourOfHalfday();
        org.joda.time.Partial partial11 = partial1.withChronologyRetainFields((org.joda.time.Chronology) copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "307" + "'", str8.equals("307"));
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(partial11);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime dateTime13 = dateTime9.withMinuteOfHour(1);
//        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond((int) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime2 = property1.getDateTime();
        org.joda.time.DateTime dateTime4 = property1.addToCopy(23);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        java.util.Date date12 = localDate11.toDate();
//        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
//        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
//        int int26 = skipUndoDateTimeField24.get((long) 11);
//        int int28 = skipUndoDateTimeField24.get(0L);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks(0);
        org.joda.time.LocalDate localDate4 = dateTime0.toLocalDate();
        int int6 = localDate4.getValue(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant4 = null;
        boolean boolean5 = partial1.isMatch(readableInstant4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = partial1.toString("1969-05-22", locale7);
        java.lang.String str10 = partial1.toString("2512365");
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-05-22" + "'", str8.equals("1969-05-22"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2512365" + "'", str10.equals("2512365"));
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusSeconds(0);
//        int int9 = dateTime6.getMinuteOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = null;
//        try {
//            int int11 = dateTime6.get(dateTimeField10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1387 + "'", int9 == 1387);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
//        int int15 = dateTime11.getSecondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime11.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime17.minus(1L);
//        int int20 = dateTime19.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 83239 + "'", int15 == 83239);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20 + "'", int20 == 20);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 2000);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2, 3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology4);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(copticChronology4);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology16 = localDate15.getChronology();
//        java.lang.String str17 = localDate15.toString();
//        int int18 = localDate15.size();
//        org.joda.time.LocalDate localDate20 = localDate15.withYearOfEra(2019);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology23);
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology23.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        long long29 = delegatedDateTimeField27.roundCeiling(1L);
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology33);
//        java.util.TimeZone timeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone36.getName(0L, locale38);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(dateTimeZone36);
//        java.util.Date date41 = localDate40.toDate();
//        int[] intArray43 = buddhistChronology33.get((org.joda.time.ReadablePartial) localDate40, (long) (short) -1);
//        org.joda.time.DurationField durationField44 = buddhistChronology33.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology46);
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType49);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology33, (org.joda.time.DateTimeField) delegatedDateTimeField50);
//        org.joda.time.ReadablePartial readablePartial52 = null;
//        int[] intArray59 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
//        int int60 = delegatedDateTimeField50.getMinimumValue(readablePartial52, intArray59);
//        int[] intArray62 = delegatedDateTimeField27.add(readablePartial30, (int) '#', intArray59, 0);
//        int[] intArray64 = offsetDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) localDate20, (int) (byte) 10, intArray62, 0);
//        java.lang.String str66 = offsetDateTimeField5.getAsShortText(902L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2018-11-03" + "'", str17.equals("2018-11-03"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 60000L + "'", long29 == 60000L);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+00:00" + "'", str39.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "83219" + "'", str66.equals("83219"));
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        java.lang.String str6 = dateTimeZone1.getID();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology8 = julianChronology7.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
//        try {
//            long long17 = julianChronology7.getDateTimeMillis(2561, (int) '4', (int) '#', 0, 6, (int) (short) 0, 307);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 15, 44);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 22);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField5.getType();
        try {
            long long9 = offsetDateTimeField5.set((long) (short) -1, "ZonedChronology[ISOChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[ISOChronology[UTC], UTC]\" for clockhourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        int int11 = localDate10.getWeekyear();
//        java.util.Date date12 = localDate10.toDate();
//        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.fromDateFields(date12);
//        java.lang.String str14 = localDate13.toString();
//        org.joda.time.LocalDate localDate16 = localDate13.withYear((int) (byte) 100);
//        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2018 + "'", int11 == 2018);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2018-11-03" + "'", str14.equals("2018-11-03"));
//        org.junit.Assert.assertNotNull(localDate16);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalDate.Property property8 = localDate5.dayOfMonth();
//        org.joda.time.LocalDate localDate9 = property8.roundFloorCopy();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate9);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 57977L, number2, (java.lang.Number) 83190);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekyear();
        org.joda.time.DurationField durationField17 = buddhistChronology15.months();
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfMonth();
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) buddhistChronology0);
        int int4 = partial3.size();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
//        boolean boolean16 = fixedDateTimeZone15.isFixed();
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        org.joda.time.Interval interval18 = localDate7.toInterval((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
//        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime27 = null;
//        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
//        org.joda.time.DateTime dateTime30 = dateTime28.plusMillis((int) (short) 0);
//        org.joda.time.DateTime dateTime32 = dateTime28.withMinuteOfHour(1);
//        boolean boolean33 = fixedDateTimeZone15.equals((java.lang.Object) dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(interval18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        org.joda.time.DateTime dateTime4 = property1.setCopy("16");
        org.joda.time.DateTime dateTime5 = property1.withMinimumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(2018);
        org.joda.time.DateTime.Property property5 = dateTime2.minuteOfDay();
        int int6 = property5.getLeapAmount();
        int int7 = property5.get();
        org.joda.time.DateTime dateTime8 = property5.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(2018);
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears((int) (short) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour(9);
        org.joda.time.Chronology chronology9 = dateTime6.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        java.lang.String str4 = copticChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[AD,mdfw=3]" + "'", str4.equals("CopticChronology[AD,mdfw=3]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(11);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusHours(57968);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1332641240929L + "'", long18 == 1332641240929L);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getName(0L, locale5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 100, dateTimeZone3);
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0f, (java.lang.Object) dateTime7);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime17 = null;
        org.joda.time.DateTime dateTime18 = localDate16.toDateTime(localTime17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property21 = dateTime20.monthOfYear();
        org.joda.time.DateTime.Property property22 = dateTime20.minuteOfHour();
        org.joda.time.DateTime dateTime23 = property22.roundHalfEvenCopy();
        boolean boolean25 = dateTime23.isAfter((long) 57973);
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime23.getZone();
        boolean boolean27 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property12.getAsShortText(locale14);
        org.joda.time.DateTime dateTime16 = property12.roundFloorCopy();
        org.joda.time.DurationField durationField17 = property12.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Nov" + "'", str15.equals("Nov"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial1.minus(readablePeriod4);
        org.joda.time.Chronology chronology6 = partial5.getChronology();
        java.lang.String str7 = partial5.toString();
        int[] intArray8 = partial5.getValues();
        java.lang.String str9 = partial5.toStringList();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.Partial partial12 = partial5.withPeriodAdded(readablePeriod10, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendEraText();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology16);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = dateTimeZone19.getName(0L, locale21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone19);
        java.util.Date date24 = localDate23.toDate();
        int[] intArray26 = buddhistChronology16.get((org.joda.time.ReadablePartial) localDate23, (long) (short) -1);
        org.joda.time.DurationField durationField27 = buddhistChronology16.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology29);
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology29.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType32);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology16, (org.joda.time.DateTimeField) delegatedDateTimeField33);
        java.util.TimeZone timeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = dateTimeZone36.getName(0L, locale38);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(dateTimeZone36);
        org.joda.time.LocalDate localDate42 = localDate40.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.LocalDate localDate45 = localDate42.withPeriodAdded(readablePeriod43, 0);
        java.util.Locale locale47 = null;
        java.lang.String str48 = skipDateTimeField34.getAsText((org.joda.time.ReadablePartial) localDate45, 57977, locale47);
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.era();
        int int51 = gregorianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology49.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 83195);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField54.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField34, dateTimeFieldType55);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType55);
        try {
            org.joda.time.Partial.Property property58 = partial5.property(dateTimeFieldType55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'clockhourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[]" + "'", str7.equals("[]"));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
        org.junit.Assert.assertNotNull(partial12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+00:00" + "'", str39.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "57977" + "'", str48.equals("57977"));
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        boolean boolean2 = dateTimeFormatter0.isParser();
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter0.parseMutableDateTime("1969-05-22");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-05-22\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.Partial partial4 = partial1.withPeriodAdded(readablePeriod2, 4);
        java.lang.String str5 = partial1.toStringList();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType7 = partial1.getFieldType(57982);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57982");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime27 = null;
        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
        boolean boolean29 = localDate18.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.LocalDate localDate31 = localDate18.plusYears((int) 'a');
        boolean boolean32 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.LocalDate.Property property33 = localDate5.yearOfEra();
        int int34 = property33.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(28800052L, 120000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 240L + "'", long2 == 240L);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        java.util.Date date6 = localDate5.toDate();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = localDate5.isSupported(dateTimeFieldType7);
//        int int9 = localDate5.getDayOfWeek();
//        org.joda.time.LocalDate.Property property10 = localDate5.dayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        int int5 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.hourOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale13 = null;
        try {
            long long14 = skipUndoDateTimeField10.set((long) 1969, "May", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"May\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        try {
            org.joda.time.Instant instant4 = org.joda.time.Instant.parse("GJChronology[UTC,cutover=2018-11-03T23:06:43.391Z]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[UTC,cutover=2018-11...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        int int5 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.hourOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology2);
        int[] intArray12 = partial11.getValues();
        int int13 = partial11.size();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(2018);
        try {
            org.joda.time.DateTime dateTime9 = dateTime2.withTime(307, 1386, 86399, 83206);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 307 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.lang.String str5 = zonedChronology3.toString();
        try {
            long long10 = zonedChronology3.getDateTimeMillis(9, 57975, (-83198), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57975 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 570L, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int9 = offsetDateTimeField5.getMaximumValue((long) (short) 1);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField5.getWrappedField();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 44);
        org.joda.time.LocalDate.Property property13 = localDate12.weekyear();
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate12, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'clockhourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 83219 + "'", int9 == 83219);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillisOfDay((int) (byte) 100);
//        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime5 = dateTime3.plus((long) 57973);
//        int int6 = dateTime5.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 477 + "'", int6 == 477);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundCeiling(1L);
        java.lang.String str9 = delegatedDateTimeField5.getAsText(0L);
        java.lang.String str10 = delegatedDateTimeField5.toString();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology12);
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = dateTimeZone15.getName(0L, locale17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone15);
        java.util.Date date20 = localDate19.toDate();
        int[] intArray22 = buddhistChronology12.get((org.joda.time.ReadablePartial) localDate19, (long) (short) -1);
        org.joda.time.DurationField durationField23 = buddhistChronology12.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology25);
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology25.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27, dateTimeFieldType28);
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology12, (org.joda.time.DateTimeField) delegatedDateTimeField29);
        java.util.TimeZone timeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = dateTimeZone32.getName(0L, locale34);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(dateTimeZone32);
        org.joda.time.LocalDate localDate38 = localDate36.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField30.getAsText((org.joda.time.ReadablePartial) localDate41, 57977, locale43);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.era();
        int int47 = gregorianChronology45.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 83195);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = offsetDateTimeField50.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField30, dateTimeFieldType51);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, dateTimeFieldType51, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str10.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00" + "'", str35.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "57977" + "'", str44.equals("57977"));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
        boolean boolean19 = dateTimeZone14.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime20 = localDate10.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology(chronology21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(chronology22);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName(0L, locale27);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone25);
        org.joda.time.LocalDate localDate31 = localDate29.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime32 = null;
        org.joda.time.DateTime dateTime33 = localDate31.toDateTime(localTime32);
        boolean boolean34 = localDate23.isAfter((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.LocalDate localDate36 = localDate23.plusYears((int) 'a');
        boolean boolean37 = localDate10.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate localDate39 = localDate10.plusWeeks((-1));
        org.joda.time.DateTime dateTime40 = dateTime2.withFields((org.joda.time.ReadablePartial) localDate10);
        int int41 = dateTime40.getMinuteOfDay();
        org.joda.time.DateTime dateTime43 = dateTime40.plus((long) (-83198));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1439 + "'", int41 == 1439);
        org.junit.Assert.assertNotNull(dateTime43);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        boolean boolean5 = dateTimeFormatterBuilder3.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        org.joda.time.LocalDate localDate13 = localDate7.withYearOfEra(10);
        org.joda.time.LocalDate localDate15 = localDate13.withYearOfCentury((int) '4');
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = localDate15.getFieldTypes();
        org.joda.time.LocalDate localDate18 = localDate15.withWeekyear((int) ' ');
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (-2812));
        boolean boolean21 = localDate15.isEqual((org.joda.time.ReadablePartial) localDate20);
        java.util.Date date22 = localDate15.toDate();
        org.joda.time.LocalDate.Property property23 = localDate15.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime3 = dateTime0.minusWeeks(0);
        org.joda.time.LocalDate localDate4 = dateTime0.toLocalDate();
        org.joda.time.DateMidnight dateMidnight5 = localDate4.toDateMidnight();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateMidnight5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.weekyear();
        org.joda.time.LocalDate localDate12 = localDate7.minusWeeks(59);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
//        int int8 = offsetDateTimeField5.getMinimumValue();
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray17 = localDate14.getFields();
//        int[] intArray18 = null;
//        int int19 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate14, intArray18);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology28 = localDate27.getChronology();
//        java.lang.String str29 = localDate27.toString();
//        int int30 = localDate27.size();
//        org.joda.time.LocalDate localDate32 = localDate27.withYearOfEra(2019);
//        int[] intArray36 = new int[] { 2019, 2, 365 };
//        int int37 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate27, intArray36);
//        long long39 = offsetDateTimeField5.roundFloor(9700L);
//        java.lang.String str40 = offsetDateTimeField5.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83219 + "'", int19 == 83219);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2018-11-03" + "'", str29.equals("2018-11-03"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 83196 + "'", int37 == 83196);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "clockhourOfDay" + "'", str40.equals("clockhourOfDay"));
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property12.getAsShortText(locale14);
        org.joda.time.DateTime dateTime16 = property12.roundFloorCopy();
        org.joda.time.Interval interval17 = property12.toInterval();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval17);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Nov" + "'", str15.equals("Nov"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertNotNull(chronology18);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        java.io.Writer writer3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str5 = iSOChronology4.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime16 = null;
//        org.joda.time.DateTime dateTime17 = localDate15.toDateTime(localTime16);
//        org.joda.time.LocalDate.Property property18 = localDate15.yearOfCentury();
//        org.joda.time.LocalDate.Property property19 = localDate15.monthOfYear();
//        org.joda.time.LocalDate localDate21 = localDate15.withYearOfEra(10);
//        org.joda.time.LocalDate localDate23 = localDate21.withYearOfCentury((int) '4');
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray24 = localDate23.getFieldTypes();
//        org.joda.time.LocalDate localDate26 = localDate23.withWeekyear((int) ' ');
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((long) (-2812));
//        boolean boolean29 = localDate23.isEqual((org.joda.time.ReadablePartial) localDate28);
//        long long31 = zonedChronology7.set((org.joda.time.ReadablePartial) localDate23, 59968L);
//        org.joda.time.DateMidnight dateMidnight32 = localDate23.toDateMidnight();
//        try {
//            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadablePartial) localDate23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[AD]" + "'", str5.equals("ISOChronology[AD]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray24);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-60499699140032L) + "'", long31 == (-60499699140032L));
//        org.junit.Assert.assertNotNull(dateMidnight32);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime.Property property10 = dateTime9.era();
//        org.joda.time.DateTime dateTime12 = dateTime9.plusMinutes(2019);
//        int int13 = dateTime9.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField5, 307, 11, 57968);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getName(0L, locale13);
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone11);
//        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray18 = localDate15.getFields();
//        int int19 = localDate15.getDayOfMonth();
//        int int20 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate15);
//        org.joda.time.DurationField durationField21 = delegatedDateTimeField5.getDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.era();
//        int int24 = gregorianChronology22.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.clockhourOfDay();
//        org.joda.time.DurationField durationField26 = gregorianChronology22.weeks();
//        java.util.TimeZone timeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = dateTimeZone28.getName(0L, locale30);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(dateTimeZone28);
//        org.joda.time.LocalDate localDate34 = localDate32.minusWeeks((int) ' ');
//        java.util.TimeZone timeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone36.getName(0L, locale38);
//        boolean boolean41 = dateTimeZone36.isStandardOffset((long) '4');
//        org.joda.time.DateTime dateTime42 = localDate32.toDateTimeAtStartOfDay(dateTimeZone36);
//        java.util.TimeZone timeZone43 = null;
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forTimeZone(timeZone43);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = dateTimeZone44.getName(0L, locale46);
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(dateTimeZone44);
//        org.joda.time.LocalDate localDate50 = localDate48.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime51 = null;
//        org.joda.time.DateTime dateTime52 = localDate50.toDateTime(localTime51);
//        org.joda.time.LocalDate.Property property53 = localDate50.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = localDate50.getFieldType(0);
//        org.joda.time.LocalDate localDate57 = localDate32.withField(dateTimeFieldType55, 57968);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, durationField26, dateTimeFieldType55);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType55, 1969, (-2812), 1969);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+00:00" + "'", str39.equals("+00:00"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "+00:00" + "'", str47.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(localDate57);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, (org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName(0L, locale7);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.LocalDate localDate11 = localDate9.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime12 = null;
//        org.joda.time.DateTime dateTime13 = localDate11.toDateTime(localTime12);
//        org.joda.time.LocalDate.Property property14 = localDate11.yearOfCentury();
//        org.joda.time.LocalDate.Property property15 = localDate11.monthOfYear();
//        org.joda.time.LocalDate localDate17 = localDate11.withYearOfEra(10);
//        org.joda.time.LocalDate localDate19 = localDate17.withYearOfCentury((int) '4');
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate19.getFieldTypes();
//        org.joda.time.LocalDate localDate22 = localDate19.withWeekyear((int) ' ');
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-2812));
//        boolean boolean25 = localDate19.isEqual((org.joda.time.ReadablePartial) localDate24);
//        long long27 = zonedChronology3.set((org.joda.time.ReadablePartial) localDate19, 59968L);
//        org.joda.time.DurationField durationField28 = zonedChronology3.weeks();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        org.joda.time.Chronology chronology31 = zonedChronology3.withZone(dateTimeZone30);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-60499699140032L) + "'", long27 == (-60499699140032L));
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(0, 70, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendWeekOfWeekyear((int) 'a');
        boolean boolean11 = dateTimeFormatterBuilder8.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatterBuilder17.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatterBuilder19.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatterBuilder19.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.append(dateTimePrinter18, dateTimeParser24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder4.appendOptional(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYear(0, 18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendFractionOfDay(0, 307);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendMonthOfYear(57977);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder3.appendFractionOfSecond(0, 2019);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withZone(dateTimeZone4);
        int int8 = dateTimeZone4.getOffsetFromLocal((long) (-671497));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) ' ');
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = localDate10.getFieldTypes();
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone13.getName(0L, locale15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone13);
        org.joda.time.LocalDate localDate19 = localDate17.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime20 = null;
        org.joda.time.DateTime dateTime21 = localDate19.toDateTime(localTime20);
        org.joda.time.LocalDate.Property property22 = localDate19.yearOfCentury();
        org.joda.time.LocalDate.Property property23 = localDate19.monthOfYear();
        org.joda.time.LocalDate localDate25 = localDate19.withYearOfEra(10);
        org.joda.time.LocalDate localDate27 = localDate25.withYearOfCentury((int) '4');
        int int28 = localDate10.compareTo((org.joda.time.ReadablePartial) localDate25);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology30);
        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology30.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType33);
        long long36 = delegatedDateTimeField34.roundCeiling(1L);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology40);
        java.util.TimeZone timeZone42 = null;
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forTimeZone(timeZone42);
        java.util.Locale locale45 = null;
        java.lang.String str46 = dateTimeZone43.getName(0L, locale45);
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(dateTimeZone43);
        java.util.Date date48 = localDate47.toDate();
        int[] intArray50 = buddhistChronology40.get((org.joda.time.ReadablePartial) localDate47, (long) (short) -1);
        org.joda.time.DurationField durationField51 = buddhistChronology40.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology53);
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology53.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55, dateTimeFieldType56);
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology40, (org.joda.time.DateTimeField) delegatedDateTimeField57);
        org.joda.time.ReadablePartial readablePartial59 = null;
        int[] intArray66 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
        int int67 = delegatedDateTimeField57.getMinimumValue(readablePartial59, intArray66);
        int[] intArray69 = delegatedDateTimeField34.add(readablePartial37, (int) '#', intArray66, 0);
        try {
            gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate25, intArray69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 60000L + "'", long36 == 60000L);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+00:00" + "'", str46.equals("+00:00"));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(intArray69);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.minus(readableDuration5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
        int int9 = dateTime6.getHourOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.minusHours(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime28 = null;
        org.joda.time.DateTime dateTime29 = localDate27.toDateTime(localTime28);
        org.joda.time.LocalDate.Property property30 = localDate27.yearOfCentury();
        org.joda.time.LocalDate.Property property31 = localDate27.monthOfYear();
        org.joda.time.LocalDate localDate33 = localDate27.withYearOfEra(10);
        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) '4');
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate33, (int) '4', locale37);
        java.lang.String str39 = skipDateTimeField19.getName();
        java.lang.String str40 = skipDateTimeField19.getName();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "52" + "'", str38.equals("52"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "minuteOfHour" + "'", str39.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "minuteOfHour" + "'", str40.equals("minuteOfHour"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        org.joda.time.DateTimeField dateTimeField13 = property11.getField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        int int16 = localDate15.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        int int11 = localDate10.getWeekyear();
//        org.joda.time.DurationFieldType durationFieldType12 = null;
//        boolean boolean13 = localDate10.isSupported(durationFieldType12);
//        int int14 = localDate10.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone15);
//        org.joda.time.LocalDate localDate17 = localDate10.withFields((org.joda.time.ReadablePartial) localDate16);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName(0L, locale21);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone19);
//        org.joda.time.LocalDate localDate25 = localDate23.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime26 = null;
//        org.joda.time.DateTime dateTime27 = localDate25.toDateTime(localTime26);
//        org.joda.time.DateTime dateTime29 = dateTime27.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property30 = dateTime29.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime29.minus(readableDuration31);
//        int int33 = dateTime29.getSecondOfDay();
//        org.joda.time.DateMidnight dateMidnight34 = dateTime29.toDateMidnight();
//        org.joda.time.DateTime dateTime35 = localDate10.toDateTime((org.joda.time.ReadableInstant) dateMidnight34);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2018 + "'", int11 == 2018);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 83243 + "'", int33 == 83243);
//        org.junit.Assert.assertNotNull(dateMidnight34);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.io.Writer writer2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone4);
        int int6 = dateTime5.getEra();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        long long7 = delegatedDateTimeField5.roundCeiling(1L);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology16 = localDate15.getChronology();
//        java.lang.String str17 = localDate15.toString();
//        int int18 = localDate15.size();
//        org.joda.time.LocalDate localDate20 = localDate15.withYearOfEra(2019);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = delegatedDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate15, 159, locale22);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2018-11-03" + "'", str17.equals("2018-11-03"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "159" + "'", str23.equals("159"));
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"[]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone15);
        org.joda.time.Chronology chronology17 = buddhistChronology12.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone15);
        java.lang.String str19 = dateTimeZone15.getID();
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime28 = null;
        org.joda.time.DateTime dateTime29 = localDate27.toDateTime(localTime28);
        org.joda.time.DateTime dateTime31 = dateTime29.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property32 = dateTime31.monthOfYear();
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.minus(readableDuration33);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone37);
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone37);
        org.joda.time.Chronology chronology40 = gJChronology35.withZone(dateTimeZone37);
        try {
            org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((int) (short) 0, 134, (int) '#', 83195, 1439, dateTimeZone37);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83195 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(buddhistChronology39);
        org.junit.Assert.assertNotNull(chronology40);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.clockhourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, 0, 2000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
//        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
//        java.lang.String str14 = dateTimeZone10.getID();
//        java.util.TimeZone timeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
//        org.joda.time.LocalDate localDate22 = localDate20.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime23 = null;
//        org.joda.time.DateTime dateTime24 = localDate22.toDateTime(localTime23);
//        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.minus(readableDuration28);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime26);
//        java.lang.String str31 = gJChronology30.toString();
//        org.joda.time.Chronology chronology32 = gJChronology30.withUTC();
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "GJChronology[UTC,cutover=2018-11-03T23:07:24.108Z]" + "'", str31.equals("GJChronology[UTC,cutover=2018-11-03T23:07:24.108Z]"));
//        org.junit.Assert.assertNotNull(chronology32);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime8 = dateTime1.withMillisOfSecond((int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime dateTime12 = dateTime8.toDateTime(chronology11);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withMonthOfYear(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        int int10 = localDate7.getEra();
        org.joda.time.LocalDate.Property property11 = localDate7.weekOfWeekyear();
        try {
            org.joda.time.LocalDate localDate13 = localDate7.withEra(8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
//        int int15 = dateTime11.getSecondOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime17 = property16.withMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 83244 + "'", int15 == 83244);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        java.lang.String str5 = dateTimeFormatter3.print((long) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZone(dateTimeZone6);
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) instant1, (java.lang.Object) dateTimeFormatter3);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970001" + "'", str5.equals("1970001"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", 44);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("LimitChronology[BuddhistChronology[AD], 0269-05-22T00:01:00.001Z, 1970-01-01T00:00:00.001Z]", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.setStandardOffset(1439);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        int int10 = dateTime9.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2018 + "'", int10 == 2018);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int8 = offsetDateTimeField5.getMinimumValue();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
        org.joda.time.DateTimeField[] dateTimeFieldArray17 = localDate14.getFields();
        int[] intArray18 = null;
        int int19 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate14, intArray18);
        boolean boolean20 = offsetDateTimeField5.isSupported();
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTimeZone22.getName(0L, locale24);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(dateTimeZone22);
        org.joda.time.LocalDate localDate28 = localDate26.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime29 = null;
        org.joda.time.DateTime dateTime30 = localDate28.toDateTime(localTime29);
        org.joda.time.LocalDate.Property property31 = localDate28.yearOfCentury();
        org.joda.time.LocalDate.Property property32 = localDate28.monthOfYear();
        org.joda.time.LocalDate localDate34 = localDate28.withYearOfEra(10);
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate28, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'clockhourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83219 + "'", int19 == 83219);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(localDate34);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
        int int9 = delegatedDateTimeField7.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getName(0L, locale4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 100, dateTimeZone2);
        try {
            org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) 1386, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1969");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
        boolean boolean16 = dateTime14.isAfter((long) 57973);
        org.joda.time.DateTime dateTime18 = dateTime14.plusYears((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2018", "DateTimeField[minuteOfHour]", (int) (byte) -1, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        boolean boolean20 = skipDateTimeField19.isLenient();
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipDateTimeField19.getAsShortText(3, locale22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) (byte) 0);
        org.joda.time.LocalTime localTime28 = dateTime25.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        boolean boolean30 = localTime28.isSupported(dateTimeFieldType29);
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology33);
        java.util.TimeZone timeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
        java.util.Locale locale38 = null;
        java.lang.String str39 = dateTimeZone36.getName(0L, locale38);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(dateTimeZone36);
        java.util.Date date41 = localDate40.toDate();
        int[] intArray43 = buddhistChronology33.get((org.joda.time.ReadablePartial) localDate40, (long) (short) -1);
        org.joda.time.DurationField durationField44 = buddhistChronology33.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology46);
        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType49);
        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology33, (org.joda.time.DateTimeField) delegatedDateTimeField50);
        long long53 = delegatedDateTimeField50.roundHalfFloor((long) (byte) 100);
        java.util.Locale locale55 = null;
        java.lang.String str56 = delegatedDateTimeField50.getAsShortText((long) (-1), locale55);
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getChronology(chronology57);
        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate(chronology58);
        java.util.TimeZone timeZone60 = null;
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.forTimeZone(timeZone60);
        java.util.Locale locale63 = null;
        java.lang.String str64 = dateTimeZone61.getName(0L, locale63);
        org.joda.time.LocalDate localDate65 = new org.joda.time.LocalDate(dateTimeZone61);
        org.joda.time.LocalDate localDate67 = localDate65.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime68 = null;
        org.joda.time.DateTime dateTime69 = localDate67.toDateTime(localTime68);
        boolean boolean70 = localDate59.isAfter((org.joda.time.ReadablePartial) localDate67);
        org.joda.time.LocalDate localDate72 = localDate59.plusYears((int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology74 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology74);
        java.util.TimeZone timeZone76 = null;
        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeZone.forTimeZone(timeZone76);
        java.util.Locale locale79 = null;
        java.lang.String str80 = dateTimeZone77.getName(0L, locale79);
        org.joda.time.LocalDate localDate81 = new org.joda.time.LocalDate(dateTimeZone77);
        java.util.Date date82 = localDate81.toDate();
        int[] intArray84 = buddhistChronology74.get((org.joda.time.ReadablePartial) localDate81, (long) (short) -1);
        int int85 = delegatedDateTimeField50.getMaximumValue((org.joda.time.ReadablePartial) localDate59, intArray84);
        java.util.Locale locale87 = null;
        try {
            int[] intArray88 = skipDateTimeField19.set((org.joda.time.ReadablePartial) localTime28, 1969, intArray84, "(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")", locale87);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "3" + "'", str23.equals("3"));
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+00:00" + "'", str39.equals("+00:00"));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "59" + "'", str56.equals("59"));
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "+00:00" + "'", str64.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(localDate72);
        org.junit.Assert.assertNotNull(buddhistChronology74);
        org.junit.Assert.assertNotNull(dateTimeZone77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "+00:00" + "'", str80.equals("+00:00"));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 59 + "'", int85 == 59);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundCeiling(1L);
        boolean boolean9 = delegatedDateTimeField5.isLeap(83188324L);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60000L + "'", long7 == 60000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(11);
//        int int16 = dateTime15.getHourOfDay();
//        org.joda.time.DateTime dateTime18 = dateTime15.plusSeconds(0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int8 = offsetDateTimeField5.getMinimumValue();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
        org.joda.time.DateTimeField[] dateTimeFieldArray17 = localDate14.getFields();
        int[] intArray18 = null;
        int int19 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate14, intArray18);
        boolean boolean20 = offsetDateTimeField5.isSupported();
        int int22 = offsetDateTimeField5.getLeapAmount((-60499699140032L));
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField5.getMaximumTextLength(locale23);
        long long27 = offsetDateTimeField5.add(59968L, 57977);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83219 + "'", int19 == 83219);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 208717259968L + "'", long27 == 208717259968L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime13 = null;
        org.joda.time.DateTime dateTime14 = localDate12.toDateTime(localTime13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime18 = dateTime14.withMinuteOfHour(1);
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.DateTime dateTime21 = dateTime18.withCenturyOfEra(2);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime24 = dateTime22.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime26 = dateTime22.minusDays(0);
        int int27 = dateTime26.getYearOfCentury();
        org.joda.time.DateTime dateTime29 = dateTime26.withMillis((long) '4');
        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime21, (org.joda.time.ReadableDateTime) dateTime26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean36 = fixedDateTimeZone35.isFixed();
        long long38 = fixedDateTimeZone35.previousTransition(0L);
        org.joda.time.Chronology chronology39 = limitChronology30.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        org.joda.time.LocalDateTime localDateTime40 = null;
        boolean boolean41 = fixedDateTimeZone35.isLocalDateTimeGap(localDateTime40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = fixedDateTimeZone35.getName((long) 69, locale43);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(limitChronology30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "+00:00" + "'", str44.equals("+00:00"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int8 = offsetDateTimeField5.getMinimumValue();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
        org.joda.time.DateTimeField[] dateTimeFieldArray17 = localDate14.getFields();
        int[] intArray18 = null;
        int int19 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate14, intArray18);
        long long21 = offsetDateTimeField5.roundHalfFloor(0L);
        boolean boolean22 = offsetDateTimeField5.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83219 + "'", int19 == 83219);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        boolean boolean3 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalDate localDate5 = localDate2.minusWeeks((int) (short) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.yearOfCentury();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("97", dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(localDate2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, 3);
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology3.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 57973, dateTimeZone4);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
//        java.util.Date date12 = localDate11.toDate();
//        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
//        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
//        long long26 = skipDateTimeField22.remainder((long) (short) 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology28.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now(dateTimeZone31);
//        org.joda.time.Chronology chronology33 = buddhistChronology28.withZone(dateTimeZone31);
//        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology28.centuryOfEra();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology36);
//        java.util.TimeZone timeZone38 = null;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = dateTimeZone39.getName(0L, locale41);
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(dateTimeZone39);
//        java.util.Date date44 = localDate43.toDate();
//        int[] intArray46 = buddhistChronology36.get((org.joda.time.ReadablePartial) localDate43, (long) (short) -1);
//        org.joda.time.DurationField durationField47 = buddhistChronology36.eras();
//        java.util.TimeZone timeZone48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forTimeZone(timeZone48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dateTimeZone49.getName(0L, locale51);
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(dateTimeZone49);
//        org.joda.time.LocalDate localDate55 = localDate53.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology56 = localDate55.getChronology();
//        long long58 = buddhistChronology36.set((org.joda.time.ReadablePartial) localDate55, 0L);
//        org.joda.time.LocalDate.Property property59 = localDate55.weekyear();
//        org.joda.time.LocalTime localTime60 = null;
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        org.joda.time.DateTime dateTime63 = localDate55.toDateTime(localTime60, dateTimeZone62);
//        org.joda.time.DateTime.Property property64 = dateTime63.minuteOfHour();
//        java.util.TimeZone timeZone65 = null;
//        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = dateTimeZone66.getName(0L, locale68);
//        org.joda.time.LocalDate localDate70 = new org.joda.time.LocalDate(dateTimeZone66);
//        org.joda.time.LocalDate localDate72 = localDate70.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime73 = null;
//        org.joda.time.DateTime dateTime74 = localDate72.toDateTime(localTime73);
//        org.joda.time.LocalDate.Property property75 = localDate72.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = localDate72.getFieldType(0);
//        org.joda.time.DateTime dateTime79 = dateTime63.withField(dateTimeFieldType77, 5);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType77, "hi!");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField83 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType77, (int) (short) 10);
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField85 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, dateTimeFieldType77, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "+00:00" + "'", str42.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "+00:00" + "'", str52.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(chronology56);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-15593472000000L) + "'", long58 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "+00:00" + "'", str69.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//        org.junit.Assert.assertNotNull(dateTime79);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        java.lang.String str6 = dateTimeZone1.getID();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        try {
            long long15 = julianChronology7.getDateTimeMillis(4, (int) (byte) 10, 2000, 0, (int) '4', 12, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
        org.junit.Assert.assertNotNull(julianChronology7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = dateTimeZone17.getName(0L, locale19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone17);
        org.joda.time.LocalDate localDate23 = localDate21.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime24 = null;
        org.joda.time.DateTime dateTime25 = localDate23.toDateTime(localTime24);
        org.joda.time.LocalDate.Property property26 = localDate23.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = localDate23.getFieldType(0);
        org.joda.time.LocalDate localDate30 = localDate5.withField(dateTimeFieldType28, 57968);
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 1L, "97");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType28, 57975, 4, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57975 for year must be in the range [4,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(localDate30);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        int int3 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = copticChronology2.withUTC();
        int int5 = copticChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.hourOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.dayOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        long long13 = skipUndoDateTimeField10.set((long) (byte) 1, 15);
        long long16 = skipUndoDateTimeField10.add(0L, 57968);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1209600001L + "'", long13 == 1209600001L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 5008435200000L + "'", long16 == 5008435200000L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970W013T160000-0800");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str5 = jodaTimePermission1.getActions();
        java.lang.String str6 = jodaTimePermission1.toString();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone8.getName(0L, locale10);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone8);
        org.joda.time.LocalDate localDate14 = localDate12.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime15 = null;
        org.joda.time.DateTime dateTime16 = localDate14.toDateTime(localTime15);
        org.joda.time.DateTime dateTime18 = dateTime16.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property19 = dateTime18.monthOfYear();
        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime18.plusHours(11);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfCentury();
        boolean boolean24 = jodaTimePermission1.equals((java.lang.Object) dateTime22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(permissionCollection4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")" + "'", str6.equals("(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        int int8 = localDate7.getDayOfWeek();
//        org.joda.time.LocalDate localDate10 = localDate7.withWeekyear(83219);
//        org.joda.time.DateTime dateTime11 = localDate10.toDateTimeAtStartOfDay();
//        org.joda.time.LocalDate.Property property12 = localDate10.weekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone0.getOffset(readableInstant2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.lang.String str5 = dateTimeZone4.getID();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Partial partial5 = partial1.withChronologyRetainFields((org.joda.time.Chronology) copticChronology4);
        org.joda.time.Chronology chronology6 = partial5.getChronology();
        java.lang.String str8 = partial5.toString("[]");
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
        boolean boolean19 = dateTimeZone14.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime20 = localDate10.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology(chronology21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(chronology22);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName(0L, locale27);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone25);
        org.joda.time.LocalDate localDate31 = localDate29.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime32 = null;
        org.joda.time.DateTime dateTime33 = localDate31.toDateTime(localTime32);
        boolean boolean34 = localDate23.isAfter((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.LocalDate localDate36 = localDate23.plusYears((int) 'a');
        boolean boolean37 = localDate10.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate localDate39 = localDate10.plusWeeks((-1));
        org.joda.time.DateTime dateTime40 = dateTime2.withFields((org.joda.time.ReadablePartial) localDate10);
        int int41 = dateTime40.getMinuteOfHour();
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology(chronology42);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(chronology43);
        java.util.TimeZone timeZone45 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forTimeZone(timeZone45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dateTimeZone46.getName(0L, locale48);
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate(dateTimeZone46);
        org.joda.time.LocalDate localDate52 = localDate50.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime53 = null;
        org.joda.time.DateTime dateTime54 = localDate52.toDateTime(localTime53);
        boolean boolean55 = localDate44.isAfter((org.joda.time.ReadablePartial) localDate52);
        int[] intArray56 = localDate44.getValues();
        org.joda.time.LocalDate localDate58 = localDate44.minusDays(4);
        org.joda.time.DateTime dateTime59 = dateTime40.withFields((org.joda.time.ReadablePartial) localDate58);
        java.util.Locale locale61 = null;
        try {
            java.lang.String str62 = dateTime40.toString("GJChronology[UTC]", locale61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 59 + "'", int41 == 59);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+00:00" + "'", str49.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(dateTime59);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int8 = fixedDateTimeZone4.getOffset((-11L));
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 19");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
        java.util.Date date12 = localDate11.toDate();
        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField22.getAsShortText(83219, locale26);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "83219" + "'", str27.equals("83219"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        boolean boolean2 = dateTimeFormatter0.isParser();
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = dateTimeZone17.getName(0L, locale19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone17);
        java.util.Date date22 = localDate21.toDate();
        int[] intArray24 = buddhistChronology14.get((org.joda.time.ReadablePartial) localDate21, (long) (short) -1);
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate21, (int) 'a', locale26);
        org.joda.time.DateTime dateTime28 = localDate21.toDateTimeAtMidnight();
        org.joda.time.LocalDate localDate30 = localDate21.withYearOfCentury(20);
        try {
            dateTimeFormatter0.printTo(appendable4, (org.joda.time.ReadablePartial) localDate21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "97" + "'", str27.equals("97"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate30);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField5.getType();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.weekyearOfCentury();
        java.lang.String str13 = buddhistChronology11.toString();
        try {
            org.joda.time.Partial partial14 = new org.joda.time.Partial(dateTimeFieldType6, 83244, (org.joda.time.Chronology) buddhistChronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83244 for clockhourOfDay must not be larger than 24");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "BuddhistChronology[UTC]" + "'", str13.equals("BuddhistChronology[UTC]"));
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
//        int int8 = offsetDateTimeField5.getMinimumValue();
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray17 = localDate14.getFields();
//        int[] intArray18 = null;
//        int int19 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) localDate14, intArray18);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology28 = localDate27.getChronology();
//        java.lang.String str29 = localDate27.toString();
//        int int30 = localDate27.size();
//        org.joda.time.LocalDate localDate32 = localDate27.withYearOfEra(2019);
//        int[] intArray36 = new int[] { 2019, 2, 365 };
//        int int37 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate27, intArray36);
//        long long39 = offsetDateTimeField5.roundFloor(9700L);
//        long long42 = offsetDateTimeField5.add((long) (byte) 0, 20);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 83219 + "'", int19 == 83219);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2018-11-03" + "'", str29.equals("2018-11-03"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 83196 + "'", int37 == 83196);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 72000000L + "'", long42 == 72000000L);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        int int7 = offsetDateTimeField5.get((long) 86399);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 83219 + "'", int7 == 83219);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime13 = dateTime9.withMinuteOfHour(1);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.minus(readableDuration14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now(dateTimeZone16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        int int19 = dateTimeZone16.getOffset(readableInstant18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.DateTime dateTime21 = dateTime13.withZone(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.DateTime dateTime14 = property12.addToCopy(0);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) (byte) 100);
//        int int18 = property12.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        int int19 = dateTime17.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.monthOfYear();
        boolean boolean12 = property11.isLeap();
        java.lang.String str13 = property11.toString();
        org.joda.time.LocalDate localDate15 = property11.addToCopy(365);
        org.joda.time.LocalDate localDate16 = property11.roundHalfFloorCopy();
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate16);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType19 = partial17.getFieldType(7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[monthOfYear]" + "'", str13.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AD" + "'", str12.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYear(0, 18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendFractionOfDay(0, 307);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatterBuilder15.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendWeekOfWeekyear((int) 'a');
        boolean boolean23 = dateTimeFormatterBuilder20.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter30 = dateTimeFormatterBuilder29.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatterBuilder31.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatterBuilder31.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder20.append(dateTimePrinter30, dateTimeParser36);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatterBuilder45.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser50 = dateTimeFormatterBuilder45.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder44.append(dateTimeParser50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder52.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder55.appendWeekOfWeekyear((int) 'a');
        boolean boolean58 = dateTimeFormatterBuilder55.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder59.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter65 = dateTimeFormatterBuilder64.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder66.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatterBuilder66.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser71 = dateTimeFormatterBuilder66.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder55.append(dateTimePrinter65, dateTimeParser71);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray73 = new org.joda.time.format.DateTimeParser[] { dateTimeParser36, dateTimeParser39, dateTimeParser50, dateTimeParser71 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder9.append(dateTimePrinter16, dateTimeParserArray73);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder74.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder74.appendClockhourOfDay(307);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap79 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder74.appendTimeZoneName(strMap79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimePrinter30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeParser50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimePrinter65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(dateTimeParser71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
        org.junit.Assert.assertNotNull(dateTimeParserArray73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
        org.junit.Assert.assertNotNull(strMap79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime13 = null;
        org.joda.time.DateTime dateTime14 = localDate12.toDateTime(localTime13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (short) 0);
        org.joda.time.DateTime dateTime18 = dateTime14.withMinuteOfHour(1);
        int int19 = dateTime18.getMonthOfYear();
        org.joda.time.DateTime dateTime21 = dateTime18.withCenturyOfEra(2);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime24 = dateTime22.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime26 = dateTime22.minusDays(0);
        int int27 = dateTime26.getYearOfCentury();
        org.joda.time.DateTime dateTime29 = dateTime26.withMillis((long) '4');
        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime21, (org.joda.time.ReadableDateTime) dateTime26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean36 = fixedDateTimeZone35.isFixed();
        long long38 = fixedDateTimeZone35.previousTransition(0L);
        org.joda.time.Chronology chronology39 = limitChronology30.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        org.joda.time.LocalDateTime localDateTime40 = null;
        boolean boolean41 = fixedDateTimeZone35.isLocalDateTimeGap(localDateTime40);
        boolean boolean43 = fixedDateTimeZone35.isStandardOffset((-38262179981L));
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(limitChronology30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getName(0L, locale18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone16);
        org.joda.time.LocalDate localDate22 = localDate20.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime23 = null;
        org.joda.time.DateTime dateTime24 = localDate22.toDateTime(localTime23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property27 = dateTime26.monthOfYear();
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.minus(readableDuration28);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone32);
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
        org.joda.time.Chronology chronology35 = gJChronology30.withZone(dateTimeZone32);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        org.joda.time.LocalDateTime localDateTime41 = null;
        boolean boolean42 = fixedDateTimeZone40.isLocalDateTimeGap(localDateTime41);
        org.joda.time.Chronology chronology43 = gJChronology30.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone40);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chronology43);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 0);
//        int int4 = dateTime3.getHourOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 23 + "'", int4 == 23);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = buddhistChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone10);
        java.lang.String str14 = dateTimeZone10.getID();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.weekyear();
        org.joda.time.DurationField durationField17 = buddhistChronology15.days();
        try {
            long long25 = buddhistChronology15.getDateTimeMillis(2019, (int) ' ', 84, 2000, 44, 159, 83217);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int8 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.DurationField durationField9 = offsetDateTimeField5.getRangeDurationField();
        int int10 = offsetDateTimeField5.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83196 + "'", int8 == 83196);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 83219 + "'", int10 == 83219);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology9);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = dateTimeZone12.getName(0L, locale14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone12);
        java.util.Date date17 = localDate16.toDate();
        int[] intArray19 = buddhistChronology9.get((org.joda.time.ReadablePartial) localDate16, (long) (short) -1);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDate16, (int) 'a', locale21);
        boolean boolean23 = delegatedDateTimeField7.isSupported();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "97" + "'", str22.equals("97"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
        int int15 = property13.getLeapAmount();
        java.util.Locale locale16 = null;
        int int17 = property13.getMaximumTextLength(locale16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long4 = buddhistChronology0.add((long) 57968, (long) (short) 1, 2000);
        org.joda.time.DurationField durationField5 = buddhistChronology0.eras();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 59968L + "'", long4 == 59968L);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int9 = offsetDateTimeField5.getMaximumValue((long) (short) 1);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField5.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField5.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 83219 + "'", int9 == 83219);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Partial partial5 = partial1.withChronologyRetainFields((org.joda.time.Chronology) copticChronology4);
        java.lang.String str6 = partial1.toStringList();
        int int7 = partial1.size();
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        org.joda.time.LocalDate.Property property24 = localDate20.weekyear();
//        org.joda.time.LocalTime localTime25 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        org.joda.time.DateTime dateTime28 = localDate20.toDateTime(localTime25, dateTimeZone27);
//        int int29 = dateTime28.getEra();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology31);
//        java.util.TimeZone timeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forTimeZone(timeZone33);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = dateTimeZone34.getName(0L, locale36);
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate(dateTimeZone34);
//        java.util.Date date39 = localDate38.toDate();
//        int[] intArray41 = buddhistChronology31.get((org.joda.time.ReadablePartial) localDate38, (long) (short) -1);
//        org.joda.time.DurationField durationField42 = buddhistChronology31.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology44);
//        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology44.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46, dateTimeFieldType47);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology31, (org.joda.time.DateTimeField) delegatedDateTimeField48);
//        long long51 = delegatedDateTimeField48.roundHalfFloor((long) (byte) 100);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = delegatedDateTimeField48.getAsShortText((long) (-1), locale53);
//        org.joda.time.Chronology chronology55 = null;
//        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getChronology(chronology55);
//        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate(chronology56);
//        java.util.TimeZone timeZone58 = null;
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forTimeZone(timeZone58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = dateTimeZone59.getName(0L, locale61);
//        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate(dateTimeZone59);
//        org.joda.time.LocalDate localDate65 = localDate63.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime66 = null;
//        org.joda.time.DateTime dateTime67 = localDate65.toDateTime(localTime66);
//        boolean boolean68 = localDate57.isAfter((org.joda.time.ReadablePartial) localDate65);
//        org.joda.time.LocalDate localDate70 = localDate57.plusYears((int) 'a');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology72);
//        java.util.TimeZone timeZone74 = null;
//        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeZone.forTimeZone(timeZone74);
//        java.util.Locale locale77 = null;
//        java.lang.String str78 = dateTimeZone75.getName(0L, locale77);
//        org.joda.time.LocalDate localDate79 = new org.joda.time.LocalDate(dateTimeZone75);
//        java.util.Date date80 = localDate79.toDate();
//        int[] intArray82 = buddhistChronology72.get((org.joda.time.ReadablePartial) localDate79, (long) (short) -1);
//        int int83 = delegatedDateTimeField48.getMaximumValue((org.joda.time.ReadablePartial) localDate57, intArray82);
//        org.joda.time.DateTime dateTime84 = dateTime28.withFields((org.joda.time.ReadablePartial) localDate57);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593472000000L) + "'", long23 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+00:00" + "'", str37.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(buddhistChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "59" + "'", str54.equals("59"));
//        org.junit.Assert.assertNotNull(chronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "+00:00" + "'", str62.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(buddhistChronology72);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "+00:00" + "'", str78.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(intArray82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 59 + "'", int83 == 59);
//        org.junit.Assert.assertNotNull(dateTime84);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.dayOfYear();
        int int12 = property11.getLeapAmount();
        org.joda.time.LocalDate localDate14 = property11.addWrapFieldToCopy(57975);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.era();
        java.lang.Object obj4 = null;
        boolean boolean5 = buddhistChronology0.equals(obj4);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Nov", (java.lang.Number) 10, (java.lang.Number) (short) 100, (java.lang.Number) 69);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField5.getAsText((long) 2018, locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "83219" + "'", str10.equals("83219"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology1.withZone(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean13 = fixedDateTimeZone12.isFixed();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int16 = fixedDateTimeZone12.getOffset((-11L));
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.Chronology chronology18 = iSOChronology7.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(chronology18);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone0.getName((long) 59, locale3);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970W013T160000-0800");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str5 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(dateTimeZone7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        int int10 = dateTimeZone7.getOffset(readableInstant9);
        jodaTimePermission1.checkGuard((java.lang.Object) int10);
        java.lang.String str12 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(permissionCollection4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970W013T160000-0800" + "'", str12.equals("1970W013T160000-0800"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 3, 100);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gregorianChronology0);
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((int) (short) 10, 24, 159, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3L + "'", long5 == 3L);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatterBuilder5.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatterBuilder5.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.append(dateTimeParser10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendTimeZoneOffset("[]", true, 307, 57982);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.hours();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) 11, dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.DateTime dateTime12 = dateTime9.plusMinutes(2019);
        org.joda.time.DateTime.Property property13 = dateTime9.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        org.joda.time.LocalDate.Property property24 = localDate20.monthOfYear();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593472000000L) + "'", long23 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(property24);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        int int7 = offsetDateTimeField5.getMaximumValue(83195L);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.LocalDate localDate18 = localDate15.withPeriodAdded(readablePeriod16, 0);
//        int int19 = localDate18.getWeekyear();
//        java.util.Date date20 = localDate18.toDate();
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.fromDateFields(date20);
//        java.lang.String str22 = localDate21.toString();
//        org.joda.time.LocalDate.Property property23 = localDate21.centuryOfEra();
//        java.util.Locale locale24 = null;
//        try {
//            java.lang.String str25 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate21, locale24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'clockhourOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 83219 + "'", int7 == 83219);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2018 + "'", int19 == 2018);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2018-11-03" + "'", str22.equals("2018-11-03"));
//        org.junit.Assert.assertNotNull(property23);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("1970W013T160000-0800");
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(dateTimeFieldType8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime14 = property13.roundFloorCopy();
        int int15 = property13.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "83200");
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendDayOfYear(7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "minuteOfHour", 1, 0);
        org.joda.time.Chronology chronology14 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(chronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology5);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone8.getName(0L, locale10);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone8);
        java.util.Date date13 = localDate12.toDate();
        int[] intArray15 = buddhistChronology5.get((org.joda.time.ReadablePartial) localDate12, (long) (short) -1);
        org.joda.time.DurationField durationField16 = buddhistChronology5.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology18.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, (org.joda.time.DateTimeField) delegatedDateTimeField22);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, (org.joda.time.DateTimeField) skipDateTimeField23, (int) (byte) 10);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipDateTimeField23);
        int int27 = skipDateTimeField23.getMinimumValue();
        long long30 = skipDateTimeField23.add(208717259968L, 12);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 208717979968L + "'", long30 == 208717979968L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = offsetDateTimeField5.getType();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField5.getMaximumValue(readablePartial7);
        java.lang.String str9 = offsetDateTimeField5.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83219 + "'", int8 == 83219);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str9.equals("DateTimeField[clockhourOfDay]"));
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
//        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime13 = null;
//        org.joda.time.DateTime dateTime14 = localDate12.toDateTime(localTime13);
//        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (short) 0);
//        org.joda.time.DateTime dateTime18 = dateTime14.withMinuteOfHour(1);
//        int int19 = dateTime18.getMonthOfYear();
//        org.joda.time.DateTime dateTime21 = dateTime18.withCenturyOfEra(2);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime24 = dateTime22.withMillisOfDay((int) (byte) 100);
//        org.joda.time.DateTime dateTime26 = dateTime22.minusDays(0);
//        int int27 = dateTime26.getYearOfCentury();
//        org.joda.time.DateTime dateTime29 = dateTime26.withMillis((long) '4');
//        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime21, (org.joda.time.ReadableDateTime) dateTime26);
//        java.lang.String str31 = limitChronology30.toString();
//        org.joda.time.DateTimeField dateTimeField32 = limitChronology30.dayOfYear();
//        java.lang.String str33 = limitChronology30.toString();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(limitChronology30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "LimitChronology[BuddhistChronology[AD], 0218-11-03T23:01:30.599Z, 2019-06-15T23:07:30.600Z]" + "'", str31.equals("LimitChronology[BuddhistChronology[AD], 0218-11-03T23:01:30.599Z, 2019-06-15T23:07:30.600Z]"));
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "LimitChronology[BuddhistChronology[AD], 0218-11-03T23:01:30.599Z, 2019-06-15T23:07:30.600Z]" + "'", str33.equals("LimitChronology[BuddhistChronology[AD], 0218-11-03T23:01:30.599Z, 2019-06-15T23:07:30.600Z]"));
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = zonedChronology3.getZone();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long20 = delegatedDateTimeField18.roundCeiling(1L);
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology24);
        java.util.TimeZone timeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = dateTimeZone27.getName(0L, locale29);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate(dateTimeZone27);
        java.util.Date date32 = localDate31.toDate();
        int[] intArray34 = buddhistChronology24.get((org.joda.time.ReadablePartial) localDate31, (long) (short) -1);
        org.joda.time.DurationField durationField35 = buddhistChronology24.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology37);
        org.joda.time.DateTimeField dateTimeField39 = buddhistChronology37.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39, dateTimeFieldType40);
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology24, (org.joda.time.DateTimeField) delegatedDateTimeField41);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray50 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
        int int51 = delegatedDateTimeField41.getMinimumValue(readablePartial43, intArray50);
        int[] intArray53 = delegatedDateTimeField18.add(readablePartial21, (int) '#', intArray50, 0);
        try {
            zonedChronology3.validate((org.joda.time.ReadablePartial) localDate12, intArray53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 60000L + "'", long20 == 60000L);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00" + "'", str30.equals("+00:00"));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray53);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology(chronology15);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(chronology16);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName(0L, locale21);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone19);
//        org.joda.time.LocalDate localDate25 = localDate23.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime26 = null;
//        org.joda.time.DateTime dateTime27 = localDate25.toDateTime(localTime26);
//        boolean boolean28 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate25);
//        org.joda.time.DateTime dateTime29 = dateTime14.withFields((org.joda.time.ReadablePartial) localDate25);
//        org.joda.time.DateTime dateTime31 = dateTime14.withYearOfCentury(10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.dayOfWeek();
//        org.joda.time.Chronology chronology36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getChronology(chronology36);
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate(chronology37);
//        java.util.TimeZone timeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dateTimeZone40.getName(0L, locale42);
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone40);
//        org.joda.time.LocalDate localDate46 = localDate44.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime47 = null;
//        org.joda.time.DateTime dateTime48 = localDate46.toDateTime(localTime47);
//        boolean boolean49 = localDate38.isAfter((org.joda.time.ReadablePartial) localDate46);
//        java.util.TimeZone timeZone50 = null;
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forTimeZone(timeZone50);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = dateTimeZone51.getName(0L, locale53);
//        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(dateTimeZone51);
//        org.joda.time.LocalDate localDate57 = localDate55.minusWeeks((int) ' ');
//        boolean boolean58 = localDate46.isBefore((org.joda.time.ReadablePartial) localDate55);
//        org.joda.time.LocalDate localDate60 = localDate55.plusWeeks((int) (byte) 10);
//        long long62 = gregorianChronology32.set((org.joda.time.ReadablePartial) localDate55, (long) 57968);
//        org.joda.time.DateTime dateTime63 = dateTime31.withFields((org.joda.time.ReadablePartial) localDate55);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+00:00" + "'", str43.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "+00:00" + "'", str54.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(localDate60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560556857968L + "'", long62 == 1560556857968L);
//        org.junit.Assert.assertNotNull(dateTime63);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology9);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = dateTimeZone12.getName(0L, locale14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(dateTimeZone12);
        java.util.Date date17 = localDate16.toDate();
        int[] intArray19 = buddhistChronology9.get((org.joda.time.ReadablePartial) localDate16, (long) (short) -1);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDate16, (int) 'a', locale21);
        java.util.Locale locale25 = null;
        long long26 = delegatedDateTimeField7.set((long) (byte) 100, "37", locale25);
        long long29 = delegatedDateTimeField7.add((long) 44, (long) 4);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "97" + "'", str22.equals("97"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2220100L + "'", long26 == 2220100L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 240044L + "'", long29 == 240044L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendDayOfWeek(15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        long long9 = offsetDateTimeField5.roundCeiling((long) 83204);
        long long12 = offsetDateTimeField5.add((long) 83198, 100);
        long long15 = offsetDateTimeField5.getDifferenceAsLong(2440588L, 83188324L);
        org.joda.time.DurationField durationField16 = offsetDateTimeField5.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3600000L + "'", long9 == 3600000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 360083198L + "'", long12 == 360083198L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-22L) + "'", long15 == (-22L));
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        java.lang.String str4 = copticChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology10 = copticChronology2.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[AD,mdfw=3]" + "'", str4.equals("CopticChronology[AD,mdfw=3]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
        boolean boolean19 = dateTimeZone14.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime20 = localDate10.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology(chronology21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(chronology22);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName(0L, locale27);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone25);
        org.joda.time.LocalDate localDate31 = localDate29.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime32 = null;
        org.joda.time.DateTime dateTime33 = localDate31.toDateTime(localTime32);
        boolean boolean34 = localDate23.isAfter((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.LocalDate localDate36 = localDate23.plusYears((int) 'a');
        boolean boolean37 = localDate10.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate localDate39 = localDate10.plusWeeks((-1));
        org.joda.time.DateTime dateTime40 = dateTime2.withFields((org.joda.time.ReadablePartial) localDate10);
        int int41 = dateTime40.getMinuteOfHour();
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology(chronology42);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(chronology43);
        java.util.TimeZone timeZone45 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forTimeZone(timeZone45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dateTimeZone46.getName(0L, locale48);
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate(dateTimeZone46);
        org.joda.time.LocalDate localDate52 = localDate50.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime53 = null;
        org.joda.time.DateTime dateTime54 = localDate52.toDateTime(localTime53);
        boolean boolean55 = localDate44.isAfter((org.joda.time.ReadablePartial) localDate52);
        int[] intArray56 = localDate44.getValues();
        org.joda.time.LocalDate localDate58 = localDate44.minusDays(4);
        org.joda.time.DateTime dateTime59 = dateTime40.withFields((org.joda.time.ReadablePartial) localDate58);
        org.joda.time.DateTime dateTime61 = dateTime59.withCenturyOfEra(7);
        java.util.Locale locale62 = null;
        java.util.Calendar calendar63 = dateTime59.toCalendar(locale62);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 59 + "'", int41 == 59);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+00:00" + "'", str49.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(calendar63);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology2);
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = dateTime3.toCalendar(locale4);
        int int6 = dateTime3.getDayOfWeek();
        org.joda.time.DateTime dateTime8 = dateTime3.minusMillis((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime3.getZone();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) 83239, dateTimeZone9);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(calendar5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.yearOfCentury();
        org.joda.time.LocalDate.Property property11 = localDate7.dayOfYear();
        org.joda.time.LocalDate.Property property12 = localDate7.dayOfMonth();
        org.joda.time.LocalDate localDate13 = property12.roundCeilingCopy();
        org.joda.time.LocalDate localDate14 = property12.withMaximumValue();
        org.joda.time.LocalDate localDate16 = localDate14.withYear(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.DateTimeField[] dateTimeFieldArray8 = localDate5.getFields();
//        int int9 = localDate5.getDayOfMonth();
//        java.lang.String str10 = localDate5.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15" + "'", str10.equals("2019-06-15"));
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology4);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone7.getName(0L, locale9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone7);
        java.util.Date date12 = localDate11.toDate();
        int[] intArray14 = buddhistChronology4.get((org.joda.time.ReadablePartial) localDate11, (long) (short) -1);
        org.joda.time.DurationField durationField15 = buddhistChronology4.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) skipDateTimeField22, (int) (byte) 10);
        long long26 = skipDateTimeField22.remainder((long) (short) 1);
        int int27 = skipDateTimeField22.getMaximumValue();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 59 + "'", int27 == 59);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.hours();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getShortName((long) 'a', locale6);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-15593386022000L), (org.joda.time.Chronology) gregorianChronology1);
        try {
            long long15 = gregorianChronology1.getDateTimeMillis(57968, 15, 83195, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3, 3);
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
        try {
            long long13 = zonedChronology7.getDateTimeMillis((long) 18, 83196, (-83218), 5, 83236);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83196 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = dateTimeZone17.getName(0L, locale19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone17);
        org.joda.time.LocalDate localDate23 = localDate21.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime24 = null;
        org.joda.time.DateTime dateTime25 = localDate23.toDateTime(localTime24);
        org.joda.time.LocalDate.Property property26 = localDate23.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = localDate23.getFieldType(0);
        org.joda.time.LocalDate localDate30 = localDate5.withField(dateTimeFieldType28, 57968);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 0.0d, (java.lang.Number) (-60513955140032L), (java.lang.Number) 2440587.5000005555d);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(localDate30);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, 5008435200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970W013T160000-0800");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("1970W013T160000-0800");
        java.lang.String str5 = jodaTimePermission4.toString();
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission4.newPermissionCollection();
        jodaTimePermission4.checkGuard((java.lang.Object) 10.0d);
        java.lang.String str9 = jodaTimePermission4.toString();
        boolean boolean10 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        java.lang.String str11 = jodaTimePermission4.toString();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")"));
        org.junit.Assert.assertNotNull(permissionCollection6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")" + "'", str9.equals("(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")" + "'", str11.equals("(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        int int7 = offsetDateTimeField5.getMaximumValue(83195L);
        int int8 = offsetDateTimeField5.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 83219 + "'", int7 == 83219);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83195 + "'", int8 == 83195);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) ' ');
        org.joda.time.DateTime dateTime2 = instant1.toDateTimeISO();
        org.joda.time.DateTime dateTime4 = dateTime2.minusDays(83190);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.weekyear();
        org.joda.time.LocalDate localDate12 = property10.addWrapFieldToCopy((int) '#');
        org.joda.time.LocalDate localDate14 = property10.addToCopy(1970);
        java.util.Locale locale15 = null;
        int int16 = property10.getMaximumTextLength(locale15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField5.getMaximumTextLength(locale8);
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone11.getName(0L, locale13);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone11);
        org.joda.time.LocalDate localDate17 = localDate15.minusWeeks((int) ' ');
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate15, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'clockhourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
        boolean boolean19 = dateTimeZone14.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime20 = localDate10.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology(chronology21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(chronology22);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName(0L, locale27);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone25);
        org.joda.time.LocalDate localDate31 = localDate29.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime32 = null;
        org.joda.time.DateTime dateTime33 = localDate31.toDateTime(localTime32);
        boolean boolean34 = localDate23.isAfter((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.LocalDate localDate36 = localDate23.plusYears((int) 'a');
        boolean boolean37 = localDate10.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate localDate39 = localDate10.plusWeeks((-1));
        org.joda.time.DateTime dateTime40 = dateTime2.withFields((org.joda.time.ReadablePartial) localDate10);
        int int41 = dateTime40.getMinuteOfHour();
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getChronology(chronology42);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(chronology43);
        java.util.TimeZone timeZone45 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forTimeZone(timeZone45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = dateTimeZone46.getName(0L, locale48);
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate(dateTimeZone46);
        org.joda.time.LocalDate localDate52 = localDate50.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime53 = null;
        org.joda.time.DateTime dateTime54 = localDate52.toDateTime(localTime53);
        boolean boolean55 = localDate44.isAfter((org.joda.time.ReadablePartial) localDate52);
        int[] intArray56 = localDate44.getValues();
        org.joda.time.LocalDate localDate58 = localDate44.minusDays(4);
        org.joda.time.DateTime dateTime59 = dateTime40.withFields((org.joda.time.ReadablePartial) localDate58);
        org.joda.time.DateTime dateTime61 = dateTime59.withCenturyOfEra(7);
        org.joda.time.MutableDateTime mutableDateTime62 = dateTime59.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 59 + "'", int41 == 59);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+00:00" + "'", str49.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(mutableDateTime62);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = dateTimeZone17.getName(0L, locale19);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone17);
        org.joda.time.LocalDate localDate23 = localDate21.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime24 = null;
        org.joda.time.DateTime dateTime25 = localDate23.toDateTime(localTime24);
        org.joda.time.LocalDate.Property property26 = localDate23.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = localDate23.getFieldType(0);
        org.joda.time.LocalDate localDate30 = localDate5.withField(dateTimeFieldType28, 57968);
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 1L, "97");
        java.lang.Number number34 = illegalFieldValueException33.getUpperBound();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNull(number34);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 159, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone4);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, readableInstant7);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone10.getName(0L, locale12);
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(dateTimeZone10);
//        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime17 = null;
//        org.joda.time.DateTime dateTime18 = localDate16.toDateTime(localTime17);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property21 = dateTime20.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.minus(readableDuration22);
//        int int24 = dateTime20.getSecondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime20.plus(readablePeriod25);
//        boolean boolean27 = gJChronology8.equals((java.lang.Object) dateTime20);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology29);
//        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology29.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate33 = org.joda.time.LocalDate.now(dateTimeZone32);
//        org.joda.time.Chronology chronology34 = buddhistChronology29.withZone(dateTimeZone32);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
//        org.joda.time.MutableDateTime mutableDateTime36 = dateTime20.toMutableDateTime(dateTimeZone32);
//        int int39 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime36, "PST", (int) (byte) -1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W014T000000Z" + "'", str2.equals("1970W014T000000Z"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 83254 + "'", int24 == 83254);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(mutableDateTime36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder0.toFormatter();
//        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder0.toPrinter();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology8);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getName(0L, locale13);
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(dateTimeZone11);
//        java.util.Date date16 = localDate15.toDate();
//        int[] intArray18 = buddhistChronology8.get((org.joda.time.ReadablePartial) localDate15, (long) (short) -1);
//        org.joda.time.DurationField durationField19 = buddhistChronology8.eras();
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
//        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology28 = localDate27.getChronology();
//        long long30 = buddhistChronology8.set((org.joda.time.ReadablePartial) localDate27, 0L);
//        org.joda.time.LocalDate.Property property31 = localDate27.weekyear();
//        org.joda.time.LocalTime localTime32 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        org.joda.time.DateTime dateTime35 = localDate27.toDateTime(localTime32, dateTimeZone34);
//        org.joda.time.DateTime.Property property36 = dateTime35.minuteOfHour();
//        java.util.TimeZone timeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone38.getName(0L, locale40);
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(dateTimeZone38);
//        org.joda.time.LocalDate localDate44 = localDate42.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime45 = null;
//        org.joda.time.DateTime dateTime46 = localDate44.toDateTime(localTime45);
//        org.joda.time.LocalDate.Property property47 = localDate44.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = localDate44.getFieldType(0);
//        org.joda.time.DateTime dateTime51 = dateTime35.withField(dateTimeFieldType49, 5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType49, 10, 2561);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeParser5);
//        org.junit.Assert.assertNotNull(dateTimePrinter6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-15593472000000L) + "'", long30 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "+00:00" + "'", str41.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.DateTime dateTime12 = localDate10.toDateTime(localTime11);
        boolean boolean13 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate10);
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = dateTimeZone15.getName(0L, locale17);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(dateTimeZone15);
        org.joda.time.LocalDate localDate21 = localDate19.minusWeeks((int) ' ');
        boolean boolean22 = localDate10.isBefore((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.LocalDate localDate24 = localDate19.plusWeeks((int) (byte) 10);
        int int25 = localDate24.getCenturyOfEra();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 20 + "'", int25 == 20);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 83206);
        org.joda.time.DateTime dateTime3 = dateTime1.minusYears(11);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970W013T160000-0800");
        java.lang.String str2 = jodaTimePermission1.toString();
        boolean boolean4 = jodaTimePermission1.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"1970W013T160000-0800\")"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.LocalDate localDate30 = localDate27.withPeriodAdded(readablePeriod28, 0);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate30, 57977, locale32);
        long long36 = skipDateTimeField19.add(0L, 9);
        java.util.Locale locale39 = null;
        try {
            long long40 = skipDateTimeField19.set((-210696552000000L), "Nov", locale39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[AD])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "57977" + "'", str33.equals("57977"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 540000L + "'", long36 == 540000L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        try {
            long long10 = julianChronology0.getDateTimeMillis((-671497), 0, 0, 22, (int) (byte) 10, (-83218), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -83218 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        org.joda.time.Chronology chronology3 = copticChronology2.withUTC();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "minuteOfHour", 1, 0);
        org.joda.time.Chronology chronology15 = gJChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        java.lang.String str16 = gJChronology9.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GJChronology[AD]" + "'", str16.equals("GJChronology[AD]"));
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test358");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime8 = null;
//        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
//        org.joda.time.LocalDate.Property property10 = localDate7.weekyear();
//        int int11 = localDate7.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 44 + "'", int11 == 44);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.String str9 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[AD]" + "'", str9.equals("ISOChronology[AD]"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime28 = null;
        org.joda.time.DateTime dateTime29 = localDate27.toDateTime(localTime28);
        org.joda.time.LocalDate.Property property30 = localDate27.yearOfCentury();
        org.joda.time.LocalDate.Property property31 = localDate27.monthOfYear();
        org.joda.time.LocalDate localDate33 = localDate27.withYearOfEra(10);
        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) '4');
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate33, (int) '4', locale37);
        long long41 = skipDateTimeField19.add(208717259968L, (long) 2019);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "52" + "'", str38.equals("52"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 208838399968L + "'", long41 == 208838399968L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        int int2 = dateTime1.getMinuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.plus((long) 57977);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime1.toYearMonthDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder3.toFormatter();
        boolean boolean6 = dateTimeFormatter5.isOffsetParsed();
        try {
            org.joda.time.LocalTime localTime8 = dateTimeFormatter5.parseLocalTime("2019-06-16T00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-16T00\" is malformed at \"-06-16T00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("AD", "PST", (int) (byte) 0, 2018);
        boolean boolean9 = fixedDateTimeZone8.isFixed();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int12 = fixedDateTimeZone8.getOffset((-11L));
        long long14 = dateTimeZone2.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone8, (long) 83186);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 83186L + "'", long14 == 83186L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969365" + "'", str5.equals("1969365"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969365" + "'", str7.equals("1969365"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(zonedChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test366");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
//        java.util.Date date9 = localDate8.toDate();
//        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
//        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(dateTimeZone14);
//        org.joda.time.LocalDate localDate20 = localDate18.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology21 = localDate20.getChronology();
//        long long23 = buddhistChronology1.set((org.joda.time.ReadablePartial) localDate20, 0L);
//        org.joda.time.LocalDate.Property property24 = localDate20.weekyear();
//        org.joda.time.LocalTime localTime25 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        org.joda.time.DateTime dateTime28 = localDate20.toDateTime(localTime25, dateTimeZone27);
//        int int29 = dateTime28.getEra();
//        java.util.GregorianCalendar gregorianCalendar30 = dateTime28.toGregorianCalendar();
//        org.joda.time.DateTime.Property property31 = dateTime28.dayOfWeek();
//        try {
//            org.joda.time.DateTime dateTime33 = property31.setCopy("16");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"16\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-15593472000000L) + "'", long23 == (-15593472000000L));
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(gregorianCalendar30);
//        org.junit.Assert.assertNotNull(property31);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime3 = dateTime1.withHourOfDay(1);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.minus(readableDuration5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
        org.joda.time.DateTime dateTime10 = dateTime6.minusDays((-2812));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        int int11 = localDate10.getWeekyear();
//        java.util.Date date12 = localDate10.toDate();
//        org.joda.time.LocalDate localDate13 = org.joda.time.LocalDate.fromDateFields(date12);
//        java.lang.String str14 = localDate13.toString();
//        org.joda.time.LocalDate localDate16 = localDate13.withYear((int) (byte) 100);
//        int[] intArray17 = localDate13.getValues();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2018 + "'", int11 == 2018);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2018-11-03" + "'", str14.equals("2018-11-03"));
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(intArray17);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.LocalDate.Property property2 = localDate1.era();
        java.lang.String str3 = property2.getAsText();
        java.lang.String str4 = property2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AD" + "'", str3.equals("AD"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[era]" + "'", str4.equals("Property[era]"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getShortName((long) 'a', locale5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        java.util.TimeZone timeZone8 = dateTimeZone3.toTimeZone();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L);
        int int11 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime10);
        int int12 = dateTime10.getYearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 57973, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime2 = property1.roundCeilingCopy();
        int int3 = property1.getMinimumValue();
        java.util.Locale locale4 = null;
        int int5 = property1.getMaximumShortTextLength(locale4);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.LocalDate localDate12 = localDate10.minusWeeks((int) ' ');
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName(0L, locale16);
        boolean boolean19 = dateTimeZone14.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime20 = localDate10.toDateTimeAtStartOfDay(dateTimeZone14);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology(chronology21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(chronology22);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getName(0L, locale27);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(dateTimeZone25);
        org.joda.time.LocalDate localDate31 = localDate29.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime32 = null;
        org.joda.time.DateTime dateTime33 = localDate31.toDateTime(localTime32);
        boolean boolean34 = localDate23.isAfter((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.LocalDate localDate36 = localDate23.plusYears((int) 'a');
        boolean boolean37 = localDate10.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate localDate39 = localDate10.plusWeeks((-1));
        org.joda.time.DateTime dateTime40 = dateTime2.withFields((org.joda.time.ReadablePartial) localDate10);
        int int41 = localDate10.size();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(calendar4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3 + "'", int41 == 3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray27 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
        int int28 = delegatedDateTimeField18.getMinimumValue(readablePartial20, intArray27);
        long long30 = delegatedDateTimeField18.roundFloor((long) (byte) 1);
        int int31 = delegatedDateTimeField18.getMaximumValue();
        long long33 = delegatedDateTimeField18.roundHalfCeiling((-17154028800000L));
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = dateTimeZone35.getName(0L, locale37);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(dateTimeZone35);
        org.joda.time.LocalDate localDate41 = localDate39.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime42 = null;
        org.joda.time.DateTime dateTime43 = localDate41.toDateTime(localTime42);
        org.joda.time.LocalDate.Property property44 = localDate41.yearOfCentury();
        org.joda.time.LocalDate.Property property45 = localDate41.monthOfYear();
        boolean boolean46 = property45.isLeap();
        java.lang.String str47 = property45.toString();
        org.joda.time.LocalDate localDate49 = property45.addToCopy(365);
        org.joda.time.LocalDate localDate50 = property45.roundHalfFloorCopy();
        java.util.TimeZone timeZone51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
        java.util.Locale locale54 = null;
        java.lang.String str55 = dateTimeZone52.getName(0L, locale54);
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate(dateTimeZone52);
        org.joda.time.LocalDate localDate57 = localDate50.withFields((org.joda.time.ReadablePartial) localDate56);
        int int58 = localDate57.getYear();
        org.joda.time.LocalDate.Property property59 = localDate57.yearOfEra();
        org.joda.time.LocalDate localDate60 = property59.roundHalfCeilingCopy();
        int[] intArray61 = null;
        int int62 = delegatedDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) localDate60, intArray61);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 59 + "'", int31 == 59);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-17154028800000L) + "'", long33 == (-17154028800000L));
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+00:00" + "'", str38.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Property[monthOfYear]" + "'", str47.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "+00:00" + "'", str55.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("57977", 0, 15, 57982, '4', 83190, 57968, 365, false, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test378");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        int int11 = localDate10.getWeekyear();
//        org.joda.time.DurationFieldType durationFieldType12 = null;
//        boolean boolean13 = localDate10.isSupported(durationFieldType12);
//        int int14 = localDate10.getDayOfMonth();
//        int int15 = localDate10.getEra();
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName(0L, locale19);
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(dateTimeZone17);
//        org.joda.time.LocalDate localDate23 = localDate21.minusWeeks((int) ' ');
//        org.joda.time.LocalTime localTime24 = null;
//        org.joda.time.DateTime dateTime25 = localDate23.toDateTime(localTime24);
//        org.joda.time.DateTime dateTime27 = dateTime25.plusMillis((int) (short) 0);
//        org.joda.time.DateTime.Property property28 = dateTime27.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.minus(readableDuration29);
//        int int31 = dateTime27.getSecondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime27.plus(readablePeriod32);
//        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) int15, (java.lang.Object) dateTime33);
//        try {
//            org.joda.time.DateTime dateTime36 = dateTime33.withYearOfCentury(83219);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83219 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2018 + "'", int11 == 2018);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 83258 + "'", int31 == 83258);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("2018");
        org.junit.Assert.assertNotNull(localDate1);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology16 = localDate15.getChronology();
//        java.lang.String str17 = localDate15.toString();
//        int int18 = localDate15.size();
//        org.joda.time.LocalDate localDate20 = localDate15.withYearOfEra(2019);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology23);
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology23.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        long long29 = delegatedDateTimeField27.roundCeiling(1L);
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology33);
//        java.util.TimeZone timeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone36.getName(0L, locale38);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(dateTimeZone36);
//        java.util.Date date41 = localDate40.toDate();
//        int[] intArray43 = buddhistChronology33.get((org.joda.time.ReadablePartial) localDate40, (long) (short) -1);
//        org.joda.time.DurationField durationField44 = buddhistChronology33.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology46);
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType49);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology33, (org.joda.time.DateTimeField) delegatedDateTimeField50);
//        org.joda.time.ReadablePartial readablePartial52 = null;
//        int[] intArray59 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
//        int int60 = delegatedDateTimeField50.getMinimumValue(readablePartial52, intArray59);
//        int[] intArray62 = delegatedDateTimeField27.add(readablePartial30, (int) '#', intArray59, 0);
//        int[] intArray64 = offsetDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) localDate20, (int) (byte) 10, intArray62, 0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology72);
//        org.joda.time.DateTimeField dateTimeField74 = buddhistChronology72.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate76 = org.joda.time.LocalDate.now(dateTimeZone75);
//        org.joda.time.Chronology chronology77 = buddhistChronology72.withZone(dateTimeZone75);
//        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone75);
//        java.lang.String str79 = dateTimeZone75.getID();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology80 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone75);
//        org.joda.time.DurationField durationField81 = buddhistChronology80.eras();
//        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField83 = gregorianChronology82.era();
//        int int84 = gregorianChronology82.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField85 = gregorianChronology82.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField87 = new org.joda.time.field.OffsetDateTimeField(dateTimeField85, 83195);
//        long long89 = offsetDateTimeField87.roundHalfCeiling((long) '#');
//        java.util.Locale locale91 = null;
//        java.lang.String str92 = offsetDateTimeField87.getAsText((long) 2018, locale91);
//        org.joda.time.DateTimeFieldType dateTimeFieldType93 = offsetDateTimeField87.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField95 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, durationField81, dateTimeFieldType93, 22);
//        long long97 = remainderDateTimeField95.roundFloor(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2018-11-03" + "'", str17.equals("2018-11-03"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 60000L + "'", long29 == 60000L);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+00:00" + "'", str39.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertNotNull(buddhistChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertNotNull(chronology77);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "UTC" + "'", str79.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology80);
//        org.junit.Assert.assertNotNull(durationField81);
//        org.junit.Assert.assertNotNull(gregorianChronology82);
//        org.junit.Assert.assertNotNull(dateTimeField83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 4 + "'", int84 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField85);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "83219" + "'", str92.equals("83219"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType93);
//        org.junit.Assert.assertTrue("'" + long97 + "' != '" + 0L + "'", long97 == 0L);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.minuteOfHour();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField5 = buddhistChronology1.months();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMinutes((int) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now(dateTimeZone14);
        org.joda.time.Chronology chronology16 = buddhistChronology11.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime9.toDateTime(chronology16);
        int int18 = dateTime17.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20, 3);
        org.joda.time.DateTimeZone dateTimeZone23 = copticChronology22.getZone();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 57973, dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.plusMillis((int) '#');
        org.joda.time.DateTime dateTime28 = dateTime24.minusWeeks(57968);
        try {
            org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.ReadableDateTime) dateTime17, (org.joda.time.ReadableDateTime) dateTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral("AD");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.append(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours(11);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfMinute();
        org.joda.time.DateTime dateTime18 = property16.addWrapFieldToCopy((int) (short) 1);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime18.toMutableDateTime(chronology19);
        boolean boolean21 = mutableDateTime20.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 3);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3, 3);
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology5.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology2.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.Interval interval12 = localDate8.toInterval();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(interval12);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra(307, 1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendDayOfYear(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(chronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime11 = null;
        org.joda.time.DateTime dateTime12 = localDate10.toDateTime(localTime11);
        boolean boolean13 = localDate2.isAfter((org.joda.time.ReadablePartial) localDate10);
        int[] intArray14 = localDate2.getValues();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField16 = gregorianChronology15.hours();
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = dateTimeZone18.getShortName((long) 'a', locale20);
        org.joda.time.Chronology chronology22 = gregorianChronology15.withZone(dateTimeZone18);
        org.joda.time.Interval interval23 = localDate2.toInterval(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(interval23);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.minusYears(9);
        int int5 = localDate4.getMonthOfYear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.Partial partial4 = partial1.withPeriodAdded(readablePeriod2, 4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = partial4.getFormatter();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Partial partial7 = new org.joda.time.Partial(chronology6);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray8 = partial7.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial7.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant10 = null;
        boolean boolean11 = partial7.isMatch(readableInstant10);
        boolean boolean12 = partial4.isBefore((org.joda.time.ReadablePartial) partial7);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType14 = partial4.getFieldType(19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.secondOfDay();
        org.joda.time.DurationField durationField5 = buddhistChronology0.weekyears();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test393");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
//        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
//        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
//        int int11 = localDate10.getWeekyear();
//        org.joda.time.DurationFieldType durationFieldType12 = null;
//        boolean boolean13 = localDate10.isSupported(durationFieldType12);
//        int int14 = localDate10.getDayOfMonth();
//        int int15 = localDate10.getEra();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology17);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
//        java.util.Date date25 = localDate24.toDate();
//        int[] intArray27 = buddhistChronology17.get((org.joda.time.ReadablePartial) localDate24, (long) (short) -1);
//        org.joda.time.DurationField durationField28 = buddhistChronology17.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology30);
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology30.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType33);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology17, (org.joda.time.DateTimeField) delegatedDateTimeField34);
//        java.util.TimeZone timeZone36 = null;
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forTimeZone(timeZone36);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone37.getName(0L, locale39);
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate(dateTimeZone37);
//        org.joda.time.LocalDate localDate43 = localDate41.minusWeeks((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.LocalDate localDate46 = localDate43.withPeriodAdded(readablePeriod44, 0);
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = skipDateTimeField35.getAsText((org.joda.time.ReadablePartial) localDate46, 57977, locale48);
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.era();
//        int int52 = gregorianChronology50.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology50.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, 83195);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField55.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField35, dateTimeFieldType56);
//        boolean boolean58 = localDate10.isSupported(dateTimeFieldType56);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2018 + "'", int11 == 2018);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+00:00" + "'", str40.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "57977" + "'", str49.equals("57977"));
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology3);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(0L, locale8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(dateTimeZone6);
        java.util.Date date11 = localDate10.toDate();
        int[] intArray13 = buddhistChronology3.get((org.joda.time.ReadablePartial) localDate10, (long) (short) -1);
        org.joda.time.DurationField durationField14 = buddhistChronology3.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology16.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = dateTimeZone23.getName(0L, locale25);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(dateTimeZone23);
        org.joda.time.LocalDate localDate29 = localDate27.minusWeeks((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate32 = localDate29.withPeriodAdded(readablePeriod30, 0);
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDate32, 57977, locale34);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.era();
        int int38 = gregorianChronology36.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 83195);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField41.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField21, dateTimeFieldType42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "57977" + "'", str35.equals("57977"));
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969365", (java.lang.Number) (short) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
        illegalFieldValueException4.prependMessage("1969365");
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        illegalFieldValueException4.prependMessage("2019-06-15");
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
//        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone9);
//        org.joda.time.LocalDate localDate15 = localDate13.minusWeeks((int) ' ');
//        org.joda.time.Chronology chronology16 = localDate15.getChronology();
//        java.lang.String str17 = localDate15.toString();
//        int int18 = localDate15.size();
//        org.joda.time.LocalDate localDate20 = localDate15.withYearOfEra(2019);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology23);
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology23.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        long long29 = delegatedDateTimeField27.roundCeiling(1L);
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology33);
//        java.util.TimeZone timeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dateTimeZone36.getName(0L, locale38);
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(dateTimeZone36);
//        java.util.Date date41 = localDate40.toDate();
//        int[] intArray43 = buddhistChronology33.get((org.joda.time.ReadablePartial) localDate40, (long) (short) -1);
//        org.joda.time.DurationField durationField44 = buddhistChronology33.eras();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology46);
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.minuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType49);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology33, (org.joda.time.DateTimeField) delegatedDateTimeField50);
//        org.joda.time.ReadablePartial readablePartial52 = null;
//        int[] intArray59 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
//        int int60 = delegatedDateTimeField50.getMinimumValue(readablePartial52, intArray59);
//        int[] intArray62 = delegatedDateTimeField27.add(readablePartial30, (int) '#', intArray59, 0);
//        int[] intArray64 = offsetDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) localDate20, (int) (byte) 10, intArray62, 0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology72);
//        org.joda.time.DateTimeField dateTimeField74 = buddhistChronology72.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDate localDate76 = org.joda.time.LocalDate.now(dateTimeZone75);
//        org.joda.time.Chronology chronology77 = buddhistChronology72.withZone(dateTimeZone75);
//        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime(1, (int) (short) 1, 3, (int) (short) 10, 10, (int) '#', dateTimeZone75);
//        java.lang.String str79 = dateTimeZone75.getID();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology80 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone75);
//        org.joda.time.DurationField durationField81 = buddhistChronology80.eras();
//        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField83 = gregorianChronology82.era();
//        int int84 = gregorianChronology82.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField85 = gregorianChronology82.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField87 = new org.joda.time.field.OffsetDateTimeField(dateTimeField85, 83195);
//        long long89 = offsetDateTimeField87.roundHalfCeiling((long) '#');
//        java.util.Locale locale91 = null;
//        java.lang.String str92 = offsetDateTimeField87.getAsText((long) 2018, locale91);
//        org.joda.time.DateTimeFieldType dateTimeFieldType93 = offsetDateTimeField87.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField95 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, durationField81, dateTimeFieldType93, 22);
//        org.joda.time.DurationField durationField96 = remainderDateTimeField95.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2018-11-03" + "'", str17.equals("2018-11-03"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 60000L + "'", long29 == 60000L);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+00:00" + "'", str39.equals("+00:00"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertNotNull(buddhistChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertNotNull(chronology77);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "UTC" + "'", str79.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology80);
//        org.junit.Assert.assertNotNull(durationField81);
//        org.junit.Assert.assertNotNull(gregorianChronology82);
//        org.junit.Assert.assertNotNull(dateTimeField83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 4 + "'", int84 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField85);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "83219" + "'", str92.equals("83219"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType93);
//        org.junit.Assert.assertNotNull(durationField96);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test397");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
//        int int5 = dateTime4.getSecondOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[AD]" + "'", str1.equals("ISOChronology[AD]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(zonedChronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 83261 + "'", int5 == 83261);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        int int3 = dateTime2.getEra();
        org.joda.time.DateTime.Property property4 = dateTime2.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 83195);
        long long7 = offsetDateTimeField5.roundHalfCeiling((long) '#');
        int int9 = offsetDateTimeField5.getMaximumValue((long) (short) 1);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField5.getWrappedField();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText(11, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField5.getAsText(12, locale15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 83219 + "'", int9 == 83219);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "11" + "'", str13.equals("11"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "12" + "'", str16.equals("12"));
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test400");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
//        java.util.Locale locale3 = null;
//        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
//        int int5 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime dateTime7 = dateTime2.minusMillis((int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getName((long) (-1), locale11);
//        org.joda.time.DateTime dateTime13 = dateTime2.withZoneRetainFields(dateTimeZone9);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(calendar4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Partial partial1 = new org.joda.time.Partial(chronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial1.getFieldTypes();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray3 = partial1.getFieldTypes();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial1.minus(readablePeriod4);
        org.joda.time.Chronology chronology6 = partial5.getChronology();
        java.lang.String str7 = partial5.toString();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray8 = partial5.getFieldTypes();
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray3);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[]" + "'", str7.equals("[]"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray8);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (short) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
        int int15 = property13.getLeapAmount();
        org.joda.time.DateTime dateTime16 = property13.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        int int3 = dateTime2.getEra();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime2.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone9.getName(0L, locale11);
        boolean boolean14 = dateTimeZone9.isStandardOffset((long) '4');
        org.joda.time.DateTime dateTime15 = localDate5.toDateTimeAtStartOfDay(dateTimeZone9);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(chronology17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone20.getName(0L, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(dateTimeZone20);
        org.joda.time.LocalDate localDate26 = localDate24.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime27 = null;
        org.joda.time.DateTime dateTime28 = localDate26.toDateTime(localTime27);
        boolean boolean29 = localDate18.isAfter((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.LocalDate localDate31 = localDate18.plusYears((int) 'a');
        boolean boolean32 = localDate5.isBefore((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.LocalDate localDate34 = localDate5.plusWeeks((-1));
        int int35 = localDate34.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(0L, locale3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.LocalDate localDate7 = localDate5.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTime dateTime9 = localDate7.toDateTime(localTime8);
        org.joda.time.LocalDate.Property property10 = localDate7.weekyear();
        org.joda.time.LocalDate localDate12 = property10.addWrapFieldToCopy((int) '#');
        org.joda.time.LocalDate localDate13 = property10.roundHalfFloorCopy();
        boolean boolean14 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00" + "'", str4.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology1);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName(0L, locale6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(dateTimeZone4);
        java.util.Date date9 = localDate8.toDate();
        int[] intArray11 = buddhistChronology1.get((org.joda.time.ReadablePartial) localDate8, (long) (short) -1);
        org.joda.time.DurationField durationField12 = buddhistChronology1.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology14);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getName(0L, locale23);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.LocalDate localDate27 = localDate25.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime28 = null;
        org.joda.time.DateTime dateTime29 = localDate27.toDateTime(localTime28);
        org.joda.time.LocalDate.Property property30 = localDate27.yearOfCentury();
        org.joda.time.LocalDate.Property property31 = localDate27.monthOfYear();
        org.joda.time.LocalDate localDate33 = localDate27.withYearOfEra(10);
        org.joda.time.LocalDate localDate35 = localDate33.withYearOfCentury((int) '4');
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField19.getAsText((org.joda.time.ReadablePartial) localDate33, (int) '4', locale37);
        java.util.TimeZone timeZone39 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
        java.util.Locale locale42 = null;
        java.lang.String str43 = dateTimeZone40.getName(0L, locale42);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(dateTimeZone40);
        org.joda.time.LocalDate localDate46 = localDate44.minusWeeks((int) ' ');
        org.joda.time.LocalTime localTime47 = null;
        org.joda.time.DateTime dateTime48 = localDate46.toDateTime(localTime47);
        org.joda.time.LocalDate.Property property49 = localDate46.yearOfCentury();
        org.joda.time.LocalDate.Property property50 = localDate46.monthOfYear();
        org.joda.time.LocalDate localDate52 = localDate46.withYearOfEra(10);
        org.joda.time.LocalDate localDate54 = localDate52.withYearOfCentury((int) '4');
        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology56);
        org.joda.time.DateTimeField dateTimeField58 = buddhistChronology56.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField60 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField58, dateTimeFieldType59);
        long long62 = delegatedDateTimeField60.roundCeiling(1L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology66 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology66);
        java.util.TimeZone timeZone68 = null;
        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forTimeZone(timeZone68);
        java.util.Locale locale71 = null;
        java.lang.String str72 = dateTimeZone69.getName(0L, locale71);
        org.joda.time.LocalDate localDate73 = new org.joda.time.LocalDate(dateTimeZone69);
        java.util.Date date74 = localDate73.toDate();
        int[] intArray76 = buddhistChronology66.get((org.joda.time.ReadablePartial) localDate73, (long) (short) -1);
        org.joda.time.DurationField durationField77 = buddhistChronology66.eras();
        org.joda.time.chrono.BuddhistChronology buddhistChronology79 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime80 = new org.joda.time.DateTime((long) (-1), (org.joda.time.Chronology) buddhistChronology79);
        org.joda.time.DateTimeField dateTimeField81 = buddhistChronology79.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField83 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField81, dateTimeFieldType82);
        org.joda.time.field.SkipDateTimeField skipDateTimeField84 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology66, (org.joda.time.DateTimeField) delegatedDateTimeField83);
        org.joda.time.ReadablePartial readablePartial85 = null;
        int[] intArray92 = new int[] { 2018, (byte) 10, (byte) 0, 'a', 11, (short) 0 };
        int int93 = delegatedDateTimeField83.getMinimumValue(readablePartial85, intArray92);
        int[] intArray95 = delegatedDateTimeField60.add(readablePartial63, (int) '#', intArray92, 0);
        int int96 = skipDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) localDate52, intArray95);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00" + "'", str24.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "52" + "'", str38.equals("52"));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+00:00" + "'", str43.equals("+00:00"));
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(buddhistChronology56);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 60000L + "'", long62 == 60000L);
        org.junit.Assert.assertNotNull(buddhistChronology66);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "+00:00" + "'", str72.equals("+00:00"));
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertNotNull(buddhistChronology79);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 59 + "'", int96 == 59);
    }
}

