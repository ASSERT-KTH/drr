import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(10L, locale17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField15.getAsShortText((int) (byte) 0, locale20);
        long long23 = delegatedDateTimeField15.roundHalfFloor((long) (short) 10);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField5, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = unsupportedDateTimeField31.getType();
        boolean boolean33 = unsupportedDateTimeField31.isSupported();
        try {
            int int35 = unsupportedDateTimeField31.getMinimumValue(1560343344902L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendWeekyear((int) (byte) 100, 20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendDayOfMonth(1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder36.appendTimeZoneOffset("1969-12-31T16:00:00.100-08:00", false, 2019, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket5.setOffset(0);
        long long12 = dateTimeParserBucket5.computeMillis(true, "0");
        long long15 = dateTimeParserBucket5.computeMillis(true, "59");
        java.lang.Object obj16 = dateTimeParserBucket5.saveState();
        int int17 = dateTimeParserBucket5.getOffset();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendFractionOfHour(4, (-1));
        dateTimeFormatterBuilder33.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendDayOfYear(2000);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 259199997L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsText((long) (-1), locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField15.getType();
        org.joda.time.DateTimeField dateTimeField24 = delegatedDateTimeField15.getWrappedField();
        long long26 = delegatedDateTimeField15.roundHalfFloor((long) 0);
        boolean boolean27 = delegatedDateTimeField15.isLenient();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology29 = dateTimeFormatter28.getChronolgy();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) chronology29);
        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property33 = dateTime30.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime35 = dateTime30.plus(readablePeriod34);
        org.joda.time.DateTime.Property property36 = dateTime30.dayOfYear();
        org.joda.time.DateTime dateTime38 = dateTime30.plusMinutes((int) (short) 0);
        org.joda.time.TimeOfDay timeOfDay39 = dateTime30.toTimeOfDay();
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) timeOfDay39, (int) '4', locale41);
        java.util.Locale locale44 = null;
        java.lang.String str45 = delegatedDateTimeField15.getAsShortText((long) 31, locale44);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(timeOfDay39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "52" + "'", str42.equals("52"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(3);
        java.io.Writer writer3 = null;
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("0");
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfHour();
        try {
            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.plusMonths((-1));
        org.joda.time.DateTime dateTime10 = dateTime5.withDurationAdded(0L, 0);
        org.joda.time.DateTime.Property property11 = dateTime5.secondOfMinute();
        org.joda.time.DateTime dateTime13 = dateTime5.withYear((int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean12 = fixedDateTimeZone11.isFixed();
        long long15 = fixedDateTimeZone11.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone20);
        boolean boolean22 = mutableDateTime18.isBefore((org.joda.time.ReadableInstant) mutableDateTime21);
        mutableDateTime21.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime21.secondOfMinute();
        java.util.Locale locale26 = null;
        java.lang.String str27 = property25.getAsText(locale26);
        org.joda.time.MutableDateTime mutableDateTime29 = property25.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField30 = property25.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
        java.lang.String str33 = delegatedDateTimeField31.getAsShortText((long) (short) 0);
        int int36 = delegatedDateTimeField31.getDifference((long) (byte) 0, (long) 'a');
        long long38 = delegatedDateTimeField31.roundFloor((long) 0);
        boolean boolean39 = fixedDateTimeZone11.equals((java.lang.Object) delegatedDateTimeField31);
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField41 = julianChronology40.clockhourOfDay();
        try {
            org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(12, 365, 24, (int) (byte) 0, (-1), 100, 20557, (org.joda.time.Chronology) julianChronology40);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-90L) + "'", long15 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "0" + "'", str33.equals("0"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.lang.String str17 = delegatedDateTimeField15.getAsShortText((long) (short) 0);
        int int20 = delegatedDateTimeField15.getDifference((long) (byte) 0, (long) 'a');
        int int22 = delegatedDateTimeField15.get(0L);
        java.lang.String str24 = delegatedDateTimeField15.getAsShortText((-1000L));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology27 = dateTimeFormatter26.getChronolgy();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) chronology27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime32 = dateTime28.minus((long) 10);
        org.joda.time.DateTime.Property property33 = dateTime28.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay34 = dateTime28.toYearMonthDay();
        org.joda.time.Chronology chronology36 = null;
        java.util.Locale locale37 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology36, locale37, (java.lang.Integer) 10, (int) ' ');
        boolean boolean42 = dateTimeParserBucket40.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket40.setOffset(0);
        long long47 = dateTimeParserBucket40.computeMillis(true, "0");
        dateTimeParserBucket40.setOffset((int) (short) 100);
        java.lang.Integer int50 = dateTimeParserBucket40.getOffsetInteger();
        java.lang.Object obj51 = dateTimeParserBucket40.saveState();
        java.util.Locale locale52 = dateTimeParserBucket40.getLocale();
        try {
            java.lang.String str53 = delegatedDateTimeField15.getAsText((org.joda.time.ReadablePartial) yearMonthDay34, locale52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "59" + "'", str24.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(yearMonthDay34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 100 + "'", int50.equals(100));
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(locale52);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.year();
        org.joda.time.Chronology chronology3 = null;
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology3, locale4, (java.lang.Integer) 10, (int) ' ');
        boolean boolean9 = dateTimeParserBucket7.restoreState((java.lang.Object) 1.0d);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeParserBucket7.getZone();
        boolean boolean11 = gJChronology0.equals((java.lang.Object) dateTimeParserBucket7);
        org.joda.time.Chronology chronology12 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
//        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeParser1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Friday, February 28, 1969" + "'", str9.equals("Friday, February 28, 1969"));
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property9 = dateTime2.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test016");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
//        int int7 = property3.getMinimumValue();
//        org.joda.time.DateTime dateTime9 = property3.setCopy(5);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (byte) 0);
//        org.joda.time.DateTime dateTime13 = dateTime11.withYearOfEra(1);
//        org.joda.time.DateTime.Property property14 = dateTime11.minuteOfDay();
//        int int15 = property14.get();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendWeekyear((int) (byte) 100, 20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendYearOfEra(42, 20521);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 1970);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        java.util.Date date16 = mutableDateTime12.toDate();
        mutableDateTime12.addMonths((-11));
        java.lang.String str19 = mutableDateTime12.toString();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime12.hourOfDay();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-0001-01-16T00:00:00.100Z" + "'", str19.equals("-0001-01-16T00:00:00.100Z"));
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
        java.util.Locale locale7 = null;
        int int8 = property3.getMaximumShortTextLength(locale7);
        org.joda.time.DateTime dateTime9 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime11 = dateTime9.minus(45747429L);
        org.joda.time.DateTime dateTime12 = dateTime11.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.lang.String str18 = delegatedDateTimeField16.getAsShortText((long) (short) 0);
        int int21 = delegatedDateTimeField16.getDifference((long) (byte) 0, (long) 'a');
        int int23 = delegatedDateTimeField16.get(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) delegatedDateTimeField16, 0);
        long long27 = skipDateTimeField25.roundHalfFloor((long) 3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        java.lang.Object obj3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj3, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfYear();
//        org.joda.time.DurationField durationField7 = gregorianChronology4.years();
//        boolean boolean8 = gJChronology0.equals((java.lang.Object) gregorianChronology4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology10 = dateTimeFormatter9.getChronolgy();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) chronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime11.minus((long) 10);
//        org.joda.time.DateTime dateTime17 = dateTime11.plusYears((int) (short) 0);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusMonths(100);
//        int int20 = dateTime19.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.ReadableDateTime) dateTime19, readableDateTime21);
//        try {
//            long long27 = limitChronology22.getDateTimeMillis(0, 31, 6, 21);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 57600 + "'", int20 == 57600);
//        org.junit.Assert.assertNotNull(limitChronology22);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        boolean boolean12 = mutableDateTime8.isBefore((org.joda.time.ReadableInstant) mutableDateTime11);
        mutableDateTime11.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.secondOfMinute();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        org.joda.time.MutableDateTime mutableDateTime19 = property15.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField20 = property15.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        int int24 = delegatedDateTimeField21.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField25 = delegatedDateTimeField21.getDurationField();
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField21.getAsText((long) (-1), locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField21.getType();
        org.joda.time.DateTimeField dateTimeField30 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField30);
        long long34 = skipUndoDateTimeField31.set((long) (short) 0, 10);
        int int36 = skipUndoDateTimeField31.get((long) 1);
        org.joda.time.DurationField durationField37 = skipUndoDateTimeField31.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "59" + "'", str28.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10000L + "'", long34 == 10000L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(durationField37);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.add(35L);
        mutableDateTime11.addWeekyears(1);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.weekOfWeekyear();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.secondOfDay();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendTwoDigitYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder30.appendSecondOfDay(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone40);
        boolean boolean42 = mutableDateTime38.isBefore((org.joda.time.ReadableInstant) mutableDateTime41);
        mutableDateTime41.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime41.secondOfMinute();
        java.util.Locale locale46 = null;
        java.lang.String str47 = property45.getAsText(locale46);
        org.joda.time.MutableDateTime mutableDateTime49 = property45.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField50 = property45.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField50);
        int int54 = delegatedDateTimeField51.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField55 = delegatedDateTimeField51.getDurationField();
        java.util.Locale locale57 = null;
        java.lang.String str58 = delegatedDateTimeField51.getAsText((long) (-1), locale57);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = delegatedDateTimeField51.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder35.appendText(dateTimeFieldType59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder35.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder35.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder68.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale71 = dateTimeFormatter70.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter72 = dateTimeFormatter70.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder68.append(dateTimePrinter72);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder34.append(dateTimePrinter72);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder74.appendDayOfWeekText();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "59" + "'", str58.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNull(locale71);
        org.junit.Assert.assertNotNull(dateTimePrinter72);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "");
        java.lang.String str3 = illegalInstantException2.toString();
        org.joda.time.IllegalInstantException illegalInstantException6 = new org.joda.time.IllegalInstantException(0L, "1969-12-31T16:00:00.100-08:00");
        java.lang.Throwable[] throwableArray7 = illegalInstantException6.getSuppressed();
        java.lang.String str8 = illegalInstantException6.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        int int27 = delegatedDateTimeField24.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField28 = delegatedDateTimeField24.getDurationField();
        java.util.Locale locale30 = null;
        java.lang.String str31 = delegatedDateTimeField24.getAsText((long) (-1), locale30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = delegatedDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-1L), (java.lang.Number) 960, (java.lang.Number) 1.0f);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = illegalFieldValueException40.getDateTimeFieldType();
        illegalFieldValueException35.addSuppressed((java.lang.Throwable) illegalFieldValueException40);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = illegalFieldValueException40.getDateTimeFieldType();
        illegalInstantException6.addSuppressed((java.lang.Throwable) illegalFieldValueException40);
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 ()" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 ()"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)" + "'", str8.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "59" + "'", str31.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNull(dateTimeFieldType41);
        org.junit.Assert.assertNull(dateTimeFieldType43);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.DateTime dateTime11 = property8.addToCopy((long) 2000);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        java.lang.Object obj4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone14);
        boolean boolean16 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
        mutableDateTime15.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.secondOfMinute();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property19.getAsText(locale20);
        org.joda.time.MutableDateTime mutableDateTime23 = property19.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField24 = property19.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        int int28 = delegatedDateTimeField25.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField25.getDurationField();
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField25.getAsText((long) (-1), locale31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField25.getType();
        org.joda.time.DateTimeField dateTimeField34 = delegatedDateTimeField25.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone38 = dateTimeFormatter37.getZone();
        java.lang.String str39 = dateTimeZone38.getID();
        java.lang.String str40 = dateTimeZone38.getID();
        java.lang.String str41 = dateTimeZone38.getID();
        org.joda.time.Chronology chronology42 = gregorianChronology1.withZone(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology1.hourOfDay();
        try {
            long long49 = gregorianChronology1.getDateTimeMillis(23, 9643, 960, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "59" + "'", str32.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "UTC" + "'", str39.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UTC" + "'", str40.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UTC" + "'", str41.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        java.lang.String str14 = zonedChronology13.toString();
        org.joda.time.Chronology chronology15 = zonedChronology13.withUTC();
        java.lang.Object obj16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(obj16, (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.weekyearOfCentury();
        java.lang.Object obj20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(obj20, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology21.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone30);
        boolean boolean32 = mutableDateTime28.isBefore((org.joda.time.ReadableInstant) mutableDateTime31);
        mutableDateTime31.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime31.secondOfMinute();
        java.util.Locale locale36 = null;
        java.lang.String str37 = property35.getAsText(locale36);
        org.joda.time.MutableDateTime mutableDateTime39 = property35.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField40 = property35.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40);
        int int44 = delegatedDateTimeField41.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField45 = delegatedDateTimeField41.getDurationField();
        java.util.Locale locale47 = null;
        java.lang.String str48 = delegatedDateTimeField41.getAsText((long) (-1), locale47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = delegatedDateTimeField41.getType();
        org.joda.time.DateTimeField dateTimeField50 = delegatedDateTimeField41.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField50);
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology17, (org.joda.time.DateTimeField) skipUndoDateTimeField51);
        java.lang.Object obj53 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(obj53, (org.joda.time.Chronology) gregorianChronology54);
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.weekyearOfCentury();
        java.lang.Object obj57 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(obj57, (org.joda.time.Chronology) gregorianChronology58);
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology58.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology58.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone64);
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.MutableDateTime mutableDateTime68 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone67);
        boolean boolean69 = mutableDateTime65.isBefore((org.joda.time.ReadableInstant) mutableDateTime68);
        mutableDateTime68.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property72 = mutableDateTime68.secondOfMinute();
        java.util.Locale locale73 = null;
        java.lang.String str74 = property72.getAsText(locale73);
        org.joda.time.MutableDateTime mutableDateTime76 = property72.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField77 = property72.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField78 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField77);
        int int81 = delegatedDateTimeField78.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField82 = delegatedDateTimeField78.getDurationField();
        java.util.Locale locale84 = null;
        java.lang.String str85 = delegatedDateTimeField78.getAsText((long) (-1), locale84);
        org.joda.time.DateTimeFieldType dateTimeFieldType86 = delegatedDateTimeField78.getType();
        org.joda.time.DateTimeField dateTimeField87 = delegatedDateTimeField78.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField88 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology58, dateTimeField87);
        org.joda.time.field.SkipDateTimeField skipDateTimeField89 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology54, (org.joda.time.DateTimeField) skipUndoDateTimeField88);
        org.joda.time.field.SkipDateTimeField skipDateTimeField90 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology17, (org.joda.time.DateTimeField) skipUndoDateTimeField88);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField92 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, (org.joda.time.DateTimeField) skipUndoDateTimeField88, 86399999);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "59" + "'", str48.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "0" + "'", str74.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(durationField82);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "59" + "'", str85.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType86);
        org.junit.Assert.assertNotNull(dateTimeField87);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[year]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        int int34 = unsupportedDateTimeField31.getDifference((long) 4, (long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField31.getType();
        boolean boolean36 = unsupportedDateTimeField31.isSupported();
        int int39 = unsupportedDateTimeField31.getDifference(10L, (long) 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.plusMonths((-1));
        org.joda.time.DateTime dateTime10 = dateTime5.withDurationAdded(0L, 0);
        org.joda.time.DateTime.Property property11 = dateTime5.secondOfMinute();
        java.lang.String str12 = property11.getAsShortText();
        org.joda.time.DateTime dateTime13 = property11.getDateTime();
        try {
            org.joda.time.DateTime dateTime15 = property11.setCopy("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        java.util.Date date16 = mutableDateTime12.toDate();
        org.joda.time.Instant instant17 = mutableDateTime12.toInstant();
        org.joda.time.DateTime dateTime18 = instant17.toDateTimeISO();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Instant instant4 = instant0.withMillis((long) 1);
        org.joda.time.Instant instant6 = instant4.minus(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        java.lang.String str9 = dateTimeZone8.getID();
        java.lang.String str10 = dateTimeZone8.getID();
        java.lang.String str11 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime12 = instant4.toDateTime(dateTimeZone8);
        int int14 = dateTimeZone8.getOffsetFromLocal((long) 21);
        try {
            org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        java.util.Date date16 = mutableDateTime12.toDate();
        java.lang.String str17 = mutableDateTime12.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-0001-12-16T00:00:00.100Z" + "'", str17.equals("-0001-12-16T00:00:00.100Z"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        mutableDateTime12.addMillis((int) (short) -1);
        mutableDateTime12.setTime(0L);
        mutableDateTime12.addWeeks((int) (byte) -1);
        try {
            mutableDateTime12.setMonthOfYear(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        mutableDateTime2.setMillis((long) 100);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.hourOfDay();
        mutableDateTime2.setWeekOfWeekyear((int) (short) 1);
        mutableDateTime2.setWeekyear(2019);
        mutableDateTime2.setSecondOfMinute(0);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean2 = buddhistChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        java.lang.String str14 = zonedChronology13.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean20 = fixedDateTimeZone19.isFixed();
        long long23 = fixedDateTimeZone19.adjustOffset((-90L), false);
        int int25 = fixedDateTimeZone19.getOffsetFromLocal((-31535999968L));
        org.joda.time.Chronology chronology26 = zonedChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        try {
            long long31 = zonedChronology13.getDateTimeMillis((-6), 9700, 9653, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9700 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-90L) + "'", long23 == (-90L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969", (java.lang.Number) (-31535940968L), (java.lang.Number) 10L, (java.lang.Number) 365);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.Object obj5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj5, (org.joda.time.Chronology) gregorianChronology6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(20, (int) (byte) 1, (-1), 1970, 0, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test043");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
//        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
//        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
//        int int10 = dateTime9.getMonthOfYear();
//        org.joda.time.DateTime dateTime12 = dateTime9.plus((-1000L));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone18);
//        boolean boolean20 = mutableDateTime16.isBefore((org.joda.time.ReadableInstant) mutableDateTime19);
//        mutableDateTime19.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property23 = mutableDateTime19.secondOfMinute();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property23.getAsText(locale24);
//        org.joda.time.MutableDateTime mutableDateTime27 = property23.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField28 = property23.getField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
//        int int32 = delegatedDateTimeField29.getDifference((long) 'a', (long) 100);
//        org.joda.time.DurationField durationField33 = delegatedDateTimeField29.getDurationField();
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = delegatedDateTimeField29.getAsText((long) (-1), locale35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = delegatedDateTimeField29.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, (java.lang.Number) 20, "secondOfMinute");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType37);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder13.appendTwoDigitYear(10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendWeekOfWeekyear((int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder43.appendSecondOfDay(6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone50);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.MutableDateTime mutableDateTime54 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone53);
//        boolean boolean55 = mutableDateTime51.isBefore((org.joda.time.ReadableInstant) mutableDateTime54);
//        mutableDateTime54.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property58 = mutableDateTime54.secondOfMinute();
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = property58.getAsText(locale59);
//        org.joda.time.MutableDateTime mutableDateTime62 = property58.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField63 = property58.getField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField64 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField63);
//        int int67 = delegatedDateTimeField64.getDifference((long) 'a', (long) 100);
//        org.joda.time.DurationField durationField68 = delegatedDateTimeField64.getDurationField();
//        java.util.Locale locale70 = null;
//        java.lang.String str71 = delegatedDateTimeField64.getAsText((long) (-1), locale70);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = delegatedDateTimeField64.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException75 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType72, (java.lang.Number) 20, "secondOfMinute");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder48.appendText(dateTimeFieldType72);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder48.appendDayOfWeekText();
//        org.joda.time.DateTimeZone dateTimeZone79 = null;
//        org.joda.time.MutableDateTime mutableDateTime80 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone79);
//        java.util.Date date81 = mutableDateTime80.toDate();
//        java.util.Locale locale82 = null;
//        java.util.Calendar calendar83 = mutableDateTime80.toCalendar(locale82);
//        org.joda.time.MutableDateTime.Property property84 = mutableDateTime80.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType85 = property84.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder77.appendShortText(dateTimeFieldType85);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder47.appendFixedDecimal(dateTimeFieldType85, 2);
//        org.joda.time.DateTime dateTime90 = dateTime9.withField(dateTimeFieldType85, (int) (byte) 1);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "59" + "'", str36.equals("59"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "0" + "'", str60.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "59" + "'", str71.equals("59"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(calendar83);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertNotNull(dateTimeFieldType85);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder86);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
//        org.junit.Assert.assertNotNull(dateTime90);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusYears(0);
//        java.lang.Object obj7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj7, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime10 = dateTime4.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        boolean boolean12 = dateTime10.isAfter((long) 5);
//        org.joda.time.Chronology chronology13 = dateTime10.getChronology();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(chronology13);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test045");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
//        int int7 = property3.getMinimumValue();
//        org.joda.time.DateTime dateTime9 = property3.setCopy(5);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds((int) (short) 100);
//        int int12 = dateTime9.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        java.lang.String str14 = zonedChronology13.toString();
        try {
            long long22 = zonedChronology13.getDateTimeMillis(21, 2, 20545, (int) (byte) 1, 0, 568937, 20521);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 568937 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone35);
        java.util.Date date37 = mutableDateTime36.toDate();
        java.lang.String str38 = mutableDateTime36.toString();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime40 = mutableDateTime36.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone45);
        boolean boolean47 = mutableDateTime43.isBefore((org.joda.time.ReadableInstant) mutableDateTime46);
        mutableDateTime46.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime46.secondOfMinute();
        java.util.Locale locale51 = null;
        java.lang.String str52 = property50.getAsText(locale51);
        org.joda.time.MutableDateTime mutableDateTime54 = property50.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField55 = property50.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55);
        int int59 = delegatedDateTimeField56.getDifference((long) 'a', (long) 100);
        int int60 = delegatedDateTimeField56.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = delegatedDateTimeField56.getType();
        org.joda.time.MutableDateTime.Property property62 = mutableDateTime36.property(dateTimeFieldType61);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder33.appendFraction(dateTimeFieldType61, 9700, 5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder33.appendMinuteOfHour(21);
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.MutableDateTime mutableDateTime70 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone69);
        java.util.Date date71 = mutableDateTime70.toDate();
        java.util.Locale locale72 = null;
        java.util.Calendar calendar73 = mutableDateTime70.toCalendar(locale72);
        org.joda.time.MutableDateTime.Property property74 = mutableDateTime70.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder33.appendSignedDecimal(dateTimeFieldType75, (int) (short) 10, 2000);
        org.joda.time.IllegalFieldValueException illegalFieldValueException80 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, "GJChronology[America/Los_Angeles]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str38.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0" + "'", str52.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(calendar73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(3);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
//        java.lang.StringBuffer stringBuffer6 = null;
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = gJChronology7.equals(obj8);
//        java.lang.Object obj10 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(obj10, (org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.dayOfYear();
//        org.joda.time.DurationField durationField14 = gregorianChronology11.years();
//        boolean boolean15 = gJChronology7.equals((java.lang.Object) gregorianChronology11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology17 = dateTimeFormatter16.getChronolgy();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) chronology17);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime22 = dateTime18.minus((long) 10);
//        org.joda.time.DateTime dateTime24 = dateTime18.plusYears((int) (short) 0);
//        org.joda.time.DateTime dateTime26 = dateTime24.minusMonths(100);
//        int int27 = dateTime26.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime28 = null;
//        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology11, (org.joda.time.ReadableDateTime) dateTime26, readableDateTime28);
//        org.joda.time.DateTime dateTime30 = limitChronology29.getLowerLimit();
//        try {
//            dateTimeFormatter5.printTo(stringBuffer6, (org.joda.time.ReadableInstant) dateTime30);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 57600 + "'", int27 == 57600);
//        org.junit.Assert.assertNotNull(limitChronology29);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            java.lang.String str5 = dateTimeFormatter0.print(readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        java.lang.String str2 = gJChronology0.toString();
        java.lang.String str3 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone8);
        boolean boolean10 = mutableDateTime6.isBefore((org.joda.time.ReadableInstant) mutableDateTime9);
        mutableDateTime9.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime9.secondOfMinute();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property13.getAsText(locale14);
        org.joda.time.MutableDateTime mutableDateTime17 = property13.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField18 = property13.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
        int int22 = delegatedDateTimeField19.getDifference((long) 'a', (long) 100);
        int int23 = delegatedDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField19.getType();
        java.lang.Object obj25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(obj25, (org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.hourOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology26.yearOfCentury();
        org.joda.time.DurationField durationField31 = gregorianChronology26.minutes();
        long long34 = durationField31.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType24, durationField31);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        java.lang.String str37 = unsupportedDateTimeField35.toString();
        int int40 = unsupportedDateTimeField35.getDifference((long) (short) 1, (long) 49);
        boolean boolean41 = gJChronology0.equals((java.lang.Object) unsupportedDateTimeField35);
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField35.getRangeDurationField();
        try {
            java.lang.String str44 = unsupportedDateTimeField35.getAsShortText(1560343317797L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 174441597981L + "'", long34 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(durationField42);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        java.lang.String str9 = dateTimeZone8.getID();
        java.lang.String str10 = dateTimeZone8.getID();
        java.lang.String str11 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime12 = dateTime6.withZoneRetainFields(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.minuteOfDay();
        org.joda.time.DurationField durationField16 = gregorianChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime6);
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime8);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getDurationField();
        try {
            int int34 = unsupportedDateTimeField31.get(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.millisOfSecond();
        try {
            long long16 = gregorianChronology1.getDateTimeMillis(61668, (int) '#', 9643, 61668, 2000, 26, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 61668 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        boolean boolean12 = mutableDateTime8.isBefore((org.joda.time.ReadableInstant) mutableDateTime11);
        mutableDateTime11.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.secondOfMinute();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        org.joda.time.MutableDateTime mutableDateTime19 = property15.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField20 = property15.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        int int24 = delegatedDateTimeField21.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField25 = delegatedDateTimeField21.getDurationField();
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField21.getAsText((long) (-1), locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField21.getType();
        org.joda.time.DateTimeField dateTimeField30 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField30);
        long long34 = skipUndoDateTimeField31.set(0L, 59);
        boolean boolean36 = skipUndoDateTimeField31.isLeap(31535999L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology38 = dateTimeFormatter37.getChronolgy();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) chronology38);
        org.joda.time.DateTime dateTime41 = dateTime39.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime43 = dateTime39.minus((long) 10);
        org.joda.time.DateTime.Property property44 = dateTime39.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime39.toYearMonthDay();
        int int46 = skipUndoDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay45);
        boolean boolean47 = skipUndoDateTimeField31.isLenient();
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipUndoDateTimeField31.getAsText(3, locale49);
        try {
            long long53 = skipUndoDateTimeField31.set((long) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "59" + "'", str28.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 59000L + "'", long34 == 59000L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "3" + "'", str50.equals("3"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology4 = dateTimeFormatter3.getChronolgy();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) chronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime5.minus((long) 10);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime11 = property10.roundHalfEvenCopy();
        jodaTimePermission1.checkGuard((java.lang.Object) property10);
        org.joda.time.JodaTimePermission jodaTimePermission14 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        java.lang.String str15 = jodaTimePermission14.getName();
        boolean boolean16 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission14);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)" + "'", str15.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
        java.util.Locale locale7 = null;
        int int8 = property3.getMaximumShortTextLength(locale7);
        org.joda.time.DateTime dateTime9 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime11 = dateTime9.minus(45747429L);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(10L, locale17);
        long long20 = delegatedDateTimeField15.roundHalfFloor(100L);
        long long22 = delegatedDateTimeField15.roundFloor((-1L));
        long long25 = delegatedDateTimeField15.set((long) 20531, 31);
        int int27 = delegatedDateTimeField15.getMinimumValue((long) 24);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1000L) + "'", long22 == (-1000L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31531L + "'", long25 == 31531L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        boolean boolean12 = mutableDateTime8.isBefore((org.joda.time.ReadableInstant) mutableDateTime11);
        mutableDateTime11.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.secondOfMinute();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        org.joda.time.MutableDateTime mutableDateTime19 = property15.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField20 = property15.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        int int24 = delegatedDateTimeField21.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField25 = delegatedDateTimeField21.getDurationField();
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField21.getAsText((long) (-1), locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField21.getType();
        org.joda.time.DateTimeField dateTimeField30 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField30);
        long long34 = skipUndoDateTimeField31.set((long) (short) 0, 10);
        int int36 = skipUndoDateTimeField31.get((long) 1);
        java.lang.String str37 = skipUndoDateTimeField31.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "59" + "'", str28.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10000L + "'", long34 == 10000L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str37.equals("DateTimeField[secondOfMinute]"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.lang.String str18 = delegatedDateTimeField16.getAsShortText((long) (short) 0);
        int int21 = delegatedDateTimeField16.getDifference((long) (byte) 0, (long) 'a');
        int int23 = delegatedDateTimeField16.get(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) delegatedDateTimeField16, 0);
        java.lang.String str27 = skipDateTimeField25.getAsShortText((long) 2);
        int int28 = skipDateTimeField25.getMinimumValue();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMinuteOfDay(86399999);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone33);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone36);
        boolean boolean38 = mutableDateTime34.isBefore((org.joda.time.ReadableInstant) mutableDateTime37);
        mutableDateTime37.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime37.secondOfMinute();
        java.util.Locale locale42 = null;
        java.lang.String str43 = property41.getAsText(locale42);
        org.joda.time.MutableDateTime mutableDateTime45 = property41.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField46 = property41.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        int int50 = delegatedDateTimeField47.getDifference((long) 'a', (long) 100);
        int int51 = delegatedDateTimeField47.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField47.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder29.appendShortText(dateTimeFieldType52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder29.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder54.appendDayOfWeek(0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        long long31 = delegatedDateTimeField24.roundFloor((long) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) delegatedDateTimeField24);
        long long36 = fixedDateTimeZone4.convertLocalToUTC((long) 1, false, (-210866673600000L));
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone43);
        boolean boolean45 = mutableDateTime41.isBefore((org.joda.time.ReadableInstant) mutableDateTime44);
        mutableDateTime44.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime44.secondOfMinute();
        java.util.Locale locale49 = null;
        java.lang.String str50 = property48.getAsText(locale49);
        org.joda.time.MutableDateTime mutableDateTime52 = property48.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField53 = property48.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53);
        java.lang.String str56 = delegatedDateTimeField54.getAsShortText((long) (short) 0);
        int int59 = delegatedDateTimeField54.getDifference((long) (byte) 0, (long) 'a');
        int int61 = delegatedDateTimeField54.get(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField63 = new org.joda.time.field.SkipDateTimeField(chronology38, (org.joda.time.DateTimeField) delegatedDateTimeField54, 0);
        boolean boolean64 = fixedDateTimeZone4.equals((java.lang.Object) skipDateTimeField63);
        boolean boolean66 = skipDateTimeField63.isLeap((long) ' ');
        int int69 = skipDateTimeField63.getDifference((long) 1970, 23L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime4.plusYears(568937);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.lang.Object obj1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField4 = gregorianChronology2.weeks();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) gregorianChronology2, locale5, (java.lang.Integer) 5, (int) '4');
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
//        org.joda.time.Chronology chronology3 = instant0.getChronology();
//        org.joda.time.Instant instant5 = instant0.minus((long) 1970);
//        long long6 = instant5.getMillis();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1970L) + "'", long6 == (-1970L));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        java.lang.String str14 = iSOChronology0.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology22 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        long long24 = fixedDateTimeZone19.previousTransition((long) (byte) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str14.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        java.lang.String str9 = dateTimeZone8.getID();
        java.lang.String str10 = dateTimeZone8.getID();
        java.lang.String str11 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime12 = dateTime6.withZoneRetainFields(dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology14 = dateTimeFormatter13.getChronolgy();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime18 = dateTime17.toDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime18.withCenturyOfEra((int) (byte) 100);
        boolean boolean21 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime23 = dateTime18.minusSeconds(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendClockhourOfHalfday(16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendDayOfWeekShortText();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        long long31 = delegatedDateTimeField24.roundFloor((long) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) delegatedDateTimeField24);
        long long36 = fixedDateTimeZone4.convertLocalToUTC((long) 1, false, (-210866673600000L));
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone43);
        boolean boolean45 = mutableDateTime41.isBefore((org.joda.time.ReadableInstant) mutableDateTime44);
        mutableDateTime44.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime44.secondOfMinute();
        java.util.Locale locale49 = null;
        java.lang.String str50 = property48.getAsText(locale49);
        org.joda.time.MutableDateTime mutableDateTime52 = property48.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField53 = property48.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53);
        java.lang.String str56 = delegatedDateTimeField54.getAsShortText((long) (short) 0);
        int int59 = delegatedDateTimeField54.getDifference((long) (byte) 0, (long) 'a');
        int int61 = delegatedDateTimeField54.get(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField63 = new org.joda.time.field.SkipDateTimeField(chronology38, (org.joda.time.DateTimeField) delegatedDateTimeField54, 0);
        boolean boolean64 = fixedDateTimeZone4.equals((java.lang.Object) skipDateTimeField63);
        boolean boolean66 = skipDateTimeField63.isLeap((long) ' ');
        int int68 = skipDateTimeField63.get(35L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.plus(readablePeriod6);
        org.joda.time.DateTime.Property property8 = dateTime2.dayOfYear();
        org.joda.time.DateTime dateTime10 = dateTime2.plusMinutes((int) (short) 0);
        org.joda.time.DateTime.Property property11 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime2.toDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        mutableDateTime13.add(readablePeriod14, (int) (byte) 1);
        mutableDateTime13.addYears((int) (byte) 1);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime13.millisOfDay();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minusHours(1969);
        java.lang.Object obj7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(obj7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.hourOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        long long15 = gregorianChronology8.add(readablePeriod12, (long) '#', (int) (byte) 0);
        org.joda.time.DateTime dateTime16 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime18 = dateTime2.plusSeconds(0);
        try {
            org.joda.time.DateTime dateTime22 = dateTime2.withDate(0, 31, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = cachedDateTimeZone5.getStandardOffset(0L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int15 = cachedDateTimeZone13.getStandardOffset(0L);
        int int17 = cachedDateTimeZone13.getOffset((long) 0);
        boolean boolean18 = cachedDateTimeZone5.equals((java.lang.Object) int17);
        long long20 = cachedDateTimeZone5.nextTransition(1560343317797L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560343317797L + "'", long20 == 1560343317797L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        java.lang.String str14 = zonedChronology13.toString();
        try {
            long long22 = zonedChronology13.getDateTimeMillis((int) (short) 10, 6, (int) ' ', 15, (int) (short) 1, 9643, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9643 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        java.lang.String str9 = dateTimeZone8.getID();
        java.lang.String str10 = dateTimeZone8.getID();
        java.lang.String str11 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime12 = dateTime6.withZoneRetainFields(dateTimeZone8);
        org.joda.time.DateTime dateTime14 = dateTime6.plus(0L);
        org.joda.time.DateTime dateTime16 = dateTime6.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        org.joda.time.DateTime.Property property18 = dateTime16.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMinuteOfDay(86399999);
        dateTimeFormatterBuilder31.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendTwoDigitYear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder31.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder31.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder31.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder38.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder38.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendWeekyear(9643, 52);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        mutableDateTime2.setMillis((long) 100);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.lang.String str7 = mutableDateTime2.toString(dateTimeFormatter6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean13 = fixedDateTimeZone12.isFixed();
        int int15 = fixedDateTimeZone12.getOffsetFromLocal((-1000L));
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) mutableDateTime2, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        mutableDateTime2.addMonths((-292275054));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.100" + "'", str7.equals("1969-12-31T16:00:00.100"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMinuteOfDay(86399999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendWeekOfWeekyear(19);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = fixedDateTimeZone4.previousTransition((long) 1);
        int int13 = fixedDateTimeZone4.getStandardOffset((long) 49);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone18);
        boolean boolean20 = mutableDateTime16.isBefore((org.joda.time.ReadableInstant) mutableDateTime19);
        mutableDateTime19.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime19.secondOfMinute();
        java.util.Locale locale24 = null;
        java.lang.String str25 = property23.getAsText(locale24);
        org.joda.time.MutableDateTime mutableDateTime27 = property23.addWrapField((int) 'a');
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        mutableDateTime27.add(readablePeriod28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = mutableDateTime27.getChronology();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone33);
        java.util.Date date35 = mutableDateTime34.toDate();
        java.lang.String str36 = mutableDateTime34.toString();
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime34.dayOfMonth();
        mutableDateTime34.setTime((long) 20521);
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime34.dayOfMonth();
        mutableDateTime27.setDate((org.joda.time.ReadableInstant) mutableDateTime34);
        boolean boolean42 = fixedDateTimeZone4.equals((java.lang.Object) mutableDateTime27);
        java.util.TimeZone timeZone43 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str36.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeZone43);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        java.lang.String str14 = zonedChronology13.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean20 = fixedDateTimeZone19.isFixed();
        long long23 = fixedDateTimeZone19.adjustOffset((-90L), false);
        int int25 = fixedDateTimeZone19.getOffsetFromLocal((-31535999968L));
        org.joda.time.Chronology chronology26 = zonedChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone27 = zonedChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone29 = dateTimeFormatter28.getZone();
        java.lang.String str30 = dateTimeZone29.getID();
        java.lang.String str31 = dateTimeZone29.getID();
        java.lang.String str32 = dateTimeZone29.getID();
        long long35 = dateTimeZone29.adjustOffset((long) (-1), false);
        long long38 = dateTimeZone29.adjustOffset((-1000L), false);
        org.joda.time.Chronology chronology39 = zonedChronology13.withZone(dateTimeZone29);
        org.joda.time.DurationField durationField40 = zonedChronology13.millis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-90L) + "'", long23 == (-90L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UTC" + "'", str30.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UTC" + "'", str31.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UTC" + "'", str32.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1L) + "'", long35 == (-1L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1000L) + "'", long38 == (-1000L));
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(durationField40);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        java.lang.Object obj1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj1, (org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime.Property property4 = dateTime3.weekOfWeekyear();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
//        int int7 = dateTime5.getYearOfCentury();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-363T00:00:00.000Z" + "'", str8.equals("1969-363T00:00:00.000Z"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.plus(readablePeriod6);
        org.joda.time.DateTime.Property property8 = dateTime2.dayOfYear();
        org.joda.time.DateTime dateTime10 = dateTime2.plusMinutes((int) (short) 0);
        org.joda.time.DateTime.Property property11 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime13 = dateTime2.withEra(0);
        org.joda.time.DateTime dateTime15 = dateTime2.minusMonths((int) (byte) 1);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test086");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
//        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
//        java.lang.String str9 = property8.getAsString();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(0);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        long long8 = dateTimeParserBucket5.computeMillis(false, "Pacific Standard Time");
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone14);
        boolean boolean16 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
        mutableDateTime15.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.secondOfMinute();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property19.getAsText(locale20);
        org.joda.time.MutableDateTime mutableDateTime23 = property19.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField24 = property19.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        java.lang.String str27 = delegatedDateTimeField25.getAsShortText((long) (short) 0);
        int int30 = delegatedDateTimeField25.getDifference((long) (byte) 0, (long) 'a');
        int int32 = delegatedDateTimeField25.get(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField(chronology9, (org.joda.time.DateTimeField) delegatedDateTimeField25, 0);
        int int36 = skipDateTimeField34.get((long) (-1));
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipDateTimeField34, 0);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone43);
        boolean boolean45 = mutableDateTime41.isBefore((org.joda.time.ReadableInstant) mutableDateTime44);
        mutableDateTime44.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime44.secondOfMinute();
        java.util.Locale locale49 = null;
        java.lang.String str50 = property48.getAsText(locale49);
        org.joda.time.MutableDateTime mutableDateTime52 = property48.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField53 = property48.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53);
        int int57 = delegatedDateTimeField54.getDifference((long) 'a', (long) 100);
        int int58 = delegatedDateTimeField54.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = delegatedDateTimeField54.getType();
        java.util.Locale locale61 = null;
        dateTimeParserBucket5.saveField(dateTimeFieldType59, "1969-12-31T16:00:00.100-08:00", locale61);
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, "52");
        java.lang.Number number65 = illegalFieldValueException64.getUpperBound();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800010L + "'", long8 == 28800010L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 59 + "'", int36 == 59);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertNull(number65);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        int int34 = unsupportedDateTimeField31.getDifference((long) 4, (long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField31.getType();
        org.joda.time.DurationField durationField36 = unsupportedDateTimeField31.getRangeDurationField();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNull(durationField36);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.Object obj5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj5, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.monthOfYear();
        java.lang.String str10 = gregorianChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
        boolean boolean17 = mutableDateTime13.isBefore((org.joda.time.ReadableInstant) mutableDateTime16);
        mutableDateTime16.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime16.secondOfMinute();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property20.getAsText(locale21);
        org.joda.time.MutableDateTime mutableDateTime24 = property20.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField25 = property20.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = delegatedDateTimeField26.getAsText(10L, locale28);
        long long31 = delegatedDateTimeField26.roundHalfFloor(100L);
        long long34 = delegatedDateTimeField26.set((-31535999968L), "59");
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        org.joda.time.DurationField durationField36 = gregorianChronology6.weeks();
        try {
            org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(52, 0, 20549, (int) (byte) 0, 69, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-31535940968L) + "'", long34 == (-31535940968L));
        org.junit.Assert.assertNotNull(durationField36);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
//        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
//        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
//        java.lang.String str11 = dateTime9.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1870-01-01T00:00:00.000Z" + "'", str11.equals("1870-01-01T00:00:00.000Z"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        mutableDateTime6.addMonths(6);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.monthOfYear();
        mutableDateTime6.addMinutes((int) ' ');
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        java.lang.String str2 = gJChronology0.toString();
        try {
            long long7 = gJChronology0.getDateTimeMillis(57600, 23, 61668, 42);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 23 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendFractionOfHour(4, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendMillisOfSecond((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendMinuteOfDay(1970);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder33.appendSecondOfMinute(42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendLiteral(' ');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime2.setYear((int) (short) 1);
        int int9 = mutableDateTime2.getMinuteOfDay();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.millisOfDay();
        int int11 = property10.getMaximumValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 86399999 + "'", int11 == 86399999);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [960,1.0]", (java.lang.Number) 174441597981L, (java.lang.Number) (byte) 100, (java.lang.Number) 20554);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        org.joda.time.Chronology chronology8 = null;
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology8, locale9, (java.lang.Integer) 10, (int) ' ');
        boolean boolean14 = dateTimeParserBucket12.restoreState((java.lang.Object) 1.0d);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket12.getZone();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime6, dateTimeZone15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField18 = gregorianChronology17.hours();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        java.lang.Object obj3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology4.years();
        boolean boolean8 = gJChronology0.equals((java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.lang.String str17 = delegatedDateTimeField15.getAsShortText((long) (short) 0);
        int int20 = delegatedDateTimeField15.getDifference((long) (byte) 0, (long) 'a');
        long long22 = delegatedDateTimeField15.roundFloor((long) 0);
        long long24 = delegatedDateTimeField15.roundHalfCeiling(969L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1000L + "'", long24 == 1000L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        mutableDateTime6.addMonths(6);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.monthOfYear();
        mutableDateTime6.setYear(16);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime6.hourOfDay();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime6.year();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        java.lang.String str14 = zonedChronology13.toString();
        org.joda.time.Chronology chronology15 = zonedChronology13.withUTC();
        java.lang.String str16 = zonedChronology13.toString();
        org.joda.time.Chronology chronology17 = zonedChronology13.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str16.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        long long31 = delegatedDateTimeField24.roundFloor((long) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) delegatedDateTimeField24);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology35 = julianChronology33.withZone(dateTimeZone34);
        java.lang.Object obj36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(obj36, (org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTime.Property property39 = dateTime38.weekOfWeekyear();
        org.joda.time.DateTime dateTime40 = property39.roundHalfEvenCopy();
        boolean boolean41 = dateTime40.isEqualNow();
        boolean boolean42 = julianChronology33.equals((java.lang.Object) dateTime40);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone47 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean48 = fixedDateTimeZone47.isFixed();
        long long51 = fixedDateTimeZone47.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.MutableDateTime mutableDateTime54 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.MutableDateTime mutableDateTime57 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone56);
        boolean boolean58 = mutableDateTime54.isBefore((org.joda.time.ReadableInstant) mutableDateTime57);
        mutableDateTime57.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property61 = mutableDateTime57.secondOfMinute();
        java.util.Locale locale62 = null;
        java.lang.String str63 = property61.getAsText(locale62);
        org.joda.time.MutableDateTime mutableDateTime65 = property61.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField66 = property61.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField67 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField66);
        java.lang.String str69 = delegatedDateTimeField67.getAsShortText((long) (short) 0);
        int int72 = delegatedDateTimeField67.getDifference((long) (byte) 0, (long) 'a');
        long long74 = delegatedDateTimeField67.roundFloor((long) 0);
        boolean boolean75 = fixedDateTimeZone47.equals((java.lang.Object) delegatedDateTimeField67);
        long long79 = fixedDateTimeZone47.convertLocalToUTC((long) 1, false, (-210866673600000L));
        org.joda.time.DateTimeZone dateTimeZone80 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone47);
        org.joda.time.MutableDateTime mutableDateTime81 = dateTime40.toMutableDateTime(dateTimeZone80);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-90L) + "'", long51 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "0" + "'", str63.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "0" + "'", str69.equals("0"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 0L + "'", long74 == 0L);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1L + "'", long79 == 1L);
        org.junit.Assert.assertNotNull(dateTimeZone80);
        org.junit.Assert.assertNotNull(mutableDateTime81);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        java.lang.String str32 = unsupportedDateTimeField31.toString();
        try {
            long long34 = unsupportedDateTimeField31.roundHalfFloor((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UnsupportedDateTimeField" + "'", str32.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Instant instant4 = instant0.withMillis((long) 1);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant7 = instant4.withDurationAdded(readableDuration5, (-1));
        org.joda.time.Instant instant8 = instant7.toInstant();
        org.joda.time.Instant instant10 = instant7.minus(0L);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        long long7 = fixedDateTimeZone5.nextTransition((long) (byte) -1);
        int int9 = fixedDateTimeZone5.getStandardOffset((long) 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "ZonedChronology[ISOChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        long long31 = delegatedDateTimeField24.roundFloor((long) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) delegatedDateTimeField24);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology35 = julianChronology33.withZone(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = julianChronology33.weekOfWeekyear();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendClockhourOfHalfday(16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.appendCenturyOfEra(16, 20521);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder33.appendFractionOfHour((int) ' ', (int) '4');
        boolean boolean42 = dateTimeFormatterBuilder33.canBuildPrinter();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        java.util.Locale locale12 = null;
        int int13 = property9.getMaximumTextLength(locale12);
        org.joda.time.MutableDateTime mutableDateTime14 = property9.roundCeiling();
        org.joda.time.Instant instant15 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Instant instant17 = instant15.plus(readableDuration16);
        org.joda.time.Instant instant19 = instant15.withMillis((long) 1);
        org.joda.time.DateTime dateTime20 = instant19.toDateTime();
        org.joda.time.DateTime.Property property21 = dateTime20.minuteOfDay();
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTime20.toString("59", locale23);
        org.joda.time.DateTime.Property property25 = dateTime20.weekOfWeekyear();
        org.joda.time.DateTime.Property property26 = dateTime20.millisOfDay();
        boolean boolean27 = mutableDateTime14.isBefore((org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "59" + "'", str24.equals("59"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (byte) -1, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.hourOfDay();
        int int4 = mutableDateTime2.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(10L, 45747429L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 457474290L + "'", long2 == 457474290L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str7 = cachedDateTimeZone5.getNameKey((long) 12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "secondOfMinute" + "'", str7.equals("secondOfMinute"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime2.setYear((int) (short) 1);
        int int9 = mutableDateTime2.getMinuteOfDay();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.millisOfDay();
        int int11 = property10.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 86399999 + "'", int11 == 86399999);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone6);
        boolean boolean8 = mutableDateTime4.isBefore((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime7.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.secondOfMinute();
        java.util.Locale locale12 = null;
        java.lang.String str13 = property11.getAsText(locale12);
        org.joda.time.MutableDateTime mutableDateTime15 = property11.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = delegatedDateTimeField17.getAsText(10L, locale19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField17.getAsShortText((int) (byte) 0, locale22);
        boolean boolean24 = gJChronology1.equals((java.lang.Object) delegatedDateTimeField17);
        boolean boolean26 = gJChronology1.equals((java.lang.Object) "secondOfMinute");
        java.lang.String str27 = gJChronology1.toString();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 100, (org.joda.time.Chronology) gJChronology1);
        try {
            long long36 = gJChronology1.getDateTimeMillis(0, 26, (int) (short) 0, 6, 42, (-292275054), 42);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str27.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendFractionOfHour(4, (-1));
        dateTimeFormatterBuilder33.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTimeZoneName();
        boolean boolean36 = dateTimeFormatterBuilder35.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter37.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder35.append(dateTimeParser38);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        java.lang.String str2 = gJChronology0.toString();
        java.lang.String str3 = gJChronology0.toString();
        org.joda.time.Instant instant4 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        long long8 = dateTimeParserBucket5.computeMillis(false, "Pacific Standard Time");
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone14);
        boolean boolean16 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
        mutableDateTime15.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.secondOfMinute();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property19.getAsText(locale20);
        org.joda.time.MutableDateTime mutableDateTime23 = property19.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField24 = property19.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        java.lang.String str27 = delegatedDateTimeField25.getAsShortText((long) (short) 0);
        int int30 = delegatedDateTimeField25.getDifference((long) (byte) 0, (long) 'a');
        int int32 = delegatedDateTimeField25.get(0L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField(chronology9, (org.joda.time.DateTimeField) delegatedDateTimeField25, 0);
        int int36 = skipDateTimeField34.get((long) (-1));
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipDateTimeField34, 0);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone43);
        boolean boolean45 = mutableDateTime41.isBefore((org.joda.time.ReadableInstant) mutableDateTime44);
        mutableDateTime44.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime44.secondOfMinute();
        java.util.Locale locale49 = null;
        java.lang.String str50 = property48.getAsText(locale49);
        org.joda.time.MutableDateTime mutableDateTime52 = property48.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField53 = property48.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField53);
        int int57 = delegatedDateTimeField54.getDifference((long) 'a', (long) 100);
        int int58 = delegatedDateTimeField54.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = delegatedDateTimeField54.getType();
        java.util.Locale locale61 = null;
        dateTimeParserBucket5.saveField(dateTimeFieldType59, "1969-12-31T16:00:00.100-08:00", locale61);
        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, (java.lang.Number) (-90L), (java.lang.Number) 20545, (java.lang.Number) 1560343325L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800010L + "'", long8 == 28800010L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 59 + "'", int36 == 59);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
    }
}

