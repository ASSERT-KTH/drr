import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (byte) -1, (-1), 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = property9.set("1969-12-31T16:00:00.100-08:00", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16:00:00.100-08:00\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 3, (int) '#', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1.0d, number2, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866673600000L) + "'", long1 == (-210866673600000L));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1L), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.io.Writer writer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(writer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        try {
            long long10 = gregorianChronology1.getDateTimeMillis(3, 0, 0, (int) (short) 100, (int) (byte) 0, 1969, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withDate(10, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray24 = new int[] { (byte) 1, 'a', (short) 100, (byte) -1, '#', '4' };
        try {
            int[] intArray26 = delegatedDateTimeField15.addWrapField(readablePartial16, (int) '4', intArray24, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = mutableDateTime2.toCalendar(locale4);
        try {
            mutableDateTime2.setMonthOfYear((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(calendar5);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = gregorianChronology1.get(readablePeriod3, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        try {
            mutableDateTime2.setWeekOfWeekyear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 960, (java.lang.Number) (byte) 100, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(10L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField15, dateTimeFieldType19, (int) '4', (int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        mutableDateTime2.setTime((long) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        int int6 = property5.getLeapAmount();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.ReadablePartial readablePartial19 = null;
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = delegatedDateTimeField15.getAsShortText(readablePartial19, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) 'a', 960, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        try {
            long long7 = gregorianChronology1.getDateTimeMillis((int) ' ', 960, (int) ' ', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            dateTimeParserBucket5.saveField(dateTimeFieldType6, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.100-08:00\" is malformed at \"-31T16:00:00.100-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.DateTime.Property property6 = dateTime4.property(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime2.withFieldAdded(durationFieldType6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.plus(readablePeriod6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime2.withFieldAdded(durationFieldType8, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        int int15 = property9.getMaximumValueOverall();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.lang.String str17 = delegatedDateTimeField15.getAsShortText((long) (short) 0);
        int int20 = delegatedDateTimeField15.getDifference((long) (byte) 0, (long) 'a');
        try {
            long long23 = delegatedDateTimeField15.set(35L, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField6 = gregorianChronology1.years();
        long long9 = durationField6.subtract((long) ' ', 1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31535999968L) + "'", long9 == (-31535999968L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        boolean boolean6 = mutableDateTime2.isEqual((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        boolean boolean13 = mutableDateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        mutableDateTime12.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime12.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeFormatter17.getZone();
        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime12.toMutableDateTime(dateTimeZone18);
        int int20 = mutableDateTime19.getMillisOfSecond();
        mutableDateTime19.setWeekyear((int) (short) -1);
        java.util.Date date23 = mutableDateTime19.toDate();
        int int24 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) mutableDateTime19);
        try {
            mutableDateTime19.setMillisOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        boolean boolean6 = mutableDateTime2.isEqual((long) (byte) 100);
        mutableDateTime2.addMillis((-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            mutableDateTime2.set(dateTimeFieldType9, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundFloor();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField18 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField15, dateTimeFieldType16, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10, (int) '4', (int) (short) 1, (int) (byte) 100, 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(59, (int) (byte) 10, (int) '#', (int) (byte) 1, 100, 3, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.yearOfCentury();
        java.lang.Object obj6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj6, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = gregorianChronology7.centuries();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) dateTimeField5, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket5.setOffset(0);
        java.lang.Integer int10 = dateTimeParserBucket5.getOffsetInteger();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10.equals(0));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        try {
            mutableDateTime5.setDayOfMonth((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        mutableDateTime2.addMinutes((int) (byte) -1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        try {
            mutableDateTime5.setDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
        java.lang.String str8 = dateTimeZone7.getID();
        java.lang.String str9 = dateTimeZone7.getID();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) '#', (-1), (int) 'a', (int) (byte) 10, 3, 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) ' ');
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray28 = new int[] { 'a', 1, '#', 10, 59, 960 };
        try {
            int[] intArray30 = delegatedDateTimeField15.addWrapField(readablePartial20, 10, intArray28, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(59, 1969, (int) '4', 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(10L, locale17);
        long long20 = delegatedDateTimeField15.roundHalfFloor(100L);
        long long22 = delegatedDateTimeField15.roundFloor((-1L));
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray29 = new int[] { 3, 1969, (short) 100, 1 };
        try {
            int[] intArray31 = delegatedDateTimeField15.addWrapPartial(readablePartial23, 59, intArray29, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 59");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1000L) + "'", long22 == (-1000L));
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        java.lang.String str9 = dateTimeZone8.getID();
        java.lang.String str10 = dateTimeZone8.getID();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, (-1), 1969, (int) (short) -1, (-1), (int) (byte) -1, 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("12", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"12/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket5.setOffset(0);
        long long12 = dateTimeParserBucket5.computeMillis(true, "0");
        java.lang.Object obj13 = dateTimeParserBucket5.saveState();
        java.lang.Integer int14 = dateTimeParserBucket5.getPivotYear();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14.equals(10));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.String str2 = dateTimeZone1.getID();
        java.lang.String str3 = dateTimeZone1.getID();
        java.lang.String str4 = dateTimeZone1.getID();
        long long7 = dateTimeZone1.adjustOffset((long) (-1), false);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone18);
        boolean boolean20 = mutableDateTime16.isBefore((org.joda.time.ReadableInstant) mutableDateTime19);
        mutableDateTime19.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime19.secondOfMinute();
        java.util.Locale locale24 = null;
        java.lang.String str25 = property23.getAsText(locale24);
        org.joda.time.MutableDateTime mutableDateTime27 = property23.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField28 = property23.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField29.getAsText(10L, locale31);
        long long34 = delegatedDateTimeField29.roundHalfFloor(100L);
        mutableDateTime12.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField29);
        try {
            mutableDateTime12.setDate(10, (int) (byte) -1, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime2.setYear((int) (short) 1);
        int int9 = mutableDateTime2.getMinuteOfDay();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.millisOfDay();
        org.joda.time.Chronology chronology11 = mutableDateTime2.getChronology();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalInstantExce...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        boolean boolean13 = mutableDateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        mutableDateTime12.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime12.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeFormatter17.getZone();
        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime12.toMutableDateTime(dateTimeZone18);
        try {
            org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(1969, 0, 2, 20, (int) (byte) -1, (int) (byte) 1, (int) (short) 10, dateTimeZone18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(3, 0, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfYear();
        org.joda.time.DurationField durationField5 = gregorianChronology2.centuries();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField6 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Object obj1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekyearOfCentury();
        java.lang.Object obj5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj5, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.hourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
        boolean boolean17 = mutableDateTime13.isBefore((org.joda.time.ReadableInstant) mutableDateTime16);
        mutableDateTime16.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime16.secondOfMinute();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property20.getAsText(locale21);
        org.joda.time.MutableDateTime mutableDateTime24 = property20.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField25 = property20.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        int int29 = delegatedDateTimeField26.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField30 = delegatedDateTimeField26.getDurationField();
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField26.getAsText((long) (-1), locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField26.getType();
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField26.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField35);
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField36);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone39 = dateTimeFormatter38.getZone();
        java.lang.String str40 = dateTimeZone39.getID();
        java.lang.String str41 = dateTimeZone39.getID();
        java.lang.String str42 = dateTimeZone39.getID();
        org.joda.time.Chronology chronology43 = gregorianChronology2.withZone(dateTimeZone39);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(0L, chronology43);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "59" + "'", str33.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UTC" + "'", str40.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UTC" + "'", str41.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "UTC" + "'", str42.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology43);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Chronology chronology3 = instant0.getChronology();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant0.minus(readableDuration4);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.Object obj5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj5, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.weekyearOfCentury();
        java.lang.Object obj9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.hourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology10.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone19);
        boolean boolean21 = mutableDateTime17.isBefore((org.joda.time.ReadableInstant) mutableDateTime20);
        mutableDateTime20.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime20.secondOfMinute();
        java.util.Locale locale25 = null;
        java.lang.String str26 = property24.getAsText(locale25);
        org.joda.time.MutableDateTime mutableDateTime28 = property24.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField29 = property24.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        int int33 = delegatedDateTimeField30.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField34 = delegatedDateTimeField30.getDurationField();
        java.util.Locale locale36 = null;
        java.lang.String str37 = delegatedDateTimeField30.getAsText((long) (-1), locale36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField30.getType();
        org.joda.time.DateTimeField dateTimeField39 = delegatedDateTimeField30.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology10, dateTimeField39);
        org.joda.time.field.SkipDateTimeField skipDateTimeField41 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology6, (org.joda.time.DateTimeField) skipUndoDateTimeField40);
        try {
            org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(0, (int) ' ', 59, 960, 10, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "59" + "'", str37.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeField39);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime4.minus((long) 10);
        org.joda.time.DateTime.Property property9 = dateTime4.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime4.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) yearMonthDay10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            long long8 = iSOChronology0.getDateTimeMillis((int) (byte) 1, 0, (int) (byte) 0, 2, (int) (short) 10, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withTime(100, 6, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
//        java.lang.String str2 = dateTimeZone1.getID();
//        java.lang.String str3 = dateTimeZone1.getID();
//        java.lang.String str4 = dateTimeZone1.getID();
//        long long7 = dateTimeZone1.adjustOffset((long) (-1), false);
//        java.lang.String str9 = dateTimeZone1.getShortName((long) (short) 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.joda.time.DurationField durationField5 = property4.getDurationField();
        org.joda.time.DateTimeField dateTimeField6 = property4.getField();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) property4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        org.joda.time.DurationField durationField21 = null;
        java.lang.Object obj22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(obj22, (org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.hourOfDay();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology23.yearOfCentury();
        org.joda.time.DurationField durationField28 = gregorianChronology23.years();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField29 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType20, durationField21, durationField28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-210866673600000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) -1, 59000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-59000) + "'", int2 == (-59000));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.plus(readablePeriod6);
        org.joda.time.DateTime.Property property8 = dateTime2.dayOfYear();
        try {
            org.joda.time.DateTime dateTime10 = property8.setCopy(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 59, "");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException(0L, "");
        java.lang.String str6 = illegalInstantException5.toString();
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 ()" + "'", str6.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 ()"));
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
//        int int7 = dateTime6.getDayOfWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("59", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = dateTime4.toString("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)", locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("59");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"59\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2019, (long) 86399999);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 174441597981L + "'", long2 == 174441597981L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime4.minus((long) 10);
        org.joda.time.DateTime.Property property9 = dateTime4.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime4.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) yearMonthDay10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.io.Writer writer1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj2, (org.joda.time.Chronology) gregorianChronology3);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("97");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '97' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        try {
            long long10 = gJChronology0.getDateTimeMillis((int) (short) 0, 5, (int) '#', (int) (short) 0, (int) (short) 10, (int) (short) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime7 = dateTime2.minusDays((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        java.util.Date date16 = mutableDateTime12.toDate();
        try {
            mutableDateTime12.setMillisOfSecond(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isParser();
        try {
            long long4 = dateTimeFormatter0.parseMillis("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("12");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"12\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant2.plus(readableDuration3);
        org.joda.time.Instant instant6 = instant2.withMillis((long) 1);
        org.joda.time.DateTime dateTime7 = instant6.toDateTime();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) instant6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter1.getPrinter();
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(59, 23, 960, 1, (int) ' ', 2019, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone6);
        boolean boolean8 = mutableDateTime4.isBefore((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime7.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.secondOfMinute();
        java.util.Locale locale12 = null;
        java.lang.String str13 = property11.getAsText(locale12);
        org.joda.time.MutableDateTime mutableDateTime15 = property11.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField16 = property11.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        java.lang.String str19 = delegatedDateTimeField17.getAsShortText((long) (short) 0);
        int int22 = delegatedDateTimeField17.getDifference((long) (byte) 0, (long) 'a');
        int int24 = delegatedDateTimeField17.get(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology26 = dateTimeFormatter25.getChronolgy();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) chronology26);
        org.joda.time.DateTime dateTime29 = dateTime27.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime31 = dateTime27.minus((long) 10);
        org.joda.time.DateTime.Property property32 = dateTime27.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime27.toYearMonthDay();
        java.util.Locale locale35 = null;
        java.lang.String str36 = delegatedDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay33, (int) 'a', locale35);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) yearMonthDay33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "97" + "'", str36.equals("97"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone3);
        java.util.Date date5 = mutableDateTime4.toDate();
        java.lang.String str6 = mutableDateTime4.toString();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.millisOfSecond();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) mutableDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str6.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Instant instant4 = instant0.withMillis((long) 1);
        java.lang.Object obj5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj5, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.hourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology6.hourOfHalfday();
        int int12 = instant4.get(dateTimeField11);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setMillisOfDay((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "59");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        int int4 = mutableDateTime2.getYearOfEra();
        boolean boolean6 = mutableDateTime2.isEqual((long) (byte) -1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        mutableDateTime13.setYear(100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime2.setYear((int) (short) 1);
        int int9 = mutableDateTime2.getMinuteOfDay();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.millisOfDay();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.secondOfMinute();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        mutableDateTime2.setMillis((long) 100);
        try {
            mutableDateTime2.setMonthOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded((long) 23, 100);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.yearOfCentury();
        org.joda.time.DurationField durationField6 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField7 = gregorianChronology1.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime4.minus((long) 10);
        org.joda.time.DateTime.Property property9 = dateTime4.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime4.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) yearMonthDay10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsText((long) (-1), locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField15.getType();
        org.joda.time.DateTimeField dateTimeField24 = delegatedDateTimeField15.getWrappedField();
        long long26 = delegatedDateTimeField15.roundHalfFloor((long) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology28 = dateTimeFormatter27.getChronolgy();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) chronology28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime33 = dateTime29.minus((long) 10);
        org.joda.time.DateTime.Property property34 = dateTime29.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay35 = dateTime29.toYearMonthDay();
        int[] intArray43 = new int[] { '#', 2, 4, (byte) 1, (-1), 1969 };
        try {
            int[] intArray45 = delegatedDateTimeField15.add((org.joda.time.ReadablePartial) yearMonthDay35, 20, intArray43, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(yearMonthDay35);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        mutableDateTime12.addMillis((int) (short) -1);
        org.joda.time.ReadableDuration readableDuration18 = null;
        mutableDateTime12.add(readableDuration18, (-59000));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears(0);
        java.lang.Object obj7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime10 = dateTime4.withChronology((org.joda.time.Chronology) gregorianChronology8);
        try {
            long long18 = gregorianChronology8.getDateTimeMillis((int) ' ', (int) (short) -1, (-59000), (int) (short) -1, 100, 0, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology9 = dateTimeFormatter8.getChronolgy();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime10.minus((long) 10);
        org.joda.time.DateTime.Property property15 = dateTime10.minuteOfHour();
        try {
            org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology7 = null;
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology7, locale8, (java.lang.Integer) 10, (int) ' ');
        boolean boolean13 = dateTimeParserBucket11.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket11.setOffset(0);
        long long18 = dateTimeParserBucket11.computeMillis(true, "0");
        dateTimeParserBucket11.setOffset((int) (short) 100);
        long long23 = dateTimeParserBucket11.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone28);
        boolean boolean30 = mutableDateTime26.isBefore((org.joda.time.ReadableInstant) mutableDateTime29);
        mutableDateTime29.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime29.secondOfMinute();
        java.util.Locale locale34 = null;
        java.lang.String str35 = property33.getAsText(locale34);
        org.joda.time.MutableDateTime mutableDateTime37 = property33.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField38 = property33.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38);
        int int42 = delegatedDateTimeField39.getDifference((long) 'a', (long) 100);
        int int43 = delegatedDateTimeField39.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = delegatedDateTimeField39.getType();
        dateTimeParserBucket11.saveField(dateTimeFieldType44, (int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime48 = dateTime4.withField(dateTimeFieldType44, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-90L) + "'", long23 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("0", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
//        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsText(locale9);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12" + "'", str10.equals("12"));
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 3, (-31535999968L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -94607999904");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
//        org.joda.time.DateTime dateTime7 = property3.withMinimumValue();
//        java.lang.Object obj8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj8, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) (byte) 0, (int) '#');
//        org.joda.time.DateTime dateTime15 = dateTime10.minusYears(100);
//        org.joda.time.DateTime dateTime16 = dateTime10.toDateTime();
//        org.joda.time.DateTime dateTime18 = dateTime10.minusMinutes(6);
//        int int19 = property3.compareTo((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime20 = dateTime10.withLaterOffsetAtOverlap();
//        int int21 = dateTime10.getHourOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears(0);
        java.lang.Object obj7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime10 = dateTime4.withChronology((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime4.withMinuteOfHour(23);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '#', 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: 35 * 86399999");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsText((long) (-1), locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField15.getType();
        org.joda.time.DurationField durationField24 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = fixedDateTimeZone4.previousTransition((long) 1);
        java.lang.Object obj12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj12, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.weekOfWeekyear();
        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime18 = property15.setCopy(3);
        org.joda.time.DateTime dateTime19 = property15.withMinimumValue();
        java.lang.Object obj20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(obj20, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime27 = dateTime22.minusYears(100);
        org.joda.time.DateTime dateTime28 = dateTime22.toDateTime();
        org.joda.time.DateTime dateTime30 = dateTime22.minusMinutes(6);
        int int31 = property15.compareTo((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime32 = dateTime22.withLaterOffsetAtOverlap();
        try {
            org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime32, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.lang.Object obj2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.monthOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology3);
        java.lang.Integer int8 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(int8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendTwoDigitYear(10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder0.appendTimeZoneOffset("secondOfMinute", false, 4, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        long long31 = delegatedDateTimeField24.roundFloor((long) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) delegatedDateTimeField24);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (-11));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -11");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(julianChronology33);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
//        org.joda.time.Chronology chronology3 = instant0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime4 = instant0.toMutableDateTime();
//        int int5 = mutableDateTime4.getDayOfWeek();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
//        org.joda.time.DateTime dateTime7 = property3.withMinimumValue();
//        java.lang.Object obj8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj8, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) (byte) 0, (int) '#');
//        org.joda.time.DateTime dateTime15 = dateTime10.minusYears(100);
//        org.joda.time.DateTime dateTime16 = dateTime10.toDateTime();
//        org.joda.time.DateTime dateTime18 = dateTime10.minusMinutes(6);
//        int int19 = property3.compareTo((org.joda.time.ReadableInstant) dateTime10);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = property3.getAsShortText(locale20);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "24" + "'", str21.equals("24"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        mutableDateTime2.setMillis((long) 100);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology7 = dateTimeFormatter6.getChronolgy();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) chronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime8.minus((long) 10);
        org.joda.time.DateTime.Property property13 = dateTime8.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime8.toYearMonthDay();
        try {
            int int15 = property5.compareTo((org.joda.time.ReadablePartial) yearMonthDay14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime2.setYear((int) (short) 1);
        int int9 = mutableDateTime2.getMinuteOfDay();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.millisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeFormatter11.getZone();
        java.lang.String str13 = dateTimeZone12.getID();
        java.lang.String str14 = dateTimeZone12.getID();
        java.lang.String str15 = dateTimeZone12.getID();
        long long18 = dateTimeZone12.adjustOffset((long) (-1), false);
        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime2.toMutableDateTime(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime2.copy();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 960 + "'", int9 == 960);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.Object obj7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(obj7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.dayOfYear();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((-59000), 1, 6, (-1), 23, (-11), 23, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        mutableDateTime12.addMillis((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone22);
        boolean boolean24 = mutableDateTime20.isBefore((org.joda.time.ReadableInstant) mutableDateTime23);
        mutableDateTime23.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime23.secondOfMinute();
        java.util.Locale locale28 = null;
        java.lang.String str29 = property27.getAsText(locale28);
        org.joda.time.MutableDateTime mutableDateTime31 = property27.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField32 = property27.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        int int36 = delegatedDateTimeField33.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField37 = delegatedDateTimeField33.getDurationField();
        java.util.Locale locale39 = null;
        java.lang.String str40 = delegatedDateTimeField33.getAsText((long) (-1), locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField33.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, (java.lang.Number) 20, "secondOfMinute");
        try {
            mutableDateTime12.set(dateTimeFieldType41, (-59000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -59000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "59" + "'", str40.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-1L), (java.lang.Number) 960, (java.lang.Number) 1.0f);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone7);
        boolean boolean9 = mutableDateTime5.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        mutableDateTime8.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime8.secondOfMinute();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsText(locale13);
        org.joda.time.MutableDateTime mutableDateTime16 = property12.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField17 = property12.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        int int21 = delegatedDateTimeField18.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField18.getDurationField();
        java.util.Locale locale24 = null;
        java.lang.String str25 = delegatedDateTimeField18.getAsText((long) (-1), locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = delegatedDateTimeField18.getType();
        org.joda.time.DateTimeField dateTimeField27 = delegatedDateTimeField18.getWrappedField();
        long long29 = delegatedDateTimeField18.roundHalfFloor((long) 0);
        boolean boolean30 = delegatedDateTimeField18.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18, 23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology34 = dateTimeFormatter33.getChronolgy();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime39 = dateTime35.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone41 = dateTimeFormatter40.getZone();
        java.lang.String str42 = dateTimeZone41.getID();
        java.lang.String str43 = dateTimeZone41.getID();
        java.lang.String str44 = dateTimeZone41.getID();
        org.joda.time.DateTime dateTime45 = dateTime39.withZoneRetainFields(dateTimeZone41);
        org.joda.time.DateTime dateTime47 = dateTime39.plus(0L);
        org.joda.time.DateTime dateTime49 = dateTime39.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime50 = dateTime49.toLocalDateTime();
        int[] intArray53 = new int[] { 2 };
        try {
            int[] intArray55 = skipDateTimeField32.set((org.joda.time.ReadablePartial) localDateTime50, 10, intArray53, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "59" + "'", str25.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "UTC" + "'", str42.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "UTC" + "'", str43.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "UTC" + "'", str44.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDateTime50);
        org.junit.Assert.assertNotNull(intArray53);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone18);
        boolean boolean20 = mutableDateTime16.isBefore((org.joda.time.ReadableInstant) mutableDateTime19);
        mutableDateTime19.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime19.secondOfMinute();
        java.util.Locale locale24 = null;
        java.lang.String str25 = property23.getAsText(locale24);
        org.joda.time.MutableDateTime mutableDateTime27 = property23.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField28 = property23.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField29.getAsText(10L, locale31);
        long long34 = delegatedDateTimeField29.roundHalfFloor(100L);
        mutableDateTime12.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField29);
        int int38 = delegatedDateTimeField29.getDifference(0L, (-90L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        java.lang.Object obj4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone14);
        boolean boolean16 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
        mutableDateTime15.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.secondOfMinute();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property19.getAsText(locale20);
        org.joda.time.MutableDateTime mutableDateTime23 = property19.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField24 = property19.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        int int28 = delegatedDateTimeField25.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField25.getDurationField();
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField25.getAsText((long) (-1), locale31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField25.getType();
        org.joda.time.DateTimeField dateTimeField34 = delegatedDateTimeField25.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        java.lang.Object obj37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(obj37, (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.weekyearOfCentury();
        java.lang.Object obj41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(obj41, (org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology42.hourOfDay();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology42.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone48);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone51);
        boolean boolean53 = mutableDateTime49.isBefore((org.joda.time.ReadableInstant) mutableDateTime52);
        mutableDateTime52.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property56 = mutableDateTime52.secondOfMinute();
        java.util.Locale locale57 = null;
        java.lang.String str58 = property56.getAsText(locale57);
        org.joda.time.MutableDateTime mutableDateTime60 = property56.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField61 = property56.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField61);
        int int65 = delegatedDateTimeField62.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField66 = delegatedDateTimeField62.getDurationField();
        java.util.Locale locale68 = null;
        java.lang.String str69 = delegatedDateTimeField62.getAsText((long) (-1), locale68);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = delegatedDateTimeField62.getType();
        org.joda.time.DateTimeField dateTimeField71 = delegatedDateTimeField62.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology42, dateTimeField71);
        org.joda.time.field.SkipDateTimeField skipDateTimeField73 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology38, (org.joda.time.DateTimeField) skipUndoDateTimeField72);
        org.joda.time.field.SkipDateTimeField skipDateTimeField74 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField72);
        org.joda.time.DurationField durationField75 = gregorianChronology1.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "59" + "'", str32.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0" + "'", str58.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "59" + "'", str69.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField75);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(59, 0, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(5, 0, (int) (short) 10, 59, 960, (int) (short) 100, (-59000), dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) chronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime3.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter8.getZone();
        java.lang.String str10 = dateTimeZone9.getID();
        java.lang.String str11 = dateTimeZone9.getID();
        java.lang.String str12 = dateTimeZone9.getID();
        org.joda.time.DateTime dateTime13 = dateTime7.withZoneRetainFields(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = dateTime7.plus(0L);
        org.joda.time.DateTime dateTime17 = dateTime7.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime18 = dateTime17.toLocalDateTime();
        int[] intArray24 = new int[] { '#', 3, (-11), ' ', 100 };
        try {
            gJChronology0.validate((org.joda.time.ReadablePartial) localDateTime18, intArray24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        try {
            long long33 = unsupportedDateTimeField31.roundHalfEven((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Instant instant4 = instant0.withMillis((long) 1);
        org.joda.time.Instant instant6 = instant4.minus(0L);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant4.plus(readableDuration7);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime4.centuryOfEra();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundHalfFloor();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.plusDays((int) '4');
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withCenturyOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for centuryOfEra must be in the range [1,2922790]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendWeekOfWeekyear((-11));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.add(35L);
        mutableDateTime11.addWeekyears(1);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            mutableDateTime11.add(durationFieldType14, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone33);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone36);
        boolean boolean38 = mutableDateTime34.isBefore((org.joda.time.ReadableInstant) mutableDateTime37);
        mutableDateTime37.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime37.secondOfMinute();
        java.util.Locale locale42 = null;
        java.lang.String str43 = property41.getAsText(locale42);
        org.joda.time.MutableDateTime mutableDateTime45 = property41.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField46 = property41.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        java.lang.String str49 = delegatedDateTimeField47.getAsShortText((long) (short) 0);
        int int52 = delegatedDateTimeField47.getDifference((long) (byte) 0, (long) 'a');
        int int54 = delegatedDateTimeField47.get(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology56 = dateTimeFormatter55.getChronolgy();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((java.lang.Object) chronology56);
        org.joda.time.DateTime dateTime59 = dateTime57.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime61 = dateTime57.minus((long) 10);
        org.joda.time.DateTime.Property property62 = dateTime57.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay63 = dateTime57.toYearMonthDay();
        java.util.Locale locale65 = null;
        java.lang.String str66 = delegatedDateTimeField47.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay63, (int) 'a', locale65);
        int[] intArray71 = new int[] { (-1), 52, 2000 };
        try {
            int[] intArray73 = unsupportedDateTimeField31.add((org.joda.time.ReadablePartial) yearMonthDay63, 52, intArray71, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNull(chronology56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(yearMonthDay63);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "97" + "'", str66.equals("97"));
        org.junit.Assert.assertNotNull(intArray71);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekyear(0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        java.lang.Object obj32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(obj32, (org.joda.time.Chronology) gregorianChronology33);
        org.joda.time.DateTime dateTime37 = dateTime34.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime39 = dateTime34.minusYears(100);
        org.joda.time.DateTime.Property property40 = dateTime39.dayOfMonth();
        org.joda.time.DateTime dateTime41 = property40.roundFloorCopy();
        int int42 = dateTime41.getMonthOfYear();
        org.joda.time.DateTime dateTime44 = dateTime41.plus((-1000L));
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone46);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone49);
        boolean boolean51 = mutableDateTime47.isBefore((org.joda.time.ReadableInstant) mutableDateTime50);
        mutableDateTime50.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property54 = mutableDateTime50.secondOfMinute();
        java.util.Locale locale55 = null;
        java.lang.String str56 = property54.getAsText(locale55);
        org.joda.time.MutableDateTime mutableDateTime58 = property54.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField59 = property54.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField60 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField59);
        java.lang.String str62 = delegatedDateTimeField60.getAsShortText((long) (short) 0);
        int int65 = delegatedDateTimeField60.getDifference((long) (byte) 0, (long) 'a');
        int int67 = delegatedDateTimeField60.get(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter68 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology69 = dateTimeFormatter68.getChronolgy();
        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime((java.lang.Object) chronology69);
        org.joda.time.DateTime dateTime72 = dateTime70.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime74 = dateTime70.minus((long) 10);
        org.joda.time.DateTime.Property property75 = dateTime70.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay76 = dateTime70.toYearMonthDay();
        java.util.Locale locale78 = null;
        java.lang.String str79 = delegatedDateTimeField60.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay76, (int) 'a', locale78);
        org.joda.time.DateTime dateTime80 = dateTime44.withFields((org.joda.time.ReadablePartial) yearMonthDay76);
        try {
            int int81 = unsupportedDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay76);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "0" + "'", str62.equals("0"));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter68);
        org.junit.Assert.assertNull(chronology69);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(yearMonthDay76);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "97" + "'", str79.equals("97"));
        org.junit.Assert.assertNotNull(dateTime80);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean6 = fixedDateTimeZone5.isFixed();
        int int8 = fixedDateTimeZone5.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        try {
            org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, (long) 1969, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withDayOfMonth((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = gregorianChronology1.get(readablePeriod4, 174441597981L, (long) 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = mutableDateTime2.toCalendar(locale4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = property6.set((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(calendar5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
        int int7 = dateTime6.getEra();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMinutes(0);
        org.joda.time.DateTime dateTime10 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readableDuration11);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime10 = property9.roundFloor();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.minuteOfHour();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsText((long) (-1), locale21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone24 = dateTimeFormatter23.getZone();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology27 = dateTimeFormatter26.getChronolgy();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) chronology27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime32 = dateTime28.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone34 = dateTimeFormatter33.getZone();
        java.lang.String str35 = dateTimeZone34.getID();
        java.lang.String str36 = dateTimeZone34.getID();
        java.lang.String str37 = dateTimeZone34.getID();
        org.joda.time.DateTime dateTime38 = dateTime32.withZoneRetainFields(dateTimeZone34);
        org.joda.time.DateTime dateTime40 = dateTime32.plus(0L);
        org.joda.time.DateTime dateTime42 = dateTime32.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime43 = dateTime42.toLocalDateTime();
        boolean boolean44 = dateTimeZone24.isLocalDateTimeGap(localDateTime43);
        int[] intArray48 = new int[] { 3, 0 };
        try {
            int[] intArray50 = delegatedDateTimeField15.add((org.joda.time.ReadablePartial) localDateTime43, (int) (short) 1, intArray48, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Fields invalid for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "UTC" + "'", str35.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UTC" + "'", str36.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UTC" + "'", str37.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localDateTime43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        boolean boolean5 = dateTime4.isEqualNow();
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withDayOfWeek(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone18);
        boolean boolean20 = mutableDateTime16.isBefore((org.joda.time.ReadableInstant) mutableDateTime19);
        mutableDateTime19.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime19.secondOfMinute();
        java.util.Locale locale24 = null;
        java.lang.String str25 = property23.getAsText(locale24);
        org.joda.time.MutableDateTime mutableDateTime27 = property23.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField28 = property23.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField29.getAsText(10L, locale31);
        long long34 = delegatedDateTimeField29.roundHalfFloor(100L);
        mutableDateTime12.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology37 = dateTimeFormatter36.getChronolgy();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) chronology37);
        org.joda.time.DateTime dateTime40 = dateTime38.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime42 = dateTime38.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone44 = dateTimeFormatter43.getZone();
        java.lang.String str45 = dateTimeZone44.getID();
        java.lang.String str46 = dateTimeZone44.getID();
        java.lang.String str47 = dateTimeZone44.getID();
        org.joda.time.DateTime dateTime48 = dateTime42.withZoneRetainFields(dateTimeZone44);
        org.joda.time.DateTime dateTime50 = dateTime42.plus(0L);
        org.joda.time.DateTime dateTime52 = dateTime42.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        int[] intArray60 = new int[] { 1, 4, 52, 49, 86399999 };
        try {
            int[] intArray62 = delegatedDateTimeField29.add((org.joda.time.ReadablePartial) localDateTime53, (int) (short) 1, intArray60, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNull(chronology37);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UTC" + "'", str45.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "UTC" + "'", str46.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UTC" + "'", str47.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertNotNull(intArray60);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        boolean boolean6 = mutableDateTime2.isEqual((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        boolean boolean13 = mutableDateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        mutableDateTime12.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime12.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeFormatter17.getZone();
        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime12.toMutableDateTime(dateTimeZone18);
        int int20 = mutableDateTime19.getMillisOfSecond();
        mutableDateTime19.setWeekyear((int) (short) -1);
        java.util.Date date23 = mutableDateTime19.toDate();
        int int24 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) mutableDateTime19);
        mutableDateTime2.addMinutes(0);
        try {
            mutableDateTime2.setDateTime(20, 0, (int) (short) 10, (int) (short) 1, (int) (byte) 0, 0, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        try {
            long long34 = unsupportedDateTimeField31.addWrapField((long) 86399999, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone34 = dateTimeFormatter33.getZone();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeUtils.getZone(dateTimeZone34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology37 = dateTimeFormatter36.getChronolgy();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) chronology37);
        org.joda.time.DateTime dateTime40 = dateTime38.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime42 = dateTime38.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone44 = dateTimeFormatter43.getZone();
        java.lang.String str45 = dateTimeZone44.getID();
        java.lang.String str46 = dateTimeZone44.getID();
        java.lang.String str47 = dateTimeZone44.getID();
        org.joda.time.DateTime dateTime48 = dateTime42.withZoneRetainFields(dateTimeZone44);
        org.joda.time.DateTime dateTime50 = dateTime42.plus(0L);
        org.joda.time.DateTime dateTime52 = dateTime42.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        boolean boolean54 = dateTimeZone34.isLocalDateTimeGap(localDateTime53);
        int[] intArray58 = new int[] { (-11), (short) 100 };
        try {
            int[] intArray60 = unsupportedDateTimeField31.addWrapPartial((org.joda.time.ReadablePartial) localDateTime53, 0, intArray58, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNull(chronology37);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UTC" + "'", str45.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "UTC" + "'", str46.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UTC" + "'", str47.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        int int10 = dateTime9.getMonthOfYear();
        org.joda.time.DateTime dateTime12 = dateTime9.plus((-1000L));
        org.joda.time.DateTime.Property property13 = dateTime9.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray11 = gregorianChronology1.get(readablePeriod8, (long) (-11), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime4.minus((long) 10);
        org.joda.time.DateTime dateTime10 = dateTime4.plusYears((int) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths(100);
        boolean boolean14 = dateTime10.isAfter((long) (-59000));
        org.joda.time.DateTime.Property property15 = dateTime10.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean22 = fixedDateTimeZone21.isFixed();
        int int24 = fixedDateTimeZone21.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime10.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime26);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        java.lang.Object obj4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone14);
        boolean boolean16 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
        mutableDateTime15.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.secondOfMinute();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property19.getAsText(locale20);
        org.joda.time.MutableDateTime mutableDateTime23 = property19.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField24 = property19.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        int int28 = delegatedDateTimeField25.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField25.getDurationField();
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField25.getAsText((long) (-1), locale31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField25.getType();
        org.joda.time.DateTimeField dateTimeField34 = delegatedDateTimeField25.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        java.lang.Object obj37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(obj37, (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.weekyearOfCentury();
        java.lang.Object obj41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(obj41, (org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology42.hourOfDay();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology42.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone48);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone51);
        boolean boolean53 = mutableDateTime49.isBefore((org.joda.time.ReadableInstant) mutableDateTime52);
        mutableDateTime52.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property56 = mutableDateTime52.secondOfMinute();
        java.util.Locale locale57 = null;
        java.lang.String str58 = property56.getAsText(locale57);
        org.joda.time.MutableDateTime mutableDateTime60 = property56.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField61 = property56.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField61);
        int int65 = delegatedDateTimeField62.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField66 = delegatedDateTimeField62.getDurationField();
        java.util.Locale locale68 = null;
        java.lang.String str69 = delegatedDateTimeField62.getAsText((long) (-1), locale68);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = delegatedDateTimeField62.getType();
        org.joda.time.DateTimeField dateTimeField71 = delegatedDateTimeField62.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology42, dateTimeField71);
        org.joda.time.field.SkipDateTimeField skipDateTimeField73 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology38, (org.joda.time.DateTimeField) skipUndoDateTimeField72);
        org.joda.time.field.SkipDateTimeField skipDateTimeField74 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField72);
        java.util.Locale locale76 = null;
        java.lang.String str77 = skipDateTimeField74.getAsShortText((-62167190822000L), locale76);
        int int78 = skipDateTimeField74.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "59" + "'", str32.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0" + "'", str58.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "59" + "'", str69.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "0" + "'", str77.equals("0"));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsText((long) (-1), locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 20, "secondOfMinute");
        java.lang.Number number27 = illegalFieldValueException26.getIllegalNumberValue();
        java.lang.Number number28 = illegalFieldValueException26.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 20 + "'", number27.equals(20));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 20 + "'", number28.equals(20));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(10L, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField16.getAsShortText((int) (byte) 0, locale21);
        boolean boolean23 = gJChronology0.equals((java.lang.Object) delegatedDateTimeField16);
        org.joda.time.Chronology chronology24 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone29);
        boolean boolean31 = mutableDateTime27.isBefore((org.joda.time.ReadableInstant) mutableDateTime30);
        mutableDateTime30.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime30.secondOfMinute();
        java.util.Locale locale35 = null;
        java.lang.String str36 = property34.getAsText(locale35);
        java.util.Locale locale37 = null;
        int int38 = property34.getMaximumTextLength(locale37);
        boolean boolean39 = gJChronology0.equals((java.lang.Object) locale37);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "1969-12-31T16:00:00.100-08:00", (int) (byte) 10);
        java.io.Writer writer7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter8.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology12 = dateTimeFormatter11.getChronolgy();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime17 = dateTime13.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter18.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        java.lang.String str21 = dateTimeZone19.getID();
        java.lang.String str22 = dateTimeZone19.getID();
        org.joda.time.DateTime dateTime23 = dateTime17.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = dateTime17.plus(0L);
        org.joda.time.DateTime dateTime27 = dateTime17.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime28 = dateTime27.toLocalDateTime();
        boolean boolean29 = dateTimeZone9.isLocalDateTimeGap(localDateTime28);
        try {
            dateTimeFormatter0.printTo(writer7, (org.joda.time.ReadablePartial) localDateTime28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.Object obj5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj5, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfYear();
        org.joda.time.DurationField durationField9 = gregorianChronology6.minutes();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2019, (int) (byte) 1, 2, 0, 0, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology6.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTimeField11, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BasicDayOfMonthDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone12);
        boolean boolean14 = mutableDateTime10.isBefore((org.joda.time.ReadableInstant) mutableDateTime13);
        mutableDateTime13.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime13.secondOfMinute();
        java.util.Locale locale18 = null;
        java.lang.String str19 = property17.getAsText(locale18);
        org.joda.time.MutableDateTime mutableDateTime21 = property17.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField22 = property17.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        int int26 = delegatedDateTimeField23.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField27 = delegatedDateTimeField23.getDurationField();
        java.util.Locale locale29 = null;
        java.lang.String str30 = delegatedDateTimeField23.getAsText((long) (-1), locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = delegatedDateTimeField23.getType();
        org.joda.time.DateTimeField dateTimeField32 = delegatedDateTimeField23.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField32);
        long long36 = skipUndoDateTimeField33.set(0L, 59);
        boolean boolean38 = skipUndoDateTimeField33.isLeap(31535999L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology40 = dateTimeFormatter39.getChronolgy();
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((java.lang.Object) chronology40);
        org.joda.time.DateTime dateTime43 = dateTime41.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime45 = dateTime41.minus((long) 10);
        org.joda.time.DateTime.Property property46 = dateTime41.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay47 = dateTime41.toYearMonthDay();
        int int48 = skipUndoDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay47);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) yearMonthDay47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "59" + "'", str30.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 59000L + "'", long36 == 59000L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(yearMonthDay47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, (int) (short) 100, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        try {
            int int32 = unsupportedDateTimeField31.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        java.lang.Object obj9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime16 = dateTime11.minusYears(100);
        int int17 = dateTime16.getCenturyOfEra();
        boolean boolean18 = property7.equals((java.lang.Object) dateTime16);
        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(59000L, (-59000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        org.joda.time.DateTime dateTime10 = property8.withMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(10L, locale17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField15.getAsShortText((int) (byte) 0, locale20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField15.getWrappedField();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 20, chronology1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.eras();
        try {
            long long9 = gJChronology0.getDateTimeMillis((int) (byte) 10, 2019, 2019, 2000, 12, (int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        java.lang.String str5 = mutableDateTime2.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str5.equals("1969-12-31T16:00:00.100-08:00"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        boolean boolean12 = mutableDateTime8.isBefore((org.joda.time.ReadableInstant) mutableDateTime11);
        mutableDateTime11.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.secondOfMinute();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        org.joda.time.MutableDateTime mutableDateTime19 = property15.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField20 = property15.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        int int24 = delegatedDateTimeField21.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField25 = delegatedDateTimeField21.getDurationField();
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField21.getAsText((long) (-1), locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField21.getType();
        org.joda.time.DateTimeField dateTimeField30 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField30);
        java.util.Locale locale32 = null;
        int int33 = skipUndoDateTimeField31.getMaximumTextLength(locale32);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "59" + "'", str28.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        try {
            mutableDateTime12.setMillisOfSecond((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket5.setOffset(0);
        long long12 = dateTimeParserBucket5.computeMillis(true, "0");
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        java.util.Locale locale15 = null;
        try {
            dateTimeParserBucket5.saveField(dateTimeFieldType13, "+00:00", locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        long long31 = delegatedDateTimeField24.roundFloor((long) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) delegatedDateTimeField24);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField34 = julianChronology33.weekOfWeekyear();
        int int35 = julianChronology33.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withEra(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        try {
            long long34 = unsupportedDateTimeField31.remainder((long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        mutableDateTime6.setTime((-210866673600000L));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = gJChronology0.equals(obj1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        long long31 = delegatedDateTimeField24.roundFloor((long) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) delegatedDateTimeField24);
        java.lang.Object obj33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(obj33, (org.joda.time.Chronology) gregorianChronology34);
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime40 = dateTime35.minusYears(100);
        org.joda.time.DateTime.Property property41 = dateTime40.dayOfMonth();
        org.joda.time.DateTime dateTime42 = property41.roundFloorCopy();
        int int43 = dateTime42.getMonthOfYear();
        org.joda.time.LocalDateTime localDateTime44 = dateTime42.toLocalDateTime();
        int[] intArray46 = null;
        try {
            int[] intArray48 = delegatedDateTimeField24.add((org.joda.time.ReadablePartial) localDateTime44, 5, intArray46, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(localDateTime44);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = fixedDateTimeZone4.previousTransition((long) 1);
        int int13 = fixedDateTimeZone4.getStandardOffset((long) 49);
        long long16 = fixedDateTimeZone4.adjustOffset((long) 23, false);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) long16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 23L + "'", long16 == 23L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        try {
            int int32 = unsupportedDateTimeField31.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeFormatter11.getZone();
        org.joda.time.MutableDateTime mutableDateTime13 = mutableDateTime6.toMutableDateTime(dateTimeZone12);
        int int14 = mutableDateTime13.getMillisOfSecond();
        mutableDateTime13.setWeekyear((int) (short) -1);
        int int19 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "", (int) (short) 10);
        java.io.Writer writer20 = null;
        org.joda.time.ReadablePartial readablePartial21 = null;
        try {
            dateTimeFormatter0.printTo(writer20, readablePartial21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-11) + "'", int19 == (-11));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(20, (int) (short) 0, (-59000), 86399999, (int) (byte) 0, (int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(100);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter2.parseLocalDate("97");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"97\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        org.joda.time.Chronology chronology8 = null;
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology8, locale9, (java.lang.Integer) 10, (int) ' ');
        boolean boolean14 = dateTimeParserBucket12.restoreState((java.lang.Object) 1.0d);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket12.getZone();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime6, dateTimeZone15);
        mutableDateTime16.addMinutes((int) (byte) 0);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        int int34 = unsupportedDateTimeField31.getDifference((long) 4, (long) (byte) -1);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int[] intArray37 = null;
        java.util.Locale locale39 = null;
        try {
            int[] intArray40 = unsupportedDateTimeField31.set(readablePartial35, 2019, intArray37, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)", locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(10L, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField16.getAsShortText((int) (byte) 0, locale21);
        boolean boolean23 = gJChronology0.equals((java.lang.Object) delegatedDateTimeField16);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField16.getAsShortText((long) 5, locale25);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(10L, locale17);
        long long20 = delegatedDateTimeField15.roundHalfFloor(100L);
        long long23 = delegatedDateTimeField15.set((-31535999968L), "59");
        java.util.Locale locale26 = null;
        try {
            long long27 = delegatedDateTimeField15.set((long) 86399999, "GregorianChronology[UTC]", locale26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31535940968L) + "'", long23 == (-31535940968L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        mutableDateTime2.setMillis((long) 100);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.hourOfDay();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = property5.set("PST");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        long long22 = delegatedDateTimeField15.roundHalfEven((long) 6);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        long long31 = delegatedDateTimeField24.roundFloor((long) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) delegatedDateTimeField24);
        long long36 = fixedDateTimeZone4.convertLocalToUTC((long) 1, false, (-210866673600000L));
        int int38 = fixedDateTimeZone4.getStandardOffset((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        boolean boolean15 = property9.isLeap();
        org.joda.time.MutableDateTime mutableDateTime16 = property9.getMutableDateTime();
        int int17 = mutableDateTime16.getYearOfEra();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("24", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"24\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((-210866673600000L), 28800010L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -210866673600000 * 28800010");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        try {
            long long11 = gregorianChronology1.getDateTimeMillis(1, 59, 12, (int) (short) 0, 0, (int) (short) 100, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        java.lang.Object obj9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime16 = dateTime11.minusYears(100);
        int int17 = dateTime16.getCenturyOfEra();
        boolean boolean18 = property7.equals((java.lang.Object) dateTime16);
        boolean boolean19 = property7.isLeap();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.lang.String str17 = delegatedDateTimeField15.getAsShortText((long) (short) 0);
        int int20 = delegatedDateTimeField15.getDifference((long) (byte) 0, (long) 'a');
        int int22 = delegatedDateTimeField15.get(0L);
        long long25 = delegatedDateTimeField15.getDifferenceAsLong((long) (byte) 10, (-31535999968L));
        long long27 = delegatedDateTimeField15.roundFloor((long) 0);
        java.util.Locale locale28 = null;
        int int29 = delegatedDateTimeField15.getMaximumShortTextLength(locale28);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31535999L + "'", long25 == 31535999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean6 = fixedDateTimeZone5.isFixed();
        int int8 = fixedDateTimeZone5.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = dateTime9.toString("1969-12-31T16:00:00.100-08:00", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
//        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) (byte) 100);
//        int int8 = dateTime7.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        mutableDateTime12.addMillis((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        mutableDateTime12.add(readablePeriod18);
        int int20 = mutableDateTime12.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        java.lang.String str9 = dateTimeZone8.getID();
        java.lang.String str10 = dateTimeZone8.getID();
        java.lang.String str11 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime12 = dateTime6.withZoneRetainFields(dateTimeZone8);
        org.joda.time.DateTime dateTime14 = dateTime6.plus(0L);
        org.joda.time.DateTime dateTime16 = dateTime6.plusYears(5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(10L, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField16.getAsShortText((int) (byte) 0, locale21);
        boolean boolean23 = gJChronology0.equals((java.lang.Object) delegatedDateTimeField16);
        try {
            long long28 = gJChronology0.getDateTimeMillis((int) (short) -1, (int) (short) 0, 86399999, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
        org.joda.time.DateTime dateTime7 = property3.withMinimumValue();
        java.lang.Object obj8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj8, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime15 = dateTime10.minusYears(100);
        org.joda.time.DateTime dateTime16 = dateTime10.toDateTime();
        org.joda.time.DateTime dateTime18 = dateTime10.minusMinutes(6);
        int int19 = property3.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime20 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            org.joda.time.DateTime dateTime23 = dateTime10.withFieldAdded(durationFieldType21, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        long long12 = fixedDateTimeZone10.nextTransition((long) (byte) -1);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(0, (int) (byte) -1, 1, (-11), 2, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendPattern("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        int int5 = dateTime4.getSecondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket5.setOffset(0);
        long long12 = dateTimeParserBucket5.computeMillis(true, "0");
        dateTimeParserBucket5.setOffset((int) (short) 100);
        dateTimeParserBucket5.setOffset(0);
        java.lang.Integer int17 = dateTimeParserBucket5.getOffsetInteger();
        dateTimeParserBucket5.setOffset((-59000));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17.equals(0));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        int int20 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField16.getType();
        java.lang.Object obj22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(obj22, (org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.hourOfDay();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology23.yearOfCentury();
        org.joda.time.DurationField durationField28 = gregorianChronology23.minutes();
        long long31 = durationField28.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField28);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 174441597981L + "'", long31 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendHourOfHalfday((-11));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        org.joda.time.Chronology chronology8 = null;
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology8, locale9, (java.lang.Integer) 10, (int) ' ');
        boolean boolean14 = dateTimeParserBucket12.restoreState((java.lang.Object) 1.0d);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket12.getZone();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime6, dateTimeZone15);
        int int17 = mutableDateTime16.getDayOfYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 365 + "'", int17 == 365);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
//        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
//        mutableDateTime5.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
//        boolean boolean15 = property9.isLeap();
//        int int16 = property9.getMinimumValueOverall();
//        org.joda.time.MutableDateTime mutableDateTime18 = property9.set("12");
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone24);
//        boolean boolean26 = mutableDateTime22.isBefore((org.joda.time.ReadableInstant) mutableDateTime25);
//        mutableDateTime25.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime25.secondOfMinute();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = property29.getAsText(locale30);
//        org.joda.time.MutableDateTime mutableDateTime33 = property29.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField34 = property29.getField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
//        java.lang.String str37 = delegatedDateTimeField35.getAsShortText((long) (short) 0);
//        int int40 = delegatedDateTimeField35.getDifference((long) (byte) 0, (long) 'a');
//        int int42 = delegatedDateTimeField35.get(0L);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField(chronology19, (org.joda.time.DateTimeField) delegatedDateTimeField35, 0);
//        java.lang.String str46 = skipDateTimeField44.getAsShortText((long) 2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology48 = dateTimeFormatter47.getChronolgy();
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((java.lang.Object) chronology48);
//        org.joda.time.DateTime dateTime51 = dateTime49.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime53 = dateTime49.minus((long) 10);
//        org.joda.time.DateTime dateTime55 = dateTime49.plusYears((int) (short) 0);
//        org.joda.time.Chronology chronology57 = null;
//        java.util.Locale locale58 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology57, locale58, (java.lang.Integer) 10, (int) ' ');
//        boolean boolean63 = dateTimeParserBucket61.restoreState((java.lang.Object) 1.0d);
//        dateTimeParserBucket61.setOffset(0);
//        long long68 = dateTimeParserBucket61.computeMillis(true, "0");
//        dateTimeParserBucket61.setOffset((int) (short) 100);
//        long long73 = dateTimeParserBucket61.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
//        org.joda.time.DateTimeZone dateTimeZone75 = null;
//        org.joda.time.MutableDateTime mutableDateTime76 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone75);
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        org.joda.time.MutableDateTime mutableDateTime79 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone78);
//        boolean boolean80 = mutableDateTime76.isBefore((org.joda.time.ReadableInstant) mutableDateTime79);
//        mutableDateTime79.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property83 = mutableDateTime79.secondOfMinute();
//        java.util.Locale locale84 = null;
//        java.lang.String str85 = property83.getAsText(locale84);
//        org.joda.time.MutableDateTime mutableDateTime87 = property83.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField88 = property83.getField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField89 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField88);
//        int int92 = delegatedDateTimeField89.getDifference((long) 'a', (long) 100);
//        int int93 = delegatedDateTimeField89.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType94 = delegatedDateTimeField89.getType();
//        dateTimeParserBucket61.saveField(dateTimeFieldType94, (int) (byte) 100);
//        int int97 = dateTime49.get(dateTimeFieldType94);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField98 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField44, dateTimeFieldType94);
//        mutableDateTime18.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField98);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "0" + "'", str46.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 10L + "'", long68 == 10L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-90L) + "'", long73 == (-90L));
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "0" + "'", str85.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime87);
//        org.junit.Assert.assertNotNull(dateTimeField88);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType94);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 5 + "'", int97 == 5);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(10L, locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField20 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField15, dateTimeFieldType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
//        org.joda.time.DateTime.Property property7 = dateTime2.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime2.toMutableDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology10 = dateTimeFormatter9.getChronolgy();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) chronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime11.minus((long) 10);
//        org.joda.time.DateTime dateTime17 = dateTime11.plusYears((int) (short) 0);
//        org.joda.time.Chronology chronology19 = null;
//        java.util.Locale locale20 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology19, locale20, (java.lang.Integer) 10, (int) ' ');
//        boolean boolean25 = dateTimeParserBucket23.restoreState((java.lang.Object) 1.0d);
//        dateTimeParserBucket23.setOffset(0);
//        long long30 = dateTimeParserBucket23.computeMillis(true, "0");
//        dateTimeParserBucket23.setOffset((int) (short) 100);
//        long long35 = dateTimeParserBucket23.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone37);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone40);
//        boolean boolean42 = mutableDateTime38.isBefore((org.joda.time.ReadableInstant) mutableDateTime41);
//        mutableDateTime41.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property45 = mutableDateTime41.secondOfMinute();
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = property45.getAsText(locale46);
//        org.joda.time.MutableDateTime mutableDateTime49 = property45.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField50 = property45.getField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField50);
//        int int54 = delegatedDateTimeField51.getDifference((long) 'a', (long) 100);
//        int int55 = delegatedDateTimeField51.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = delegatedDateTimeField51.getType();
//        dateTimeParserBucket23.saveField(dateTimeFieldType56, (int) (byte) 100);
//        int int59 = dateTime11.get(dateTimeFieldType56);
//        mutableDateTime8.setDate((org.joda.time.ReadableInstant) dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-90L) + "'", long35 == (-90L));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 5 + "'", int59 == 5);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (byte) -1, dateTimeZone1);
        try {
            mutableDateTime2.setMonthOfYear(59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        mutableDateTime6.setSecondOfDay(100);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(10L, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField16.getAsShortText((int) (byte) 0, locale21);
        boolean boolean23 = gJChronology0.equals((java.lang.Object) delegatedDateTimeField16);
        java.lang.String str25 = delegatedDateTimeField16.getAsText((-62167190822000L));
        int int27 = delegatedDateTimeField16.getLeapAmount(28800010L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        int int10 = dateTime9.getMonthOfYear();
        org.joda.time.DateTime dateTime12 = dateTime9.plus((-1000L));
        int int13 = dateTime9.getSecondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = gJChronology0.get(readablePeriod1, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendTwoDigitYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder32.appendTimeZoneOffset("GregorianChronology[UTC]", false, (int) 'a', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMinuteOfDay(86399999);
        dateTimeFormatterBuilder31.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone38);
        boolean boolean40 = mutableDateTime36.isBefore((org.joda.time.ReadableInstant) mutableDateTime39);
        mutableDateTime39.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime39.secondOfMinute();
        java.util.Locale locale44 = null;
        java.lang.String str45 = property43.getAsText(locale44);
        org.joda.time.MutableDateTime mutableDateTime47 = property43.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField48 = property43.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48);
        int int52 = delegatedDateTimeField49.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField53 = delegatedDateTimeField49.getDurationField();
        java.util.Locale locale55 = null;
        java.lang.String str56 = delegatedDateTimeField49.getAsText((long) (-1), locale55);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = delegatedDateTimeField49.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder33.appendText(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder33.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder33.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder66.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter68 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale69 = dateTimeFormatter68.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter70 = dateTimeFormatter68.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder66.append(dateTimePrinter70);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser73 = dateTimeFormatter72.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder31.append(dateTimePrinter70, dateTimeParser73);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "59" + "'", str56.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(dateTimeFormatter68);
        org.junit.Assert.assertNull(locale69);
        org.junit.Assert.assertNotNull(dateTimePrinter70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(dateTimeParser73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2, 0, 0, 12, 0, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(permissionCollection3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(10L, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField16.getAsShortText((int) (byte) 0, locale21);
        boolean boolean23 = gJChronology0.equals((java.lang.Object) delegatedDateTimeField16);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField16, 59, (int) (byte) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for secondOfMinute must be in the range [10,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        long long7 = property6.remainder();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 19287727630L + "'", long7 == 19287727630L);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        try {
            long long34 = unsupportedDateTimeField31.roundHalfEven(174441597981L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField7 = gregorianChronology1.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = mutableDateTime2.toCalendar(locale4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        mutableDateTime2.add(readablePeriod6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(calendar5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.lang.String str17 = delegatedDateTimeField15.getAsShortText((long) (short) 0);
        int int20 = delegatedDateTimeField15.getDifference((long) (byte) 0, (long) 'a');
        org.joda.time.DurationField durationField21 = delegatedDateTimeField15.getRangeDurationField();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-1000L));
        try {
            java.lang.String str3 = mutableDateTime1.toString("secondOfMinute");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: c");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "1969-12-31T16:00:00.100-08:00", (int) (byte) 10);
        java.lang.String str7 = mutableDateTime3.toString();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime3.year();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        int int31 = delegatedDateTimeField24.get(0L);
        long long34 = delegatedDateTimeField24.getDifferenceAsLong((long) (byte) 10, (-31535999968L));
        try {
            mutableDateTime3.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField24, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.100Z" + "'", str7.equals("1969-12-31T16:00:00.100Z"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31535999L + "'", long34 == 31535999L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        mutableDateTime1.setSecondOfMinute((int) (byte) 0);
        java.lang.Object obj4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(obj4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfHalfday();
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology5);
        try {
            org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime9, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        boolean boolean6 = mutableDateTime2.isEqual((long) (byte) 100);
        try {
            mutableDateTime2.setTime(100, 2019, (int) 'a', 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfWeek();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = property3.set(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        int int34 = unsupportedDateTimeField31.getDifference((long) 4, (long) (byte) -1);
        try {
            java.lang.String str36 = unsupportedDateTimeField31.getAsShortText((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket5.setOffset(0);
        long long12 = dateTimeParserBucket5.computeMillis(true, "0");
        dateTimeParserBucket5.setOffset((int) (short) 100);
        long long17 = dateTimeParserBucket5.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone22);
        boolean boolean24 = mutableDateTime20.isBefore((org.joda.time.ReadableInstant) mutableDateTime23);
        mutableDateTime23.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime23.secondOfMinute();
        java.util.Locale locale28 = null;
        java.lang.String str29 = property27.getAsText(locale28);
        org.joda.time.MutableDateTime mutableDateTime31 = property27.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField32 = property27.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        int int36 = delegatedDateTimeField33.getDifference((long) 'a', (long) 100);
        int int37 = delegatedDateTimeField33.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField33.getType();
        dateTimeParserBucket5.saveField(dateTimeFieldType38, (int) (byte) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, "PST");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-90L) + "'", long17 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone13);
        boolean boolean15 = mutableDateTime11.isBefore((org.joda.time.ReadableInstant) mutableDateTime14);
        mutableDateTime14.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.secondOfMinute();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MutableDateTime mutableDateTime22 = property18.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField23 = property18.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (short) 0);
        int int29 = delegatedDateTimeField24.getDifference((long) (byte) 0, (long) 'a');
        long long31 = delegatedDateTimeField24.roundFloor((long) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) delegatedDateTimeField24);
        java.lang.String str34 = fixedDateTimeZone4.getNameKey((long) (short) 10);
        try {
            org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "secondOfMinute" + "'", str34.equals("secondOfMinute"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        mutableDateTime2.setMillisOfDay((int) (byte) 0);
        mutableDateTime2.addMonths((int) ' ');
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        java.lang.Object obj4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone14);
        boolean boolean16 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
        mutableDateTime15.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.secondOfMinute();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property19.getAsText(locale20);
        org.joda.time.MutableDateTime mutableDateTime23 = property19.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField24 = property19.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        int int28 = delegatedDateTimeField25.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField25.getDurationField();
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField25.getAsText((long) (-1), locale31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField25.getType();
        org.joda.time.DateTimeField dateTimeField34 = delegatedDateTimeField25.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        java.lang.Object obj37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(obj37, (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.weekyearOfCentury();
        java.lang.Object obj41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(obj41, (org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology42.hourOfDay();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology42.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone48);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone51);
        boolean boolean53 = mutableDateTime49.isBefore((org.joda.time.ReadableInstant) mutableDateTime52);
        mutableDateTime52.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property56 = mutableDateTime52.secondOfMinute();
        java.util.Locale locale57 = null;
        java.lang.String str58 = property56.getAsText(locale57);
        org.joda.time.MutableDateTime mutableDateTime60 = property56.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField61 = property56.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField61);
        int int65 = delegatedDateTimeField62.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField66 = delegatedDateTimeField62.getDurationField();
        java.util.Locale locale68 = null;
        java.lang.String str69 = delegatedDateTimeField62.getAsText((long) (-1), locale68);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = delegatedDateTimeField62.getType();
        org.joda.time.DateTimeField dateTimeField71 = delegatedDateTimeField62.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology42, dateTimeField71);
        org.joda.time.field.SkipDateTimeField skipDateTimeField73 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology38, (org.joda.time.DateTimeField) skipUndoDateTimeField72);
        org.joda.time.field.SkipDateTimeField skipDateTimeField74 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField72);
        java.lang.String str75 = skipDateTimeField74.getName();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "59" + "'", str32.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0" + "'", str58.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "59" + "'", str69.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "secondOfMinute" + "'", str75.equals("secondOfMinute"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        org.joda.time.Chronology chronology8 = null;
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology8, locale9, (java.lang.Integer) 10, (int) ' ');
        boolean boolean14 = dateTimeParserBucket12.restoreState((java.lang.Object) 1.0d);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket12.getZone();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime6, dateTimeZone15);
        try {
            org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        java.util.Date date16 = mutableDateTime12.toDate();
        org.joda.time.ReadableDuration readableDuration17 = null;
        mutableDateTime12.add(readableDuration17, (int) '#');
        try {
            mutableDateTime12.setWeekOfWeekyear((-11));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(date16);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusHours(1969);
//        int int7 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime dateTime9 = dateTime2.minusSeconds(0);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(readableDuration10, (int) (short) 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.year();
        int int8 = mutableDateTime2.getYearOfEra();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        java.util.Date date6 = mutableDateTime2.toDate();
        java.lang.String str7 = mutableDateTime2.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str7.equals("1969-12-31T16:00:00.100-08:00"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        org.joda.time.Chronology chronology8 = null;
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology8, locale9, (java.lang.Integer) 10, (int) ' ');
        boolean boolean14 = dateTimeParserBucket12.restoreState((java.lang.Object) 1.0d);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket12.getZone();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime6, dateTimeZone15);
        try {
            mutableDateTime6.setDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone18);
        boolean boolean20 = mutableDateTime16.isBefore((org.joda.time.ReadableInstant) mutableDateTime19);
        mutableDateTime19.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime19.secondOfMinute();
        java.util.Locale locale24 = null;
        java.lang.String str25 = property23.getAsText(locale24);
        org.joda.time.MutableDateTime mutableDateTime27 = property23.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField28 = property23.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField29.getAsText(10L, locale31);
        long long34 = delegatedDateTimeField29.roundHalfFloor(100L);
        mutableDateTime12.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField29);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        mutableDateTime12.add(readablePeriod36, (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        boolean boolean15 = property9.isLeap();
        int int16 = property9.getMinimumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime18 = property9.set("12");
        mutableDateTime18.setYear(2000);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket5.setOffset(0);
        long long12 = dateTimeParserBucket5.computeMillis(true, "0");
        dateTimeParserBucket5.setOffset((int) (short) 100);
        long long17 = dateTimeParserBucket5.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.Chronology chronology19 = null;
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology19, locale20, (java.lang.Integer) 10, (int) ' ');
        boolean boolean25 = dateTimeParserBucket23.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket23.setOffset(0);
        long long30 = dateTimeParserBucket23.computeMillis(true, "0");
        dateTimeParserBucket23.setOffset((int) (short) 100);
        long long35 = dateTimeParserBucket23.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone40);
        boolean boolean42 = mutableDateTime38.isBefore((org.joda.time.ReadableInstant) mutableDateTime41);
        mutableDateTime41.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime41.secondOfMinute();
        java.util.Locale locale46 = null;
        java.lang.String str47 = property45.getAsText(locale46);
        org.joda.time.MutableDateTime mutableDateTime49 = property45.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField50 = property45.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField50);
        int int54 = delegatedDateTimeField51.getDifference((long) 'a', (long) 100);
        int int55 = delegatedDateTimeField51.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = delegatedDateTimeField51.getType();
        dateTimeParserBucket23.saveField(dateTimeFieldType56, (int) (byte) 100);
        java.util.Locale locale60 = null;
        dateTimeParserBucket5.saveField(dateTimeFieldType56, "", locale60);
        int int62 = dateTimeParserBucket5.getOffset();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-90L) + "'", long17 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-90L) + "'", long35 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone7);
        mutableDateTime8.setMillis((long) 100);
        boolean boolean11 = dateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime2.getZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (long) '4', 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        java.util.Locale locale34 = null;
        try {
            java.lang.String str35 = unsupportedDateTimeField31.getAsText((long) (short) 0, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = unsupportedDateTimeField31.getType();
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = unsupportedDateTimeField31.getAsShortText(100, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        int int34 = unsupportedDateTimeField31.getDifference((long) 4, (long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField31.getType();
        java.lang.Object obj36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(obj36, (org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.hourOfDay();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone43);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone46);
        boolean boolean48 = mutableDateTime44.isBefore((org.joda.time.ReadableInstant) mutableDateTime47);
        mutableDateTime47.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property51 = mutableDateTime47.secondOfMinute();
        java.util.Locale locale52 = null;
        java.lang.String str53 = property51.getAsText(locale52);
        org.joda.time.MutableDateTime mutableDateTime55 = property51.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField56 = property51.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56);
        int int60 = delegatedDateTimeField57.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField61 = delegatedDateTimeField57.getDurationField();
        java.util.Locale locale63 = null;
        java.lang.String str64 = delegatedDateTimeField57.getAsText((long) (-1), locale63);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = delegatedDateTimeField57.getType();
        org.joda.time.DateTimeField dateTimeField66 = delegatedDateTimeField57.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField67 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology37, dateTimeField66);
        long long70 = skipUndoDateTimeField67.set(0L, 59);
        boolean boolean72 = skipUndoDateTimeField67.isLeap(31535999L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology74 = dateTimeFormatter73.getChronolgy();
        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((java.lang.Object) chronology74);
        org.joda.time.DateTime dateTime77 = dateTime75.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime79 = dateTime75.minus((long) 10);
        org.joda.time.DateTime.Property property80 = dateTime75.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay81 = dateTime75.toYearMonthDay();
        int int82 = skipUndoDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay81);
        int[] intArray90 = new int[] { 59, (short) 10, 20, (short) 100, 20527, 6 };
        try {
            int[] intArray92 = unsupportedDateTimeField31.addWrapField((org.joda.time.ReadablePartial) yearMonthDay81, 2, intArray90, 9700);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "0" + "'", str53.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "59" + "'", str64.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 59000L + "'", long70 == 59000L);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter73);
        org.junit.Assert.assertNull(chronology74);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertNotNull(yearMonthDay81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(intArray90);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone34);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone37);
        boolean boolean39 = mutableDateTime35.isBefore((org.joda.time.ReadableInstant) mutableDateTime38);
        mutableDateTime38.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime38.secondOfMinute();
        java.util.Locale locale43 = null;
        java.lang.String str44 = property42.getAsText(locale43);
        org.joda.time.MutableDateTime mutableDateTime46 = property42.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField47 = property42.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47);
        java.lang.String str50 = delegatedDateTimeField48.getAsShortText((long) (short) 0);
        int int53 = delegatedDateTimeField48.getDifference((long) (byte) 0, (long) 'a');
        int int55 = delegatedDateTimeField48.get(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology57 = dateTimeFormatter56.getChronolgy();
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((java.lang.Object) chronology57);
        org.joda.time.DateTime dateTime60 = dateTime58.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime62 = dateTime58.minus((long) 10);
        org.joda.time.DateTime.Property property63 = dateTime58.minuteOfHour();
        org.joda.time.YearMonthDay yearMonthDay64 = dateTime58.toYearMonthDay();
        java.util.Locale locale66 = null;
        java.lang.String str67 = delegatedDateTimeField48.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay64, (int) 'a', locale66);
        try {
            int int68 = unsupportedDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay64);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "0" + "'", str44.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNull(chronology57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(yearMonthDay64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "97" + "'", str67.equals("97"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = property6.addToCopy(20521);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        int int10 = dateTime9.getMonthOfYear();
        org.joda.time.DateTime.Property property11 = dateTime9.dayOfYear();
        java.util.Locale locale12 = null;
        int int13 = property11.getMaximumShortTextLength(locale12);
        org.joda.time.Chronology chronology16 = null;
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology16, locale17, (java.lang.Integer) 10, (int) ' ');
        boolean boolean22 = dateTimeParserBucket20.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket20.setOffset(0);
        long long27 = dateTimeParserBucket20.computeMillis(true, "0");
        dateTimeParserBucket20.setOffset((int) (short) 100);
        long long32 = dateTimeParserBucket20.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.Chronology chronology34 = null;
        java.util.Locale locale35 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology34, locale35, (java.lang.Integer) 10, (int) ' ');
        boolean boolean40 = dateTimeParserBucket38.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket38.setOffset(0);
        long long45 = dateTimeParserBucket38.computeMillis(true, "0");
        dateTimeParserBucket38.setOffset((int) (short) 100);
        long long50 = dateTimeParserBucket38.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone52);
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.MutableDateTime mutableDateTime56 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone55);
        boolean boolean57 = mutableDateTime53.isBefore((org.joda.time.ReadableInstant) mutableDateTime56);
        mutableDateTime56.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property60 = mutableDateTime56.secondOfMinute();
        java.util.Locale locale61 = null;
        java.lang.String str62 = property60.getAsText(locale61);
        org.joda.time.MutableDateTime mutableDateTime64 = property60.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField65 = property60.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField66 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField65);
        int int69 = delegatedDateTimeField66.getDifference((long) 'a', (long) 100);
        int int70 = delegatedDateTimeField66.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType71 = delegatedDateTimeField66.getType();
        dateTimeParserBucket38.saveField(dateTimeFieldType71, (int) (byte) 100);
        java.util.Locale locale75 = null;
        dateTimeParserBucket20.saveField(dateTimeFieldType71, "", locale75);
        java.util.Locale locale77 = dateTimeParserBucket20.getLocale();
        try {
            org.joda.time.DateTime dateTime78 = property11.setCopy("2019-06-10T00:00:00.000Z", locale77);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-10T00:00:00.000Z\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-90L) + "'", long32 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-90L) + "'", long50 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "0" + "'", str62.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType71);
        org.junit.Assert.assertNotNull(locale77);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField7 = gregorianChronology1.eras();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(10L, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField16.getAsShortText((int) (byte) 0, locale21);
        boolean boolean23 = gJChronology0.equals((java.lang.Object) delegatedDateTimeField16);
        boolean boolean25 = gJChronology0.equals((java.lang.Object) "secondOfMinute");
        java.lang.String str26 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = gJChronology0.withZone(dateTimeZone27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        try {
            int[] intArray31 = gJChronology0.get(readablePeriod29, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str26.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 20531, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20532L + "'", long2 == 20532L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) unsupportedDateTimeField31, (int) (byte) 100, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone7);
        boolean boolean9 = mutableDateTime5.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        mutableDateTime8.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime8.secondOfMinute();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsText(locale13);
        org.joda.time.MutableDateTime mutableDateTime16 = property12.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField17 = property12.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        int int21 = delegatedDateTimeField18.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField18.getDurationField();
        java.util.Locale locale24 = null;
        java.lang.String str25 = delegatedDateTimeField18.getAsText((long) (-1), locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = delegatedDateTimeField18.getType();
        org.joda.time.DateTimeField dateTimeField27 = delegatedDateTimeField18.getWrappedField();
        long long29 = delegatedDateTimeField18.roundHalfFloor((long) 0);
        boolean boolean30 = delegatedDateTimeField18.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18, 23);
        boolean boolean33 = delegatedDateTimeField18.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "59" + "'", str25.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.Instant instant8 = dateTime7.toInstant();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = unsupportedDateTimeField31.getType();
        try {
            int int35 = unsupportedDateTimeField31.getLeapAmount((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("97");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"97\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale36 = dateTimeFormatter35.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter37 = dateTimeFormatter35.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.append(dateTimePrinter37);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder33.appendTimeZoneOffset("ZonedChronology[ISOChronology[UTC], UTC]", false, (int) (short) 0, 9700);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNull(locale36);
        org.junit.Assert.assertNotNull(dateTimePrinter37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("97");
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(960, (-59000), (int) ' ', 9700);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9643 + "'", int4 == 9643);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        try {
            mutableDateTime5.setMonthOfYear(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 9700);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
//        org.joda.time.DateTime dateTime8 = dateTime2.plusYears((int) (short) 0);
//        org.joda.time.Chronology chronology10 = null;
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology10, locale11, (java.lang.Integer) 10, (int) ' ');
//        boolean boolean16 = dateTimeParserBucket14.restoreState((java.lang.Object) 1.0d);
//        dateTimeParserBucket14.setOffset(0);
//        long long21 = dateTimeParserBucket14.computeMillis(true, "0");
//        dateTimeParserBucket14.setOffset((int) (short) 100);
//        long long26 = dateTimeParserBucket14.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone31);
//        boolean boolean33 = mutableDateTime29.isBefore((org.joda.time.ReadableInstant) mutableDateTime32);
//        mutableDateTime32.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime32.secondOfMinute();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = property36.getAsText(locale37);
//        org.joda.time.MutableDateTime mutableDateTime40 = property36.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField41 = property36.getField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField41);
//        int int45 = delegatedDateTimeField42.getDifference((long) 'a', (long) 100);
//        int int46 = delegatedDateTimeField42.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = delegatedDateTimeField42.getType();
//        dateTimeParserBucket14.saveField(dateTimeFieldType47, (int) (byte) 100);
//        int int50 = dateTime2.get(dateTimeFieldType47);
//        org.joda.time.DateTime dateTime52 = dateTime2.plusDays(20527);
//        org.joda.time.DateTime dateTime53 = dateTime2.withTimeAtStartOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-90L) + "'", long26 == (-90L));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 24 + "'", int50 == 24);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime53);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("59", "97");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "59" + "'", str3.equals("59"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-31535940968L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsText((long) (-1), locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField15.getType();
        org.joda.time.DateTimeField dateTimeField24 = delegatedDateTimeField15.getWrappedField();
        long long26 = delegatedDateTimeField15.roundHalfFloor((long) 0);
        boolean boolean27 = delegatedDateTimeField15.isLenient();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology29 = dateTimeFormatter28.getChronolgy();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) chronology29);
        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property33 = dateTime30.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime35 = dateTime30.plus(readablePeriod34);
        org.joda.time.DateTime.Property property36 = dateTime30.dayOfYear();
        org.joda.time.DateTime dateTime38 = dateTime30.plusMinutes((int) (short) 0);
        org.joda.time.TimeOfDay timeOfDay39 = dateTime30.toTimeOfDay();
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) timeOfDay39, (int) '4', locale41);
        org.joda.time.DurationField durationField43 = delegatedDateTimeField15.getDurationField();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(timeOfDay39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "52" + "'", str42.equals("52"));
        org.junit.Assert.assertNotNull(durationField43);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = unsupportedDateTimeField31.getType();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology35 = dateTimeFormatter34.getChronolgy();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((java.lang.Object) chronology35);
        org.joda.time.DateTime dateTime38 = dateTime36.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime40 = dateTime36.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone42 = dateTimeFormatter41.getZone();
        java.lang.String str43 = dateTimeZone42.getID();
        java.lang.String str44 = dateTimeZone42.getID();
        java.lang.String str45 = dateTimeZone42.getID();
        org.joda.time.DateTime dateTime46 = dateTime40.withZoneRetainFields(dateTimeZone42);
        org.joda.time.DateTime dateTime48 = dateTime40.plus(0L);
        org.joda.time.DateTime dateTime50 = dateTime40.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime51 = dateTime50.toLocalDateTime();
        int[] intArray56 = new int[] { (byte) 0, (short) -1, (byte) 0 };
        try {
            int[] intArray58 = unsupportedDateTimeField31.set((org.joda.time.ReadablePartial) localDateTime51, 20521, intArray56, 20527);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNull(chronology35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "UTC" + "'", str43.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "UTC" + "'", str44.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UTC" + "'", str45.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(localDateTime51);
        org.junit.Assert.assertNotNull(intArray56);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        int int34 = unsupportedDateTimeField31.getDifference((long) 4, (long) (byte) -1);
        try {
            long long36 = unsupportedDateTimeField31.roundCeiling(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.io.Writer writer2 = null;
        java.lang.Object obj3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        mutableDateTime11.setMillis((long) 100);
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime11);
        java.lang.String str15 = mutableDateTime11.toString();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime11.dayOfWeek();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) mutableDateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str15.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property16);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
//        org.joda.time.Chronology chronology3 = instant0.getChronology();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.Instant instant6 = instant0.withDurationAdded(readableDuration4, (-1));
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.Instant instant9 = instant0.withDurationAdded(readableDuration7, 6);
//        long long10 = instant9.getMillis();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560343344902L + "'", long10 == 1560343344902L);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            mutableDateTime5.add(durationFieldType10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 960");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket5.setOffset(0);
        long long12 = dateTimeParserBucket5.computeMillis(true, "0");
        dateTimeParserBucket5.setOffset((int) (short) 100);
        long long17 = dateTimeParserBucket5.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone22);
        boolean boolean24 = mutableDateTime20.isBefore((org.joda.time.ReadableInstant) mutableDateTime23);
        mutableDateTime23.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime23.secondOfMinute();
        java.util.Locale locale28 = null;
        java.lang.String str29 = property27.getAsText(locale28);
        org.joda.time.MutableDateTime mutableDateTime31 = property27.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField32 = property27.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        int int36 = delegatedDateTimeField33.getDifference((long) 'a', (long) 100);
        int int37 = delegatedDateTimeField33.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField33.getType();
        dateTimeParserBucket5.saveField(dateTimeFieldType38, (int) (byte) 100);
        int int41 = dateTimeParserBucket5.getOffset();
        java.lang.Integer int42 = dateTimeParserBucket5.getOffsetInteger();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-90L) + "'", long17 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 100 + "'", int41 == 100);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42.equals(100));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("59");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone6);
        boolean boolean8 = mutableDateTime4.isBefore((org.joda.time.ReadableInstant) mutableDateTime7);
        mutableDateTime7.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone13 = dateTimeFormatter12.getZone();
        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime7.toMutableDateTime(dateTimeZone13);
        int int15 = mutableDateTime14.getMillisOfSecond();
        mutableDateTime14.setWeekyear((int) (short) -1);
        java.util.Date date18 = mutableDateTime14.toDate();
        jodaTimePermission1.checkGuard((java.lang.Object) mutableDateTime14);
        java.lang.String str20 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "59" + "'", str20.equals("59"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.add(35L);
        mutableDateTime11.addWeekyears(1);
        boolean boolean14 = mutableDateTime11.isBeforeNow();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.weekyear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Object obj1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField4 = gregorianChronology2.weeks();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) gregorianChronology2, locale5, (java.lang.Integer) 5, (int) '4');
        org.joda.time.IllegalInstantException illegalInstantException11 = new org.joda.time.IllegalInstantException(0L, "1969-12-31T16:00:00.100-08:00");
        java.lang.Throwable[] throwableArray12 = illegalInstantException11.getSuppressed();
        boolean boolean13 = gregorianChronology2.equals((java.lang.Object) throwableArray12);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusHours(1969);
//        int int7 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime dateTime9 = dateTime2.minusSeconds(0);
//        int int10 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusWeeks((int) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20545 + "'", int10 == 20545);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsText((long) (-1), locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 20, "secondOfMinute");
        java.lang.String str27 = illegalFieldValueException26.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20" + "'", str27.equals("20"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.eras();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        long long9 = fixedDateTimeZone7.nextTransition((long) (byte) -1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.Chronology chronology11 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        int int13 = fixedDateTimeZone7.getStandardOffset((long) 23);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        java.lang.String str9 = dateTimeZone8.getID();
        java.lang.String str10 = dateTimeZone8.getID();
        java.lang.String str11 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime12 = dateTime6.withZoneRetainFields(dateTimeZone8);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long7 = cachedDateTimeZone5.nextTransition((-62167190822000L));
        int int9 = cachedDateTimeZone5.getStandardOffset(0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167190822000L) + "'", long7 == (-62167190822000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        int int13 = mutableDateTime12.getMillisOfSecond();
        mutableDateTime12.setWeekyear((int) (short) -1);
        mutableDateTime12.addMillis((int) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean23 = fixedDateTimeZone22.isFixed();
        long long26 = fixedDateTimeZone22.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone31);
        boolean boolean33 = mutableDateTime29.isBefore((org.joda.time.ReadableInstant) mutableDateTime32);
        mutableDateTime32.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime32.secondOfMinute();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MutableDateTime mutableDateTime40 = property36.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField41 = property36.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField41);
        java.lang.String str44 = delegatedDateTimeField42.getAsShortText((long) (short) 0);
        int int47 = delegatedDateTimeField42.getDifference((long) (byte) 0, (long) 'a');
        long long49 = delegatedDateTimeField42.roundFloor((long) 0);
        boolean boolean50 = fixedDateTimeZone22.equals((java.lang.Object) delegatedDateTimeField42);
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTimeField dateTimeField52 = julianChronology51.clockhourOfDay();
        mutableDateTime12.setChronology((org.joda.time.Chronology) julianChronology51);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-90L) + "'", long26 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "0" + "'", str44.equals("0"));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.plusDays((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime5.withMillisOfDay((int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology11 = dateTimeFormatter10.getChronolgy();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime16 = dateTime12.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeFormatter17.getZone();
        java.lang.String str19 = dateTimeZone18.getID();
        java.lang.String str20 = dateTimeZone18.getID();
        java.lang.String str21 = dateTimeZone18.getID();
        org.joda.time.DateTime dateTime22 = dateTime16.withZoneRetainFields(dateTimeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, (int) (short) 1);
        org.joda.time.DateTime dateTime25 = dateTime9.withZoneRetainFields(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMinuteOfDay(86399999);
        dateTimeFormatterBuilder31.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendTwoDigitYear((int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendText(dateTimeFieldType35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        mutableDateTime2.setTime((long) (byte) 0);
        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime2.getRoundingField();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNull(dateTimeField7);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
//        java.lang.Object obj9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj9, (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (byte) 0, (int) '#');
//        org.joda.time.DateTime dateTime16 = dateTime11.minusYears(100);
//        int int17 = dateTime16.getCenturyOfEra();
//        boolean boolean18 = property7.equals((java.lang.Object) dateTime16);
//        long long19 = property7.remainder();
//        org.joda.time.DateTime dateTime20 = property7.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 753L + "'", long19 == 753L);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone12);
        boolean boolean14 = mutableDateTime10.isBefore((org.joda.time.ReadableInstant) mutableDateTime13);
        mutableDateTime13.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime13.secondOfMinute();
        java.util.Locale locale18 = null;
        java.lang.String str19 = property17.getAsText(locale18);
        org.joda.time.MutableDateTime mutableDateTime21 = property17.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField22 = property17.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        int int26 = delegatedDateTimeField23.getDifference((long) 'a', (long) 100);
        int int27 = delegatedDateTimeField23.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField23.getType();
        org.joda.time.DateTime.Property property29 = dateTime7.property(dateTimeFieldType28);
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 9700, (java.lang.Number) (-210866671631000L), (java.lang.Number) 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(property29);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology1, locale2, (java.lang.Integer) 10, (int) ' ');
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) 1.0d);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeParserBucket5.getZone();
        dateTimeParserBucket5.setOffset((java.lang.Integer) 960);
        int int11 = dateTimeParserBucket5.getOffset();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 960 + "'", int11 == 960);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(9643, 59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 568937 + "'", int2 == 568937);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 3, (long) 86399999);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 259199997L + "'", long2 == 259199997L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundCeiling();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(23L, "");
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        try {
            java.lang.String str9 = dateTime7.toString("secondOfMinute");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: c");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = mutableDateTime2.toCalendar(locale4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.millisOfSecond();
        org.joda.time.Chronology chronology9 = null;
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology9, locale10, (java.lang.Integer) 10, (int) ' ');
        boolean boolean15 = dateTimeParserBucket13.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket13.setOffset(0);
        long long20 = dateTimeParserBucket13.computeMillis(true, "0");
        dateTimeParserBucket13.setOffset((int) (short) 100);
        long long25 = dateTimeParserBucket13.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.Chronology chronology27 = null;
        java.util.Locale locale28 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology27, locale28, (java.lang.Integer) 10, (int) ' ');
        boolean boolean33 = dateTimeParserBucket31.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket31.setOffset(0);
        long long38 = dateTimeParserBucket31.computeMillis(true, "0");
        dateTimeParserBucket31.setOffset((int) (short) 100);
        long long43 = dateTimeParserBucket31.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone48);
        boolean boolean50 = mutableDateTime46.isBefore((org.joda.time.ReadableInstant) mutableDateTime49);
        mutableDateTime49.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property53 = mutableDateTime49.secondOfMinute();
        java.util.Locale locale54 = null;
        java.lang.String str55 = property53.getAsText(locale54);
        org.joda.time.MutableDateTime mutableDateTime57 = property53.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField58 = property53.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField58);
        int int62 = delegatedDateTimeField59.getDifference((long) 'a', (long) 100);
        int int63 = delegatedDateTimeField59.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = delegatedDateTimeField59.getType();
        dateTimeParserBucket31.saveField(dateTimeFieldType64, (int) (byte) 100);
        java.util.Locale locale68 = null;
        dateTimeParserBucket13.saveField(dateTimeFieldType64, "", locale68);
        java.util.Locale locale70 = dateTimeParserBucket13.getLocale();
        try {
            java.lang.String str71 = mutableDateTime2.toString("hi!", locale70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(calendar5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-90L) + "'", long25 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-90L) + "'", long43 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(locale70);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale36 = dateTimeFormatter35.getLocale();
        org.joda.time.format.DateTimePrinter dateTimePrinter37 = dateTimeFormatter35.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.append(dateTimePrinter37);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder33.appendFractionOfMinute((int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNull(locale36);
        org.junit.Assert.assertNotNull(dateTimePrinter37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withDayOfMonth(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendTwoDigitYear(10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendPattern("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        java.lang.String str4 = gregorianChronology1.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        try {
            long long33 = unsupportedDateTimeField31.roundHalfFloor((long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(49);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfWeek();
//        long long4 = property3.remainder();
//        int int5 = property3.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 45747429L + "'", long4 == 45747429L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears(0);
        java.lang.Object obj7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime10 = dateTime4.withChronology((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded(19000L, 20521);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime7 = property4.setCopy(3);
        int int8 = dateTime7.getEra();
        org.joda.time.DateTime dateTime10 = dateTime7.minusMinutes(0);
        org.joda.time.DateTime dateTime11 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology13 = null;
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology13, locale14, (java.lang.Integer) 10, (int) ' ');
        boolean boolean19 = dateTimeParserBucket17.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket17.setOffset(0);
        long long24 = dateTimeParserBucket17.computeMillis(true, "0");
        dateTimeParserBucket17.setOffset((int) (short) 100);
        long long29 = dateTimeParserBucket17.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.Chronology chronology31 = null;
        java.util.Locale locale32 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology31, locale32, (java.lang.Integer) 10, (int) ' ');
        boolean boolean37 = dateTimeParserBucket35.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket35.setOffset(0);
        long long42 = dateTimeParserBucket35.computeMillis(true, "0");
        dateTimeParserBucket35.setOffset((int) (short) 100);
        long long47 = dateTimeParserBucket35.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone49);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone52);
        boolean boolean54 = mutableDateTime50.isBefore((org.joda.time.ReadableInstant) mutableDateTime53);
        mutableDateTime53.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property57 = mutableDateTime53.secondOfMinute();
        java.util.Locale locale58 = null;
        java.lang.String str59 = property57.getAsText(locale58);
        org.joda.time.MutableDateTime mutableDateTime61 = property57.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField62 = property57.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField63 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField62);
        int int66 = delegatedDateTimeField63.getDifference((long) 'a', (long) 100);
        int int67 = delegatedDateTimeField63.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = delegatedDateTimeField63.getType();
        dateTimeParserBucket35.saveField(dateTimeFieldType68, (int) (byte) 100);
        java.util.Locale locale72 = null;
        dateTimeParserBucket17.saveField(dateTimeFieldType68, "", locale72);
        org.joda.time.DateTime.Property property74 = dateTime10.property(dateTimeFieldType68);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-90L) + "'", long29 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-90L) + "'", long47 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertNotNull(property74);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsText((long) (-1), locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-1L), (java.lang.Number) 960, (java.lang.Number) 1.0f);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = illegalFieldValueException31.getDateTimeFieldType();
        illegalFieldValueException26.addSuppressed((java.lang.Throwable) illegalFieldValueException31);
        java.lang.Number number34 = illegalFieldValueException31.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1L) + "'", number34.equals((-1L)));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setWeekyear((int) (short) -1);
        mutableDateTime5.setDate((int) (short) -1, 3, 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "1969-12-31T16:00:00.100-08:00", (int) (byte) 10);
        java.lang.String str7 = mutableDateTime3.toString();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime3.year();
        mutableDateTime3.setMillisOfDay((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.100Z" + "'", str7.equals("1969-12-31T16:00:00.100Z"));
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField7 = gregorianChronology1.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.DateTime dateTime8 = dateTime2.plusYears((int) (short) 0);
        org.joda.time.DateTime dateTime9 = dateTime2.toDateTimeISO();
        org.joda.time.DateTime.Property property10 = dateTime2.hourOfDay();
        org.joda.time.DateTime.Property property11 = dateTime2.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
        try {
            int int34 = unsupportedDateTimeField31.getLeapAmount((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        long long4 = mutableDateTime2.getMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.Object obj3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime10 = dateTime5.minusYears(100);
        org.joda.time.DateTime dateTime11 = dateTime5.toDateTime();
        java.lang.Object obj12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj12, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.hourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime5.withChronology((org.joda.time.Chronology) gregorianChronology13);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone20 = dateTimeFormatter19.getZone();
        java.lang.String str21 = dateTimeZone20.getID();
        java.lang.String str22 = dateTimeZone20.toString();
        org.joda.time.DateTime dateTime23 = dateTime5.withZone(dateTimeZone20);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 59000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra(24);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) '4');
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendTwoDigitYear(10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        try {
            org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatterBuilder30, (org.joda.time.DateTimeZone) fixedDateTimeZone35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
//        org.joda.time.DateTime dateTime8 = dateTime2.plusYears((int) (short) 0);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(100);
//        int int11 = dateTime10.getSecondOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime10.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20549 + "'", int11 == 20549);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("59", "97");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560343325L, 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9362059950L + "'", long2 == 9362059950L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(753L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000087153d + "'", double1 == 2440587.5000087153d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.lang.String str17 = delegatedDateTimeField15.getAsShortText((long) (short) 0);
        int int20 = delegatedDateTimeField15.getDifference((long) (byte) 0, (long) 'a');
        int int22 = delegatedDateTimeField15.get(0L);
        java.lang.String str24 = delegatedDateTimeField15.getAsShortText((-1000L));
        long long26 = delegatedDateTimeField15.remainder((long) 86399999);
        int int28 = delegatedDateTimeField15.getMinimumValue(0L);
        java.lang.String str30 = delegatedDateTimeField15.getAsText((long) 568937);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "59" + "'", str24.equals("59"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 999L + "'", long26 == 999L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "28" + "'", str30.equals("28"));
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
//        int int9 = dateTime8.getDayOfWeek();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusYears(1);
//        java.lang.String str12 = dateTime8.toString();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-06-12T05:42:30.000-07:00" + "'", str12.equals("2019-06-12T05:42:30.000-07:00"));
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 753L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology4 = dateTimeFormatter3.getChronolgy();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) chronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime5.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        java.lang.String str12 = dateTimeZone11.getID();
        java.lang.String str13 = dateTimeZone11.getID();
        java.lang.String str14 = dateTimeZone11.getID();
        org.joda.time.DateTime dateTime15 = dateTime9.withZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTime dateTime17 = dateTime9.plus(0L);
        org.joda.time.DateTime dateTime19 = dateTime9.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        boolean boolean21 = dateTimeZone1.isLocalDateTimeGap(localDateTime20);
        boolean boolean22 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone7);
        boolean boolean9 = mutableDateTime5.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        mutableDateTime8.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime8.secondOfMinute();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsText(locale13);
        org.joda.time.MutableDateTime mutableDateTime16 = property12.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField17 = property12.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        int int21 = delegatedDateTimeField18.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField18.getDurationField();
        java.util.Locale locale24 = null;
        java.lang.String str25 = delegatedDateTimeField18.getAsText((long) (-1), locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = delegatedDateTimeField18.getType();
        org.joda.time.DateTimeField dateTimeField27 = delegatedDateTimeField18.getWrappedField();
        long long29 = delegatedDateTimeField18.roundHalfFloor((long) 0);
        boolean boolean30 = delegatedDateTimeField18.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField18, 23);
        int int35 = skipDateTimeField32.getDifference((long) '#', (-1L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "59" + "'", str25.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        java.lang.Object obj3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj3, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfYear();
//        org.joda.time.DurationField durationField7 = gregorianChronology4.years();
//        boolean boolean8 = gJChronology0.equals((java.lang.Object) gregorianChronology4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology10 = dateTimeFormatter9.getChronolgy();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) chronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime11.minus((long) 10);
//        org.joda.time.DateTime dateTime17 = dateTime11.plusYears((int) (short) 0);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusMonths(100);
//        int int20 = dateTime19.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.ReadableDateTime) dateTime19, readableDateTime21);
//        try {
//            long long28 = limitChronology22.getDateTimeMillis((long) (byte) 0, 0, (int) (byte) 0, 23, 2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2011-02-12T13:42:31.101Z (GregorianChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20551 + "'", int20 == 20551);
//        org.junit.Assert.assertNotNull(limitChronology22);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Instant instant4 = instant0.withMillis((long) 1);
        org.joda.time.DateTime dateTime5 = instant4.toDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        boolean boolean13 = mutableDateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        mutableDateTime12.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime12.secondOfMinute();
        java.util.Locale locale17 = null;
        java.lang.String str18 = property16.getAsText(locale17);
        org.joda.time.MutableDateTime mutableDateTime20 = property16.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        int int25 = delegatedDateTimeField22.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField26 = delegatedDateTimeField22.getDurationField();
        java.util.Locale locale28 = null;
        java.lang.String str29 = delegatedDateTimeField22.getAsText((long) (-1), locale28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField22.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType30);
        org.joda.time.DateTime dateTime36 = dateTime5.withField(dateTimeFieldType30, 5);
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone39);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone42);
        boolean boolean44 = mutableDateTime40.isBefore((org.joda.time.ReadableInstant) mutableDateTime43);
        mutableDateTime43.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property47 = mutableDateTime43.secondOfMinute();
        java.util.Locale locale48 = null;
        java.lang.String str49 = property47.getAsText(locale48);
        org.joda.time.MutableDateTime mutableDateTime51 = property47.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField52 = property47.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
        java.util.Locale locale55 = null;
        java.lang.String str56 = delegatedDateTimeField53.getAsText(10L, locale55);
        java.util.Locale locale58 = null;
        java.lang.String str59 = delegatedDateTimeField53.getAsShortText((int) (byte) 0, locale58);
        boolean boolean60 = gJChronology37.equals((java.lang.Object) delegatedDateTimeField53);
        org.joda.time.DateTimeField dateTimeField61 = gJChronology37.clockhourOfHalfday();
        org.joda.time.DurationField durationField62 = gJChronology37.halfdays();
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.MutableDateTime mutableDateTime66 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone65);
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone68);
        boolean boolean70 = mutableDateTime66.isBefore((org.joda.time.ReadableInstant) mutableDateTime69);
        mutableDateTime69.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property73 = mutableDateTime69.secondOfMinute();
        java.util.Locale locale74 = null;
        java.lang.String str75 = property73.getAsText(locale74);
        org.joda.time.MutableDateTime mutableDateTime77 = property73.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField78 = property73.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField79 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField78);
        java.util.Locale locale81 = null;
        java.lang.String str82 = delegatedDateTimeField79.getAsText(10L, locale81);
        java.util.Locale locale84 = null;
        java.lang.String str85 = delegatedDateTimeField79.getAsShortText((int) (byte) 0, locale84);
        boolean boolean86 = gJChronology63.equals((java.lang.Object) delegatedDateTimeField79);
        boolean boolean88 = gJChronology63.equals((java.lang.Object) "secondOfMinute");
        org.joda.time.DurationField durationField89 = gJChronology63.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField90 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType30, durationField62, durationField89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "59" + "'", str29.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "0" + "'", str75.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "0" + "'", str82.equals("0"));
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "0" + "'", str85.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(durationField89);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.monthOfYear();
        java.lang.String str5 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone10);
        boolean boolean12 = mutableDateTime8.isBefore((org.joda.time.ReadableInstant) mutableDateTime11);
        mutableDateTime11.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime11.secondOfMinute();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        org.joda.time.MutableDateTime mutableDateTime19 = property15.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField20 = property15.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField21.getAsText(10L, locale23);
        long long26 = delegatedDateTimeField21.roundHalfFloor(100L);
        long long29 = delegatedDateTimeField21.set((-31535999968L), "59");
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField21);
        try {
            long long33 = skipUndoDateTimeField30.set((long) ' ', "ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[America/Los_Angeles]\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31535940968L) + "'", long29 == (-31535940968L));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendWeekyear((int) (byte) 100, 20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatterBuilder34.toFormatter();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        boolean boolean6 = mutableDateTime2.isEqual((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        boolean boolean13 = mutableDateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        mutableDateTime12.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime12.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeFormatter17.getZone();
        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime12.toMutableDateTime(dateTimeZone18);
        int int20 = mutableDateTime19.getMillisOfSecond();
        mutableDateTime19.setWeekyear((int) (short) -1);
        java.util.Date date23 = mutableDateTime19.toDate();
        int int24 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) mutableDateTime19);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone26);
        java.util.Date date28 = mutableDateTime27.toDate();
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime27.weekyear();
        org.joda.time.DateTimeField dateTimeField30 = null;
        mutableDateTime27.setRounding(dateTimeField30, (int) (byte) 1);
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime19, (org.joda.time.ReadableInstant) mutableDateTime27);
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime19.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology36 = dateTimeFormatter35.getChronolgy();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((java.lang.Object) chronology36);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime41 = dateTime37.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone43 = dateTimeFormatter42.getZone();
        java.lang.String str44 = dateTimeZone43.getID();
        java.lang.String str45 = dateTimeZone43.getID();
        java.lang.String str46 = dateTimeZone43.getID();
        org.joda.time.DateTime dateTime47 = dateTime41.withZoneRetainFields(dateTimeZone43);
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.minuteOfDay();
        org.joda.time.DurationField durationField51 = gregorianChronology49.weeks();
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((java.lang.Object) mutableDateTime19, (org.joda.time.Chronology) gregorianChronology49);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "UTC" + "'", str44.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UTC" + "'", str45.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "UTC" + "'", str46.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField51);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology13.getZone();
        java.lang.Object obj15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(obj15, (org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime22 = dateTime17.minusYears(100);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfMonth();
        org.joda.time.DateTime dateTime24 = property23.roundFloorCopy();
        int int25 = dateTime24.getMonthOfYear();
        org.joda.time.DateTime.Property property26 = dateTime24.dayOfYear();
        java.util.Locale locale27 = null;
        int int28 = property26.getMaximumShortTextLength(locale27);
        boolean boolean29 = zonedChronology13.equals((java.lang.Object) int28);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = buddhistChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.secondOfDay();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.Object obj5 = null;
        boolean boolean6 = gJChronology4.equals(obj5);
        java.lang.Object obj7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(obj7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.dayOfYear();
        org.joda.time.DurationField durationField11 = gregorianChronology8.years();
        boolean boolean12 = gJChronology4.equals((java.lang.Object) gregorianChronology8);
        boolean boolean13 = buddhistChronology0.equals((java.lang.Object) boolean12);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.plusMillis(3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.monthOfYear();
        java.lang.String str11 = julianChronology9.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology9.getZone();
        org.joda.time.DateTime dateTime14 = dateTime2.withChronology((org.joda.time.Chronology) julianChronology9);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str11.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.lang.String str17 = delegatedDateTimeField15.getAsShortText((long) (short) 0);
        int int20 = delegatedDateTimeField15.getDifference((long) (byte) 0, (long) 'a');
        int int22 = delegatedDateTimeField15.get(0L);
        long long25 = delegatedDateTimeField15.getDifferenceAsLong((long) (byte) 10, (-31535999968L));
        long long27 = delegatedDateTimeField15.roundFloor((long) 0);
        int int28 = delegatedDateTimeField15.getMinimumValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31535999L + "'", long25 == 31535999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.lang.String str17 = delegatedDateTimeField15.getAsShortText((long) (short) 0);
        int int20 = delegatedDateTimeField15.getDifference((long) (byte) 0, (long) 'a');
        long long22 = delegatedDateTimeField15.roundFloor((long) 0);
        org.joda.time.Chronology chronology24 = null;
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology24, locale25, (java.lang.Integer) 10, (int) ' ');
        boolean boolean30 = dateTimeParserBucket28.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket28.setOffset(0);
        long long35 = dateTimeParserBucket28.computeMillis(true, "0");
        dateTimeParserBucket28.setOffset((int) (short) 100);
        long long40 = dateTimeParserBucket28.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.Chronology chronology42 = null;
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology42, locale43, (java.lang.Integer) 10, (int) ' ');
        boolean boolean48 = dateTimeParserBucket46.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket46.setOffset(0);
        long long53 = dateTimeParserBucket46.computeMillis(true, "0");
        dateTimeParserBucket46.setOffset((int) (short) 100);
        long long58 = dateTimeParserBucket46.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.MutableDateTime mutableDateTime61 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone60);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.MutableDateTime mutableDateTime64 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone63);
        boolean boolean65 = mutableDateTime61.isBefore((org.joda.time.ReadableInstant) mutableDateTime64);
        mutableDateTime64.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property68 = mutableDateTime64.secondOfMinute();
        java.util.Locale locale69 = null;
        java.lang.String str70 = property68.getAsText(locale69);
        org.joda.time.MutableDateTime mutableDateTime72 = property68.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField73 = property68.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73);
        int int77 = delegatedDateTimeField74.getDifference((long) 'a', (long) 100);
        int int78 = delegatedDateTimeField74.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = delegatedDateTimeField74.getType();
        dateTimeParserBucket46.saveField(dateTimeFieldType79, (int) (byte) 100);
        java.util.Locale locale83 = null;
        dateTimeParserBucket28.saveField(dateTimeFieldType79, "", locale83);
        java.util.Locale locale85 = dateTimeParserBucket28.getLocale();
        int int86 = delegatedDateTimeField15.getMaximumTextLength(locale85);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-90L) + "'", long40 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-90L) + "'", long58 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "0" + "'", str70.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(locale85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 2 + "'", int86 == 2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-1L), (java.lang.Number) 960, (java.lang.Number) 1.0f);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str6 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [960,1.0]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [960,1.0]"));
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = gJChronology0.equals(obj1);
//        java.lang.Object obj3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj3, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.dayOfYear();
//        org.joda.time.DurationField durationField7 = gregorianChronology4.years();
//        boolean boolean8 = gJChronology0.equals((java.lang.Object) gregorianChronology4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology10 = dateTimeFormatter9.getChronolgy();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) chronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime11.minus((long) 10);
//        org.joda.time.DateTime dateTime17 = dateTime11.plusYears((int) (short) 0);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusMonths(100);
//        int int20 = dateTime19.getSecondOfDay();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.ReadableDateTime) dateTime19, readableDateTime21);
//        try {
//            long long28 = limitChronology22.getDateTimeMillis((long) 9643, 100, 42, (int) (short) 10, 12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2011-02-12T13:42:33.052Z (GregorianChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20553 + "'", int20 == 20553);
//        org.junit.Assert.assertNotNull(limitChronology22);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendTwoDigitYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendYearOfCentury(568937, 9700);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560343353654L + "'", long0 == 1560343353654L);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.DateTime dateTime11 = property8.addWrapFieldToCopy(10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.Chronology chronology2 = null;
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology2, locale3, (java.lang.Integer) 10, (int) ' ');
        boolean boolean8 = dateTimeParserBucket6.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket6.setOffset(0);
        long long13 = dateTimeParserBucket6.computeMillis(true, "0");
        dateTimeParserBucket6.setOffset((int) (short) 100);
        long long18 = dateTimeParserBucket6.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.Chronology chronology20 = null;
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket((long) (short) 10, chronology20, locale21, (java.lang.Integer) 10, (int) ' ');
        boolean boolean26 = dateTimeParserBucket24.restoreState((java.lang.Object) 1.0d);
        dateTimeParserBucket24.setOffset(0);
        long long31 = dateTimeParserBucket24.computeMillis(true, "0");
        dateTimeParserBucket24.setOffset((int) (short) 100);
        long long36 = dateTimeParserBucket24.computeMillis(false, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone38);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone41);
        boolean boolean43 = mutableDateTime39.isBefore((org.joda.time.ReadableInstant) mutableDateTime42);
        mutableDateTime42.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime42.secondOfMinute();
        java.util.Locale locale47 = null;
        java.lang.String str48 = property46.getAsText(locale47);
        org.joda.time.MutableDateTime mutableDateTime50 = property46.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField51 = property46.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField51);
        int int55 = delegatedDateTimeField52.getDifference((long) 'a', (long) 100);
        int int56 = delegatedDateTimeField52.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = delegatedDateTimeField52.getType();
        dateTimeParserBucket24.saveField(dateTimeFieldType57, (int) (byte) 100);
        java.util.Locale locale61 = null;
        dateTimeParserBucket6.saveField(dateTimeFieldType57, "", locale61);
        java.util.Locale locale63 = dateTimeParserBucket6.getLocale();
        try {
            java.lang.String str64 = org.joda.time.format.DateTimeFormat.patternForStyle("GJChronology[America/Los_Angeles]", locale63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: GJChronology[America/Los_Angeles]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-90L) + "'", long18 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-90L) + "'", long36 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(locale63);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
//        int int6 = dateTime5.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Instant instant9 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant11 = instant9.plus(readableDuration10);
        org.joda.time.Instant instant13 = instant9.withMillis((long) 1);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Instant instant16 = instant13.withDurationAdded(readableDuration14, (-1));
        org.joda.time.Instant instant17 = instant16.toInstant();
        boolean boolean18 = mutableDateTime8.isAfter((org.joda.time.ReadableInstant) instant17);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '#', 59, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendClockhourOfHalfday(16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendMillisOfDay((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("52");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        java.lang.Object obj4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone14);
        boolean boolean16 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
        mutableDateTime15.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.secondOfMinute();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property19.getAsText(locale20);
        org.joda.time.MutableDateTime mutableDateTime23 = property19.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField24 = property19.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        int int28 = delegatedDateTimeField25.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField25.getDurationField();
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField25.getAsText((long) (-1), locale31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField25.getType();
        org.joda.time.DateTimeField dateTimeField34 = delegatedDateTimeField25.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone38 = dateTimeFormatter37.getZone();
        java.lang.String str39 = dateTimeZone38.getID();
        java.lang.String str40 = dateTimeZone38.getID();
        java.lang.String str41 = dateTimeZone38.getID();
        org.joda.time.Chronology chronology42 = gregorianChronology1.withZone(dateTimeZone38);
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime(dateTimeZone38);
        mutableDateTime43.addMillis(2019);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "59" + "'", str32.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "UTC" + "'", str39.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UTC" + "'", str40.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UTC" + "'", str41.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology42);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        boolean boolean29 = dateTimeFormatterBuilder28.canBuildFormatter();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter3.getZone();
        long long6 = dateTimeZone4.convertUTCToLocal((-1L));
        org.joda.time.Chronology chronology7 = julianChronology0.withZone(dateTimeZone4);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, readableInstant8);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Instant instant4 = instant0.withMillis((long) 1);
        org.joda.time.DateTime dateTime5 = instant4.toDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        boolean boolean13 = mutableDateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        mutableDateTime12.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime12.secondOfMinute();
        java.util.Locale locale17 = null;
        java.lang.String str18 = property16.getAsText(locale17);
        org.joda.time.MutableDateTime mutableDateTime20 = property16.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        int int25 = delegatedDateTimeField22.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField26 = delegatedDateTimeField22.getDurationField();
        java.util.Locale locale28 = null;
        java.lang.String str29 = delegatedDateTimeField22.getAsText((long) (-1), locale28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField22.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType30);
        org.joda.time.DateTime dateTime36 = dateTime5.withField(dateTimeFieldType30, 5);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, 9643, 59, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9643 for secondOfMinute must be in the range [59,24]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "59" + "'", str29.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
        java.util.Locale locale7 = null;
        int int8 = property3.getMaximumShortTextLength(locale7);
        org.joda.time.DateTime dateTime9 = property3.withMaximumValue();
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withTime(49, 9700, 23, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
        org.joda.time.DateTime dateTime7 = property3.withMinimumValue();
        java.lang.Object obj8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj8, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime15 = dateTime10.minusYears(100);
        org.joda.time.DateTime dateTime16 = dateTime10.toDateTime();
        org.joda.time.DateTime dateTime18 = dateTime10.minusMinutes(6);
        int int19 = property3.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime20 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property21 = dateTime20.yearOfEra();
        int int22 = dateTime20.getYearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19 + "'", int22 == 19);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology13.getZone();
        try {
            long long22 = zonedChronology13.getDateTimeMillis(20545, 7, 568937, 52, 49, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.clockhourOfHalfday();
        try {
            long long14 = gregorianChronology1.getDateTimeMillis(24, 9643, 7, 4, 24, 24, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendTwoDigitYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendHourOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendTimeZoneShortName();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean7 = fixedDateTimeZone6.isFixed();
        long long10 = fixedDateTimeZone6.adjustOffset((-90L), false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.parse("0", dateTimeFormatter11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-90L) + "'", long10 == (-90L));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        int int34 = unsupportedDateTimeField31.getDifference((long) 4, (long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField31.getType();
        try {
            long long38 = unsupportedDateTimeField31.addWrapField((long) (-11), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        org.joda.time.DateTime dateTime12 = dateTime6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, 24);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
//        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
//        mutableDateTime5.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsText(locale10);
//        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
//        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
//        int int19 = delegatedDateTimeField15.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
//        java.lang.Object obj21 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
//        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
//        long long30 = durationField27.subtract(174441597981L, 0L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getLeapDurationField();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone37 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
//        boolean boolean38 = fixedDateTimeZone37.isFixed();
//        long long41 = fixedDateTimeZone37.adjustOffset((-90L), false);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone43);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone46);
//        boolean boolean48 = mutableDateTime44.isBefore((org.joda.time.ReadableInstant) mutableDateTime47);
//        mutableDateTime47.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property51 = mutableDateTime47.secondOfMinute();
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = property51.getAsText(locale52);
//        org.joda.time.MutableDateTime mutableDateTime55 = property51.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField56 = property51.getField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56);
//        java.lang.String str59 = delegatedDateTimeField57.getAsShortText((long) (short) 0);
//        int int62 = delegatedDateTimeField57.getDifference((long) (byte) 0, (long) 'a');
//        long long64 = delegatedDateTimeField57.roundFloor((long) 0);
//        boolean boolean65 = fixedDateTimeZone37.equals((java.lang.Object) delegatedDateTimeField57);
//        org.joda.time.chrono.JulianChronology julianChronology66 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone37);
//        java.lang.Object obj67 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(obj67, (org.joda.time.Chronology) gregorianChronology68);
//        org.joda.time.DateTime dateTime72 = dateTime69.withDurationAdded((long) (byte) 0, (int) '#');
//        org.joda.time.DateTime dateTime74 = dateTime69.minusYears(100);
//        org.joda.time.DateTime.Property property75 = dateTime74.dayOfMonth();
//        org.joda.time.DateTime dateTime76 = property75.roundFloorCopy();
//        int int77 = dateTime76.getMonthOfYear();
//        org.joda.time.LocalDateTime localDateTime78 = dateTime76.toLocalDateTime();
//        long long80 = julianChronology66.set((org.joda.time.ReadablePartial) localDateTime78, 45747429L);
//        int[] intArray86 = new int[] { 'a', 20, 12, (-1) };
//        try {
//            int[] intArray88 = unsupportedDateTimeField31.addWrapField((org.joda.time.ReadablePartial) localDateTime78, (int) (byte) 10, intArray86, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-90L) + "'", long41 == (-90L));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "0" + "'", str53.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(julianChronology66);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 6 + "'", int77 == 6);
//        org.junit.Assert.assertNotNull(localDateTime78);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-1594339200000L) + "'", long80 == (-1594339200000L));
//        org.junit.Assert.assertNotNull(intArray86);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter1.getZone();
        long long4 = dateTimeZone2.convertUTCToLocal((-1L));
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) 42, dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.secondOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology1.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology9 = dateTimeFormatter8.getChronolgy();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime10.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeFormatter15.getZone();
        java.lang.String str17 = dateTimeZone16.getID();
        java.lang.String str18 = dateTimeZone16.getID();
        java.lang.String str19 = dateTimeZone16.getID();
        org.joda.time.DateTime dateTime20 = dateTime14.withZoneRetainFields(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = dateTime14.plus(0L);
        org.joda.time.DateTime dateTime24 = dateTime14.minusSeconds(960);
        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
        boolean boolean26 = dateTimeZone6.isLocalDateTimeGap(localDateTime25);
        try {
            dateTimeFormatter0.printTo(stringBuffer4, (org.joda.time.ReadablePartial) localDateTime25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime();
        java.lang.Object obj9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime16 = dateTime11.minusYears(100);
        org.joda.time.DateTime dateTime17 = dateTime11.toDateTime();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getChronology(chronology18);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.Object obj1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime8 = dateTime3.minusYears(100);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfMonth();
        org.joda.time.DateTime dateTime10 = property9.roundFloorCopy();
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        boolean boolean12 = iSOChronology0.equals((java.lang.Object) property11);
        org.joda.time.DurationField durationField13 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        java.lang.String str5 = dateTimeZone3.getID();
        java.lang.String str6 = dateTimeZone3.getID();
        long long9 = dateTimeZone3.adjustOffset((long) (-1), false);
        long long12 = dateTimeZone3.adjustOffset((-1000L), false);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone3);
        try {
            long long19 = zonedChronology13.getDateTimeMillis((long) 20, (int) ' ', (int) (byte) 1, (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1000L) + "'", long12 == (-1000L));
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minusHours(1969);
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        boolean boolean13 = mutableDateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        mutableDateTime12.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime12.secondOfMinute();
        java.util.Locale locale17 = null;
        java.lang.String str18 = property16.getAsText(locale17);
        org.joda.time.MutableDateTime mutableDateTime20 = property16.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField21 = property16.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        int int25 = delegatedDateTimeField22.getDifference((long) 'a', (long) 100);
        int int26 = delegatedDateTimeField22.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = delegatedDateTimeField22.getType();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime2.property(dateTimeFieldType27);
        org.joda.time.MutableDateTime mutableDateTime29 = property28.roundHalfCeiling();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6) + "'", int1 == (-6));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean7 = fixedDateTimeZone6.isFixed();
        long long10 = fixedDateTimeZone6.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
        boolean boolean17 = mutableDateTime13.isBefore((org.joda.time.ReadableInstant) mutableDateTime16);
        mutableDateTime16.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime16.secondOfMinute();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property20.getAsText(locale21);
        org.joda.time.MutableDateTime mutableDateTime24 = property20.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField25 = property20.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        java.lang.String str28 = delegatedDateTimeField26.getAsShortText((long) (short) 0);
        int int31 = delegatedDateTimeField26.getDifference((long) (byte) 0, (long) 'a');
        long long33 = delegatedDateTimeField26.roundFloor((long) 0);
        boolean boolean34 = fixedDateTimeZone6.equals((java.lang.Object) delegatedDateTimeField26);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        boolean boolean36 = jodaTimePermission1.equals((java.lang.Object) fixedDateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology38 = dateTimeFormatter37.getChronolgy();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) chronology38);
        org.joda.time.DateTime dateTime41 = dateTime39.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime43 = dateTime39.minus((long) 10);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((java.lang.Object) dateTime43);
        boolean boolean45 = jodaTimePermission1.equals((java.lang.Object) dateTime44);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-90L) + "'", long10 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        org.joda.time.DurationField durationField9 = property7.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) ' ');
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter0.printTo(appendable4, (-90L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        mutableDateTime0.setSecondOfMinute((int) (byte) 0);
        java.lang.Object obj3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(obj3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DurationField durationField6 = gregorianChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.hourOfHalfday();
        org.joda.time.DateTime dateTime8 = mutableDateTime0.toDateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1), 20545, 20, (int) (byte) 10, (int) 'a', 3, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        int int34 = unsupportedDateTimeField31.getDifference((long) 4, (long) (byte) -1);
        try {
            int int36 = unsupportedDateTimeField31.get((-210866671631000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears(0);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
        org.joda.time.DateTimeField dateTimeField8 = null;
        try {
            int int9 = dateTime6.get(dateTimeField8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (byte) -1, dateTimeZone1);
        try {
            mutableDateTime2.setSecondOfMinute(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone5);
        boolean boolean7 = mutableDateTime3.isBefore((org.joda.time.ReadableInstant) mutableDateTime6);
        mutableDateTime6.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField15 = property10.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int19 = delegatedDateTimeField16.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getDurationField();
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField16.getAsText((long) (-1), locale22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField16.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20, "secondOfMinute");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendFractionOfHour(4, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendMillisOfSecond((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendMinuteOfDay(0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59" + "'", str23.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Instant instant4 = instant0.withMillis((long) 1);
        org.joda.time.DateTime dateTime5 = instant4.toDateTime();
        java.lang.Object obj6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj6, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.weekyearOfCentury();
        java.lang.Object obj10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(obj10, (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.hourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology11.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone20);
        boolean boolean22 = mutableDateTime18.isBefore((org.joda.time.ReadableInstant) mutableDateTime21);
        mutableDateTime21.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property25 = mutableDateTime21.secondOfMinute();
        java.util.Locale locale26 = null;
        java.lang.String str27 = property25.getAsText(locale26);
        org.joda.time.MutableDateTime mutableDateTime29 = property25.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField30 = property25.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
        int int34 = delegatedDateTimeField31.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField35 = delegatedDateTimeField31.getDurationField();
        java.util.Locale locale37 = null;
        java.lang.String str38 = delegatedDateTimeField31.getAsText((long) (-1), locale37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = delegatedDateTimeField31.getType();
        org.joda.time.DateTimeField dateTimeField40 = delegatedDateTimeField31.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField40);
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeField) skipUndoDateTimeField41);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone44 = dateTimeFormatter43.getZone();
        java.lang.String str45 = dateTimeZone44.getID();
        java.lang.String str46 = dateTimeZone44.getID();
        java.lang.String str47 = dateTimeZone44.getID();
        org.joda.time.Chronology chronology48 = gregorianChronology7.withZone(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology7.dayOfWeek();
        org.joda.time.DateTime dateTime50 = dateTime5.withChronology((org.joda.time.Chronology) gregorianChronology7);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "59" + "'", str38.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UTC" + "'", str45.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "UTC" + "'", str46.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UTC" + "'", str47.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime50);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-31535999968L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 20553, number2, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("UnsupportedDateTimeField");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UnsupportedDateTimeField\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime2.setYear((int) (short) 1);
        mutableDateTime2.setSecondOfDay(20549);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Object obj1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone8);
        mutableDateTime9.setMillis((long) 100);
        boolean boolean12 = dateTime3.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        java.lang.String str13 = mutableDateTime9.toString();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime9.dayOfWeek();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime9.monthOfYear();
        org.joda.time.Chronology chronology16 = mutableDateTime9.getChronology();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 2, chronology16);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str13.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        int int19 = delegatedDateTimeField15.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        java.lang.Object obj21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.yearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.minutes();
        long long30 = durationField27.subtract(174441597981L, 0L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType20, durationField27);
        int int34 = unsupportedDateTimeField31.getDifference((long) 4, (long) (byte) -1);
        org.joda.time.DurationField durationField35 = unsupportedDateTimeField31.getRangeDurationField();
        try {
            long long37 = unsupportedDateTimeField31.roundFloor((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 174441597981L + "'", long30 == 174441597981L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNull(durationField35);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int18 = delegatedDateTimeField15.getDifference((long) 'a', (long) 100);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField15.getDurationField();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField15.getAsText((long) (-1), locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField15.getType();
        java.lang.String str24 = delegatedDateTimeField15.getName();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "secondOfMinute" + "'", str24.equals("secondOfMinute"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GJChronology[UTC]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        java.lang.String str9 = dateTimeZone8.getID();
        java.lang.String str10 = dateTimeZone8.getID();
        java.lang.String str11 = dateTimeZone8.getID();
        org.joda.time.DateTime dateTime12 = dateTime6.withZoneRetainFields(dateTimeZone8);
        org.joda.time.DateTime dateTime14 = dateTime6.plus(0L);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMinutes((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 12, 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone2);
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "1969-12-31T16:00:00.100-08:00", (int) (byte) 10);
        java.lang.String str7 = mutableDateTime3.toString();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime3.year();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        mutableDateTime3.add(readablePeriod9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.100Z" + "'", str7.equals("1969-12-31T16:00:00.100Z"));
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean6 = fixedDateTimeZone5.isFixed();
        int int8 = fixedDateTimeZone5.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone14);
        boolean boolean16 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
        mutableDateTime15.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime15.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeFormatter20.getZone();
        org.joda.time.MutableDateTime mutableDateTime22 = mutableDateTime15.toMutableDateTime(dateTimeZone21);
        int int23 = mutableDateTime22.getMillisOfSecond();
        mutableDateTime22.setWeekyear((int) (short) -1);
        java.util.Date date26 = mutableDateTime22.toDate();
        org.joda.time.ReadableDuration readableDuration27 = null;
        mutableDateTime22.add(readableDuration27, (int) '#');
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime22);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(gJChronology30);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (1969-12-31T16:00:00.100-08:00)");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean7 = fixedDateTimeZone6.isFixed();
        long long10 = fixedDateTimeZone6.adjustOffset((-90L), false);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone15);
        boolean boolean17 = mutableDateTime13.isBefore((org.joda.time.ReadableInstant) mutableDateTime16);
        mutableDateTime16.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime16.secondOfMinute();
        java.util.Locale locale21 = null;
        java.lang.String str22 = property20.getAsText(locale21);
        org.joda.time.MutableDateTime mutableDateTime24 = property20.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField25 = property20.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        java.lang.String str28 = delegatedDateTimeField26.getAsShortText((long) (short) 0);
        int int31 = delegatedDateTimeField26.getDifference((long) (byte) 0, (long) 'a');
        long long33 = delegatedDateTimeField26.roundFloor((long) 0);
        boolean boolean34 = fixedDateTimeZone6.equals((java.lang.Object) delegatedDateTimeField26);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        boolean boolean36 = jodaTimePermission1.equals((java.lang.Object) fixedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-90L) + "'", long10 == (-90L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(iSOChronology37);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime10 = property7.addToCopy(0L);
        java.util.Locale locale11 = null;
        int int12 = property7.getMaximumTextLength(locale11);
        org.joda.time.DateTime dateTime13 = property7.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
//        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone12);
//        boolean boolean14 = mutableDateTime10.isBefore((org.joda.time.ReadableInstant) mutableDateTime13);
//        mutableDateTime13.setDayOfMonth((int) (byte) 10);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime13.secondOfMinute();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = property17.getAsText(locale18);
//        org.joda.time.MutableDateTime mutableDateTime21 = property17.addWrapField((int) 'a');
//        org.joda.time.DateTimeField dateTimeField22 = property17.getField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
//        int int26 = delegatedDateTimeField23.getDifference((long) 'a', (long) 100);
//        int int27 = delegatedDateTimeField23.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField23.getType();
//        org.joda.time.DateTime.Property property29 = dateTime7.property(dateTimeFieldType28);
//        long long30 = property29.remainder();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 295L + "'", long30 == 295L);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        long long5 = dateTimeZone1.adjustOffset((-210866673600000L), true);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210866673600000L) + "'", long5 == (-210866673600000L));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.adjustOffset((-90L), false);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-90L) + "'", long8 == (-90L));
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "LimitChronology[GregorianChronology[UTC], 2011-02-12T05:42:33.158-08:00, NoLimit]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) (byte) 0, 9643, 0, 1969, 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime();
        java.lang.Object obj9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj9, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.hourOfDay();
        org.joda.time.DateTime dateTime14 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime16 = dateTime14.withCenturyOfEra(12);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone12);
        boolean boolean14 = mutableDateTime10.isBefore((org.joda.time.ReadableInstant) mutableDateTime13);
        mutableDateTime13.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime13.secondOfMinute();
        java.util.Locale locale18 = null;
        java.lang.String str19 = property17.getAsText(locale18);
        org.joda.time.MutableDateTime mutableDateTime21 = property17.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField22 = property17.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        int int26 = delegatedDateTimeField23.getDifference((long) 'a', (long) 100);
        int int27 = delegatedDateTimeField23.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField23.getType();
        org.joda.time.DateTime.Property property29 = dateTime7.property(dateTimeFieldType28);
        org.joda.time.DateTime dateTime30 = property29.roundCeilingCopy();
        boolean boolean31 = dateTime30.isAfterNow();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "secondOfMinute", (int) (short) 0, 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) (short) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField((int) 'a');
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(10L, locale17);
        long long20 = delegatedDateTimeField15.roundHalfFloor(100L);
        java.lang.String str21 = delegatedDateTimeField15.getName();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "secondOfMinute" + "'", str21.equals("secondOfMinute"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 174441597981L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfFloor();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        java.util.Date date3 = mutableDateTime2.toDate();
        java.lang.String str4 = mutableDateTime2.toString();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.toMutableDateTime();
        int int7 = mutableDateTime6.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) 100L, dateTimeZone4);
        boolean boolean6 = mutableDateTime2.isBefore((org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.setDayOfMonth((int) (byte) 10);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime5.toMutableDateTime(dateTimeZone11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime5.weekyear();
        mutableDateTime5.addWeeks((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded((long) (byte) 0, (int) '#');
        org.joda.time.DateTime dateTime7 = dateTime2.minusYears(100);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        java.lang.String str11 = property10.getAsShortText();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
    }
}

