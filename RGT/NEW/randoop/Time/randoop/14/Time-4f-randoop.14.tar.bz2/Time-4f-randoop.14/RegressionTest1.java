import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("year", "dayOfMonth");
        illegalFieldValueException2.prependMessage("DateTimeField[dayOfMonth]");
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
//        boolean boolean4 = delegatedDateTimeField3.isLenient();
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology5);
//        int int7 = dateTime6.getDayOfWeek();
//        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths(10);
//        org.joda.time.LocalTime localTime10 = dateTime6.toLocalTime();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.secondOfMinute();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        int int14 = delegatedDateTimeField13.getMinimumValue();
//        org.joda.time.DurationField durationField15 = delegatedDateTimeField13.getDurationField();
//        int int16 = dateTime6.get((org.joda.time.DateTimeField) delegatedDateTimeField13);
//        long long19 = delegatedDateTimeField13.add(5001L, (int) (short) 100);
//        int int21 = delegatedDateTimeField13.getMaximumValue((long) 53);
//        org.joda.time.DurationField durationField22 = delegatedDateTimeField13.getDurationField();
//        java.util.Locale locale23 = null;
//        int int24 = delegatedDateTimeField13.getMaximumTextLength(locale23);
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology25);
//        int int27 = dateTime26.getDayOfWeek();
//        org.joda.time.DateTime dateTime29 = dateTime26.minusMonths(10);
//        org.joda.time.LocalTime localTime30 = dateTime26.toLocalTime();
//        int int31 = dateTime26.getSecondOfMinute();
//        org.joda.time.DateTime.Property property32 = dateTime26.millisOfDay();
//        org.joda.time.DateTime dateTime33 = property32.roundCeilingCopy();
//        org.joda.time.DateTime dateTime34 = property32.withMinimumValue();
//        org.joda.time.DateTime.Property property35 = dateTime34.year();
//        org.joda.time.DateTime dateTime36 = property35.withMaximumValue();
//        org.joda.time.DateTime dateTime37 = property35.roundHalfEvenCopy();
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = property35.getAsText(locale38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property35.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField41 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology42);
//        int int44 = copticChronology42.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField45 = copticChronology42.millisOfSecond();
//        org.joda.time.DurationField durationField46 = copticChronology42.years();
//        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology47);
//        int int49 = dateTime48.getDayOfWeek();
//        org.joda.time.DateTime dateTime51 = dateTime48.minusMonths(10);
//        org.joda.time.LocalTime localTime52 = dateTime48.toLocalTime();
//        int int53 = dateTime48.getSecondOfMinute();
//        org.joda.time.DateTime.Property property54 = dateTime48.millisOfDay();
//        org.joda.time.DateTime dateTime55 = property54.roundCeilingCopy();
//        org.joda.time.DateTime dateTime56 = property54.withMinimumValue();
//        org.joda.time.DateTime.Property property57 = dateTime56.year();
//        org.joda.time.DateTime.Property property58 = dateTime56.millisOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology59 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology59);
//        int int61 = dateTime60.getDayOfWeek();
//        org.joda.time.DateTime dateTime63 = dateTime60.minusMonths(10);
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((java.lang.Object) dateTime60);
//        org.joda.time.DateTime dateTime66 = dateTime64.plusSeconds(6);
//        int int67 = dateTime64.getDayOfMonth();
//        org.joda.time.DateTime.Property property68 = dateTime64.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property68.getFieldType();
//        int int70 = dateTime56.get(dateTimeFieldType69);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField72 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField41, durationField46, dateTimeFieldType69, 52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType69, (int) (byte) 1, 1969, 0);
//        int int77 = offsetDateTimeField76.getOffset();
//        int int79 = offsetDateTimeField76.get((long) 1736);
//        try {
//            long long82 = offsetDateTimeField76.add((long) 54, 1970);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 51 for hourOfDay must be in the range [1969,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localTime10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 37 + "'", int16 == 37);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 105001L + "'", long19 == 105001L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 37 + "'", int31 == 37);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1735" + "'", str39.equals("1735"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(copticChronology47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 7 + "'", int49 == 7);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(localTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 37 + "'", int53 == 37);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(copticChronology59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 7 + "'", int61 == 7);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 9 + "'", int67 == 9);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(dateTimeFieldType69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology34.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        org.joda.time.DateTimeField dateTimeField37 = delegatedDateTimeField36.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.LocalDate localDate43 = localDate40.withPeriodAdded(readablePeriod41, 0);
        int int44 = delegatedDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.LocalDate localDate50 = localDate47.withPeriodAdded(readablePeriod48, 0);
        java.util.Locale locale52 = null;
        java.lang.String str53 = delegatedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate50, 31, locale52);
        org.joda.time.DateTime dateTime54 = localDate50.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate56 = localDate50.plusYears(35);
        org.joda.time.LocalDate localDate58 = localDate56.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone60);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.LocalDate localDate64 = localDate61.withPeriodAdded(readablePeriod62, 0);
        org.joda.time.LocalDate.Property property65 = localDate64.dayOfYear();
        int int66 = localDate64.getDayOfWeek();
        boolean boolean67 = localDate56.isAfter((org.joda.time.ReadablePartial) localDate64);
        int int68 = dividedDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField69 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33);
        org.joda.time.DurationField durationField70 = remainderDateTimeField69.getDurationField();
        java.util.Locale locale71 = null;
        int int72 = remainderDateTimeField69.getMaximumShortTextLength(locale71);
        int int73 = remainderDateTimeField69.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 59 + "'", int44 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31" + "'", str53.equals("31"));
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 3 + "'", int66 == 3);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekOfWeekyear();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        try {
            long long10 = copticChronology0.getDateTimeMillis(46213, 0, 53, 34, 1, 35, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 34 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
//        int int2 = dateTime1.getDayOfWeek();
//        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
//        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
//        int int6 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property7.getAsShortText(locale9);
//        org.joda.time.DateTime dateTime12 = property7.addToCopy((int) (short) 1);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
//        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology14);
//        int int16 = dateTime15.getDayOfWeek();
//        org.joda.time.DateTime dateTime18 = dateTime15.minusMonths(10);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) dateTime15);
//        boolean boolean20 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime19);
//        int int21 = dateTime12.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime23 = dateTime12.minusMonths(0);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(localTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 38 + "'", int6 == 38);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3158358" + "'", str10.equals("3158358"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(copticChronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 40 + "'", int21 == 40);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-292268510));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone50);
        org.joda.time.LocalDate localDate53 = localDate51.withYearOfEra(6);
        org.joda.time.LocalDate localDate55 = localDate51.plusDays((int) (byte) 10);
        org.joda.time.LocalDate localDate57 = localDate51.minusDays(6);
        java.util.Locale locale58 = null;
        try {
            java.lang.String str59 = unsupportedDateTimeField47.getAsText((org.joda.time.ReadablePartial) localDate51, locale58);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(localDate57);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate22 = localDate16.plusYears(35);
        org.joda.time.LocalDate localDate24 = localDate22.withWeekyear(0);
        java.lang.String str25 = localDate22.toString();
        org.joda.time.DateTime dateTime26 = localDate22.toDateTimeAtStartOfDay();
        org.joda.time.DateTime dateTime28 = dateTime26.withMinuteOfHour(36);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2004-12-31" + "'", str25.equals("2004-12-31"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-292268510));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gregorianChronology0.equals(obj1);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (byte) 1);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        int int8 = delegatedDateTimeField7.getMinimumValue();
        org.joda.time.DurationField durationField9 = delegatedDateTimeField7.getDurationField();
        java.lang.String str11 = delegatedDateTimeField7.getAsText((long) 54);
        int int13 = delegatedDateTimeField7.getMinimumValue((long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate19 = localDate16.withPeriodAdded(readablePeriod17, 0);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime21 = localDate19.toDateTimeAtCurrentTime(dateTimeZone20);
        int int22 = localDate19.getDayOfMonth();
        org.joda.time.LocalDate.Property property23 = localDate19.dayOfMonth();
        org.joda.time.LocalDate localDate24 = property23.roundCeilingCopy();
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDate24, 59, locale26);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "59" + "'", str27.equals("59"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.weekOfWeekyear();
        org.joda.time.Interval interval7 = property6.toInterval();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(interval7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfEvenCopy();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = localDate7.isSupported(durationFieldType8);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = localDate7.getFieldTypes();
        org.joda.time.Partial partial11 = new org.joda.time.Partial();
        java.lang.String str12 = partial11.toStringList();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.Partial partial14 = partial11.without(dateTimeFieldType13);
        boolean boolean15 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) partial11);
        int[] intArray16 = partial11.getValues();
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.dayOfMonth();
        boolean boolean20 = copticChronology17.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology22 = copticChronology17.withZone(dateTimeZone21);
        try {
            org.joda.time.Partial partial23 = new org.joda.time.Partial(dateTimeFieldTypeArray10, intArray16, (org.joda.time.Chronology) copticChronology17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[]" + "'", str12.equals("[]"));
        org.junit.Assert.assertNotNull(partial14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField47.getLeapDurationField();
        int int52 = unsupportedDateTimeField47.getDifference((long) 2, 0L);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone54);
        org.joda.time.LocalDate localDate57 = localDate55.withYearOfEra(6);
        try {
            int int58 = unsupportedDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) localDate55);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(localDate57);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long6 = fixedDateTimeZone4.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "56992242", (int) (byte) 0, (int) (byte) 1);
        org.joda.time.Chronology chronology13 = iSOChronology7.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        java.util.TimeZone timeZone14 = fixedDateTimeZone12.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3540L + "'", long6 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str13 = fixedDateTimeZone11.getShortName((long) (byte) 100);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        boolean boolean16 = buddhistChronology14.equals((java.lang.Object) "hi!");
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology14.yearOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long24 = fixedDateTimeZone22.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        java.lang.String str27 = fixedDateTimeZone22.getNameKey(100L);
        org.joda.time.Chronology chronology28 = buddhistChronology14.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        boolean boolean30 = fixedDateTimeZone11.equals((java.lang.Object) fixedDateTimeZone22);
        org.joda.time.DateMidnight dateMidnight31 = localDate5.toDateMidnight((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.035" + "'", str13.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3540L + "'", long24 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateMidnight31);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate22 = localDate16.plusYears(35);
        org.joda.time.LocalDate localDate24 = localDate22.withWeekyear(0);
        org.joda.time.LocalDate localDate26 = localDate24.plusYears(55);
        try {
            org.joda.time.LocalDate localDate28 = localDate26.withDayOfWeek(53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(localDate26);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long12 = fixedDateTimeZone10.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTime dateTime14 = localDate5.toDateTimeAtMidnight((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate5.minus(readablePeriod15);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology17);
        int int19 = dateTime18.getDayOfWeek();
        org.joda.time.DateTime dateTime21 = dateTime18.minusMonths(10);
        org.joda.time.LocalTime localTime22 = dateTime18.toLocalTime();
        int int23 = dateTime18.getSecondOfMinute();
        org.joda.time.DateTime.Property property24 = dateTime18.millisOfDay();
        org.joda.time.DateTime dateTime25 = property24.roundCeilingCopy();
        org.joda.time.DateTime dateTime26 = property24.withMinimumValue();
        org.joda.time.DateTime.Property property27 = dateTime26.year();
        org.joda.time.DateTime.Property property28 = dateTime26.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology29);
        int int31 = dateTime30.getDayOfWeek();
        org.joda.time.DateTime dateTime33 = dateTime30.minusMonths(10);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) dateTime30);
        org.joda.time.DateTime dateTime36 = dateTime34.plusSeconds(6);
        int int37 = dateTime34.getDayOfMonth();
        org.joda.time.DateTime.Property property38 = dateTime34.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, (java.lang.Number) 34, "31");
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField45 = julianChronology44.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField45);
        try {
            int int47 = localDate5.get(dateTimeFieldType39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3540L + "'", long12 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 51 + "'", int23 == 51);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 7 + "'", int31 == 7);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 19 + "'", int37 == 19);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("57007393", (java.lang.Number) 1735, (java.lang.Number) 1735L, (java.lang.Number) 56);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField2 = julianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.halfdayOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long10 = fixedDateTimeZone8.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str18 = fixedDateTimeZone16.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone19 = fixedDateTimeZone16.toTimeZone();
        org.joda.time.Chronology chronology20 = iSOChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.Chronology chronology21 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3540L + "'", long10 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.035" + "'", str18.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("hi!", 14);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("57008156", true);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder5.toDateTimeZone("13", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder5.setFixedSavings("DateTimeField[dayOfMonth]", 1736);
        java.io.DataOutput dataOutput16 = null;
        try {
            dateTimeZoneBuilder5.writeTo("1735-10-08T15:49:49.485-07:00", dataOutput16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate22 = localDate16.plusYears(35);
        org.joda.time.LocalDate localDate24 = localDate22.withWeekyear(0);
        java.lang.String str25 = localDate22.toString();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval27 = localDate22.toInterval(dateTimeZone26);
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval27);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2004-12-31" + "'", str25.equals("2004-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(interval27);
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        long long8 = dateTime1.getMillis();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-292268510L) + "'", long8 == (-292268510L));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("57007120", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"57007120\" is malformed at \"007120\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime10 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour((int) ' ');
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology13);
        int int15 = dateTime14.getDayOfWeek();
        org.joda.time.DateTime dateTime17 = dateTime14.minusMonths(10);
        org.joda.time.LocalTime localTime18 = dateTime14.toLocalTime();
        int int19 = dateTime14.getSecondOfMinute();
        org.joda.time.DateTime.Property property20 = dateTime14.millisOfDay();
        org.joda.time.DateTime dateTime21 = property20.roundCeilingCopy();
        org.joda.time.DateTime dateTime22 = property20.withMinimumValue();
        org.joda.time.DateTime.Property property23 = dateTime22.year();
        org.joda.time.DateTime.Property property24 = dateTime22.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology25);
        int int27 = dateTime26.getDayOfWeek();
        org.joda.time.DateTime dateTime29 = dateTime26.minusMonths(10);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) dateTime26);
        org.joda.time.DateTime dateTime32 = dateTime30.plusSeconds(6);
        int int33 = dateTime30.getDayOfMonth();
        org.joda.time.DateTime.Property property34 = dateTime30.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        int int36 = dateTime22.get(dateTimeFieldType35);
        boolean boolean37 = dateTime10.isSupported(dateTimeFieldType35);
        try {
            org.joda.time.DateTime dateTime39 = dateTime10.withMonthOfYear(1735);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1735 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 51 + "'", int19 == 51);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 19 + "'", int33 == 19);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = gregorianChronology0.equals(obj1);
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfEra(6);
        int int5 = localDate4.getDayOfYear();
        int int6 = localDate4.getEra();
        org.joda.time.LocalDate localDate8 = localDate4.minusWeeks(58);
        try {
            org.joda.time.DateTimeField dateTimeField10 = localDate4.getField(19);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 19");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 1735, 1560638995619L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560638997354L + "'", long2 == 1560638997354L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str11 = fixedDateTimeZone9.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone12 = fixedDateTimeZone9.toTimeZone();
        java.lang.String str14 = fixedDateTimeZone9.getName(100L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology16 = gJChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime17 = dateTime1.toDateTime((org.joda.time.Chronology) gJChronology4);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.035" + "'", str11.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.035" + "'", str14.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.LocalDate localDate10 = localDate7.withPeriodAdded(readablePeriod8, 0);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = localDate10.toDateTimeAtCurrentTime(dateTimeZone11);
        int int13 = localDate10.getDayOfMonth();
        org.joda.time.LocalDate.Property property14 = localDate10.dayOfMonth();
        int int15 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate10);
        int int16 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.secondOfMinute();
        org.joda.time.DurationField durationField19 = julianChronology17.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        org.joda.time.DateTimeField dateTimeField23 = delegatedDateTimeField22.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.LocalDate localDate29 = localDate26.withPeriodAdded(readablePeriod27, 0);
        int int30 = delegatedDateTimeField22.getMaximumValue((org.joda.time.ReadablePartial) localDate29);
        org.joda.time.LocalDate.Property property31 = localDate29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, durationField19, dateTimeFieldType32, 35);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        org.joda.time.DateTimeField dateTimeField38 = delegatedDateTimeField37.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone40);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.LocalDate localDate44 = localDate41.withPeriodAdded(readablePeriod42, 0);
        int int45 = delegatedDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) localDate44);
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone47);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.LocalDate localDate51 = localDate48.withPeriodAdded(readablePeriod49, 0);
        java.util.Locale locale53 = null;
        java.lang.String str54 = delegatedDateTimeField37.getAsShortText((org.joda.time.ReadablePartial) localDate51, 31, locale53);
        org.joda.time.DateTime dateTime55 = localDate51.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate57 = localDate51.plusYears(35);
        org.joda.time.LocalDate localDate59 = localDate57.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone61);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.LocalDate localDate65 = localDate62.withPeriodAdded(readablePeriod63, 0);
        org.joda.time.LocalDate.Property property66 = localDate65.dayOfYear();
        int int67 = localDate65.getDayOfWeek();
        boolean boolean68 = localDate57.isAfter((org.joda.time.ReadablePartial) localDate65);
        int int69 = dividedDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localDate65);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField34);
        long long73 = remainderDateTimeField70.set((long) (short) 0, (int) (short) 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField75 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) remainderDateTimeField70, 59);
        long long77 = remainderDateTimeField70.roundFloor((long) 33);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 59 + "'", int45 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31" + "'", str54.equals("31"));
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(localDate65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology2);
        int int4 = dateTime3.getDayOfWeek();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(10);
        org.joda.time.LocalTime localTime7 = dateTime3.toLocalTime();
        int int8 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTime dateTime11 = property9.withMinimumValue();
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime14 = property12.roundHalfEvenCopy();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property12.getAsText(locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType17, 8, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendFractionOfHour((int) 'a', (-12));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder20.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 51 + "'", int8 == 51);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1686" + "'", str16.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        int int50 = unsupportedDateTimeField47.getDifference((long) 4, 17000L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long6 = fixedDateTimeZone4.previousTransition(3540L);
        long long9 = fixedDateTimeZone4.adjustOffset((long) 8, true);
        java.lang.String str10 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3540L + "'", long6 == 3540L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate22 = localDate16.plusYears(35);
        org.joda.time.LocalDate localDate24 = localDate22.withWeekyear(0);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        org.joda.time.DateTimeField dateTimeField28 = delegatedDateTimeField27.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.LocalDate localDate34 = localDate31.withPeriodAdded(readablePeriod32, 0);
        int int35 = delegatedDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) localDate34);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        java.util.Locale locale43 = null;
        java.lang.String str44 = delegatedDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) localDate41, 31, locale43);
        org.joda.time.DateTime dateTime45 = localDate41.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate47 = localDate41.plusYears(35);
        org.joda.time.LocalDate localDate49 = localDate47.withWeekyear(0);
        java.lang.String str50 = localDate47.toString();
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Interval interval52 = localDate47.toInterval(dateTimeZone51);
        org.joda.time.Interval interval53 = localDate22.toInterval(dateTimeZone51);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 59 + "'", int35 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "2004-12-31" + "'", str50.equals("2004-12-31"));
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(interval52);
        org.junit.Assert.assertNotNull(interval53);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long13 = fixedDateTimeZone11.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str16 = fixedDateTimeZone11.getNameKey(100L);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-12), 100, 60, (int) (short) 10, 34, (-2), 51, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3540L + "'", long13 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.DateTime dateTime11 = property10.withMaximumValue();
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(6);
        int int8 = dateTime5.getDayOfMonth();
        org.joda.time.DateTime.Property property9 = dateTime5.hourOfDay();
        org.joda.time.LocalTime localTime10 = dateTime5.toLocalTime();
        org.joda.time.DateTime dateTime12 = dateTime5.withMillis((long) 59);
        java.lang.String str14 = dateTime5.toString("56994671");
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "56994671" + "'", str14.equals("56994671"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime10 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour((int) ' ');
        org.joda.time.DateTime dateTime14 = dateTime10.plus((long) ' ');
        org.joda.time.DateTime dateTime15 = dateTime10.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(7);
        int int18 = dateTime17.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 42 + "'", int18 == 42);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = localDate3.withYearOfEra(6);
        org.joda.time.LocalDate localDate7 = localDate3.plusDays((int) (byte) 10);
        boolean boolean8 = localDate0.isAfter((org.joda.time.ReadablePartial) localDate3);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((-10));
        org.joda.time.Chronology chronology3 = gJChronology0.withZone(dateTimeZone2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone2.getName(2440588L, locale5);
        long long9 = dateTimeZone2.adjustOffset(8002L, false);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-10:00" + "'", str6.equals("-10:00"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8002L + "'", long9 == 8002L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int9 = delegatedDateTimeField8.getMinimumValue();
        org.joda.time.DurationField durationField10 = delegatedDateTimeField8.getDurationField();
        int int11 = dateTime1.get((org.joda.time.DateTimeField) delegatedDateTimeField8);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = delegatedDateTimeField8.getType();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 51 + "'", int11 == 51);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        java.lang.String str2 = buddhistChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.secondOfDay();
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology1);
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.monthOfYear();
//        java.lang.String str6 = buddhistChronology1.toString();
//        try {
//            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) buddhistChronology1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[-10:00]" + "'", str2.equals("BuddhistChronology[-10:00]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[-10:00]" + "'", str6.equals("BuddhistChronology[-10:00]"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int3 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DurationField durationField4 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        int int6 = delegatedDateTimeField2.getMaximumShortTextLength(locale5);
        long long8 = delegatedDateTimeField2.roundCeiling(0L);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField10 = copticChronology9.halfdays();
        long long13 = durationField10.subtract((long) (short) -1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, durationField10, dateTimeFieldType14);
        long long18 = durationField10.subtract((long) 7, 22);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43199999L + "'", long13 == 43199999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-950399993L) + "'", long18 == (-950399993L));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) 949, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.lang.String str8 = fixedDateTimeZone6.getID();
        org.joda.time.Chronology chronology9 = copticChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate22 = localDate16.plusYears(35);
        org.joda.time.LocalDate localDate24 = localDate22.withWeekyear(0);
        java.lang.String str25 = localDate22.toString();
        org.joda.time.DateTime dateTime26 = localDate22.toDateTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate32 = localDate29.withPeriodAdded(readablePeriod30, 0);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime34 = localDate32.toDateTimeAtCurrentTime(dateTimeZone33);
        int int35 = localDate32.getDayOfMonth();
        org.joda.time.LocalDate.Property property36 = localDate32.dayOfMonth();
        org.joda.time.DateTimeField[] dateTimeFieldArray37 = localDate32.getFields();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone39);
        org.joda.time.LocalDate localDate42 = localDate40.withYearOfEra(6);
        org.joda.time.Chronology chronology43 = localDate40.getChronology();
        boolean boolean44 = localDate32.equals((java.lang.Object) localDate40);
        int int45 = localDate40.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetHours((-10));
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate(0L, dateTimeZone48);
        org.joda.time.DateTime dateTime50 = localDate40.toDateTimeAtCurrentTime(dateTimeZone48);
        org.joda.time.DateMidnight dateMidnight51 = localDate22.toDateMidnight(dateTimeZone48);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2004-12-31" + "'", str25.equals("2004-12-31"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 31 + "'", int35 == 31);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFieldArray37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateMidnight51);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(68915000L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology12);
        int int14 = dateTime13.getDayOfWeek();
        org.joda.time.DateTime dateTime16 = dateTime13.minusMonths(10);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) dateTime13);
        org.joda.time.DateTime dateTime19 = dateTime17.plusSeconds(6);
        int int20 = dateTime17.getDayOfMonth();
        org.joda.time.DateTime.Property property21 = dateTime17.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        int int23 = dateTime9.get(dateTimeFieldType22);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 34, "31");
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = julianChronology27.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField28);
        try {
            org.joda.time.Partial partial31 = new org.joda.time.Partial(dateTimeFieldType22, 36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36 for hourOfDay must not be larger than 23");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField2 = julianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.halfdayOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long10 = fixedDateTimeZone8.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str18 = fixedDateTimeZone16.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone19 = fixedDateTimeZone16.toTimeZone();
        org.joda.time.Chronology chronology20 = iSOChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.Chronology chronology21 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3540L + "'", long10 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.035" + "'", str18.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long12 = fixedDateTimeZone10.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTime dateTime14 = localDate5.toDateTimeAtMidnight((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.LocalDate localDate16 = localDate5.minus(readablePeriod15);
        org.joda.time.LocalDate localDate18 = localDate5.plusYears(10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3540L + "'", long12 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusDays((int) 'a');
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
//        int int2 = dateTime1.getDayOfWeek();
//        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
//        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
//        int int6 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
//        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(100);
//        boolean boolean13 = dateTime11.isEqual(0L);
//        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.dayOfMonth();
//        boolean boolean17 = copticChronology14.equals((java.lang.Object) 0L);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology19 = copticChronology14.withZone(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime11.withZone(dateTimeZone18);
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        int int22 = dateTimeZone18.getOffset(readableInstant21);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(localTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(copticChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-36000000) + "'", int22 == (-36000000));
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfEra(6);
        int int5 = localDate4.getDayOfWeek();
        org.joda.time.LocalDate localDate7 = localDate4.withYearOfCentury(30);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        boolean boolean49 = unsupportedDateTimeField47.isSupported();
        try {
            long long51 = unsupportedDateTimeField47.roundHalfEven((long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (byte) 10, 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendPattern("60");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField47.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = unsupportedDateTimeField47.getType();
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = julianChronology51.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
        org.joda.time.DateTimeField dateTimeField54 = delegatedDateTimeField53.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone56);
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.LocalDate localDate60 = localDate57.withPeriodAdded(readablePeriod58, 0);
        int int61 = delegatedDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) localDate60);
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate64 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone63);
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        org.joda.time.LocalDate localDate67 = localDate64.withPeriodAdded(readablePeriod65, 0);
        java.util.Locale locale69 = null;
        java.lang.String str70 = delegatedDateTimeField53.getAsShortText((org.joda.time.ReadablePartial) localDate67, 31, locale69);
        org.joda.time.DateTime dateTime71 = localDate67.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate73 = localDate67.plusYears(35);
        org.joda.time.LocalDate localDate75 = localDate67.minusWeeks(0);
        int int76 = localDate75.size();
        java.util.Locale locale77 = null;
        try {
            java.lang.String str78 = unsupportedDateTimeField47.getAsText((org.joda.time.ReadablePartial) localDate75, locale77);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 59 + "'", int61 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "31" + "'", str70.equals("31"));
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 3 + "'", int76 == 3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int3 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DurationField durationField4 = delegatedDateTimeField2.getDurationField();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField7.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 0);
        int int15 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.LocalDate localDate21 = localDate18.withPeriodAdded(readablePeriod19, 0);
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localDate21, 31, locale23);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField26 = copticChronology25.halfdays();
        long long29 = durationField26.subtract((long) (short) -1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField7, durationField26, dateTimeFieldType30);
        org.joda.time.DurationField durationField32 = delegatedDateTimeField31.getDurationField();
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.dayOfMonth();
        boolean boolean36 = copticChronology33.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology38 = copticChronology33.withZone(dateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone40);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.LocalDate localDate44 = localDate41.withPeriodAdded(readablePeriod42, 0);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = localDate44.toDateTimeAtCurrentTime(dateTimeZone45);
        int int47 = localDate44.getDayOfMonth();
        int[] intArray49 = copticChronology33.get((org.joda.time.ReadablePartial) localDate44, (long) '4');
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = copticChronology50.dayOfMonth();
        boolean boolean53 = copticChronology50.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology55 = copticChronology50.withZone(dateTimeZone54);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone57);
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.LocalDate localDate61 = localDate58.withPeriodAdded(readablePeriod59, 0);
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime63 = localDate61.toDateTimeAtCurrentTime(dateTimeZone62);
        int int64 = localDate61.getDayOfMonth();
        int[] intArray66 = copticChronology50.get((org.joda.time.ReadablePartial) localDate61, (long) '4');
        int int67 = delegatedDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) localDate44, intArray66);
        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate70 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone69);
        int int71 = localDate44.compareTo((org.joda.time.ReadablePartial) localDate70);
        int int72 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate44);
        try {
            long long75 = delegatedDateTimeField2.set(189302401000L, 1735);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1735 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 59 + "'", int15 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31" + "'", str24.equals("31"));
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43199999L + "'", long29 == 43199999L);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 31 + "'", int47 == 31);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(chronology55);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 31 + "'", int64 == 31);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 59 + "'", int72 == 59);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField47.getLeapDurationField();
        long long52 = unsupportedDateTimeField47.add((long) 40, 6);
        org.joda.time.ReadablePartial readablePartial53 = null;
        int[] intArray58 = new int[] { 4, 59, 51 };
        try {
            int[] intArray60 = unsupportedDateTimeField47.set(readablePartial53, (-3), intArray58, 46213);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 189302400040L + "'", long52 == 189302400040L);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfEra(6);
        org.joda.time.LocalDate localDate6 = localDate2.plusDays((int) (byte) 10);
        org.joda.time.LocalDate localDate8 = localDate2.minusDays(6);
        java.util.Date date9 = localDate8.toDate();
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.fromDateFields(date9);
        int int11 = localDate10.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int9 = delegatedDateTimeField8.getMinimumValue();
        org.joda.time.DurationField durationField10 = delegatedDateTimeField8.getDurationField();
        int int11 = dateTime1.get((org.joda.time.DateTimeField) delegatedDateTimeField8);
        long long14 = delegatedDateTimeField8.add(5001L, (int) (short) 100);
        int int16 = delegatedDateTimeField8.getMaximumValue((long) 53);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField8.getDurationField();
        java.util.Locale locale18 = null;
        int int19 = delegatedDateTimeField8.getMaximumTextLength(locale18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology20);
        int int22 = dateTime21.getDayOfWeek();
        org.joda.time.DateTime dateTime24 = dateTime21.minusMonths(10);
        org.joda.time.LocalTime localTime25 = dateTime21.toLocalTime();
        int int26 = dateTime21.getSecondOfMinute();
        org.joda.time.DateTime.Property property27 = dateTime21.millisOfDay();
        org.joda.time.DateTime dateTime28 = property27.roundCeilingCopy();
        org.joda.time.DateTime dateTime29 = property27.withMinimumValue();
        org.joda.time.DateTime.Property property30 = dateTime29.year();
        org.joda.time.DateTime dateTime31 = property30.withMaximumValue();
        org.joda.time.DateTime dateTime32 = property30.roundHalfEvenCopy();
        java.util.Locale locale33 = null;
        java.lang.String str34 = property30.getAsText(locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property30.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType35);
        org.joda.time.chrono.CopticChronology copticChronology37 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology37);
        int int39 = copticChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField40 = copticChronology37.millisOfSecond();
        org.joda.time.DurationField durationField41 = copticChronology37.years();
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology42);
        int int44 = dateTime43.getDayOfWeek();
        org.joda.time.DateTime dateTime46 = dateTime43.minusMonths(10);
        org.joda.time.LocalTime localTime47 = dateTime43.toLocalTime();
        int int48 = dateTime43.getSecondOfMinute();
        org.joda.time.DateTime.Property property49 = dateTime43.millisOfDay();
        org.joda.time.DateTime dateTime50 = property49.roundCeilingCopy();
        org.joda.time.DateTime dateTime51 = property49.withMinimumValue();
        org.joda.time.DateTime.Property property52 = dateTime51.year();
        org.joda.time.DateTime.Property property53 = dateTime51.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology54 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology54);
        int int56 = dateTime55.getDayOfWeek();
        org.joda.time.DateTime dateTime58 = dateTime55.minusMonths(10);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((java.lang.Object) dateTime55);
        org.joda.time.DateTime dateTime61 = dateTime59.plusSeconds(6);
        int int62 = dateTime59.getDayOfMonth();
        org.joda.time.DateTime.Property property63 = dateTime59.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField36, durationField41, dateTimeFieldType64, 52);
        long long69 = zeroIsMaxDateTimeField36.roundHalfCeiling(8002L);
        long long71 = zeroIsMaxDateTimeField36.roundHalfFloor(1686L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 51 + "'", int11 == 51);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 105001L + "'", long14 == 105001L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 51 + "'", int26 == 51);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1686" + "'", str34.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(copticChronology37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 7 + "'", int44 == 7);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(localTime47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 51 + "'", int48 == 51);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(copticChronology54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 7 + "'", int56 == 7);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 19 + "'", int62 == 19);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 8000L + "'", long69 == 8000L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2000L + "'", long71 == 2000L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        boolean boolean3 = copticChronology0.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate8.withPeriodAdded(readablePeriod9, 0);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = localDate11.toDateTimeAtCurrentTime(dateTimeZone12);
        int int14 = localDate11.getDayOfMonth();
        int[] intArray16 = copticChronology0.get((org.joda.time.ReadablePartial) localDate11, (long) '4');
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate26 = localDate23.withPeriodAdded(readablePeriod24, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime28 = localDate26.toDateTimeAtCurrentTime(dateTimeZone27);
        int int29 = localDate26.getDayOfMonth();
        org.joda.time.LocalDate.Property property30 = localDate26.dayOfMonth();
        int int31 = delegatedDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) localDate26);
        int int32 = delegatedDateTimeField20.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology33.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        org.joda.time.DateTimeField dateTimeField36 = delegatedDateTimeField35.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone38);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.LocalDate localDate42 = localDate39.withPeriodAdded(readablePeriod40, 0);
        int int43 = delegatedDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) localDate42);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.LocalDate localDate49 = localDate46.withPeriodAdded(readablePeriod47, 0);
        java.util.Locale locale51 = null;
        java.lang.String str52 = delegatedDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) localDate49, 31, locale51);
        org.joda.time.DateTime dateTime53 = localDate49.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate55 = localDate49.plusYears(35);
        org.joda.time.LocalDate localDate57 = localDate55.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone59);
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.LocalDate localDate63 = localDate60.withPeriodAdded(readablePeriod61, 0);
        org.joda.time.LocalDate.Property property64 = localDate63.dayOfYear();
        int int65 = localDate63.getDayOfWeek();
        boolean boolean66 = localDate55.isAfter((org.joda.time.ReadablePartial) localDate63);
        org.joda.time.LocalDate localDate68 = localDate63.withCenturyOfEra(57);
        org.joda.time.chrono.CopticChronology copticChronology69 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField70 = copticChronology69.dayOfMonth();
        boolean boolean72 = copticChronology69.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology74 = copticChronology69.withZone(dateTimeZone73);
        org.joda.time.DateTimeZone dateTimeZone76 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate77 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone76);
        org.joda.time.ReadablePeriod readablePeriod78 = null;
        org.joda.time.LocalDate localDate80 = localDate77.withPeriodAdded(readablePeriod78, 0);
        org.joda.time.DateTimeZone dateTimeZone81 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime82 = localDate80.toDateTimeAtCurrentTime(dateTimeZone81);
        int int83 = localDate80.getDayOfMonth();
        int[] intArray85 = copticChronology69.get((org.joda.time.ReadablePartial) localDate80, (long) '4');
        int int86 = delegatedDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDate68, intArray85);
        org.joda.time.LocalDate localDate87 = localDate11.withFields((org.joda.time.ReadablePartial) localDate68);
        org.joda.time.DateTimeZone dateTimeZone89 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate90 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone89);
        org.joda.time.LocalDate localDate92 = localDate90.withYearOfEra(6);
        org.joda.time.LocalDate localDate94 = localDate90.plusDays((int) (byte) 10);
        org.joda.time.LocalDate localDate96 = localDate90.minusDays(6);
        java.util.Date date97 = localDate96.toDate();
        org.joda.time.LocalDate localDate98 = org.joda.time.LocalDate.fromDateFields(date97);
        org.joda.time.LocalDate localDate99 = localDate11.withFields((org.joda.time.ReadablePartial) localDate98);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 59 + "'", int43 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31" + "'", str52.equals("31"));
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 3 + "'", int65 == 3);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertNotNull(copticChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertNotNull(chronology74);
        org.junit.Assert.assertNotNull(dateTimeZone76);
        org.junit.Assert.assertNotNull(localDate80);
        org.junit.Assert.assertNotNull(dateTimeZone81);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 31 + "'", int83 == 31);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 59 + "'", int86 == 59);
        org.junit.Assert.assertNotNull(localDate87);
        org.junit.Assert.assertNotNull(dateTimeZone89);
        org.junit.Assert.assertNotNull(localDate92);
        org.junit.Assert.assertNotNull(localDate94);
        org.junit.Assert.assertNotNull(localDate96);
        org.junit.Assert.assertNotNull(date97);
        org.junit.Assert.assertNotNull(localDate98);
        org.junit.Assert.assertNotNull(localDate99);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long6 = fixedDateTimeZone4.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "56992242", (int) (byte) 0, (int) (byte) 1);
        org.joda.time.Chronology chronology13 = iSOChronology7.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        java.util.TimeZone timeZone14 = fixedDateTimeZone12.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3540L + "'", long6 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str2 = partial0.toString("[]");
        java.util.Locale locale4 = null;
        java.lang.String str5 = partial0.toString("+00:00:00.035", locale4);
        java.lang.String str6 = partial0.toString();
        java.lang.String str7 = partial0.toStringList();
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = partial0.toString("", locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[]" + "'", str2.equals("[]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.035" + "'", str5.equals("+00:00:00.035"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[]" + "'", str7.equals("[]"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology34.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        org.joda.time.DateTimeField dateTimeField37 = delegatedDateTimeField36.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.LocalDate localDate43 = localDate40.withPeriodAdded(readablePeriod41, 0);
        int int44 = delegatedDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.LocalDate localDate50 = localDate47.withPeriodAdded(readablePeriod48, 0);
        java.util.Locale locale52 = null;
        java.lang.String str53 = delegatedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate50, 31, locale52);
        org.joda.time.DateTime dateTime54 = localDate50.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate56 = localDate50.plusYears(35);
        org.joda.time.LocalDate localDate58 = localDate56.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone60);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.LocalDate localDate64 = localDate61.withPeriodAdded(readablePeriod62, 0);
        org.joda.time.LocalDate.Property property65 = localDate64.dayOfYear();
        int int66 = localDate64.getDayOfWeek();
        boolean boolean67 = localDate56.isAfter((org.joda.time.ReadablePartial) localDate64);
        int int68 = dividedDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField69 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33);
        long long72 = remainderDateTimeField69.set((long) (short) 0, (int) (short) 0);
        boolean boolean74 = remainderDateTimeField69.isLeap((long) 50);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 59 + "'", int44 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31" + "'", str53.equals("31"));
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 3 + "'", int66 == 3);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 6, 13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 78L + "'", long2 == 78L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        try {
            long long49 = unsupportedDateTimeField47.remainder((long) 52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-2));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField21 = copticChronology20.halfdays();
        long long24 = durationField21.subtract((long) (short) -1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, durationField21, dateTimeFieldType25);
        org.joda.time.DurationField durationField27 = delegatedDateTimeField26.getDurationField();
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology28.dayOfMonth();
        boolean boolean31 = copticChronology28.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology33 = copticChronology28.withZone(dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.LocalDate localDate39 = localDate36.withPeriodAdded(readablePeriod37, 0);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime41 = localDate39.toDateTimeAtCurrentTime(dateTimeZone40);
        int int42 = localDate39.getDayOfMonth();
        int[] intArray44 = copticChronology28.get((org.joda.time.ReadablePartial) localDate39, (long) '4');
        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = copticChronology45.dayOfMonth();
        boolean boolean48 = copticChronology45.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology50 = copticChronology45.withZone(dateTimeZone49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate56 = localDate53.withPeriodAdded(readablePeriod54, 0);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime58 = localDate56.toDateTimeAtCurrentTime(dateTimeZone57);
        int int59 = localDate56.getDayOfMonth();
        int[] intArray61 = copticChronology45.get((org.joda.time.ReadablePartial) localDate56, (long) '4');
        int int62 = delegatedDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localDate39, intArray61);
        java.util.Locale locale64 = null;
        java.lang.String str65 = delegatedDateTimeField26.getAsText(365, locale64);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43199999L + "'", long24 == 43199999L);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 31 + "'", int42 == 31);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(copticChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 31 + "'", int59 == 31);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "365" + "'", str65.equals("365"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toStringList();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.Partial partial3 = partial0.minus(readablePeriod2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(partial3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        org.joda.time.DateTimeField dateTimeField19 = delegatedDateTimeField18.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.LocalDate localDate25 = localDate22.withPeriodAdded(readablePeriod23, 0);
        int int26 = delegatedDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate32 = localDate29.withPeriodAdded(readablePeriod30, 0);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate32, 31, locale34);
        org.joda.time.DateTime dateTime36 = localDate32.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate38 = localDate32.plusYears(35);
        org.joda.time.LocalDate localDate40 = localDate38.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.LocalDate localDate46 = localDate43.withPeriodAdded(readablePeriod44, 0);
        org.joda.time.LocalDate.Property property47 = localDate46.dayOfYear();
        int int48 = localDate46.getDayOfWeek();
        boolean boolean49 = localDate38.isAfter((org.joda.time.ReadablePartial) localDate46);
        org.joda.time.LocalDate localDate51 = localDate46.withCenturyOfEra(57);
        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = copticChronology52.dayOfMonth();
        boolean boolean55 = copticChronology52.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology57 = copticChronology52.withZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone59);
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.LocalDate localDate63 = localDate60.withPeriodAdded(readablePeriod61, 0);
        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime65 = localDate63.toDateTimeAtCurrentTime(dateTimeZone64);
        int int66 = localDate63.getDayOfMonth();
        int[] intArray68 = copticChronology52.get((org.joda.time.ReadablePartial) localDate63, (long) '4');
        int int69 = delegatedDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) localDate51, intArray68);
        long long71 = delegatedDateTimeField3.roundFloor((-950399993L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 59 + "'", int26 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31" + "'", str35.equals("31"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 3 + "'", int48 == 3);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(copticChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 31 + "'", int66 == 31);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-950400000L) + "'", long71 == (-950400000L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate22 = localDate16.plusYears(35);
        org.joda.time.LocalDate.Property property23 = localDate22.dayOfYear();
        org.joda.time.LocalDate localDate24 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField25 = property23.getField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        boolean boolean2 = buddhistChronology0.equals((java.lang.Object) "hi!");
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField47.getLeapDurationField();
        boolean boolean50 = unsupportedDateTimeField47.isLenient();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        boolean boolean3 = copticChronology0.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate8.withPeriodAdded(readablePeriod9, 0);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = localDate11.toDateTimeAtCurrentTime(dateTimeZone12);
        int int14 = localDate11.getDayOfMonth();
        int[] intArray16 = copticChronology0.get((org.joda.time.ReadablePartial) localDate11, (long) '4');
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.LocalDate localDate26 = localDate23.withPeriodAdded(readablePeriod24, 0);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime28 = localDate26.toDateTimeAtCurrentTime(dateTimeZone27);
        int int29 = localDate26.getDayOfMonth();
        org.joda.time.LocalDate.Property property30 = localDate26.dayOfMonth();
        int int31 = delegatedDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) localDate26);
        int int32 = delegatedDateTimeField20.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology33.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        org.joda.time.DateTimeField dateTimeField36 = delegatedDateTimeField35.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone38);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.LocalDate localDate42 = localDate39.withPeriodAdded(readablePeriod40, 0);
        int int43 = delegatedDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) localDate42);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.LocalDate localDate49 = localDate46.withPeriodAdded(readablePeriod47, 0);
        java.util.Locale locale51 = null;
        java.lang.String str52 = delegatedDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) localDate49, 31, locale51);
        org.joda.time.DateTime dateTime53 = localDate49.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate55 = localDate49.plusYears(35);
        org.joda.time.LocalDate localDate57 = localDate55.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone59);
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.LocalDate localDate63 = localDate60.withPeriodAdded(readablePeriod61, 0);
        org.joda.time.LocalDate.Property property64 = localDate63.dayOfYear();
        int int65 = localDate63.getDayOfWeek();
        boolean boolean66 = localDate55.isAfter((org.joda.time.ReadablePartial) localDate63);
        org.joda.time.LocalDate localDate68 = localDate63.withCenturyOfEra(57);
        org.joda.time.chrono.CopticChronology copticChronology69 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField70 = copticChronology69.dayOfMonth();
        boolean boolean72 = copticChronology69.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology74 = copticChronology69.withZone(dateTimeZone73);
        org.joda.time.DateTimeZone dateTimeZone76 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate77 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone76);
        org.joda.time.ReadablePeriod readablePeriod78 = null;
        org.joda.time.LocalDate localDate80 = localDate77.withPeriodAdded(readablePeriod78, 0);
        org.joda.time.DateTimeZone dateTimeZone81 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime82 = localDate80.toDateTimeAtCurrentTime(dateTimeZone81);
        int int83 = localDate80.getDayOfMonth();
        int[] intArray85 = copticChronology69.get((org.joda.time.ReadablePartial) localDate80, (long) '4');
        int int86 = delegatedDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDate68, intArray85);
        org.joda.time.LocalDate localDate87 = localDate11.withFields((org.joda.time.ReadablePartial) localDate68);
        org.joda.time.LocalDate localDate89 = localDate87.plusYears(7);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder90 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder92 = dateTimeZoneBuilder90.setStandardOffset(1);
        org.joda.time.DateTimeZone dateTimeZone95 = dateTimeZoneBuilder90.toDateTimeZone("dayOfMonth", false);
        org.joda.time.DateMidnight dateMidnight96 = localDate87.toDateMidnight(dateTimeZone95);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 59 + "'", int43 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31" + "'", str52.equals("31"));
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 3 + "'", int65 == 3);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertNotNull(copticChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertNotNull(chronology74);
        org.junit.Assert.assertNotNull(dateTimeZone76);
        org.junit.Assert.assertNotNull(localDate80);
        org.junit.Assert.assertNotNull(dateTimeZone81);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 31 + "'", int83 == 31);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 59 + "'", int86 == 59);
        org.junit.Assert.assertNotNull(localDate87);
        org.junit.Assert.assertNotNull(localDate89);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder92);
        org.junit.Assert.assertNotNull(dateTimeZone95);
        org.junit.Assert.assertNotNull(dateMidnight96);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder0.toDateTimeZone("dayOfMonth", false);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toStringList();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.Partial partial3 = partial0.without(dateTimeFieldType2);
        boolean boolean4 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) partial0);
        int[] intArray5 = partial0.getValues();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField8.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate15 = localDate12.withPeriodAdded(readablePeriod13, 0);
        int int16 = delegatedDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate.Property property17 = localDate15.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = localDate28.toDateTimeAtCurrentTime(dateTimeZone29);
        int int31 = localDate28.getDayOfMonth();
        org.joda.time.LocalDate.Property property32 = localDate28.dayOfMonth();
        int int33 = delegatedDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) localDate28);
        int int34 = delegatedDateTimeField22.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.secondOfMinute();
        org.joda.time.DurationField durationField37 = julianChronology35.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        org.joda.time.DateTimeField dateTimeField41 = delegatedDateTimeField40.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.LocalDate localDate47 = localDate44.withPeriodAdded(readablePeriod45, 0);
        int int48 = delegatedDateTimeField40.getMaximumValue((org.joda.time.ReadablePartial) localDate47);
        org.joda.time.LocalDate.Property property49 = localDate47.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property49.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField52 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField22, durationField37, dateTimeFieldType50, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField37);
        java.lang.String str54 = unsupportedDateTimeField53.getName();
        org.joda.time.DurationField durationField55 = unsupportedDateTimeField53.getLeapDurationField();
        int int58 = unsupportedDateTimeField53.getDifference((long) 2, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = unsupportedDateTimeField53.getType();
        try {
            org.joda.time.Partial.Property property60 = partial0.property(dateTimeFieldType59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(partial3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 31 + "'", int31 == 31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 59 + "'", int48 == 59);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "dayOfMonth" + "'", str54.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("13", "0", (-2), (int) (byte) 1);
        long long6 = fixedDateTimeZone4.previousTransition(432000003L);
        long long8 = fixedDateTimeZone4.previousTransition((long) 365);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 432000003L + "'", long6 == 432000003L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 365L + "'", long8 == 365L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        org.joda.time.DateTime dateTime20 = localDate16.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate22 = localDate16.plusYears(35);
        org.joda.time.LocalDate localDate24 = localDate16.minusWeeks(0);
        int int25 = localDate24.size();
        org.joda.time.LocalDate localDate27 = localDate24.withCenturyOfEra((int) (short) 0);
        try {
            org.joda.time.LocalDate localDate29 = localDate27.withYearOfEra((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(localDate27);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 7, (long) 58);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-51L) + "'", long2 == (-51L));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int3 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DurationField durationField4 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        int int6 = delegatedDateTimeField2.getMaximumShortTextLength(locale5);
        long long8 = delegatedDateTimeField2.roundCeiling(0L);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField10 = copticChronology9.halfdays();
        long long13 = durationField10.subtract((long) (short) -1, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, durationField10, dateTimeFieldType14);
        boolean boolean17 = delegatedDateTimeField15.isLeap((long) (-15));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43199999L + "'", long13 == 43199999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        long long21 = delegatedDateTimeField2.roundHalfCeiling(0L);
        long long24 = delegatedDateTimeField2.add((long) 50, (long) 100);
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField2.getAsShortText((long) 8, locale26);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100050L + "'", long24 == 100050L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.plusWeeks(51);
        org.joda.time.DateTime dateTime7 = dateTime1.withDurationAdded((long) (-2), 54);
        int int8 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime dateTime10 = dateTime7.withSecondOfMinute(0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(57);
        java.lang.Appendable appendable3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField6.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate13 = localDate10.withPeriodAdded(readablePeriod11, 0);
        int int14 = delegatedDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate20 = localDate17.withPeriodAdded(readablePeriod18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDate20, 31, locale22);
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate26 = localDate20.plusYears(35);
        org.joda.time.LocalDate localDate28 = localDate26.withWeekyear(0);
        try {
            dateTimeFormatter2.printTo(appendable3, (org.joda.time.ReadablePartial) localDate26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31" + "'", str23.equals("31"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(localDate28);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-10));
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        org.joda.time.DateTime.Property property11 = dateTime9.dayOfWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime10 = property7.withMinimumValue();
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((int) ' ');
        try {
            java.lang.String str14 = dateTime12.toString("1969-12-31T14:00:00.001-10:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("hi!", 14);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder2.toDateTimeZone("1969-12-31", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        int int4 = localDate2.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int9 = delegatedDateTimeField8.getMinimumValue();
        org.joda.time.DurationField durationField10 = delegatedDateTimeField8.getDurationField();
        int int11 = dateTime1.get((org.joda.time.DateTimeField) delegatedDateTimeField8);
        long long14 = delegatedDateTimeField8.add(5001L, (int) (short) 100);
        int int16 = delegatedDateTimeField8.getMaximumValue((long) 53);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField8.getDurationField();
        java.util.Locale locale18 = null;
        int int19 = delegatedDateTimeField8.getMaximumTextLength(locale18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology20);
        int int22 = dateTime21.getDayOfWeek();
        org.joda.time.DateTime dateTime24 = dateTime21.minusMonths(10);
        org.joda.time.LocalTime localTime25 = dateTime21.toLocalTime();
        int int26 = dateTime21.getSecondOfMinute();
        org.joda.time.DateTime.Property property27 = dateTime21.millisOfDay();
        org.joda.time.DateTime dateTime28 = property27.roundCeilingCopy();
        org.joda.time.DateTime dateTime29 = property27.withMinimumValue();
        org.joda.time.DateTime.Property property30 = dateTime29.year();
        org.joda.time.DateTime dateTime31 = property30.withMaximumValue();
        org.joda.time.DateTime dateTime32 = property30.roundHalfEvenCopy();
        java.util.Locale locale33 = null;
        java.lang.String str34 = property30.getAsText(locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property30.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType35);
        int int38 = zeroIsMaxDateTimeField36.getMinimumValue((long) 949);
        long long40 = zeroIsMaxDateTimeField36.remainder(0L);
        long long43 = zeroIsMaxDateTimeField36.getDifferenceAsLong(3540L, 1560639008479L);
        int int46 = zeroIsMaxDateTimeField36.getDifference(1L, (long) '#');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 51 + "'", int11 == 51);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 105001L + "'", long14 == 105001L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 51 + "'", int26 == 51);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1686" + "'", str34.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1560639004L) + "'", long43 == (-1560639004L));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, 35);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        java.lang.String str34 = dividedDateTimeField33.getName();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.LocalDate localDate40 = localDate37.withPeriodAdded(readablePeriod38, 0);
        org.joda.time.LocalDate.Property property41 = localDate40.dayOfYear();
        int int42 = localDate40.getDayOfWeek();
        java.util.Locale locale44 = null;
        java.lang.String str45 = dividedDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate40, 8, locale44);
        java.lang.String str46 = dividedDateTimeField33.getName();
        java.util.Locale locale47 = null;
        int int48 = dividedDateTimeField33.getMaximumShortTextLength(locale47);
        long long51 = dividedDateTimeField33.getDifferenceAsLong(0L, (-51L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "8" + "'", str45.equals("8"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "dayOfMonth" + "'", str46.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        java.lang.String str34 = dividedDateTimeField33.getName();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.LocalDate localDate40 = localDate37.withPeriodAdded(readablePeriod38, 0);
        org.joda.time.LocalDate.Property property41 = localDate40.dayOfYear();
        int int42 = localDate40.getDayOfWeek();
        java.util.Locale locale44 = null;
        java.lang.String str45 = dividedDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate40, 8, locale44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = dividedDateTimeField33.getAsText(13, locale47);
        long long50 = dividedDateTimeField33.roundHalfFloor(3540L);
        org.joda.time.DurationField durationField51 = dividedDateTimeField33.getDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "8" + "'", str45.equals("8"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13" + "'", str48.equals("13"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(durationField51);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology34.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        org.joda.time.DateTimeField dateTimeField37 = delegatedDateTimeField36.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.LocalDate localDate43 = localDate40.withPeriodAdded(readablePeriod41, 0);
        int int44 = delegatedDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.LocalDate localDate50 = localDate47.withPeriodAdded(readablePeriod48, 0);
        java.util.Locale locale52 = null;
        java.lang.String str53 = delegatedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate50, 31, locale52);
        org.joda.time.DateTime dateTime54 = localDate50.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate56 = localDate50.plusYears(35);
        org.joda.time.LocalDate localDate58 = localDate56.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone60);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.LocalDate localDate64 = localDate61.withPeriodAdded(readablePeriod62, 0);
        org.joda.time.LocalDate.Property property65 = localDate64.dayOfYear();
        int int66 = localDate64.getDayOfWeek();
        boolean boolean67 = localDate56.isAfter((org.joda.time.ReadablePartial) localDate64);
        int int68 = dividedDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField69 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33);
        long long72 = remainderDateTimeField69.set((long) (short) 0, (int) (short) 0);
        boolean boolean73 = remainderDateTimeField69.isLenient();
        int int75 = remainderDateTimeField69.getMaximumValue(0L);
        long long77 = remainderDateTimeField69.roundFloor(100050L);
        java.lang.String str79 = remainderDateTimeField69.getAsShortText(0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 59 + "'", int44 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31" + "'", str53.equals("31"));
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 3 + "'", int66 == 3);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 34 + "'", int75 == 34);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 100000L + "'", long77 == 100000L);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "0" + "'", str79.equals("0"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        java.lang.String str34 = dividedDateTimeField33.getName();
        long long37 = dividedDateTimeField33.addWrapField((long) (byte) 10, 35);
        long long39 = dividedDateTimeField33.remainder((long) (short) 100);
        org.joda.time.DurationField durationField40 = dividedDateTimeField33.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35010L + "'", long37 == 35010L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(durationField40);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("59");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"59\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        long long1 = dateTime0.getMillis();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-292268510L) + "'", long1 == (-292268510L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isLenient();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology5);
        int int7 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths(10);
        org.joda.time.LocalTime localTime10 = dateTime6.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        int int14 = delegatedDateTimeField13.getMinimumValue();
        org.joda.time.DurationField durationField15 = delegatedDateTimeField13.getDurationField();
        int int16 = dateTime6.get((org.joda.time.DateTimeField) delegatedDateTimeField13);
        long long19 = delegatedDateTimeField13.add(5001L, (int) (short) 100);
        int int21 = delegatedDateTimeField13.getMaximumValue((long) 53);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField13.getDurationField();
        java.util.Locale locale23 = null;
        int int24 = delegatedDateTimeField13.getMaximumTextLength(locale23);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology25);
        int int27 = dateTime26.getDayOfWeek();
        org.joda.time.DateTime dateTime29 = dateTime26.minusMonths(10);
        org.joda.time.LocalTime localTime30 = dateTime26.toLocalTime();
        int int31 = dateTime26.getSecondOfMinute();
        org.joda.time.DateTime.Property property32 = dateTime26.millisOfDay();
        org.joda.time.DateTime dateTime33 = property32.roundCeilingCopy();
        org.joda.time.DateTime dateTime34 = property32.withMinimumValue();
        org.joda.time.DateTime.Property property35 = dateTime34.year();
        org.joda.time.DateTime dateTime36 = property35.withMaximumValue();
        org.joda.time.DateTime dateTime37 = property35.roundHalfEvenCopy();
        java.util.Locale locale38 = null;
        java.lang.String str39 = property35.getAsText(locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property35.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField41 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology42);
        int int44 = copticChronology42.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField45 = copticChronology42.millisOfSecond();
        org.joda.time.DurationField durationField46 = copticChronology42.years();
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology47);
        int int49 = dateTime48.getDayOfWeek();
        org.joda.time.DateTime dateTime51 = dateTime48.minusMonths(10);
        org.joda.time.LocalTime localTime52 = dateTime48.toLocalTime();
        int int53 = dateTime48.getSecondOfMinute();
        org.joda.time.DateTime.Property property54 = dateTime48.millisOfDay();
        org.joda.time.DateTime dateTime55 = property54.roundCeilingCopy();
        org.joda.time.DateTime dateTime56 = property54.withMinimumValue();
        org.joda.time.DateTime.Property property57 = dateTime56.year();
        org.joda.time.DateTime.Property property58 = dateTime56.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology59 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology59);
        int int61 = dateTime60.getDayOfWeek();
        org.joda.time.DateTime dateTime63 = dateTime60.minusMonths(10);
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((java.lang.Object) dateTime60);
        org.joda.time.DateTime dateTime66 = dateTime64.plusSeconds(6);
        int int67 = dateTime64.getDayOfMonth();
        org.joda.time.DateTime.Property property68 = dateTime64.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property68.getFieldType();
        int int70 = dateTime56.get(dateTimeFieldType69);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField72 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField41, durationField46, dateTimeFieldType69, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType69, (int) (byte) 1, 1969, 0);
        boolean boolean78 = offsetDateTimeField76.isLeap((long) 35);
        int int80 = offsetDateTimeField76.getLeapAmount((long) 53);
        java.lang.String str81 = offsetDateTimeField76.getName();
        try {
            long long84 = offsetDateTimeField76.addWrapField((-950399993L), 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 51 + "'", int16 == 51);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 105001L + "'", long19 == 105001L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 51 + "'", int31 == 51);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1686" + "'", str39.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 7 + "'", int49 == 7);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 51 + "'", int53 == 51);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(copticChronology59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 7 + "'", int61 == 7);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 19 + "'", int67 == 19);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "hourOfDay" + "'", str81.equals("hourOfDay"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.LocalDate localDate12 = property11.roundFloorCopy();
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        long long16 = property11.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2L + "'", long16 == 2L);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        int int4 = dateTime2.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) ' ');
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        boolean boolean4 = dateTimeFormatter2.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readablePeriod3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTime((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes(35);
        int int12 = dateTime9.getWeekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfEvenCopy();
        boolean boolean8 = property6.isLeap();
        java.lang.String str9 = property6.getAsString();
        org.joda.time.LocalDate localDate10 = property6.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "365" + "'", str9.equals("365"));
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.millisOfSecond();
        org.joda.time.DurationField durationField4 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.minuteOfDay();
        org.joda.time.DurationField durationField6 = copticChronology0.hours();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.year();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.minutes();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekOfWeekyear();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology2);
        int int4 = dateTime3.getDayOfWeek();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(10);
        org.joda.time.LocalTime localTime7 = dateTime3.toLocalTime();
        int int8 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTime dateTime11 = property9.withMinimumValue();
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime14 = property12.roundHalfEvenCopy();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property12.getAsText(locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType17, 8, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendTimeZoneOffset("1969-12-31", false, 1736, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendMillisOfSecond(5);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap28 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendTimeZoneName(strMap28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 51 + "'", int8 == 51);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1686" + "'", str16.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(strMap28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-35), 30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int3 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DurationField durationField4 = delegatedDateTimeField2.getDurationField();
        java.lang.String str6 = delegatedDateTimeField2.getAsText((long) 54);
        int int8 = delegatedDateTimeField2.getMaximumValue((long) 35);
        org.joda.time.Partial partial9 = new org.joda.time.Partial();
        java.lang.String str10 = partial9.toStringList();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.Partial partial12 = partial9.without(dateTimeFieldType11);
        java.lang.String str13 = partial9.toStringList();
        int int14 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) partial9);
        java.lang.String str15 = delegatedDateTimeField2.getName();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[]" + "'", str10.equals("[]"));
        org.junit.Assert.assertNotNull(partial12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[]" + "'", str13.equals("[]"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "secondOfMinute" + "'", str15.equals("secondOfMinute"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfHour(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) ' ', 38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfDay(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime10 = property7.withMinimumValue();
        org.joda.time.DateTime dateTime11 = property7.withMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate16, 31, locale18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate();
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        int int24 = delegatedDateTimeField23.getMinimumValue();
        org.joda.time.DurationField durationField25 = delegatedDateTimeField23.getDurationField();
        java.util.Locale locale26 = null;
        int int27 = delegatedDateTimeField23.getMaximumShortTextLength(locale26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str35 = fixedDateTimeZone33.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone36 = fixedDateTimeZone33.toTimeZone();
        java.lang.String str38 = fixedDateTimeZone33.getName(100L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(10L, (org.joda.time.Chronology) buddhistChronology39);
        java.util.Locale locale42 = null;
        java.lang.String str43 = delegatedDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) localDate40, (int) 'a', locale42);
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = julianChronology44.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45);
        org.joda.time.DateTimeField dateTimeField47 = delegatedDateTimeField46.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone49);
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.LocalDate localDate53 = localDate50.withPeriodAdded(readablePeriod51, 0);
        int int54 = delegatedDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) localDate53);
        org.joda.time.LocalDate.Property property55 = localDate53.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property55.getFieldType();
        boolean boolean57 = localDate40.isSupported(dateTimeFieldType56);
        int int58 = localDate20.indexOf(dateTimeFieldType56);
        try {
            org.joda.time.LocalDate localDate60 = localDate16.withField(dateTimeFieldType56, 50);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 50 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31" + "'", str19.equals("31"));
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.035" + "'", str35.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+00:00:00.035" + "'", str38.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(buddhistChronology39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "97" + "'", str43.equals("97"));
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 59 + "'", int54 == 59);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toStringList();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.Partial partial3 = partial0.without(dateTimeFieldType2);
        boolean boolean4 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) partial0);
        int[] intArray5 = partial0.getValues();
        int[] intArray6 = partial0.getValues();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(partial3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) 949, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.LocalDate localDate16 = localDate13.withPeriodAdded(readablePeriod14, 0);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = localDate16.toDateTimeAtCurrentTime(dateTimeZone17);
        int int19 = localDate16.getDayOfMonth();
        org.joda.time.LocalDate.Property property20 = localDate16.dayOfMonth();
        int int21 = delegatedDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDate16);
        int int22 = delegatedDateTimeField10.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology23.secondOfMinute();
        org.joda.time.DurationField durationField25 = julianChronology23.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology26.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        org.joda.time.DateTimeField dateTimeField29 = delegatedDateTimeField28.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone31);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate35 = localDate32.withPeriodAdded(readablePeriod33, 0);
        int int36 = delegatedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.LocalDate.Property property37 = localDate35.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField10, durationField25, dateTimeFieldType38, 35);
        boolean boolean41 = localDate6.isSupported(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 59 + "'", int36 == 59);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField6.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate13 = localDate10.withPeriodAdded(readablePeriod11, 0);
        int int14 = delegatedDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate20 = localDate17.withPeriodAdded(readablePeriod18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDate20, 31, locale22);
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay();
        int int25 = property3.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property26 = dateTime24.minuteOfDay();
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology27.weekyear();
        org.joda.time.DateTimeField dateTimeField30 = copticChronology27.monthOfYear();
        org.joda.time.DateTime dateTime31 = dateTime24.toDateTime((org.joda.time.Chronology) copticChronology27);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31" + "'", str23.equals("31"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField47.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = unsupportedDateTimeField47.getType();
        boolean boolean51 = unsupportedDateTimeField47.isLenient();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readablePeriod3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTime((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfHour();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtCurrentTime(dateTimeZone6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.LocalDate localDate10 = localDate5.withFieldAdded(durationFieldType8, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        java.lang.String str34 = dividedDateTimeField33.getName();
        long long37 = dividedDateTimeField33.addWrapField((long) (byte) 10, 35);
        java.lang.String str38 = dividedDateTimeField33.toString();
        int int39 = dividedDateTimeField33.getMaximumValue();
        java.lang.String str40 = dividedDateTimeField33.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35010L + "'", long37 == 35010L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str38.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str40.equals("DateTimeField[dayOfMonth]"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int3 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DurationField durationField4 = delegatedDateTimeField2.getDurationField();
        java.lang.String str6 = delegatedDateTimeField2.getAsText((long) 54);
        int int8 = delegatedDateTimeField2.getMinimumValue((long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 0);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = localDate14.toDateTimeAtCurrentTime(dateTimeZone15);
        int int17 = localDate14.getDayOfMonth();
        org.joda.time.LocalDate.Property property18 = localDate14.dayOfMonth();
        org.joda.time.LocalDate localDate19 = property18.roundCeilingCopy();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) localDate19, 59, locale21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        int int27 = delegatedDateTimeField26.getMinimumValue();
        org.joda.time.DurationField durationField28 = delegatedDateTimeField26.getDurationField();
        java.util.Locale locale29 = null;
        int int30 = delegatedDateTimeField26.getMaximumShortTextLength(locale29);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone36 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str38 = fixedDateTimeZone36.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone39 = fixedDateTimeZone36.toTimeZone();
        java.lang.String str41 = fixedDateTimeZone36.getName(100L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone36);
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(10L, (org.joda.time.Chronology) buddhistChronology42);
        java.util.Locale locale45 = null;
        java.lang.String str46 = delegatedDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localDate43, (int) 'a', locale45);
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = julianChronology47.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48);
        org.joda.time.DateTimeField dateTimeField50 = delegatedDateTimeField49.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate56 = localDate53.withPeriodAdded(readablePeriod54, 0);
        int int57 = delegatedDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) localDate56);
        org.joda.time.LocalDate.Property property58 = localDate56.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
        boolean boolean60 = localDate43.isSupported(dateTimeFieldType59);
        int int61 = localDate23.indexOf(dateTimeFieldType59);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType59);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong((long) 3306, (-24L));
        int int67 = zeroIsMaxDateTimeField62.getMinimumValue(0L);
        java.lang.String str69 = zeroIsMaxDateTimeField62.getAsShortText(0L);
        org.joda.time.chrono.JulianChronology julianChronology70 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField71 = julianChronology70.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField71);
        org.joda.time.DateTimeField dateTimeField73 = delegatedDateTimeField72.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate76 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone75);
        org.joda.time.ReadablePeriod readablePeriod77 = null;
        org.joda.time.LocalDate localDate79 = localDate76.withPeriodAdded(readablePeriod77, 0);
        int int80 = delegatedDateTimeField72.getMaximumValue((org.joda.time.ReadablePartial) localDate79);
        org.joda.time.DateTimeZone dateTimeZone82 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate83 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone82);
        org.joda.time.ReadablePeriod readablePeriod84 = null;
        org.joda.time.LocalDate localDate86 = localDate83.withPeriodAdded(readablePeriod84, 0);
        java.util.Locale locale88 = null;
        java.lang.String str89 = delegatedDateTimeField72.getAsShortText((org.joda.time.ReadablePartial) localDate86, 31, locale88);
        org.joda.time.DateTime dateTime90 = localDate86.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate92 = localDate86.plusYears(35);
        org.joda.time.LocalDate.Property property93 = localDate92.dayOfYear();
        org.joda.time.LocalDate localDate94 = property93.roundHalfCeilingCopy();
        int int95 = zeroIsMaxDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) localDate94);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+00:00:00.035" + "'", str38.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "+00:00:00.035" + "'", str41.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "97" + "'", str46.equals("97"));
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 59 + "'", int57 == 59);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3L + "'", long65 == 3L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "60" + "'", str69.equals("60"));
        org.junit.Assert.assertNotNull(julianChronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(dateTimeZone75);
        org.junit.Assert.assertNotNull(localDate79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 59 + "'", int80 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone82);
        org.junit.Assert.assertNotNull(localDate86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "31" + "'", str89.equals("31"));
        org.junit.Assert.assertNotNull(dateTime90);
        org.junit.Assert.assertNotNull(localDate92);
        org.junit.Assert.assertNotNull(property93);
        org.junit.Assert.assertNotNull(localDate94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isLenient();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology5);
        int int7 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths(10);
        org.joda.time.LocalTime localTime10 = dateTime6.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        int int14 = delegatedDateTimeField13.getMinimumValue();
        org.joda.time.DurationField durationField15 = delegatedDateTimeField13.getDurationField();
        int int16 = dateTime6.get((org.joda.time.DateTimeField) delegatedDateTimeField13);
        long long19 = delegatedDateTimeField13.add(5001L, (int) (short) 100);
        int int21 = delegatedDateTimeField13.getMaximumValue((long) 53);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField13.getDurationField();
        java.util.Locale locale23 = null;
        int int24 = delegatedDateTimeField13.getMaximumTextLength(locale23);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology25);
        int int27 = dateTime26.getDayOfWeek();
        org.joda.time.DateTime dateTime29 = dateTime26.minusMonths(10);
        org.joda.time.LocalTime localTime30 = dateTime26.toLocalTime();
        int int31 = dateTime26.getSecondOfMinute();
        org.joda.time.DateTime.Property property32 = dateTime26.millisOfDay();
        org.joda.time.DateTime dateTime33 = property32.roundCeilingCopy();
        org.joda.time.DateTime dateTime34 = property32.withMinimumValue();
        org.joda.time.DateTime.Property property35 = dateTime34.year();
        org.joda.time.DateTime dateTime36 = property35.withMaximumValue();
        org.joda.time.DateTime dateTime37 = property35.roundHalfEvenCopy();
        java.util.Locale locale38 = null;
        java.lang.String str39 = property35.getAsText(locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property35.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField41 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology42);
        int int44 = copticChronology42.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField45 = copticChronology42.millisOfSecond();
        org.joda.time.DurationField durationField46 = copticChronology42.years();
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology47);
        int int49 = dateTime48.getDayOfWeek();
        org.joda.time.DateTime dateTime51 = dateTime48.minusMonths(10);
        org.joda.time.LocalTime localTime52 = dateTime48.toLocalTime();
        int int53 = dateTime48.getSecondOfMinute();
        org.joda.time.DateTime.Property property54 = dateTime48.millisOfDay();
        org.joda.time.DateTime dateTime55 = property54.roundCeilingCopy();
        org.joda.time.DateTime dateTime56 = property54.withMinimumValue();
        org.joda.time.DateTime.Property property57 = dateTime56.year();
        org.joda.time.DateTime.Property property58 = dateTime56.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology59 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology59);
        int int61 = dateTime60.getDayOfWeek();
        org.joda.time.DateTime dateTime63 = dateTime60.minusMonths(10);
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((java.lang.Object) dateTime60);
        org.joda.time.DateTime dateTime66 = dateTime64.plusSeconds(6);
        int int67 = dateTime64.getDayOfMonth();
        org.joda.time.DateTime.Property property68 = dateTime64.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property68.getFieldType();
        int int70 = dateTime56.get(dateTimeFieldType69);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField72 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField41, durationField46, dateTimeFieldType69, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType69, (int) (byte) 1, 1969, 0);
        int int77 = offsetDateTimeField76.getOffset();
        int int79 = offsetDateTimeField76.get((long) 1736);
        java.util.Locale locale81 = null;
        java.lang.String str82 = offsetDateTimeField76.getAsText(40, locale81);
        long long84 = offsetDateTimeField76.roundHalfCeiling((long) 53);
        org.joda.time.DurationField durationField85 = offsetDateTimeField76.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 51 + "'", int16 == 51);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 105001L + "'", long19 == 105001L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 51 + "'", int31 == 51);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1686" + "'", str39.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 7 + "'", int49 == 7);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 51 + "'", int53 == 51);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(copticChronology59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 7 + "'", int61 == 7);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 19 + "'", int67 == 19);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "40" + "'", str82.equals("40"));
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
        org.junit.Assert.assertNull(durationField85);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.secondOfMinute();
        org.joda.time.DurationField durationField8 = julianChronology6.weekyears();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long15 = fixedDateTimeZone13.previousTransition(3540L);
        org.joda.time.Chronology chronology16 = julianChronology6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(4, 46213, 54, 0, 10, 0, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 46213 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3540L + "'", long15 == 3540L);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1686L, 55);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 92730L + "'", long2 == 92730L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtCurrentTime(dateTimeZone6);
        int int8 = dateTime7.getHourOfDay();
        int int9 = dateTime7.getDayOfWeek();
        org.joda.time.Instant instant10 = dateTime7.toInstant();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField6.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate13 = localDate10.withPeriodAdded(readablePeriod11, 0);
        int int14 = delegatedDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate20 = localDate17.withPeriodAdded(readablePeriod18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDate20, 31, locale22);
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay();
        int int25 = property3.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.Interval interval26 = property3.toInterval();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31" + "'", str23.equals("31"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(interval26);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int9 = delegatedDateTimeField8.getMinimumValue();
        org.joda.time.DurationField durationField10 = delegatedDateTimeField8.getDurationField();
        int int11 = dateTime1.get((org.joda.time.DateTimeField) delegatedDateTimeField8);
        long long14 = delegatedDateTimeField8.add(5001L, (int) (short) 100);
        int int16 = delegatedDateTimeField8.getMaximumValue((long) 53);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField8.getDurationField();
        java.util.Locale locale18 = null;
        int int19 = delegatedDateTimeField8.getMaximumTextLength(locale18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology20);
        int int22 = dateTime21.getDayOfWeek();
        org.joda.time.DateTime dateTime24 = dateTime21.minusMonths(10);
        org.joda.time.LocalTime localTime25 = dateTime21.toLocalTime();
        int int26 = dateTime21.getSecondOfMinute();
        org.joda.time.DateTime.Property property27 = dateTime21.millisOfDay();
        org.joda.time.DateTime dateTime28 = property27.roundCeilingCopy();
        org.joda.time.DateTime dateTime29 = property27.withMinimumValue();
        org.joda.time.DateTime.Property property30 = dateTime29.year();
        org.joda.time.DateTime dateTime31 = property30.withMaximumValue();
        org.joda.time.DateTime dateTime32 = property30.roundHalfEvenCopy();
        java.util.Locale locale33 = null;
        java.lang.String str34 = property30.getAsText(locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property30.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType35);
        long long38 = delegatedDateTimeField8.roundHalfEven((long) 2);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 51 + "'", int11 == 51);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 105001L + "'", long14 == 105001L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 51 + "'", int26 == 51);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1686" + "'", str34.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str7 = fixedDateTimeZone5.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone8 = fixedDateTimeZone5.toTimeZone();
        java.lang.String str10 = fixedDateTimeZone5.getName(100L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Chronology chronology12 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.035" + "'", str7.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.035" + "'", str10.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int3 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DurationField durationField4 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale5 = null;
        int int6 = delegatedDateTimeField2.getMaximumShortTextLength(locale5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str14 = fixedDateTimeZone12.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone15 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str17 = fixedDateTimeZone12.getName(100L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(10L, (org.joda.time.Chronology) buddhistChronology18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate19, (int) 'a', locale21);
        int int24 = delegatedDateTimeField2.getMinimumValue(3540L);
        org.joda.time.Partial partial25 = new org.joda.time.Partial();
        java.lang.String str27 = partial25.toString("[]");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.Partial partial29 = partial25.plus(readablePeriod28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial();
        java.lang.String str32 = partial30.toString("[]");
        java.util.Locale locale34 = null;
        java.lang.String str35 = partial30.toString("+00:00:00.035", locale34);
        java.lang.String str36 = partial30.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.Partial partial38 = partial30.without(dateTimeFieldType37);
        boolean boolean39 = partial29.isEqual((org.joda.time.ReadablePartial) partial38);
        org.joda.time.Partial partial41 = new org.joda.time.Partial();
        java.lang.String str42 = partial41.toStringList();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
        org.joda.time.Partial partial44 = partial41.without(dateTimeFieldType43);
        boolean boolean45 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) partial41);
        int[] intArray46 = partial41.getValues();
        try {
            int[] intArray48 = delegatedDateTimeField2.set((org.joda.time.ReadablePartial) partial29, 6, intArray46, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.035" + "'", str14.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.035" + "'", str17.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "97" + "'", str22.equals("97"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[]" + "'", str27.equals("[]"));
        org.junit.Assert.assertNotNull(partial29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "[]" + "'", str32.equals("[]"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.035" + "'", str35.equals("+00:00:00.035"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "[]" + "'", str36.equals("[]"));
        org.junit.Assert.assertNotNull(partial38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "[]" + "'", str42.equals("[]"));
        org.junit.Assert.assertNotNull(partial44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("hi!", 14);
        java.io.OutputStream outputStream7 = null;
        try {
            dateTimeZoneBuilder2.writeTo("58", outputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("57005228");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate8.withPeriodAdded(readablePeriod9, 0);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = localDate11.toDateTimeAtCurrentTime(dateTimeZone12);
        int int14 = localDate11.getDayOfMonth();
        org.joda.time.LocalDate.Property property15 = localDate11.dayOfMonth();
        int int16 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate11);
        int int17 = delegatedDateTimeField5.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.secondOfMinute();
        org.joda.time.DurationField durationField20 = julianChronology18.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        org.joda.time.DateTimeField dateTimeField24 = delegatedDateTimeField23.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.LocalDate localDate30 = localDate27.withPeriodAdded(readablePeriod28, 0);
        int int31 = delegatedDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.LocalDate.Property property32 = localDate30.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, durationField20, dateTimeFieldType33, 35);
        java.lang.String str36 = dividedDateTimeField35.getName();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone38);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.LocalDate localDate42 = localDate39.withPeriodAdded(readablePeriod40, 0);
        org.joda.time.LocalDate.Property property43 = localDate42.dayOfYear();
        int int44 = localDate42.getDayOfWeek();
        java.util.Locale locale46 = null;
        java.lang.String str47 = dividedDateTimeField35.getAsText((org.joda.time.ReadablePartial) localDate42, 8, locale46);
        java.util.Locale locale49 = null;
        java.lang.String str50 = dividedDateTimeField35.getAsText(13, locale49);
        java.util.Locale locale51 = null;
        int int52 = dividedDateTimeField35.getMaximumShortTextLength(locale51);
        long long55 = dividedDateTimeField35.getDifferenceAsLong((long) 2000, 1L);
        java.util.Locale locale56 = null;
        int int57 = dividedDateTimeField35.getMaximumTextLength(locale56);
        int int58 = dateTime1.get((org.joda.time.DateTimeField) dividedDateTimeField35);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 59 + "'", int31 == 59);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "dayOfMonth" + "'", str36.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 3 + "'", int44 == 3);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "8" + "'", str47.equals("8"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "13" + "'", str50.equals("13"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField2 = julianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField4 = julianChronology0.years();
        try {
            long long12 = julianChronology0.getDateTimeMillis(0, 0, 0, 59, 0, 13, 56);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 65L, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("hi!", 14);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("57008156", true);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder5.toDateTimeZone("13", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder5.setFixedSavings("DateTimeField[dayOfMonth]", 1736);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeZoneBuilder14.toDateTimeZone("dayOfMonth", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("57007393", (java.lang.Number) 1735, (java.lang.Number) 1735L, (java.lang.Number) 56);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 56 + "'", number7.equals(56));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekOfWeekyear();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField6.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate13 = localDate10.withPeriodAdded(readablePeriod11, 0);
        int int14 = delegatedDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate20 = localDate17.withPeriodAdded(readablePeriod18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDate20, 31, locale22);
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay();
        int int25 = property3.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology26.getZone();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.Chronology chronology29 = gJChronology26.withZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = dateTime24.withChronology((org.joda.time.Chronology) gJChronology26);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31" + "'", str23.equals("31"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime10 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour((int) ' ');
        org.joda.time.DateTime dateTime14 = dateTime10.plus((long) ' ');
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField16 = copticChronology15.halfdays();
        long long20 = copticChronology15.add((long) (byte) 1, (long) 50, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology15.getZone();
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime14.toMutableDateTime((org.joda.time.Chronology) copticChronology15);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 5001L + "'", long20 == 5001L);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, (-15));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1500) + "'", int2 == (-1500));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField6.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.LocalDate localDate13 = localDate10.withPeriodAdded(readablePeriod11, 0);
        int int14 = delegatedDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate20 = localDate17.withPeriodAdded(readablePeriod18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDate20, 31, locale22);
        org.joda.time.DateTime dateTime24 = localDate20.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate26 = localDate20.plusYears(35);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) localDate20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31" + "'", str23.equals("31"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDate26);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long6 = fixedDateTimeZone4.previousTransition(3540L);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = copticChronology7.getDateTimeMillis((long) 9, 4, 17, 2, 42);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3540L + "'", long6 == 3540L);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 15422007L + "'", long13 == 15422007L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[-10:00]" + "'", str1.equals("BuddhistChronology[-10:00]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        java.lang.String str34 = dividedDateTimeField33.getName();
        long long37 = dividedDateTimeField33.addWrapField((long) (byte) 10, 35);
        long long39 = dividedDateTimeField33.remainder((long) (short) 100);
        int int41 = dividedDateTimeField33.getMinimumValue(8L);
        int int43 = dividedDateTimeField33.get(0L);
        long long46 = dividedDateTimeField33.addWrapField(189302400040L, 1735);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35010L + "'", long37 == 35010L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 189302435040L + "'", long46 == 189302435040L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime10 = property7.roundHalfEvenCopy();
        int int11 = dateTime10.getWeekyear();
        int int12 = dateTime10.getMillisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((-10));
        org.joda.time.Chronology chronology16 = gJChronology13.withZone(dateTimeZone15);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology17);
        boolean boolean19 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1686 + "'", int11 == 1686);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 490 + "'", int12 == 490);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField47.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = unsupportedDateTimeField47.getType();
        java.util.Locale locale51 = null;
        try {
            int int52 = unsupportedDateTimeField47.getMaximumTextLength(locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology2);
        int int4 = dateTime3.getDayOfWeek();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(10);
        org.joda.time.LocalTime localTime7 = dateTime3.toLocalTime();
        int int8 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTime dateTime11 = property9.withMinimumValue();
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime14 = property12.roundHalfEvenCopy();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property12.getAsText(locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType17, 8, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendFractionOfHour((int) 'a', (-12));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 51 + "'", int8 == 51);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1686" + "'", str16.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYearOfEra(2000);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime3.toGregorianCalendar();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((java.lang.Object) dateTime3);
        org.joda.time.LocalDate localDate7 = localDate5.withWeekOfWeekyear(6);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int9 = delegatedDateTimeField8.getMinimumValue();
        org.joda.time.DurationField durationField10 = delegatedDateTimeField8.getDurationField();
        int int11 = dateTime1.get((org.joda.time.DateTimeField) delegatedDateTimeField8);
        long long14 = delegatedDateTimeField8.add(5001L, (int) (short) 100);
        int int16 = delegatedDateTimeField8.getMaximumValue((long) 53);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField8.getDurationField();
        java.util.Locale locale18 = null;
        int int19 = delegatedDateTimeField8.getMaximumTextLength(locale18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology20);
        int int22 = dateTime21.getDayOfWeek();
        org.joda.time.DateTime dateTime24 = dateTime21.minusMonths(10);
        org.joda.time.LocalTime localTime25 = dateTime21.toLocalTime();
        int int26 = dateTime21.getSecondOfMinute();
        org.joda.time.DateTime.Property property27 = dateTime21.millisOfDay();
        org.joda.time.DateTime dateTime28 = property27.roundCeilingCopy();
        org.joda.time.DateTime dateTime29 = property27.withMinimumValue();
        org.joda.time.DateTime.Property property30 = dateTime29.year();
        org.joda.time.DateTime dateTime31 = property30.withMaximumValue();
        org.joda.time.DateTime dateTime32 = property30.roundHalfEvenCopy();
        java.util.Locale locale33 = null;
        java.lang.String str34 = property30.getAsText(locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property30.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType35);
        org.joda.time.chrono.CopticChronology copticChronology37 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology37);
        int int39 = copticChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField40 = copticChronology37.millisOfSecond();
        org.joda.time.DurationField durationField41 = copticChronology37.years();
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology42);
        int int44 = dateTime43.getDayOfWeek();
        org.joda.time.DateTime dateTime46 = dateTime43.minusMonths(10);
        org.joda.time.LocalTime localTime47 = dateTime43.toLocalTime();
        int int48 = dateTime43.getSecondOfMinute();
        org.joda.time.DateTime.Property property49 = dateTime43.millisOfDay();
        org.joda.time.DateTime dateTime50 = property49.roundCeilingCopy();
        org.joda.time.DateTime dateTime51 = property49.withMinimumValue();
        org.joda.time.DateTime.Property property52 = dateTime51.year();
        org.joda.time.DateTime.Property property53 = dateTime51.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology54 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology54);
        int int56 = dateTime55.getDayOfWeek();
        org.joda.time.DateTime dateTime58 = dateTime55.minusMonths(10);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((java.lang.Object) dateTime55);
        org.joda.time.DateTime dateTime61 = dateTime59.plusSeconds(6);
        int int62 = dateTime59.getDayOfMonth();
        org.joda.time.DateTime.Property property63 = dateTime59.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField36, durationField41, dateTimeFieldType64, 52);
        long long69 = zeroIsMaxDateTimeField36.roundHalfCeiling(8002L);
        long long72 = zeroIsMaxDateTimeField36.addWrapField((long) (byte) 0, (-35));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 51 + "'", int11 == 51);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 105001L + "'", long14 == 105001L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 51 + "'", int26 == 51);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1686" + "'", str34.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(copticChronology37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 7 + "'", int44 == 7);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(localTime47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 51 + "'", int48 == 51);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(copticChronology54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 7 + "'", int56 == 7);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 19 + "'", int62 == 19);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 8000L + "'", long69 == 8000L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 25000L + "'", long72 == 25000L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTimeISO();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 1);
        org.joda.time.Instant instant4 = instant1.withDurationAdded((long) 56, 56);
        org.joda.time.Instant instant6 = instant4.withMillis((long) (short) 10);
        org.joda.time.Instant instant8 = instant6.minus(0L);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        java.lang.String str5 = buddhistChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.yearOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology3, dateTimeField7, (int) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField9, (int) '#');
        long long14 = skipDateTimeField11.set(0L, 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[-10:00]" + "'", str5.equals("BuddhistChronology[-10:00]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-79240032000000L) + "'", long14 == (-79240032000000L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        boolean boolean3 = copticChronology0.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate8.withPeriodAdded(readablePeriod9, 0);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = localDate11.toDateTimeAtCurrentTime(dateTimeZone12);
        int int14 = localDate11.getDayOfMonth();
        int[] intArray16 = copticChronology0.get((org.joda.time.ReadablePartial) localDate11, (long) '4');
        org.joda.time.DateTimeField dateTimeField17 = copticChronology0.dayOfWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 949, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        long long27 = fixedDateTimeZone23.convertLocalToUTC((long) 7, false);
        org.joda.time.Chronology chronology28 = copticChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-28L) + "'", long27 == (-28L));
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfEra(6);
        org.joda.time.Chronology chronology5 = localDate2.getChronology();
        int int6 = localDate2.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.clockhourOfHalfday();
        try {
            long long6 = copticChronology0.getDateTimeMillis((int) (short) 1, 53, (-10), 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        try {
            org.joda.time.LocalDate localDate5 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtCurrentTime(dateTimeZone6);
        int int8 = localDate5.getDayOfMonth();
        org.joda.time.LocalDate.Property property9 = localDate5.dayOfMonth();
        org.joda.time.LocalDate localDate11 = property9.addToCopy(4);
        org.joda.time.LocalDate localDate12 = property9.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology34.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        org.joda.time.DateTimeField dateTimeField37 = delegatedDateTimeField36.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.LocalDate localDate43 = localDate40.withPeriodAdded(readablePeriod41, 0);
        int int44 = delegatedDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.LocalDate localDate50 = localDate47.withPeriodAdded(readablePeriod48, 0);
        java.util.Locale locale52 = null;
        java.lang.String str53 = delegatedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate50, 31, locale52);
        org.joda.time.DateTime dateTime54 = localDate50.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate56 = localDate50.plusYears(35);
        org.joda.time.LocalDate localDate58 = localDate56.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone60);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.LocalDate localDate64 = localDate61.withPeriodAdded(readablePeriod62, 0);
        org.joda.time.LocalDate.Property property65 = localDate64.dayOfYear();
        int int66 = localDate64.getDayOfWeek();
        boolean boolean67 = localDate56.isAfter((org.joda.time.ReadablePartial) localDate64);
        int int68 = dividedDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField69 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33);
        long long72 = remainderDateTimeField69.set((long) (short) 0, (int) (short) 0);
        boolean boolean73 = remainderDateTimeField69.isLenient();
        int int75 = remainderDateTimeField69.getMaximumValue(0L);
        int int78 = remainderDateTimeField69.getDifference((long) (short) 0, (long) 490);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 59 + "'", int44 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31" + "'", str53.equals("31"));
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 3 + "'", int66 == 3);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 34 + "'", int75 == 34);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int3 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DurationField durationField4 = delegatedDateTimeField2.getDurationField();
        java.lang.String str6 = delegatedDateTimeField2.getAsText((long) 54);
        int int8 = delegatedDateTimeField2.getMinimumValue((long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 0);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = localDate14.toDateTimeAtCurrentTime(dateTimeZone15);
        int int17 = localDate14.getDayOfMonth();
        org.joda.time.LocalDate.Property property18 = localDate14.dayOfMonth();
        org.joda.time.LocalDate localDate19 = property18.roundCeilingCopy();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) localDate19, 59, locale21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        int int27 = delegatedDateTimeField26.getMinimumValue();
        org.joda.time.DurationField durationField28 = delegatedDateTimeField26.getDurationField();
        java.util.Locale locale29 = null;
        int int30 = delegatedDateTimeField26.getMaximumShortTextLength(locale29);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone36 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str38 = fixedDateTimeZone36.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone39 = fixedDateTimeZone36.toTimeZone();
        java.lang.String str41 = fixedDateTimeZone36.getName(100L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone36);
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(10L, (org.joda.time.Chronology) buddhistChronology42);
        java.util.Locale locale45 = null;
        java.lang.String str46 = delegatedDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localDate43, (int) 'a', locale45);
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = julianChronology47.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48);
        org.joda.time.DateTimeField dateTimeField50 = delegatedDateTimeField49.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate56 = localDate53.withPeriodAdded(readablePeriod54, 0);
        int int57 = delegatedDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) localDate56);
        org.joda.time.LocalDate.Property property58 = localDate56.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
        boolean boolean60 = localDate43.isSupported(dateTimeFieldType59);
        int int61 = localDate23.indexOf(dateTimeFieldType59);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType59);
        int int65 = zeroIsMaxDateTimeField62.getDifference((long) 2000, 1560639012400L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+00:00:00.035" + "'", str38.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "+00:00:00.035" + "'", str41.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "97" + "'", str46.equals("97"));
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 59 + "'", int57 == 59);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1560639010) + "'", int65 == (-1560639010));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder0.toDateTimeZone("dayOfMonth", false);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now(dateTimeZone5);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 30");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.LocalDate.Property property6 = localDate5.dayOfYear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate9 = localDate7.plusYears(1736);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.DateTime dateTime11 = property10.withMaximumValue();
        org.joda.time.DateTime dateTime12 = property10.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime13 = property10.roundFloorCopy();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        java.lang.String str34 = dividedDateTimeField33.getName();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.LocalDate localDate40 = localDate37.withPeriodAdded(readablePeriod38, 0);
        org.joda.time.LocalDate.Property property41 = localDate40.dayOfYear();
        int int42 = localDate40.getDayOfWeek();
        java.util.Locale locale44 = null;
        java.lang.String str45 = dividedDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate40, 8, locale44);
        java.lang.String str46 = dividedDateTimeField33.getName();
        int int49 = dividedDateTimeField33.getDifference(5001L, (-28L));
        try {
            long long52 = dividedDateTimeField33.set((-3L), (-15));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -15 for dayOfMonth must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "8" + "'", str45.equals("8"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "dayOfMonth" + "'", str46.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField47.getLeapDurationField();
        int int52 = unsupportedDateTimeField47.getDifference((long) 2, 0L);
        java.util.Locale locale55 = null;
        try {
            long long56 = unsupportedDateTimeField47.set(65L, "0", locale55);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate5 = localDate2.withPeriodAdded(readablePeriod3, 0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = localDate5.toDateTimeAtCurrentTime(dateTimeZone6);
        int int8 = localDate5.getDayOfMonth();
        org.joda.time.LocalDate.Property property9 = localDate5.dayOfMonth();
        org.joda.time.LocalDate localDate10 = property9.roundFloorCopy();
        org.joda.time.LocalDate localDate11 = property9.withMinimumValue();
        java.util.Locale locale13 = null;
        try {
            org.joda.time.LocalDate localDate14 = property9.setCopy("1735-10-08T15:49:49.485-07:00", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1735-10-08T15:49:49.485-07:00\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(100);
        boolean boolean13 = dateTime11.isEqual(0L);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.dayOfMonth();
        boolean boolean17 = copticChronology14.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology19 = copticChronology14.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime11.withZone(dateTimeZone18);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long27 = fixedDateTimeZone25.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTime dateTime29 = dateTime20.toDateTime((org.joda.time.Chronology) iSOChronology28);
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology30);
        int int32 = dateTime31.getDayOfWeek();
        org.joda.time.DateTime dateTime34 = dateTime31.minusMonths(10);
        org.joda.time.LocalTime localTime35 = dateTime31.toLocalTime();
        int int36 = dateTime31.getSecondOfMinute();
        org.joda.time.DateTime.Property property37 = dateTime31.millisOfDay();
        org.joda.time.DateTime dateTime38 = property37.roundCeilingCopy();
        org.joda.time.DateTime dateTime39 = property37.withMinimumValue();
        org.joda.time.DateTime.Property property40 = dateTime39.year();
        org.joda.time.DateTime.Property property41 = dateTime39.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology42);
        int int44 = dateTime43.getDayOfWeek();
        org.joda.time.DateTime dateTime46 = dateTime43.minusMonths(10);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((java.lang.Object) dateTime43);
        org.joda.time.DateTime dateTime49 = dateTime47.plusSeconds(6);
        int int50 = dateTime47.getDayOfMonth();
        org.joda.time.DateTime.Property property51 = dateTime47.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
        int int53 = dateTime39.get(dateTimeFieldType52);
        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 34, "31");
        int int57 = dateTime29.get(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3540L + "'", long27 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 7 + "'", int32 == 7);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 51 + "'", int36 == 51);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 7 + "'", int44 == 7);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 19 + "'", int50 == 19);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 11 + "'", int57 == 11);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        java.lang.String str34 = dividedDateTimeField33.getName();
        long long37 = dividedDateTimeField33.addWrapField((long) (byte) 10, 35);
        long long39 = dividedDateTimeField33.remainder((long) (short) 100);
        int int41 = dividedDateTimeField33.getMinimumValue(8L);
        int int43 = dividedDateTimeField33.get(0L);
        org.joda.time.Partial partial44 = new org.joda.time.Partial();
        java.lang.String str45 = partial44.toStringList();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        org.joda.time.Partial partial47 = partial44.without(dateTimeFieldType46);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
        org.joda.time.Partial partial49 = partial47.without(dateTimeFieldType48);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate56 = localDate53.withPeriodAdded(readablePeriod54, 0);
        org.joda.time.LocalDate.Property property57 = localDate56.dayOfYear();
        org.joda.time.LocalDate localDate58 = property57.roundHalfEvenCopy();
        org.joda.time.DurationFieldType durationFieldType59 = null;
        boolean boolean60 = localDate58.isSupported(durationFieldType59);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray61 = localDate58.getFieldTypes();
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = copticChronology62.dayOfMonth();
        boolean boolean65 = copticChronology62.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology67 = copticChronology62.withZone(dateTimeZone66);
        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate70 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone69);
        org.joda.time.ReadablePeriod readablePeriod71 = null;
        org.joda.time.LocalDate localDate73 = localDate70.withPeriodAdded(readablePeriod71, 0);
        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime75 = localDate73.toDateTimeAtCurrentTime(dateTimeZone74);
        int int76 = localDate73.getDayOfMonth();
        int[] intArray78 = copticChronology62.get((org.joda.time.ReadablePartial) localDate73, (long) '4');
        org.joda.time.Partial partial79 = new org.joda.time.Partial(dateTimeFieldTypeArray61, intArray78);
        java.util.Locale locale81 = null;
        try {
            int[] intArray82 = dividedDateTimeField33.set((org.joda.time.ReadablePartial) partial49, (int) (short) -1, intArray78, "56992242", locale81);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 56992242 for dayOfMonth must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35010L + "'", long37 == 35010L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "[]" + "'", str45.equals("[]"));
        org.junit.Assert.assertNotNull(partial47);
        org.junit.Assert.assertNotNull(partial49);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray61);
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(chronology67);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 31 + "'", int76 == 31);
        org.junit.Assert.assertNotNull(intArray78);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        java.lang.String str5 = buddhistChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.yearOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology3, dateTimeField7, (int) (short) -1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField9, (int) '#');
        int int12 = skipUndoDateTimeField9.getMinimumValue();
        org.joda.time.DurationField durationField13 = skipUndoDateTimeField9.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField14 = skipUndoDateTimeField9.getWrappedField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[-10:00]" + "'", str5.equals("BuddhistChronology[-10:00]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292268510) + "'", int12 == (-292268510));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((int) (byte) 10, 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendDayOfYear((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(100);
        boolean boolean13 = dateTime11.isEqual(0L);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.dayOfMonth();
        boolean boolean17 = copticChronology14.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology19 = copticChronology14.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime11.withZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = dateTime11.getZone();
        org.joda.time.DateTime.Property property22 = dateTime11.yearOfEra();
        try {
            org.joda.time.DateTime dateTime24 = property22.setCopy("JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[UTC]\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYearOfEra(6);
        org.joda.time.LocalDate localDate6 = localDate2.plusDays((int) (byte) 10);
        boolean boolean8 = localDate2.equals((java.lang.Object) 432000000L);
        int int9 = localDate2.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        long long6 = fixedDateTimeZone4.previousTransition(3540L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str14 = fixedDateTimeZone12.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone15 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str17 = fixedDateTimeZone12.getName(100L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.Chronology chronology19 = iSOChronology7.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone20 = iSOChronology7.getZone();
        org.joda.time.DurationField durationField21 = iSOChronology7.halfdays();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3540L + "'", long6 == 3540L);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.035" + "'", str14.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.035" + "'", str17.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (short) 0, (java.lang.Number) 10.0f, (java.lang.Number) 100);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        boolean boolean49 = unsupportedDateTimeField47.isSupported();
        try {
            int int50 = unsupportedDateTimeField47.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.LocalDate.Property property12 = localDate9.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        boolean boolean4 = delegatedDateTimeField3.isLenient();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology5);
        int int7 = dateTime6.getDayOfWeek();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths(10);
        org.joda.time.LocalTime localTime10 = dateTime6.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        int int14 = delegatedDateTimeField13.getMinimumValue();
        org.joda.time.DurationField durationField15 = delegatedDateTimeField13.getDurationField();
        int int16 = dateTime6.get((org.joda.time.DateTimeField) delegatedDateTimeField13);
        long long19 = delegatedDateTimeField13.add(5001L, (int) (short) 100);
        int int21 = delegatedDateTimeField13.getMaximumValue((long) 53);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField13.getDurationField();
        java.util.Locale locale23 = null;
        int int24 = delegatedDateTimeField13.getMaximumTextLength(locale23);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology25);
        int int27 = dateTime26.getDayOfWeek();
        org.joda.time.DateTime dateTime29 = dateTime26.minusMonths(10);
        org.joda.time.LocalTime localTime30 = dateTime26.toLocalTime();
        int int31 = dateTime26.getSecondOfMinute();
        org.joda.time.DateTime.Property property32 = dateTime26.millisOfDay();
        org.joda.time.DateTime dateTime33 = property32.roundCeilingCopy();
        org.joda.time.DateTime dateTime34 = property32.withMinimumValue();
        org.joda.time.DateTime.Property property35 = dateTime34.year();
        org.joda.time.DateTime dateTime36 = property35.withMaximumValue();
        org.joda.time.DateTime dateTime37 = property35.roundHalfEvenCopy();
        java.util.Locale locale38 = null;
        java.lang.String str39 = property35.getAsText(locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property35.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField41 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology42);
        int int44 = copticChronology42.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField45 = copticChronology42.millisOfSecond();
        org.joda.time.DurationField durationField46 = copticChronology42.years();
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology47);
        int int49 = dateTime48.getDayOfWeek();
        org.joda.time.DateTime dateTime51 = dateTime48.minusMonths(10);
        org.joda.time.LocalTime localTime52 = dateTime48.toLocalTime();
        int int53 = dateTime48.getSecondOfMinute();
        org.joda.time.DateTime.Property property54 = dateTime48.millisOfDay();
        org.joda.time.DateTime dateTime55 = property54.roundCeilingCopy();
        org.joda.time.DateTime dateTime56 = property54.withMinimumValue();
        org.joda.time.DateTime.Property property57 = dateTime56.year();
        org.joda.time.DateTime.Property property58 = dateTime56.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology59 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology59);
        int int61 = dateTime60.getDayOfWeek();
        org.joda.time.DateTime dateTime63 = dateTime60.minusMonths(10);
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((java.lang.Object) dateTime60);
        org.joda.time.DateTime dateTime66 = dateTime64.plusSeconds(6);
        int int67 = dateTime64.getDayOfMonth();
        org.joda.time.DateTime.Property property68 = dateTime64.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property68.getFieldType();
        int int70 = dateTime56.get(dateTimeFieldType69);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField72 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField41, durationField46, dateTimeFieldType69, 52);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, dateTimeFieldType69, (int) (byte) 1, 1969, 0);
        int int77 = offsetDateTimeField76.getOffset();
        int int78 = offsetDateTimeField76.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 51 + "'", int16 == 51);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 105001L + "'", long19 == 105001L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 51 + "'", int31 == 51);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1686" + "'", str39.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 7 + "'", int49 == 7);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(localTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 51 + "'", int53 == 51);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(copticChronology59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 7 + "'", int61 == 7);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 19 + "'", int67 == 19);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1969 + "'", int78 == 1969);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField12.getType();
        org.joda.time.DateTime.Property property14 = dateTime8.property(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (byte) 100);
        boolean boolean5 = dateTime1.isEqual((long) (-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        java.lang.String str7 = buddhistChronology6.toString();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology6.clockhourOfDay();
        org.joda.time.DateTime dateTime10 = dateTime1.toDateTime((org.joda.time.Chronology) buddhistChronology6);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[-10:00]" + "'", str7.equals("BuddhistChronology[-10:00]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        java.lang.String str34 = dividedDateTimeField33.getName();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.LocalDate localDate40 = localDate37.withPeriodAdded(readablePeriod38, 0);
        org.joda.time.LocalDate.Property property41 = localDate40.dayOfYear();
        int int42 = localDate40.getDayOfWeek();
        java.util.Locale locale44 = null;
        java.lang.String str45 = dividedDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate40, 8, locale44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = dividedDateTimeField33.getAsText(13, locale47);
        java.util.Locale locale49 = null;
        int int50 = dividedDateTimeField33.getMaximumShortTextLength(locale49);
        long long53 = dividedDateTimeField33.getDifferenceAsLong(5001L, (long) (-35));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "8" + "'", str45.equals("8"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13" + "'", str48.equals("13"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int9 = delegatedDateTimeField8.getMinimumValue();
        org.joda.time.DurationField durationField10 = delegatedDateTimeField8.getDurationField();
        int int11 = dateTime1.get((org.joda.time.DateTimeField) delegatedDateTimeField8);
        long long14 = delegatedDateTimeField8.add(5001L, (int) (short) 100);
        int int16 = delegatedDateTimeField8.getMaximumValue((long) 53);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField8.getDurationField();
        java.util.Locale locale18 = null;
        int int19 = delegatedDateTimeField8.getMaximumTextLength(locale18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology20);
        int int22 = dateTime21.getDayOfWeek();
        org.joda.time.DateTime dateTime24 = dateTime21.minusMonths(10);
        org.joda.time.LocalTime localTime25 = dateTime21.toLocalTime();
        int int26 = dateTime21.getSecondOfMinute();
        org.joda.time.DateTime.Property property27 = dateTime21.millisOfDay();
        org.joda.time.DateTime dateTime28 = property27.roundCeilingCopy();
        org.joda.time.DateTime dateTime29 = property27.withMinimumValue();
        org.joda.time.DateTime.Property property30 = dateTime29.year();
        org.joda.time.DateTime dateTime31 = property30.withMaximumValue();
        org.joda.time.DateTime dateTime32 = property30.roundHalfEvenCopy();
        java.util.Locale locale33 = null;
        java.lang.String str34 = property30.getAsText(locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property30.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType35);
        int int38 = zeroIsMaxDateTimeField36.getMinimumValue((long) 949);
        long long40 = zeroIsMaxDateTimeField36.remainder(0L);
        long long43 = zeroIsMaxDateTimeField36.getDifferenceAsLong(3540L, 1560639008479L);
        long long46 = zeroIsMaxDateTimeField36.getDifferenceAsLong((long) 2000, (long) '4');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 51 + "'", int11 == 51);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 105001L + "'", long14 == 105001L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 51 + "'", int26 == 51);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1686" + "'", str34.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1560639004L) + "'", long43 == (-1560639004L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1L + "'", long46 == 1L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfHour(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = localDate9.toDateTimeAtCurrentTime(dateTimeZone10);
        int int12 = localDate9.getDayOfMonth();
        org.joda.time.LocalDate.Property property13 = localDate9.dayOfMonth();
        int int14 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
        int int15 = delegatedDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField18 = julianChronology16.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField21.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.LocalDate localDate28 = localDate25.withPeriodAdded(readablePeriod26, 0);
        int int29 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.LocalDate.Property property30 = localDate28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, durationField18, dateTimeFieldType31, 35);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology34.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        org.joda.time.DateTimeField dateTimeField37 = delegatedDateTimeField36.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.LocalDate localDate43 = localDate40.withPeriodAdded(readablePeriod41, 0);
        int int44 = delegatedDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.LocalDate localDate50 = localDate47.withPeriodAdded(readablePeriod48, 0);
        java.util.Locale locale52 = null;
        java.lang.String str53 = delegatedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate50, 31, locale52);
        org.joda.time.DateTime dateTime54 = localDate50.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate56 = localDate50.plusYears(35);
        org.joda.time.LocalDate localDate58 = localDate56.withWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone60);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.LocalDate localDate64 = localDate61.withPeriodAdded(readablePeriod62, 0);
        org.joda.time.LocalDate.Property property65 = localDate64.dayOfYear();
        int int66 = localDate64.getDayOfWeek();
        boolean boolean67 = localDate56.isAfter((org.joda.time.ReadablePartial) localDate64);
        int int68 = dividedDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate64);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField69 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33);
        long long72 = remainderDateTimeField69.set((long) (short) 0, (int) (short) 0);
        boolean boolean73 = remainderDateTimeField69.isLenient();
        org.joda.time.DurationField durationField74 = remainderDateTimeField69.getDurationField();
        long long76 = remainderDateTimeField69.roundHalfEven((-950400000L));
        java.util.Locale locale77 = null;
        int int78 = remainderDateTimeField69.getMaximumShortTextLength(locale77);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 59 + "'", int29 == 59);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 59 + "'", int44 == 59);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31" + "'", str53.equals("31"));
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 3 + "'", int66 == 3);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(durationField74);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-950400000L) + "'", long76 == (-950400000L));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        int int1 = partial0.size();
        org.joda.time.Chronology chronology2 = partial0.getChronology();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.Partial partial4 = partial0.minus(readablePeriod3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Partial partial6 = partial0.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(partial6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(6);
        int int8 = dateTime5.getDayOfMonth();
        org.joda.time.Chronology chronology9 = dateTime5.getChronology();
        org.joda.time.DateTime dateTime11 = dateTime5.plusMonths((int) (short) 100);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, 35);
        org.joda.time.DateTime dateTime10 = dateTime5.plusDays(86399);
        boolean boolean12 = dateTime10.isEqual(0L);
        org.joda.time.DateTime dateTime14 = dateTime10.withMinuteOfHour(19);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology2);
        int int4 = dateTime3.getDayOfWeek();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMonths(10);
        org.joda.time.LocalTime localTime7 = dateTime3.toLocalTime();
        int int8 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTime dateTime11 = property9.withMinimumValue();
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime14 = property12.roundHalfEvenCopy();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property12.getAsText(locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType17, 8, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendTimeZoneOffset("1969-12-31", false, 1736, 1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendMillisOfSecond(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMonthOfYear(53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 51 + "'", int8 == 51);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1686" + "'", str16.equals("1686"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int3 = delegatedDateTimeField2.getMinimumValue();
        org.joda.time.DurationField durationField4 = delegatedDateTimeField2.getDurationField();
        java.lang.String str6 = delegatedDateTimeField2.getAsText((long) 54);
        int int8 = delegatedDateTimeField2.getMinimumValue((long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 0);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = localDate14.toDateTimeAtCurrentTime(dateTimeZone15);
        int int17 = localDate14.getDayOfMonth();
        org.joda.time.LocalDate.Property property18 = localDate14.dayOfMonth();
        org.joda.time.LocalDate localDate19 = property18.roundCeilingCopy();
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) localDate19, 59, locale21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        int int27 = delegatedDateTimeField26.getMinimumValue();
        org.joda.time.DurationField durationField28 = delegatedDateTimeField26.getDurationField();
        java.util.Locale locale29 = null;
        int int30 = delegatedDateTimeField26.getMaximumShortTextLength(locale29);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone36 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", (int) '#', (int) (byte) 1);
        java.lang.String str38 = fixedDateTimeZone36.getShortName((long) (byte) 100);
        java.util.TimeZone timeZone39 = fixedDateTimeZone36.toTimeZone();
        java.lang.String str41 = fixedDateTimeZone36.getName(100L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone36);
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(10L, (org.joda.time.Chronology) buddhistChronology42);
        java.util.Locale locale45 = null;
        java.lang.String str46 = delegatedDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localDate43, (int) 'a', locale45);
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = julianChronology47.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48);
        org.joda.time.DateTimeField dateTimeField50 = delegatedDateTimeField49.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.LocalDate localDate56 = localDate53.withPeriodAdded(readablePeriod54, 0);
        int int57 = delegatedDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) localDate56);
        org.joda.time.LocalDate.Property property58 = localDate56.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
        boolean boolean60 = localDate43.isSupported(dateTimeFieldType59);
        int int61 = localDate23.indexOf(dateTimeFieldType59);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType59);
        long long65 = zeroIsMaxDateTimeField62.getDifferenceAsLong((long) 3306, (-24L));
        int int67 = zeroIsMaxDateTimeField62.getMinimumValue(0L);
        java.util.Locale locale68 = null;
        int int69 = zeroIsMaxDateTimeField62.getMaximumTextLength(locale68);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "59" + "'", str22.equals("59"));
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+00:00:00.035" + "'", str38.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "+00:00:00.035" + "'", str41.equals("+00:00:00.035"));
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "97" + "'", str46.equals("97"));
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 59 + "'", int57 == 59);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3L + "'", long65 == 3L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2 + "'", int69 == 2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        boolean boolean49 = unsupportedDateTimeField47.isSupported();
        java.util.Locale locale51 = null;
        try {
            java.lang.String str52 = unsupportedDateTimeField47.getAsText((-1), locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendOptional(dateTimeParser5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology11);
        int int13 = dateTime12.getDayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime12.minusMonths(10);
        org.joda.time.LocalTime localTime16 = dateTime12.toLocalTime();
        int int17 = dateTime12.getSecondOfMinute();
        org.joda.time.DateTime.Property property18 = dateTime12.millisOfDay();
        org.joda.time.DateTime dateTime20 = property18.addToCopy(0);
        org.joda.time.DateTime dateTime21 = property18.roundHalfEvenCopy();
        int int22 = dateTime21.getWeekyear();
        long long23 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        long long24 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
        java.lang.String str26 = buddhistChronology25.toString();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology25.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology25.clockhourOfDay();
        org.joda.time.DateTime dateTime29 = dateTime21.withChronology((org.joda.time.Chronology) buddhistChronology25);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 51 + "'", int17 == 51);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1686 + "'", int22 == 1686);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-292268510L) + "'", long23 == (-292268510L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "BuddhistChronology[-10:00]" + "'", str26.equals("BuddhistChronology[-10:00]"));
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        org.joda.time.LocalTime localTime5 = dateTime1.toLocalTime();
        int int6 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime.Property property7 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology12);
        int int14 = dateTime13.getDayOfWeek();
        org.joda.time.DateTime dateTime16 = dateTime13.minusMonths(10);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) dateTime13);
        org.joda.time.DateTime dateTime19 = dateTime17.plusSeconds(6);
        int int20 = dateTime17.getDayOfMonth();
        org.joda.time.DateTime.Property property21 = dateTime17.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        int int23 = dateTime9.get(dateTimeFieldType22);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 34, "31");
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = julianChronology27.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField28);
        long long32 = unsupportedDateTimeField29.getDifferenceAsLong(8000L, (long) (byte) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 51 + "'", int6 == 51);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeField dateTimeField3 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate6.withPeriodAdded(readablePeriod7, 0);
        int int10 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.LocalDate.Property property11 = localDate9.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.LocalDate localDate22 = localDate19.withPeriodAdded(readablePeriod20, 0);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = localDate22.toDateTimeAtCurrentTime(dateTimeZone23);
        int int25 = localDate22.getDayOfMonth();
        org.joda.time.LocalDate.Property property26 = localDate22.dayOfMonth();
        int int27 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
        int int28 = delegatedDateTimeField16.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.secondOfMinute();
        org.joda.time.DurationField durationField31 = julianChronology29.weekyears();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.secondOfMinute();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        org.joda.time.DateTimeField dateTimeField35 = delegatedDateTimeField34.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (byte) 100, dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.LocalDate localDate41 = localDate38.withPeriodAdded(readablePeriod39, 0);
        int int42 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate41.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, durationField31, dateTimeFieldType44, 35);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField31);
        java.lang.String str48 = unsupportedDateTimeField47.getName();
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField47.getLeapDurationField();
        long long52 = unsupportedDateTimeField47.add((long) 40, 6);
        try {
            int int54 = unsupportedDateTimeField47.getMinimumValue(10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 189302400040L + "'", long52 == 189302400040L);
    }
}

