import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str6 = fixedDateTimeZone4.getNameKey(320L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period4 = period2.withSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.withMillis(10);
        int int7 = period6.getSeconds();
        org.joda.time.Duration duration8 = period6.toStandardDuration();
        org.joda.time.Period period10 = period6.plusHours(100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass9 = fixedDateTimeZone8.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int12 = fixedDateTimeZone8.getOffset((long) (byte) 1);
        int int14 = fixedDateTimeZone8.getOffsetFromLocal(1560628055020L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone8.getShortName(0L, locale16);
        org.joda.time.Chronology chronology18 = lenientChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        java.lang.String str19 = lenientChronology3.toString();
        org.joda.time.DurationField durationField20 = lenientChronology3.seconds();
        org.joda.time.DurationField durationField21 = lenientChronology3.centuries();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.Chronology chronology23 = lenientChronology3.withZone(dateTimeZone22);
        boolean boolean25 = lenientChronology3.equals((java.lang.Object) "13500");
        org.joda.time.DateTimeField dateTimeField26 = lenientChronology3.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-35) + "'", int12 == (-35));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-35) + "'", int14 == (-35));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.035" + "'", str17.equals("-00:00:00.035"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str19.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period1.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType7 = period1.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        try {
            long long13 = unsupportedDurationField10.getValueAsLong(374587200000L, 283996800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology4.add(readablePeriod8, 0L, 1);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType15, 8);
        long long19 = dividedDateTimeField17.roundFloor(0L);
        long long21 = dividedDateTimeField17.roundCeiling((-352065513657540000L));
        long long23 = dividedDateTimeField17.roundFloor((-61756905600000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-221011200000L) + "'", long19 == (-221011200000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-352065356150400000L) + "'", long21 == (-352065356150400000L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61946294400000L) + "'", long23 == (-61946294400000L));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.millisOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.hours();
        long long17 = durationField14.subtract((long) (short) 10, (int) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField14);
        org.joda.time.DurationField durationField19 = unsupportedDateTimeField18.getLeapDurationField();
        boolean boolean20 = unsupportedDateTimeField18.isLenient();
        org.joda.time.ReadablePartial readablePartial21 = null;
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = unsupportedDateTimeField18.getAsText(readablePartial21, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-125999990L) + "'", long17 == (-125999990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass5 = fixedDateTimeZone4.getClass();
        long long7 = fixedDateTimeZone4.nextTransition(0L);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone9.getUncachedZone();
        int int12 = cachedDateTimeZone9.getOffsetFromLocal(100L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-35) + "'", int12 == (-35));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.Period period1 = org.joda.time.Period.days(2001);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, 0, 4, 60);
        org.joda.time.Period period6 = period4.withWeeks(13500);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period1.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType7 = period1.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        boolean boolean11 = unsupportedDurationField10.isSupported();
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField10.getType();
        long long13 = unsupportedDurationField10.getUnitMillis();
        try {
            int int16 = unsupportedDurationField10.getDifference((-2108667081600000L), (-1198972800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass9 = fixedDateTimeZone8.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int12 = fixedDateTimeZone8.getOffset((long) (byte) 1);
        int int14 = fixedDateTimeZone8.getOffsetFromLocal(1560628055020L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone8.getShortName(0L, locale16);
        org.joda.time.Chronology chronology18 = lenientChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        java.lang.String str19 = lenientChronology3.toString();
        org.joda.time.Period period21 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period23 = period21.minusWeeks(0);
        org.joda.time.Period period25 = period23.minusMinutes((int) '4');
        int[] intArray28 = lenientChronology3.get((org.joda.time.ReadablePeriod) period25, (long) 'a', (long) (short) 10);
        java.lang.String str29 = period25.toString();
        org.joda.time.Period period31 = period25.plusSeconds(2001);
        org.joda.time.Period period33 = period31.plusSeconds(0);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        try {
            org.joda.time.Period period35 = period33.withPeriodType(periodType34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'minutes'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-35) + "'", int12 == (-35));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-35) + "'", int14 == (-35));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.035" + "'", str17.equals("-00:00:00.035"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str19.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PT-52M" + "'", str29.equals("PT-52M"));
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(periodType34);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 2002, (java.lang.Number) (byte) 10, (java.lang.Number) (-35));
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField18);
        java.lang.String str20 = unsupportedDateTimeField19.toString();
        int int23 = unsupportedDateTimeField19.getDifference((long) (byte) 10, 210858120000100L);
        long long26 = unsupportedDateTimeField19.add(1876247260679L, 97L);
        int int29 = unsupportedDateTimeField19.getDifference(315532799999L, 210858120000100L);
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField19.getRangeDurationField();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) unsupportedDateTimeField19, 4, 8, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for year must be in the range [8,4]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnsupportedDateTimeField" + "'", str20.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-348641) + "'", int23 == (-348641));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1934912860679L + "'", long26 == 1934912860679L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-348119) + "'", int29 == (-348119));
        org.junit.Assert.assertNull(durationField30);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period6 = period4.withSeconds((int) (byte) 100);
        org.joda.time.Period period8 = period6.withMillis(10);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        long long11 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearDay();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        boolean boolean14 = periodType12.isSupported(durationFieldType13);
        org.joda.time.PeriodType periodType15 = periodType12.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = periodType12.withMonthsRemoved();
        org.joda.time.PeriodType periodType17 = periodType16.withDaysRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration10, periodType16);
        org.joda.time.PeriodType periodType19 = periodType16.withMillisRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withYearsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.Period period23 = new org.joda.time.Period(0L, periodType20, (org.joda.time.Chronology) lenientChronology22);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100010L + "'", long11 == 100010L);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(lenientChronology22);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology4.add(readablePeriod8, 0L, 1);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType15, 8);
        int int20 = dividedDateTimeField17.getDifference((long) '4', (long) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        long long24 = dividedDateTimeField17.add(1934912860679L, (int) (short) 10);
        long long27 = dividedDateTimeField17.add((long) 100, 0);
        int int28 = dividedDateTimeField17.getMinimumValue();
        long long31 = dividedDateTimeField17.addWrapField(63244800000L, 60);
        boolean boolean33 = dividedDateTimeField17.isLeap((-70L));
        org.joda.time.DurationField durationField34 = dividedDateTimeField17.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 4459348060679L + "'", long24 == 4459348060679L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1198972800000L) + "'", long31 == (-1198972800000L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str8 = fixedDateTimeZone6.getNameKey(1L);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Period period13 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period15 = period13.withSeconds((int) (byte) 100);
        org.joda.time.Period period17 = period15.withMillis(10);
        org.joda.time.Period period19 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        boolean boolean21 = period19.isSupported(durationFieldType20);
        org.joda.time.PeriodType periodType22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) durationFieldType20, periodType22);
        org.joda.time.Period period24 = period15.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.DurationFieldType durationFieldType25 = null;
        int int26 = period23.get(durationFieldType25);
        org.joda.time.Period period28 = period23.withWeeks((-35));
        boolean boolean29 = zonedChronology10.equals((java.lang.Object) (-35));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.years();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 'a', (long) (short) 0, periodType10);
        org.joda.time.PeriodType periodType12 = periodType10.withDaysRemoved();
        org.joda.time.PeriodType periodType13 = periodType10.withYearsRemoved();
        java.lang.String str14 = periodType10.toString();
        org.joda.time.PeriodType periodType15 = periodType10.withMonthsRemoved();
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((int) (short) 0, 8415354, 32, (-9133595), 12, (int) (byte) -1, 1, (int) ' ', periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PeriodType[Years]" + "'", str14.equals("PeriodType[Years]"));
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period5 = period3.withSeconds((int) (byte) 100);
        org.joda.time.Period period7 = period5.withMillis(10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9, periodType11);
        org.joda.time.Period period13 = period12.negated();
        org.joda.time.Period period15 = period12.minusMillis((int) (short) 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100010L + "'", long10 == 100010L);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period1.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType7 = period1.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        java.lang.String str11 = unsupportedDurationField10.toString();
        try {
            long long14 = unsupportedDurationField10.subtract((-9133595L), 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnsupportedDurationField[months]" + "'", str11.equals("UnsupportedDurationField[months]"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-348641));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(508523773660679L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8326279L + "'", long1 == 8326279L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period1.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType7 = period1.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        java.lang.String str11 = unsupportedDurationField10.toString();
        try {
            int int14 = unsupportedDurationField10.getDifference(0L, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnsupportedDurationField[months]" + "'", str11.equals("UnsupportedDurationField[months]"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology4.add(readablePeriod8, 0L, 1);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType15, 8);
        int int20 = dividedDateTimeField17.getDifference((long) '4', (long) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField17, 45);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dividedDateTimeField17.getAsText((-348119), locale24);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = dividedDateTimeField17.getAsShortText(readablePartial26, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-348119" + "'", str25.equals("-348119"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "ISOChronology[hi!]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-00:00:00.035");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period7 = period5.withSeconds((int) (byte) 100);
        org.joda.time.Period period9 = period7.withMillis(10);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period9.toDurationTo(readableInstant10);
        org.joda.time.Period period13 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.years();
        org.joda.time.Period period17 = new org.joda.time.Period((long) 'a', (long) (short) 0, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withDaysRemoved();
        org.joda.time.Period period19 = period13.withPeriodType(periodType16);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration11, periodType16);
        jodaTimePermission1.checkGuard((java.lang.Object) readableInstant2);
        java.security.PermissionCollection permissionCollection22 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection23 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(permissionCollection22);
        org.junit.Assert.assertNotNull(permissionCollection23);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        long long5 = durationField2.subtract((-210863779200000L), 1009843200001L);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period10 = period8.withSeconds((int) (byte) 100);
        org.joda.time.Period period12 = period10.plusMinutes((int) (byte) 1);
        org.joda.time.PeriodType periodType13 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (byte) 0);
        org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType15, 2001);
        long long18 = scaledDurationField17.getUnitMillis();
        boolean boolean19 = scaledDurationField17.isSupported();
        long long22 = scaledDurationField17.add(31795200000L, (long) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-3635646383782800000L) + "'", long5 == (-3635646383782800000L));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 7203600000L + "'", long18 == 7203600000L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24591600000L + "'", long22 == 24591600000L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 60, (-9223372036854775808L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 60 * -9223372036854775808");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean7 = fixedDateTimeZone6.isFixed();
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) boolean7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str17 = fixedDateTimeZone15.getNameKey(1L);
        java.lang.String str18 = fixedDateTimeZone15.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology20.yearOfCentury();
        long long25 = zonedChronology20.add(100L, 100L, 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.035", "", (int) (short) 0, (int) (short) 100);
        org.joda.time.Chronology chronology31 = zonedChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        long long33 = fixedDateTimeZone30.previousTransition(3204285L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1100L + "'", long25 == 1100L);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3204285L + "'", long33 == 3204285L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        long long5 = durationField2.subtract((-210863779200000L), 1009843200001L);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period10 = period8.withSeconds((int) (byte) 100);
        org.joda.time.Period period12 = period10.plusMinutes((int) (byte) 1);
        org.joda.time.PeriodType periodType13 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (byte) 0);
        org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType15, 2001);
        long long20 = scaledDurationField17.getValueAsLong(3600032L, 1009843800001L);
        int int21 = scaledDurationField17.getScalar();
        boolean boolean22 = scaledDurationField17.isPrecise();
        long long24 = scaledDurationField17.getValueAsLong((-290404479744000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-3635646383782800000L) + "'", long5 == (-3635646383782800000L));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2001 + "'", int21 == 2001);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-40313798L) + "'", long24 == (-40313798L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Standard", "10", (int) (byte) 100, (int) 'a');
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName((-26010467L), locale6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.100" + "'", str7.equals("+00:00:00.100"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology5.getZone();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gregorianChronology5.add(readablePeriod9, 0L, 1);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology5.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.millisOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology17.hours();
        long long22 = durationField19.subtract((long) (short) 10, (int) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField19);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType16);
        long long26 = zeroIsMaxDateTimeField24.roundHalfEven(31536000035L);
        int int27 = zeroIsMaxDateTimeField24.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 31536000000L + "'", long26 == 31536000000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 60 + "'", int27 == 60);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.millisOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.hours();
        long long17 = durationField14.subtract((long) (short) 10, (int) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField14);
        try {
            int int20 = unsupportedDateTimeField18.getMaximumValue((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-125999990L) + "'", long17 == (-125999990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str21 = fixedDateTimeZone19.getNameKey(1L);
        java.lang.String str22 = fixedDateTimeZone19.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = zonedChronology23.withZone(dateTimeZone24);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period30 = period28.withSeconds((int) (byte) 100);
        org.joda.time.Period period32 = period30.withMillis(10);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period32.toDurationTo(readableInstant33);
        org.joda.time.Period period36 = period32.withHours((int) (byte) -1);
        int[] intArray38 = zonedChronology23.get((org.joda.time.ReadablePeriod) period32, (long) (-1));
        int[] intArray40 = offsetDateTimeField10.add(readablePartial11, 1, intArray38, (int) (byte) 0);
        int int42 = offsetDateTimeField10.getLeapAmount((long) '#');
        long long44 = offsetDateTimeField10.roundCeiling((long) 100);
        java.util.Locale locale45 = null;
        int int46 = offsetDateTimeField10.getMaximumShortTextLength(locale45);
        long long48 = offsetDateTimeField10.roundHalfFloor((-2108666908800000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 31536000000L + "'", long44 == 31536000000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-2108667081600000L) + "'", long48 == (-2108667081600000L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean7 = fixedDateTimeZone6.isFixed();
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) boolean7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str17 = fixedDateTimeZone15.getNameKey(1L);
        java.lang.String str18 = fixedDateTimeZone15.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        boolean boolean22 = fixedDateTimeZone15.isStandardOffset((-70L));
        java.lang.String str24 = fixedDateTimeZone15.getShortName(214013793600100L);
        org.joda.time.LocalDateTime localDateTime25 = null;
        boolean boolean26 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime25);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-00:00:00.035" + "'", str24.equals("-00:00:00.035"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.Period period2 = period0.plusMonths(135);
        org.joda.time.Period period4 = period0.withYears((-166275032));
        org.joda.time.Period period5 = period4.toPeriod();
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass9 = fixedDateTimeZone8.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int12 = fixedDateTimeZone8.getOffset((long) (byte) 1);
        int int14 = fixedDateTimeZone8.getOffsetFromLocal(1560628055020L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone8.getShortName(0L, locale16);
        org.joda.time.Chronology chronology18 = lenientChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        java.lang.String str19 = lenientChronology3.toString();
        java.lang.String str20 = lenientChronology3.toString();
        java.lang.String str21 = lenientChronology3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-35) + "'", int12 == (-35));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-35) + "'", int14 == (-35));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.035" + "'", str17.equals("-00:00:00.035"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str19.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str20.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str21.equals("LenientChronology[GregorianChronology[UTC]]"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass9 = fixedDateTimeZone8.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int12 = fixedDateTimeZone8.getOffset((long) (byte) 1);
        int int14 = fixedDateTimeZone8.getOffsetFromLocal(1560628055020L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone8.getShortName(0L, locale16);
        org.joda.time.Chronology chronology18 = lenientChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        java.lang.String str19 = lenientChronology3.toString();
        org.joda.time.Period period21 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period23 = period21.minusWeeks(0);
        org.joda.time.Period period25 = period23.minusMinutes((int) '4');
        int[] intArray28 = lenientChronology3.get((org.joda.time.ReadablePeriod) period25, (long) 'a', (long) (short) 10);
        org.joda.time.Period period30 = period25.withMinutes(2001);
        org.joda.time.Period period32 = period25.plusDays((int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-35) + "'", int12 == (-35));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-35) + "'", int14 == (-35));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.035" + "'", str17.equals("-00:00:00.035"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str19.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean7 = fixedDateTimeZone6.isFixed();
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) boolean7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str17 = fixedDateTimeZone15.getNameKey(1L);
        java.lang.String str18 = fixedDateTimeZone15.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        boolean boolean22 = fixedDateTimeZone15.isStandardOffset((-70L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass28 = fixedDateTimeZone27.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        int int31 = fixedDateTimeZone27.getOffset((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        boolean boolean33 = fixedDateTimeZone15.equals((java.lang.Object) fixedDateTimeZone27);
        org.joda.time.LocalDateTime localDateTime34 = null;
        boolean boolean35 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime34);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-35) + "'", int31 == (-35));
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str8 = fixedDateTimeZone6.getNameKey(1L);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray16 = gregorianChronology0.get(readablePeriod13, 63072000000L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology5.getZone();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gregorianChronology5.add(readablePeriod9, 0L, 1);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology5.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.millisOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology17.hours();
        long long22 = durationField19.subtract((long) (short) 10, (int) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField19);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType16);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = zeroIsMaxDateTimeField24.getMinimumValue(readablePartial25);
        org.joda.time.DurationField durationField27 = zeroIsMaxDateTimeField24.getLeapDurationField();
        long long30 = zeroIsMaxDateTimeField24.addWrapField((-568080000000L), (int) '#');
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableDuration32, readableInstant33);
        org.joda.time.DurationFieldType[] durationFieldTypeArray35 = period34.getFieldTypes();
        int int36 = period34.getYears();
        int[] intArray37 = period34.getValues();
        int int38 = zeroIsMaxDateTimeField24.getMaximumValue(readablePartial31, intArray37);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-568077900000L) + "'", long30 == (-568077900000L));
        org.junit.Assert.assertNotNull(durationFieldTypeArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 60 + "'", int38 == 60);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology4.add(readablePeriod8, 0L, 1);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType15, 8);
        int int20 = dividedDateTimeField17.getDifference((long) '4', (long) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int22 = dividedDateTimeField17.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale25 = null;
        java.lang.String str26 = dividedDateTimeField17.getAsShortText(readablePartial23, 0, locale25);
        java.util.Locale locale27 = null;
        int int28 = dividedDateTimeField17.getMaximumShortTextLength(locale27);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 60);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 60 + "'", int1 == 60);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = dateTimeZone7.isLocalDateTimeGap(localDateTime8);
        long long12 = dateTimeZone7.adjustOffset(0L, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology4.add(readablePeriod8, 0L, 1);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType15, (int) '4');
        boolean boolean18 = offsetDateTimeField17.isLenient();
        int int20 = offsetDateTimeField17.getMaximumValue((-348321L));
        boolean boolean22 = offsetDateTimeField17.isLeap((long) 4);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsShortText((long) (-9), locale24);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField17.getAsShortText(readablePartial26, 13500, locale28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 86400051 + "'", int20 == 86400051);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "86400043" + "'", str25.equals("86400043"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13500" + "'", str29.equals("13500"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT100.010S", (java.lang.Number) 320, (java.lang.Number) (-1.0d), (java.lang.Number) (-166275032));
        org.joda.time.Period period6 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period8 = period6.minusWeeks(0);
        org.joda.time.Period period10 = period6.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType12 = period6.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType12, "-00:00:00.035");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException14);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period1.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType7 = period1.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        java.lang.String str11 = unsupportedDurationField10.toString();
        try {
            long long14 = unsupportedDurationField10.getDifferenceAsLong((long) 2, (-290404479744000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnsupportedDurationField[months]" + "'", str11.equals("UnsupportedDurationField[months]"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str6 = fixedDateTimeZone4.getNameKey(1L);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField10 = gregorianChronology9.weekyears();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str3 = illegalFieldValueException2.toString();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period8 = period6.withSeconds((int) (byte) 100);
        org.joda.time.Period period10 = period8.withMillis(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant3, (org.joda.time.ReadableDuration) duration12, periodType14);
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType14);
        org.joda.time.Period period17 = new org.joda.time.Period((long) 320, periodType14);
        int int18 = periodType14.size();
        int int19 = periodType14.size();
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100010L + "'", long13 == 100010L);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 210858120000000L, (java.lang.Number) 2002, (java.lang.Number) 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = illegalFieldValueException15.getDateTimeFieldType();
        illegalFieldValueException15.prependMessage("PT100.010S");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfEra();
        org.joda.time.DurationField durationField6 = gregorianChronology0.days();
        int int7 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period3.minusMinutes((int) '4');
        org.joda.time.Period period7 = period5.plusWeeks((-35));
        int[] intArray8 = period5.getValues();
        org.joda.time.Period period10 = period5.plusHours(12);
        org.joda.time.MutablePeriod mutablePeriod11 = period5.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.Period period1 = org.joda.time.Period.months((-348641));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "PT100.010S");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT100.010S" + "'", str3.equals("PT100.010S"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology4.add(readablePeriod8, 0L, 1);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType15, 8);
        int int20 = dividedDateTimeField17.getDifference((long) '4', (long) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int22 = dividedDateTimeField17.getMaximumValue();
        org.joda.time.DurationField durationField23 = dividedDateTimeField17.getDurationField();
        int int25 = dividedDateTimeField17.getMaximumValue(60000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.toString();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((-252525558528000035L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 32, 3092688000000L);
        try {
            org.joda.time.Days days3 = period2.toStandardDays();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Days as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period1.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType7 = period1.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        org.joda.time.DurationFieldType durationFieldType11 = unsupportedDurationField10.getType();
        try {
            long long14 = unsupportedDurationField10.getValueAsLong(283996800000L, (-2678399930L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertNotNull(durationFieldType11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-00:00:00.035");
        org.joda.time.Period period3 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period5 = period3.minusWeeks(0);
        org.joda.time.Period period7 = period5.minusMinutes((int) '4');
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.weeks();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.months();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.hourOfDay();
        org.joda.time.Period period17 = new org.joda.time.Period((-70L), periodType11, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType11);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period25 = period23.withSeconds((int) (byte) 100);
        org.joda.time.Period period27 = period25.withMillis(10);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period27.toDurationTo(readableInstant28);
        org.joda.time.Period period31 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.years();
        org.joda.time.Period period35 = new org.joda.time.Period((long) 'a', (long) (short) 0, periodType34);
        org.joda.time.PeriodType periodType36 = periodType34.withDaysRemoved();
        org.joda.time.Period period37 = period31.withPeriodType(periodType34);
        org.joda.time.Period period38 = new org.joda.time.Period(readableInstant20, (org.joda.time.ReadableDuration) duration29, periodType34);
        org.joda.time.Period period39 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant19, periodType34);
        org.joda.time.PeriodType periodType40 = periodType34.withWeeksRemoved();
        jodaTimePermission1.checkGuard((java.lang.Object) periodType34);
        java.lang.String str42 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"-00:00:00.035\")" + "'", str42.equals("(\"org.joda.time.JodaTimePermission\" \"-00:00:00.035\")"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass9 = fixedDateTimeZone8.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int12 = fixedDateTimeZone8.getOffset((long) (byte) 1);
        int int14 = fixedDateTimeZone8.getOffsetFromLocal(1560628055020L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone8.getShortName(0L, locale16);
        org.joda.time.Chronology chronology18 = lenientChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        boolean boolean20 = lenientChronology3.equals((java.lang.Object) "LenientChronology[GregorianChronology[UTC]]");
        org.joda.time.DurationField durationField21 = lenientChronology3.years();
        org.joda.time.DurationField durationField22 = lenientChronology3.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-35) + "'", int12 == (-35));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-35) + "'", int14 == (-35));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.035" + "'", str17.equals("-00:00:00.035"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str8 = fixedDateTimeZone6.getNameKey(1L);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = zonedChronology10.withZone(dateTimeZone11);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period17 = period15.withSeconds((int) (byte) 100);
        org.joda.time.Period period19 = period17.withMillis(10);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period19.toDurationTo(readableInstant20);
        org.joda.time.Period period23 = period19.withHours((int) (byte) -1);
        int[] intArray25 = zonedChronology10.get((org.joda.time.ReadablePeriod) period19, (long) (-1));
        java.lang.String str26 = zonedChronology10.toString();
        java.lang.Class<?> wildcardClass27 = zonedChronology10.getClass();
        org.joda.time.Chronology chronology28 = zonedChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = zonedChronology10.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ZonedChronology[GregorianChronology[UTC], hi!]" + "'", str26.equals("ZonedChronology[GregorianChronology[UTC], hi!]"));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str6 = fixedDateTimeZone4.toString();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = fixedDateTimeZone4.getStandardOffset(1533600L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(81648000032L, (-58543));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4779918865873376L) + "'", long2 == (-4779918865873376L));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period3.minusMinutes((int) '4');
        org.joda.time.Period period7 = period3.plusDays((int) (short) 100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType9 = periodType8.withMillisRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) period3, periodType8);
        org.joda.time.PeriodType periodType11 = periodType8.withMinutesRemoved();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        int[] intArray4 = period3.getValues();
        org.joda.time.Hours hours5 = period3.toStandardHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(hours5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean7 = fixedDateTimeZone6.isFixed();
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) boolean7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str17 = fixedDateTimeZone15.getNameKey(1L);
        java.lang.String str18 = fixedDateTimeZone15.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        boolean boolean22 = fixedDateTimeZone15.isStandardOffset((-70L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass28 = fixedDateTimeZone27.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        int int31 = fixedDateTimeZone27.getOffset((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        boolean boolean33 = fixedDateTimeZone15.equals((java.lang.Object) fixedDateTimeZone27);
        boolean boolean34 = fixedDateTimeZone27.isFixed();
        java.util.TimeZone timeZone35 = fixedDateTimeZone27.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-35) + "'", int31 == (-35));
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 2002, (java.lang.Number) (byte) 10, (java.lang.Number) (-35));
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField18);
        java.lang.String str20 = unsupportedDateTimeField19.toString();
        int int23 = unsupportedDateTimeField19.getDifference((long) (byte) 10, 210858120000100L);
        long long26 = unsupportedDateTimeField19.add(1876247260679L, 97L);
        int int29 = unsupportedDateTimeField19.getDifference(315532799999L, 210858120000100L);
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField19.getLeapDurationField();
        java.lang.String str31 = unsupportedDateTimeField19.toString();
        try {
            int int32 = unsupportedDateTimeField19.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnsupportedDateTimeField" + "'", str20.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-348641) + "'", int23 == (-348641));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1934912860679L + "'", long26 == 1934912860679L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-348119) + "'", int29 == (-348119));
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(0, 'a', (int) (byte) 10, 10, 0, true, 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("PeriodType[Years]", 8);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.setFixedSavings("10", 320);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) ' ', (int) 'a');
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval5);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) readableInterval5);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.DurationField durationField11 = gregorianChronology8.millis();
        org.junit.Assert.assertNotNull(readableInterval6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str21 = fixedDateTimeZone19.getNameKey(1L);
        java.lang.String str22 = fixedDateTimeZone19.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = zonedChronology23.withZone(dateTimeZone24);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period30 = period28.withSeconds((int) (byte) 100);
        org.joda.time.Period period32 = period30.withMillis(10);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period32.toDurationTo(readableInstant33);
        org.joda.time.Period period36 = period32.withHours((int) (byte) -1);
        int[] intArray38 = zonedChronology23.get((org.joda.time.ReadablePeriod) period32, (long) (-1));
        int[] intArray40 = offsetDateTimeField10.add(readablePartial11, 1, intArray38, (int) (byte) 0);
        long long42 = offsetDateTimeField10.roundHalfFloor((-1L));
        long long45 = offsetDateTimeField10.add(1560628060679L, 10);
        long long47 = offsetDateTimeField10.roundCeiling((long) 7);
        long long49 = offsetDateTimeField10.roundHalfEven((long) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1876247260679L + "'", long45 == 1876247260679L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 31536000000L + "'", long47 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 2002, (java.lang.Number) (byte) 10, (java.lang.Number) (-35));
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField18);
        java.lang.String str20 = unsupportedDateTimeField19.toString();
        int int23 = unsupportedDateTimeField19.getDifference((long) (byte) 10, 210858120000100L);
        long long26 = unsupportedDateTimeField19.add(1876247260679L, 97L);
        int int29 = unsupportedDateTimeField19.getDifference(315532799999L, 210858120000100L);
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField19.getRangeDurationField();
        boolean boolean31 = unsupportedDateTimeField19.isSupported();
        boolean boolean32 = unsupportedDateTimeField19.isSupported();
        java.lang.String str33 = unsupportedDateTimeField19.toString();
        org.joda.time.ReadablePartial readablePartial34 = null;
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = unsupportedDateTimeField19.getAsText(readablePartial34, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnsupportedDateTimeField" + "'", str20.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-348641) + "'", int23 == (-348641));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1934912860679L + "'", long26 == 1934912860679L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-348119) + "'", int29 == (-348119));
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "UnsupportedDateTimeField" + "'", str33.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        long long13 = offsetDateTimeField10.roundFloor((long) 9);
        java.lang.String str14 = offsetDateTimeField10.getName();
        long long17 = offsetDateTimeField10.add((long) 45, (int) (byte) 1);
        long long19 = offsetDateTimeField10.roundCeiling((-125999990L));
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField10.getAsShortText(2002, locale21);
        long long24 = offsetDateTimeField10.roundFloor(126144000000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31536000045L + "'", long17 == 31536000045L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2002" + "'", str22.equals("2002"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 94694400000L + "'", long24 == 94694400000L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology5.getZone();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gregorianChronology5.add(readablePeriod9, 0L, 1);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology5.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.millisOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology17.hours();
        long long22 = durationField19.subtract((long) (short) 10, (int) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField19);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType16);
        long long26 = zeroIsMaxDateTimeField24.roundFloor(92016000010L);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray32 = new int[] { 86400051, 1, (byte) 100, 2002 };
        int int33 = zeroIsMaxDateTimeField24.getMaximumValue(readablePartial27, intArray32);
        boolean boolean35 = zeroIsMaxDateTimeField24.isLeap((long) 46);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 92016000000L + "'", long26 == 92016000000L);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 60 + "'", int33 == 60);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 2002, (java.lang.Number) (byte) 10, (java.lang.Number) (-35));
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField18);
        java.lang.String str20 = unsupportedDateTimeField19.toString();
        int int23 = unsupportedDateTimeField19.getDifference((long) (byte) 10, 210858120000100L);
        long long26 = unsupportedDateTimeField19.add(1876247260679L, 97L);
        int int29 = unsupportedDateTimeField19.getDifference(315532799999L, 210858120000100L);
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField19.getRangeDurationField();
        boolean boolean31 = unsupportedDateTimeField19.isSupported();
        boolean boolean32 = unsupportedDateTimeField19.isSupported();
        try {
            java.lang.String str34 = unsupportedDateTimeField19.getAsText(97L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnsupportedDateTimeField" + "'", str20.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-348641) + "'", int23 == (-348641));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1934912860679L + "'", long26 == 1934912860679L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-348119) + "'", int29 == (-348119));
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 2002, (java.lang.Number) (byte) 10, (java.lang.Number) (-35));
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField18);
        java.lang.String str20 = unsupportedDateTimeField19.toString();
        int int23 = unsupportedDateTimeField19.getDifference((long) (byte) 10, 210858120000100L);
        long long26 = unsupportedDateTimeField19.add(320L, (long) (-1));
        java.util.Locale locale27 = null;
        try {
            int int28 = unsupportedDateTimeField19.getMaximumTextLength(locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnsupportedDateTimeField" + "'", str20.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-348641) + "'", int23 == (-348641));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-604799680L) + "'", long26 == (-604799680L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PeriodType[Years]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PeriodType[Years]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass10 = fixedDateTimeZone9.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int13 = fixedDateTimeZone9.getOffset((long) (byte) 1);
        int int15 = fixedDateTimeZone9.getOffsetFromLocal(1560628055020L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = fixedDateTimeZone9.getShortName(0L, locale17);
        org.joda.time.Chronology chronology19 = lenientChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str20 = lenientChronology4.toString();
        org.joda.time.Period period22 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period24 = period22.minusWeeks(0);
        org.joda.time.Period period26 = period24.minusMinutes((int) '4');
        int[] intArray29 = lenientChronology4.get((org.joda.time.ReadablePeriod) period26, (long) 'a', (long) (short) 10);
        long long33 = lenientChronology4.add(0L, 31795200000L, (-9133595));
        org.joda.time.Period period34 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) lenientChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-35) + "'", int13 == (-35));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-35) + "'", int15 == (-35));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.035" + "'", str18.equals("-00:00:00.035"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str20.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-290404479744000000L) + "'", long33 == (-290404479744000000L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.joda.time.Period period3 = period1.plusMonths((int) (short) -1);
        int int4 = period1.getSeconds();
        int int5 = period1.getYears();
        org.joda.time.Period period7 = period1.plusHours((int) (short) -1);
        org.joda.time.Period period9 = period7.minusYears(2002);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass5 = fixedDateTimeZone4.getClass();
        long long7 = fixedDateTimeZone4.nextTransition(0L);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone9.getUncachedZone();
        boolean boolean12 = cachedDateTimeZone9.equals((java.lang.Object) 2440587.50000037d);
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone9.getUncachedZone();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period3.minusMinutes((int) '4');
        org.joda.time.Duration duration6 = period3.toStandardDuration();
        int int7 = period3.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str21 = fixedDateTimeZone19.getNameKey(1L);
        java.lang.String str22 = fixedDateTimeZone19.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = zonedChronology23.withZone(dateTimeZone24);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period30 = period28.withSeconds((int) (byte) 100);
        org.joda.time.Period period32 = period30.withMillis(10);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period32.toDurationTo(readableInstant33);
        org.joda.time.Period period36 = period32.withHours((int) (byte) -1);
        int[] intArray38 = zonedChronology23.get((org.joda.time.ReadablePeriod) period32, (long) (-1));
        int[] intArray40 = offsetDateTimeField10.add(readablePartial11, 1, intArray38, (int) (byte) 0);
        int int42 = offsetDateTimeField10.getLeapAmount((long) '#');
        boolean boolean44 = offsetDateTimeField10.isLeap(1009843200001L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period4 = period2.withSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.withMillis(10);
        org.joda.time.Weeks weeks7 = period4.toStandardWeeks();
        org.joda.time.Period period9 = period4.withHours((-1));
        int int10 = period4.getWeeks();
        org.joda.time.Period period12 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.years();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 'a', (long) (short) 0, periodType15);
        org.joda.time.PeriodType periodType17 = periodType15.withDaysRemoved();
        org.joda.time.Period period18 = period12.withPeriodType(periodType15);
        org.joda.time.PeriodType periodType19 = periodType15.withWeeksRemoved();
        org.joda.time.Period period20 = period4.normalizedStandard(periodType15);
        boolean boolean22 = periodType15.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(weeks7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.millisOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.hours();
        long long17 = durationField14.subtract((long) (short) 10, (int) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField14);
        org.joda.time.DurationField durationField19 = unsupportedDateTimeField18.getLeapDurationField();
        try {
            int int21 = unsupportedDateTimeField18.getMaximumValue((-604799680L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-125999990L) + "'", long17 == (-125999990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology5.getZone();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gregorianChronology5.add(readablePeriod9, 0L, 1);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology5.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField15.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.millisOfDay();
        org.joda.time.DurationField durationField19 = gregorianChronology17.hours();
        long long22 = durationField19.subtract((long) (short) 10, (int) '#');
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField19);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType16);
        long long27 = zeroIsMaxDateTimeField24.getDifferenceAsLong((-2678400000L), (-26010467L));
        int int28 = zeroIsMaxDateTimeField24.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial29 = null;
        int int30 = zeroIsMaxDateTimeField24.getMaximumValue(readablePartial29);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-125999990L) + "'", long22 == (-125999990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-44206L) + "'", long27 == (-44206L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 60 + "'", int28 == 60);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 60 + "'", int30 == 60);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 2002, (java.lang.Number) (byte) 10, (java.lang.Number) (-35));
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField18);
        java.lang.String str20 = unsupportedDateTimeField19.toString();
        int int23 = unsupportedDateTimeField19.getDifference((long) (byte) 10, 210858120000100L);
        long long26 = unsupportedDateTimeField19.add(1876247260679L, 97L);
        int int29 = unsupportedDateTimeField19.getDifference(315532799999L, 210858120000100L);
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField19.getRangeDurationField();
        boolean boolean31 = unsupportedDateTimeField19.isSupported();
        boolean boolean32 = unsupportedDateTimeField19.isSupported();
        java.lang.String str33 = unsupportedDateTimeField19.toString();
        java.util.Locale locale34 = null;
        try {
            int int35 = unsupportedDateTimeField19.getMaximumShortTextLength(locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnsupportedDateTimeField" + "'", str20.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-348641) + "'", int23 == (-348641));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1934912860679L + "'", long26 == 1934912860679L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-348119) + "'", int29 == (-348119));
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "UnsupportedDateTimeField" + "'", str33.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology4.add(readablePeriod8, 0L, 1);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType15, 8);
        int int20 = dividedDateTimeField17.getDifference((long) '4', (long) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        int int22 = dividedDateTimeField17.getMaximumValue();
        org.joda.time.DurationField durationField23 = dividedDateTimeField17.getDurationField();
        int int24 = dividedDateTimeField17.getMaximumValue();
        int int26 = dividedDateTimeField17.getMaximumValue(320L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period8 = period6.withSeconds((int) (byte) 100);
        org.joda.time.Period period10 = period8.withMillis(10);
        int int11 = period8.getDays();
        org.joda.time.Period period13 = period8.multipliedBy(0);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        int int15 = period13.get(durationFieldType14);
        int[] intArray18 = iSOChronology2.get((org.joda.time.ReadablePeriod) period13, (-2108658959999965L), 126144000000L);
        boolean boolean19 = cachedDateTimeZone1.equals((java.lang.Object) 126144000000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass5 = fixedDateTimeZone4.getClass();
        long long7 = fixedDateTimeZone4.nextTransition(0L);
        long long10 = fixedDateTimeZone4.adjustOffset((-70L), true);
        long long12 = fixedDateTimeZone4.previousTransition(31536000000L);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone4.getName(3359735260679L, locale14);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-70L) + "'", long10 == (-70L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000000L + "'", long12 == 31536000000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-00:00:00.035" + "'", str15.equals("-00:00:00.035"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str21 = fixedDateTimeZone19.getNameKey(1L);
        java.lang.String str22 = fixedDateTimeZone19.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = zonedChronology23.withZone(dateTimeZone24);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period30 = period28.withSeconds((int) (byte) 100);
        org.joda.time.Period period32 = period30.withMillis(10);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period32.toDurationTo(readableInstant33);
        org.joda.time.Period period36 = period32.withHours((int) (byte) -1);
        int[] intArray38 = zonedChronology23.get((org.joda.time.ReadablePeriod) period32, (long) (-1));
        int[] intArray40 = offsetDateTimeField10.add(readablePartial11, 1, intArray38, (int) (byte) 0);
        int int42 = offsetDateTimeField10.getLeapAmount((long) '#');
        long long44 = offsetDateTimeField10.roundCeiling((long) 100);
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = offsetDateTimeField10.getMinimumValue(readablePartial45);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.millisOfDay();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone50 = gregorianChronology47.getZone();
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        long long54 = gregorianChronology47.add(readablePeriod51, 0L, 1);
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology47.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField57.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType58, (java.lang.Number) 210858120000000L, (java.lang.Number) 2002, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField64 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType58, (int) ' ');
        int int65 = dividedDateTimeField64.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField64);
        long long69 = remainderDateTimeField66.set(35020L, 9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 31536000000L + "'", long44 == 31536000000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-292275022) + "'", int46 == (-292275022));
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 9133719 + "'", int65 == 9133719);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-283996764980L) + "'", long69 == (-283996764980L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str8 = fixedDateTimeZone6.getNameKey(1L);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology11.getZone();
        boolean boolean15 = zonedChronology10.equals((java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology10.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.years();
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 2002, (java.lang.Number) (byte) 10, (java.lang.Number) (-35));
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField18);
        java.lang.String str20 = unsupportedDateTimeField19.toString();
        int int23 = unsupportedDateTimeField19.getDifference((long) (byte) 10, 210858120000100L);
        long long26 = unsupportedDateTimeField19.add(1876247260679L, 97L);
        int int29 = unsupportedDateTimeField19.getDifference(315532799999L, 210858120000100L);
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField19.getRangeDurationField();
        boolean boolean31 = unsupportedDateTimeField19.isSupported();
        boolean boolean32 = unsupportedDateTimeField19.isSupported();
        boolean boolean33 = unsupportedDateTimeField19.isSupported();
        try {
            long long35 = unsupportedDateTimeField19.roundFloor(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnsupportedDateTimeField" + "'", str20.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-348641) + "'", int23 == (-348641));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1934912860679L + "'", long26 == 1934912860679L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-348119) + "'", int29 == (-348119));
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str8 = fixedDateTimeZone6.getNameKey(1L);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = gregorianChronology11.months();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.year();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.millisOfDay();
        boolean boolean16 = gregorianChronology11.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology11.dayOfYear();
        boolean boolean18 = fixedDateTimeZone6.equals((java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology11.clockhourOfDay();
        org.joda.time.Period period22 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period24 = period22.withSeconds((int) (byte) 100);
        org.joda.time.Period period26 = period24.withMillis(10);
        int int27 = period24.getDays();
        int[] intArray29 = gregorianChronology11.get((org.joda.time.ReadablePeriod) period24, (long) 'a');
        org.joda.time.DurationFieldType durationFieldType31 = period24.getFieldType(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(durationFieldType31);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str21 = fixedDateTimeZone19.getNameKey(1L);
        java.lang.String str22 = fixedDateTimeZone19.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = zonedChronology23.withZone(dateTimeZone24);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period30 = period28.withSeconds((int) (byte) 100);
        org.joda.time.Period period32 = period30.withMillis(10);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period32.toDurationTo(readableInstant33);
        org.joda.time.Period period36 = period32.withHours((int) (byte) -1);
        int[] intArray38 = zonedChronology23.get((org.joda.time.ReadablePeriod) period32, (long) (-1));
        int[] intArray40 = offsetDateTimeField10.add(readablePartial11, 1, intArray38, (int) (byte) 0);
        long long42 = offsetDateTimeField10.roundHalfFloor((-1L));
        boolean boolean44 = offsetDateTimeField10.isLeap((long) (-292275022));
        long long46 = offsetDateTimeField10.roundFloor(8326279L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period4 = period2.withSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.withMillis(10);
        org.joda.time.Weeks weeks7 = period4.toStandardWeeks();
        org.joda.time.Period period9 = period4.withHours((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period9.getFieldTypes();
        int int11 = period9.getMillis();
        int int12 = period9.getWeeks();
        org.joda.time.Period period14 = period9.plusHours((-9133595));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(weeks7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 135 + "'", int11 == 135);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        long long5 = durationField2.subtract((-210863779200000L), 1009843200001L);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period10 = period8.withSeconds((int) (byte) 100);
        org.joda.time.Period period12 = period10.plusMinutes((int) (byte) 1);
        org.joda.time.PeriodType periodType13 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (byte) 0);
        org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType15, 2001);
        long long18 = scaledDurationField17.getUnitMillis();
        long long21 = scaledDurationField17.getValueAsLong((long) 'a', (-208842235200000L));
        boolean boolean22 = scaledDurationField17.isPrecise();
        long long24 = scaledDurationField17.getValueAsLong((long) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-3635646383782800000L) + "'", long5 == (-3635646383782800000L));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 7203600000L + "'", long18 == 7203600000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period1.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType7 = period1.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        try {
            long long12 = unsupportedDurationField10.getMillis(2001);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-352065513657540000L));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-35) + "'", int7 == (-35));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 2002, (java.lang.Number) (byte) 10, (java.lang.Number) (-35));
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField18);
        java.lang.String str20 = unsupportedDateTimeField19.toString();
        int int23 = unsupportedDateTimeField19.getDifference((long) (byte) 10, 210858120000100L);
        long long26 = unsupportedDateTimeField19.add(1876247260679L, 97L);
        int int29 = unsupportedDateTimeField19.getDifference(315532799999L, 210858120000100L);
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField19.getRangeDurationField();
        boolean boolean31 = unsupportedDateTimeField19.isSupported();
        boolean boolean32 = unsupportedDateTimeField19.isSupported();
        long long35 = unsupportedDateTimeField19.add((long) 32, 135);
        try {
            java.lang.String str37 = unsupportedDateTimeField19.getAsText((long) 13500);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnsupportedDateTimeField" + "'", str20.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-348641) + "'", int23 == (-348641));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1934912860679L + "'", long26 == 1934912860679L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-348119) + "'", int29 == (-348119));
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 81648000032L + "'", long35 == 81648000032L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period4 = period2.withSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.plusMinutes((int) (byte) 1);
        org.joda.time.PeriodType periodType7 = period4.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = periodType7.getFieldType((int) (byte) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(durationFieldType9, "P52Y");
        org.joda.time.field.PreciseDurationField preciseDurationField13 = new org.joda.time.field.PreciseDurationField(durationFieldType9, (-208842235200000L));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period4 = period2.withSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.withMillis(10);
        int int7 = period4.getDays();
        org.joda.time.Period period9 = period4.plusYears((int) (byte) 100);
        int int10 = period4.getDays();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.years();
        org.joda.time.Period period13 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period15 = period13.minusWeeks(0);
        boolean boolean16 = periodType11.equals((java.lang.Object) period13);
        int int17 = period13.getHours();
        org.joda.time.Period period19 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period21 = period19.minusWeeks(0);
        org.joda.time.Period period23 = period19.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType25 = period19.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(durationFieldType25, "");
        org.joda.time.Period period29 = period13.withField(durationFieldType25, (int) (byte) 100);
        org.joda.time.Period period31 = period4.withFieldAdded(durationFieldType25, 135);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology0.seconds();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DurationField durationField10 = gregorianChronology8.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass17 = fixedDateTimeZone16.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int20 = fixedDateTimeZone16.getOffset((long) (byte) 1);
        int int22 = fixedDateTimeZone16.getOffsetFromLocal(1560628055020L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone16.getShortName(0L, locale24);
        org.joda.time.Chronology chronology26 = lenientChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        java.lang.String str27 = lenientChronology11.toString();
        org.joda.time.Period period29 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period31 = period29.minusWeeks(0);
        org.joda.time.Period period33 = period31.minusMinutes((int) '4');
        int[] intArray36 = lenientChronology11.get((org.joda.time.ReadablePeriod) period33, (long) 'a', (long) (short) 10);
        java.lang.String str37 = period33.toString();
        org.joda.time.Period period39 = period33.plusSeconds(2001);
        org.joda.time.Period period41 = period39.plusSeconds(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.millisOfDay();
        org.joda.time.DurationField durationField44 = gregorianChronology42.hours();
        long long47 = durationField44.subtract((-210863779200000L), 1009843200001L);
        org.joda.time.Period period50 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period52 = period50.withSeconds((int) (byte) 100);
        org.joda.time.Period period54 = period52.plusMinutes((int) (byte) 1);
        org.joda.time.PeriodType periodType55 = period52.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType57 = periodType55.getFieldType((int) (byte) 0);
        org.joda.time.field.ScaledDurationField scaledDurationField59 = new org.joda.time.field.ScaledDurationField(durationField44, durationFieldType57, 2001);
        org.joda.time.Period period61 = period39.withFieldAdded(durationFieldType57, (int) (short) -1);
        org.joda.time.field.ScaledDurationField scaledDurationField63 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType57, 9);
        long long66 = scaledDurationField63.add(3075652060679L, (-58543));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-35) + "'", int20 == (-35));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-35) + "'", int22 == (-35));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-00:00:00.035" + "'", str25.equals("-00:00:00.035"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str27.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PT-52M" + "'", str37.equals("PT-52M"));
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-3635646383782800000L) + "'", long47 == (-3635646383782800000L));
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 3075125173679L + "'", long66 == 3075125173679L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        org.joda.time.PeriodType periodType3 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withMillisRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        int int7 = periodType5.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"-00:00:00.035\")", (java.lang.Number) (-1), (java.lang.Number) 92016000010L, (java.lang.Number) 10);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 2002);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        long long5 = durationField2.subtract((-210863779200000L), 1009843200001L);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period10 = period8.withSeconds((int) (byte) 100);
        org.joda.time.Period period12 = period10.plusMinutes((int) (byte) 1);
        org.joda.time.PeriodType periodType13 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (byte) 0);
        org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType15, 2001);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.millisOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.secondOfMinute();
        org.joda.time.DurationField durationField21 = gregorianChronology18.millis();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.dayOfYear();
        org.joda.time.DurationField durationField23 = gregorianChronology18.hours();
        int int24 = scaledDurationField17.compareTo(durationField23);
        org.joda.time.DurationField durationField25 = scaledDurationField17.getWrappedField();
        long long28 = scaledDurationField17.getMillis((long) '#', (-2678399930L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-3635646383782800000L) + "'", long5 == (-3635646383782800000L));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 252126000000L + "'", long28 == 252126000000L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(2002, 0, (int) 'a', (-166275032), (int) (byte) 1, (int) (byte) 100, (int) '4', 35, periodType8);
        org.joda.time.Period period11 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period13 = period11.minusWeeks(0);
        org.joda.time.Period period15 = period11.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType17 = period11.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        boolean boolean21 = period9.isSupported(durationFieldType17);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        long long14 = offsetDateTimeField10.add(1876247260679L, 0);
        long long17 = offsetDateTimeField10.add((long) (-1), (int) (short) 10);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField10.getAsText(readablePartial18, (int) 'a', locale20);
        boolean boolean22 = offsetDateTimeField10.isSupported();
        long long25 = offsetDateTimeField10.addWrapField(0L, 4);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField10.getAsShortText(0, locale27);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1876247260679L + "'", long14 == 1876247260679L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 315532799999L + "'", long17 == 315532799999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "97" + "'", str21.equals("97"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 126230400000L + "'", long25 == 126230400000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period1.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType7 = period1.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        boolean boolean11 = unsupportedDurationField10.isPrecise();
        long long12 = unsupportedDurationField10.getUnitMillis();
        boolean boolean13 = unsupportedDurationField10.isSupported();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology4.add(readablePeriod8, 0L, 1);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology4.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType15, 8);
        int int20 = dividedDateTimeField17.getDifference((long) '4', (long) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        long long23 = remainderDateTimeField21.roundCeiling((long) (byte) -1);
        long long25 = remainderDateTimeField21.roundFloor(10L);
        java.util.Locale locale26 = null;
        int int27 = remainderDateTimeField21.getMaximumTextLength(locale26);
        long long29 = remainderDateTimeField21.roundHalfCeiling(0L);
        long long31 = remainderDateTimeField21.remainder((-348321L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31795200000L + "'", long23 == 31795200000L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-259200000L) + "'", long25 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-259200000L) + "'", long29 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 258851679L + "'", long31 == 258851679L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.Period period1 = org.joda.time.Period.millis(8415354);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((-352065513657540000L));
        long long10 = fixedDateTimeZone4.adjustOffset((long) 9133719, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-35) + "'", int7 == (-35));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9133719L + "'", long10 == 9133719L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str3 = illegalFieldValueException2.toString();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        illegalFieldValueException2.prependMessage("P52Y");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass5 = fixedDateTimeZone4.getClass();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey(10L);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        boolean boolean10 = fixedDateTimeZone4.isStandardOffset(3075125173679L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str8 = fixedDateTimeZone6.getNameKey(1L);
        java.lang.String str9 = fixedDateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = zonedChronology10.withZone(dateTimeZone11);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period17 = period15.withSeconds((int) (byte) 100);
        org.joda.time.Period period19 = period17.withMillis(10);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period19.toDurationTo(readableInstant20);
        org.joda.time.Period period23 = period19.withHours((int) (byte) -1);
        int[] intArray25 = zonedChronology10.get((org.joda.time.ReadablePeriod) period19, (long) (-1));
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology10.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology10.yearOfEra();
        try {
            long long35 = zonedChronology10.getDateTimeMillis((int) '#', 9133719, 7, (int) ' ', (-9133595), 4, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test122");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        java.lang.String str3 = dateTimeZone1.getShortName((long) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) dateTimeZone6);
//        org.joda.time.Chronology chronology8 = iSOChronology4.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(chronology8);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str3 = iSOChronology2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyear();
        long long6 = gregorianChronology0.add((long) 4, 31536000045L, 32);
        java.lang.String str7 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1009152001444L + "'", long6 == 1009152001444L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        org.joda.time.PeriodType periodType3 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = periodType0.withSecondsRemoved();
        java.lang.String str5 = periodType4.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[YearDay]" + "'", str5.equals("PeriodType[YearDay]"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "PT-1S", "ISOChronology[UTC]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "2002", "hi!");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period5 = period3.withSeconds((int) (byte) 100);
        int int6 = period5.getSeconds();
        org.joda.time.Duration duration7 = period5.toStandardDuration();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7);
        org.joda.time.Period period10 = period8.plusMinutes(13500);
        int int11 = period10.getSeconds();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 40 + "'", int11 == 40);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period1.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType7 = period1.getFieldType(1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType7, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField10 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        boolean boolean11 = unsupportedDurationField10.isPrecise();
        try {
            long long14 = unsupportedDurationField10.getMillis((-221011200000L), (long) (-58543));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: months field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.Class<?> wildcardClass9 = fixedDateTimeZone8.getClass();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        int int12 = fixedDateTimeZone8.getOffset((long) (byte) 1);
        int int14 = fixedDateTimeZone8.getOffsetFromLocal(1560628055020L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone8.getShortName(0L, locale16);
        org.joda.time.Chronology chronology18 = lenientChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeField dateTimeField19 = lenientChronology3.minuteOfHour();
        org.joda.time.DurationField durationField20 = lenientChronology3.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-35) + "'", int12 == (-35));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-35) + "'", int14 == (-35));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.035" + "'", str17.equals("-00:00:00.035"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(135);
        long long4 = dateTimeZone1.convertLocalToUTC(63072000000L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 62586000000L + "'", long4 == 62586000000L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str21 = fixedDateTimeZone19.getNameKey(1L);
        java.lang.String str22 = fixedDateTimeZone19.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = zonedChronology23.withZone(dateTimeZone24);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period30 = period28.withSeconds((int) (byte) 100);
        org.joda.time.Period period32 = period30.withMillis(10);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period32.toDurationTo(readableInstant33);
        org.joda.time.Period period36 = period32.withHours((int) (byte) -1);
        int[] intArray38 = zonedChronology23.get((org.joda.time.ReadablePeriod) period32, (long) (-1));
        int[] intArray40 = offsetDateTimeField10.add(readablePartial11, 1, intArray38, (int) (byte) 0);
        long long42 = offsetDateTimeField10.roundHalfEven((long) 100);
        org.joda.time.DateTimeField dateTimeField43 = offsetDateTimeField10.getWrappedField();
        java.lang.String str44 = offsetDateTimeField10.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DateTimeField[year]" + "'", str44.equals("DateTimeField[year]"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str21 = fixedDateTimeZone19.getNameKey(1L);
        java.lang.String str22 = fixedDateTimeZone19.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.Chronology chronology25 = zonedChronology23.withZone(dateTimeZone24);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period30 = period28.withSeconds((int) (byte) 100);
        org.joda.time.Period period32 = period30.withMillis(10);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period32.toDurationTo(readableInstant33);
        org.joda.time.Period period36 = period32.withHours((int) (byte) -1);
        int[] intArray38 = zonedChronology23.get((org.joda.time.ReadablePeriod) period32, (long) (-1));
        int[] intArray40 = offsetDateTimeField10.add(readablePartial11, 1, intArray38, (int) (byte) 0);
        int int42 = offsetDateTimeField10.getLeapAmount((long) '#');
        long long44 = offsetDateTimeField10.roundCeiling((long) 100);
        java.lang.String str46 = offsetDateTimeField10.getAsText((long) (byte) 0);
        long long48 = offsetDateTimeField10.roundFloor(210858120000000L);
        org.joda.time.ReadablePartial readablePartial49 = null;
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField10.getAsShortText(readablePartial49, (int) (short) 100, locale51);
        int int54 = offsetDateTimeField10.get(258851679L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 31536000000L + "'", long44 == 31536000000L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2002" + "'", str46.equals("2002"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 210831984000000L + "'", long48 == 210831984000000L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "100" + "'", str52.equals("100"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2002 + "'", int54 == 2002);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfEra();
        org.joda.time.DurationField durationField6 = gregorianChronology0.days();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period13 = period11.withSeconds((int) (byte) 100);
        org.joda.time.Period period15 = period13.plusMinutes((int) (byte) 1);
        org.joda.time.PeriodType periodType16 = period13.getPeriodType();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology17.months();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.year();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology17.year();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology17.millisOfDay();
        org.joda.time.Period period23 = new org.joda.time.Period((long) 86400051, (-568080000000L), periodType16, (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (-35), 100L);
        org.joda.time.Period period28 = period26.withSeconds((int) (byte) 100);
        org.joda.time.Period period30 = period28.plusMinutes((int) (byte) 1);
        org.joda.time.PeriodType periodType31 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType33 = periodType31.getFieldType((int) (byte) 0);
        int int34 = periodType16.indexOf(durationFieldType33);
        org.joda.time.field.ScaledDurationField scaledDurationField36 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType33, (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone43 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str45 = fixedDateTimeZone43.getNameKey(1L);
        java.lang.String str46 = fixedDateTimeZone43.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology37, (org.joda.time.DateTimeZone) fixedDateTimeZone43);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.Chronology chronology49 = zonedChronology47.withZone(dateTimeZone48);
        org.joda.time.DateTimeField dateTimeField50 = zonedChronology47.monthOfYear();
        org.joda.time.Chronology chronology51 = zonedChronology47.withUTC();
        org.joda.time.DurationField durationField52 = zonedChronology47.seconds();
        int int53 = scaledDurationField36.compareTo(durationField52);
        long long56 = durationField52.subtract(92016000000L, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 92016000000L + "'", long56 == 92016000000L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        boolean boolean7 = fixedDateTimeZone6.isFixed();
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) boolean7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("hi!", "hi!", (-35), (-1));
        java.lang.String str17 = fixedDateTimeZone15.getNameKey(1L);
        java.lang.String str18 = fixedDateTimeZone15.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone22 = dateTimeZone21.toTimeZone();
        long long25 = dateTimeZone21.adjustOffset((long) (byte) -1, true);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone21.isLocalDateTimeGap(localDateTime26);
        org.joda.time.Chronology chronology28 = zonedChronology20.withZone(dateTimeZone21);
        java.lang.Object obj29 = null;
        boolean boolean30 = zonedChronology20.equals(obj29);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 0L, 1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 2002, (java.lang.Number) (byte) 10, (java.lang.Number) (-35));
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField18);
        java.lang.String str20 = unsupportedDateTimeField19.toString();
        int int23 = unsupportedDateTimeField19.getDifference((long) (byte) 10, 210858120000100L);
        long long26 = unsupportedDateTimeField19.getDifferenceAsLong(3600032L, 374587200000L);
        try {
            int int28 = unsupportedDateTimeField19.getMaximumValue(100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnsupportedDateTimeField" + "'", str20.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-348641) + "'", int23 == (-348641));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-619L) + "'", long26 == (-619L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(100, 'a', 10, (-35), (int) (byte) 10, false, 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("(\"org.joda.time.JodaTimePermission\" \"-00:00:00.035\")", (-348641), 100, (int) (byte) 10, 'a', (int) (short) 1, (-1), 2002, false, (int) (byte) -1);
        java.io.DataOutput dataOutput21 = null;
        try {
            dateTimeZoneBuilder0.writeTo("10", dataOutput21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }
}

