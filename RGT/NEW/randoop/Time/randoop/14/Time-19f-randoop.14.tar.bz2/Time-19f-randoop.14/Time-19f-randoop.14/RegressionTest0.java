import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) ' ', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            long long8 = iSOChronology0.getDateTimeMillis((int) 'a', (-1), 0, (int) (byte) 100, (int) 'a', (int) (short) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, (int) 'a', (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 100, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test015");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getName(1L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pacific Standard Time" + "'", str2.equals("Pacific Standard Time"));
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 100, 0, (int) (byte) 10, 0, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        try {
            long long4 = dateTimeFormatter2.parseMillis("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(6, (int) (short) 100, 10, (int) '#', 10, (org.joda.time.DateTimeZone) cachedDateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560635348561L + "'", long0 == 1560635348561L);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = iSOChronology0.get(readablePeriod1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.era();
        org.joda.time.DurationField durationField4 = iSOChronology1.seconds();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField5 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(100, 100, 0, (int) (byte) -1, 0, 6, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(78537);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.append(dateTimePrinter3, dateTimeParser4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.append(dateTimePrinter5, dateTimeParser6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("UTC", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"UTC/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime13 = dateTime10.plusDays((int) 'a');
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(78537, 2019, 78537, 100, 0, (int) (byte) 1, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
//        org.joda.time.DurationFieldType durationFieldType14 = null;
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime11.withFieldAdded(durationFieldType14, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78539 + "'", int9 == 78539);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(0);
        try {
            java.lang.String str12 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 3, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withTime(3, 3, 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        try {
            long long2 = dateTimeFormatter0.parseMillis("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plusSeconds((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withDayOfYear(78539);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78539 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        int int7 = dateTime6.getYear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime9.plus(0L);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withEra(6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 6 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = iSOChronology0.add(readablePeriod3, (long) 1, (int) (short) 1);
        java.lang.Object obj7 = null;
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 1, obj7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) 0.0f, (java.lang.Number) 1560635348561L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) (byte) 10, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendClockhourOfHalfday((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone1.getName((long) 'a', locale8);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (-1), (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, 0, 0, 2019);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime6.getDayOfWeek();
//        int int10 = dateTime6.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long8 = dateTimeZone4.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate12 = dateTime9.toLocalDate();
        long long14 = gregorianChronology2.set((org.joda.time.ReadablePartial) localDate12, 0L);
        boolean boolean15 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate12);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560556800000L + "'", long14 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        int int13 = property12.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        try {
//            java.lang.String str13 = dateTime8.toString("GregorianChronology[America/Los_Angeles]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78542 + "'", int9 == 78542);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.LocalDate localDate12 = dateTime8.toLocalDate();
//        int int13 = dateTime8.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 331 + "'", int13 == 331);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        java.lang.Class<?> wildcardClass12 = dateTime11.getClass();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78542 + "'", int9 == 78542);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(2000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfDay((int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray9 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.append(dateTimePrinter8, dateTimeParserArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeParserArray9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(2000, (int) (byte) 10, 331, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 331 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendYearOfCentury((int) (byte) 1, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear((-1), true);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFixedDecimal(dateTimeFieldType13, 78541);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePeriod3, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 100, 11, (int) '4', (-28800000), (int) '4', (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 10, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.secondOfDay();
        org.joda.time.DurationField durationField7 = iSOChronology5.millis();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) -1, 331, 6, 0, 6, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 331 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate16 = dateTime13.toLocalDate();
        long long18 = gregorianChronology6.set((org.joda.time.ReadablePartial) localDate16, 0L);
        java.lang.String str19 = gregorianChronology6.toString();
        org.joda.time.DurationField durationField20 = gregorianChronology6.months();
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(78541, (-28800000), 331, (int) (byte) 10, 3, 9, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560556800000L + "'", long18 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[UTC]" + "'", str19.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendSecondOfDay(2000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate10, 0L);
        java.lang.String str13 = gregorianChronology0.toString();
        try {
            long long21 = gregorianChronology0.getDateTimeMillis((-1), (int) '4', (int) (short) -1, 1, (int) (byte) 10, 53, 13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560556800000L + "'", long12 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((long) (byte) 10, 78539, (int) '4', (int) (short) 10, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78539 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfDay((int) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.append(dateTimePrinter8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 0, 78538);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withLocale(locale3);
        java.lang.Appendable appendable5 = null;
        try {
            dateTimeFormatter0.printTo(appendable5, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate11 = dateTime8.toLocalDate();
        long long13 = gregorianChronology1.set((org.joda.time.ReadablePartial) localDate11, 0L);
        try {
            java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560556800000L + "'", long13 == 1560556800000L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[UTC]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[UTC]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("2019", 78544, 78543, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78544 for 2019 must be in the range [78543,2019]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName(0L, locale3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long11 = dateTimeZone7.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = dateTime12.toDateTimeISO();
//        org.joda.time.DateTime dateTime17 = dateTime12.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime18 = dateTime12.toDateTimeISO();
//        boolean boolean19 = dateTime5.equals((java.lang.Object) dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime13 = dateTime10.plusDays((int) 'a');
        org.joda.time.LocalDate localDate14 = dateTime10.toLocalDate();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.era();
        org.joda.time.DurationField durationField4 = iSOChronology1.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = iSOChronology5.add(readablePeriod8, (long) 1, (int) (short) 1);
        org.joda.time.DurationField durationField12 = iSOChronology5.years();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField13 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField4, durationField12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(durationField12);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 10);
//        int int14 = dateTime13.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withFields(readablePartial15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.minus(readablePeriod17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.era();
//        boolean boolean23 = iSOChronology19.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DateTime dateTime24 = dateTime18.toDateTime((org.joda.time.Chronology) iSOChronology19);
//        try {
//            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(3, 100, (int) (short) 10, 0, 78546, (org.joda.time.Chronology) iSOChronology19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78546 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 78546 + "'", int14 == 78546);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        java.lang.String str12 = dateTime11.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-09-20T21:49:07.284Z" + "'", str12.equals("2019-09-20T21:49:07.284Z"));
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(0);
//        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear(100);
//        boolean boolean14 = dateTime11.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78547 + "'", int9 == 78547);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatterBuilder1.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        boolean boolean4 = dateTime2.isEqual((long) 9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.era();
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.weekyear();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime6, (org.joda.time.Chronology) iSOChronology12);
        try {
            long long23 = iSOChronology12.getDateTimeMillis(78542873, 0, (int) (short) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate11 = dateTime8.toLocalDate();
        long long13 = gregorianChronology1.set((org.joda.time.ReadablePartial) localDate11, 0L);
        java.lang.String str14 = gregorianChronology1.toString();
        org.joda.time.DurationField durationField15 = gregorianChronology1.months();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560556800000L + "'", long13 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[UTC]" + "'", str14.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfEra();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = dateTime11.toLocalDate();
//        long long16 = gregorianChronology4.set((org.joda.time.ReadablePartial) localDate14, 0L);
//        int[] intArray18 = iSOChronology1.get((org.joda.time.ReadablePartial) localDate14, (long) 78538);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.secondOfDay();
//        org.joda.time.DurationField durationField21 = iSOChronology19.millis();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long27 = dateTimeZone23.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone23);
//        int int29 = dateTime28.getSecondOfMinute();
//        org.joda.time.LocalDate localDate30 = dateTime28.toLocalDate();
//        int[] intArray32 = iSOChronology19.get((org.joda.time.ReadablePartial) localDate30, (long) 78539);
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate14, intArray32);
//        try {
//            long long38 = gregorianChronology0.getDateTimeMillis(10, 78543, 2019, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78543 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560556800000L + "'", long16 == 1560556800000L);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 18 + "'", int29 == 18);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(intArray32);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfDay((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.yearOfEra();
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = dateTime13.toLocalDate();
//        long long18 = gregorianChronology6.set((org.joda.time.ReadablePartial) localDate16, 0L);
//        int[] intArray20 = iSOChronology3.get((org.joda.time.ReadablePartial) localDate16, (long) 78538);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfDay();
//        org.joda.time.DurationField durationField23 = iSOChronology21.millis();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long29 = dateTimeZone25.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone25);
//        int int31 = dateTime30.getSecondOfMinute();
//        org.joda.time.LocalDate localDate32 = dateTime30.toLocalDate();
//        int[] intArray34 = iSOChronology21.get((org.joda.time.ReadablePartial) localDate32, (long) 78539);
//        gregorianChronology2.validate((org.joda.time.ReadablePartial) localDate16, intArray34);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560556800000L + "'", long18 == 1560556800000L);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 18 + "'", int31 == 18);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", 78542, 78543, (-1), ' ', 78542, 78542, (int) ' ', false, 0);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("38", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        boolean boolean3 = cachedDateTimeZone1.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone2.getName((long) (-28800000), locale5);
//        long long8 = dateTimeZone0.getMillisKeepLocal(dateTimeZone2, 1560635353669L);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560635353669L + "'", long8 == 1560635353669L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withFieldAdded(durationFieldType6, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 78542, (java.lang.Number) 10L, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-51L) + "'", long2 == (-51L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.lang.String str6 = dateTimeZone5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone8.adjustOffset(1560635349338L, true);
        long long13 = dateTimeZone5.getMillisKeepLocal(dateTimeZone8, 0L);
        boolean boolean14 = property3.equals((java.lang.Object) long13);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560635349338L + "'", long11 == 1560635349338L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter6.withLocale(locale9);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter10.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.append(dateTimePrinter11, dateTimeParser12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone7.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        long long17 = gregorianChronology5.set((org.joda.time.ReadablePartial) localDate15, 0L);
        java.lang.String str18 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) localDate15);
        int[] intArray20 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate15, (long) 11);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        try {
            int[] intArray23 = iSOChronology0.get(readablePeriod21, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560556800000L + "'", long17 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendClockhourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.yearOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology6);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology6);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-28800000), 10, 0, (int) (byte) -1, 52, (int) (byte) 10, chronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(331);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfDay(0);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            int int16 = dateTime11.get(dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1560635351849L, (java.lang.Number) 331, (java.lang.Number) 1560635359481L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 10);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        java.io.Writer writer3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.yearOfEra();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long13 = dateTimeZone9.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate17 = dateTime14.toLocalDate();
        long long19 = gregorianChronology7.set((org.joda.time.ReadablePartial) localDate17, 0L);
        int[] intArray21 = iSOChronology4.get((org.joda.time.ReadablePartial) localDate17, (long) 78538);
        try {
            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadablePartial) localDate17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560556800000L + "'", long19 == 1560556800000L);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate9 = dateTime6.toLocalDate();
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone1.getName((long) 'a', locale8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone1.getName((long) 78544, locale11);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        int int13 = dateTime11.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 263 + "'", int13 == 263);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2019-09-20T21:49:07.284Z");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-09-20T21:49:07.284Z/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy(1L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.era();
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.weekyear();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime6, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        int int20 = property19.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 86399 + "'", int20 == 86399);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType2, 78539);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DurationField durationField3 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate13 = dateTime10.toLocalDate();
        int[] intArray15 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate13, (long) (short) 10);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, dateTimeFieldType17, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMonthOfYearShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime14 = dateTime8.withMillis((long) 'a');
//        org.joda.time.DateTime dateTime16 = dateTime8.plus((long) 331);
//        java.util.Date date17 = dateTime8.toDate();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78551 + "'", int9 == 78551);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plusSeconds((int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime2.isSupported(dateTimeFieldType5);
        boolean boolean7 = dateTime2.isBeforeNow();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime13 = dateTime10.plusDays((int) 'a');
        org.joda.time.LocalDate localDate14 = dateTime10.toLocalDate();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendYearOfCentury((int) (byte) 1, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear((-1), true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1560635353669L, 1560635349937L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3121270703606L + "'", long2 == 3121270703606L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        int int15 = property12.getMaximumValueOverall();
        org.joda.time.DateTime dateTime17 = property12.addToCopy(0L);
        int int18 = property12.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "38" + "'", str14.equals("38"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        org.joda.time.DateTime dateTime16 = property12.addToCopy((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "38" + "'", str14.equals("38"));
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long14 = gregorianChronology6.getDateTimeMillis(2000, 2000, (int) (short) -1, (int) '4', 17, (int) (short) 10, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFraction(dateTimeFieldType6, (int) (short) -1, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMonths(78537);
//        try {
//            org.joda.time.DateTime dateTime19 = dateTime12.withTime(78545, (int) (byte) 1, (int) '#', (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78545 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78552 + "'", int9 == 78552);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        int int7 = dateTime6.getSecondOfMinute();
//        org.joda.time.LocalDate localDate8 = dateTime6.toLocalDate();
//        org.joda.time.DateTime dateTime10 = dateTime6.withDayOfMonth(13);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime10.withTime((-28800000), 17, 78544, 78546);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 22 + "'", int7 == 22);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate10, 0L);
        java.lang.String str13 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField14 = gregorianChronology0.months();
        long long17 = durationField14.subtract(0L, (long) 53);
        long long20 = durationField14.subtract((long) 78546, 86399);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560556800000L + "'", long12 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-139449600000L) + "'", long17 == (-139449600000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-227207375921454L) + "'", long20 == (-227207375921454L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) -1, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-101L) + "'", long2 == (-101L));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        int int7 = dateTime6.getYear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths(0);
        int int10 = dateTime9.getCenturyOfEra();
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = dateTime9.toString("UTC", locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
//        java.util.Locale locale5 = null;
//        int int6 = property3.getMaximumTextLength(locale5);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone8);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime.Property property15 = dateTime13.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfMonth();
//        int int18 = property3.getDifference((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime.Property property19 = dateTime16.millisOfSecond();
//        int int20 = property19.getMaximumValueOverall();
//        java.util.Locale locale21 = null;
//        int int22 = property19.getMaximumTextLength(locale21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560635363637L + "'", long14 == 1560635363637L);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 999 + "'", int20 == 999);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long5 = cachedDateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone3, (long) (byte) 0);
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = cachedDateTimeZone3.isLocalDateTimeGap(localDateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DurationField durationField3 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate13 = dateTime10.toLocalDate();
        int[] intArray15 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate13, (long) (short) 10);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.lang.String str8 = dateTimeZone7.toString();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long13 = dateTimeZone10.adjustOffset(1560635349338L, true);
//        long long15 = dateTimeZone7.getMillisKeepLocal(dateTimeZone10, 0L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone7.getShortName((long) 10, locale17);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone7);
//        try {
//            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) ' ', 13, 52, 52, 78539, 78543, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560635349338L + "'", long13 == 1560635349338L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) -1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long5 = cachedDateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone3, (long) (byte) 0);
        long long7 = cachedDateTimeZone1.previousTransition((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone1);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(263, 19, 0, (int) (short) 0, 24, 24, 17, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 78547);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long5 = cachedDateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone3, (long) (byte) 0);
        boolean boolean6 = cachedDateTimeZone1.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) 100, false);
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZoneBuilder0, (java.lang.Object) dateTimeFormatterBuilder1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[UTC]", (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover(15, '4', 2000, (int) 'a', (int) (byte) -1, false, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) (byte) 0, 78538, (int) (short) 1, 78544, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78544 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendYearOfCentury((int) (byte) 1, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear((-1), true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(0, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 19);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long17 = dateTimeZone13.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 10);
//        int int21 = dateTime20.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withFields(readablePartial22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        int int26 = dateTime11.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.minusSeconds(78547);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78555 + "'", int9 == 78555);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78555 + "'", int21 == 78555);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.era();
        org.joda.time.DurationField durationField4 = iSOChronology1.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.secondOfDay();
        org.joda.time.DurationField durationField7 = iSOChronology5.millis();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField8 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField4, durationField7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName(0L, locale3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        boolean boolean7 = dateTime5.isSupported(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1560635361085L, (java.lang.Number) 1560635356265L, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(31);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime8.withEra(2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78556 + "'", int9 == 78556);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        try {
            long long7 = iSOChronology0.getDateTimeMillis(0L, 2019, 263, (int) (short) -1, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1560635359955L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime.Property property4 = dateTime3.era();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 10);
//        int int14 = dateTime13.getSecondOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfDay(0);
//        int int17 = dateTime13.getWeekyear();
//        org.joda.time.DateTime.Property property18 = dateTime13.yearOfCentury();
//        org.joda.time.DateTime dateTime19 = dateTime13.toDateTimeISO();
//        try {
//            long long20 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime19);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 78556 + "'", int14 == 78556);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("38");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"38\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withLocale(locale7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder26.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray28 = new org.joda.time.format.DateTimeParser[] { dateTimeParser18, dateTimeParser27 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder3.appendHourOfDay(86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendSecondOfMinute((int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeParserArray28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("38", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"38\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 263);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
//        java.util.Locale locale5 = null;
//        int int6 = property3.getMaximumTextLength(locale5);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone8);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime.Property property15 = dateTime13.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfMonth();
//        int int18 = property3.getDifference((org.joda.time.ReadableInstant) dateTime16);
//        java.util.GregorianCalendar gregorianCalendar19 = dateTime16.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560635366859L + "'", long14 == 1560635366859L);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(gregorianCalendar19);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 25, (long) 78554);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1963850 + "'", int2 == 1963850);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long17 = dateTimeZone13.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 10);
//        int int21 = dateTime20.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withFields(readablePartial22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        int int26 = dateTime11.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.minusMillis(100);
//        try {
//            org.joda.time.DateTime dateTime30 = dateTime25.withDayOfWeek(78544);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78544 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78557 + "'", int9 == 78557);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78557 + "'", int21 == 78557);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfHalfday((int) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType7, 53, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, 16, 19, 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for era must be in the range [19,16]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "ISOChronology[UTC]", "2019");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long5 = cachedDateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone3, (long) (byte) 0);
        long long7 = cachedDateTimeZone1.previousTransition((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone1);
        int int10 = cachedDateTimeZone1.getStandardOffset(1560635352507L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) ' ', 17, 19, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 17 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfHalfday(78547);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology0.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("GregorianChronology[America/Los_Angeles]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
        int int16 = dateTime8.get(dateTimeField15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
        long long20 = offsetDateTimeField18.roundFloor((long) 9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long28 = dateTimeZone24.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime31 = dateTime29.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
        long long34 = gregorianChronology22.set((org.joda.time.ReadablePartial) localDate32, 0L);
        java.lang.String str35 = dateTimeFormatter21.print((org.joda.time.ReadablePartial) localDate32);
        int[] intArray37 = new int[] {};
        try {
            int[] intArray39 = offsetDateTimeField18.addWrapField((org.joda.time.ReadablePartial) localDate32, (int) (byte) 0, intArray37, 263);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78558 + "'", int9 == 78558);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560556800000L + "'", long34 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.era();
        boolean boolean18 = iSOChronology14.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DurationField durationField20 = iSOChronology14.halfdays();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long26 = dateTimeZone22.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone22);
        int int28 = dateTime27.getSecondOfMinute();
        org.joda.time.LocalDate localDate29 = dateTime27.toLocalDate();
        int[] intArray31 = iSOChronology14.get((org.joda.time.ReadablePartial) localDate29, (long) 2019);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78558 + "'", int9 == 78558);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 28 + "'", int28 == 28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) 100, false);
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZoneBuilder0, (java.lang.Object) dateTimeFormatterBuilder1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[UTC]", (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 10);
        java.io.OutputStream outputStream14 = null;
        try {
            dateTimeZoneBuilder12.writeTo("dayOfMonth", outputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property8 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfCeilingCopy();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendEraText();
//        boolean boolean13 = dateTime9.equals((java.lang.Object) dateTimeFormatterBuilder12);
//        int int14 = dateTime9.getMinuteOfDay();
//        org.joda.time.DateTime.Property property15 = dateTime9.era();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635368506L + "'", long7 == 1560635368506L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 100, 31, 1963850, (int) (short) 0, 78542873);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78542873 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        try {
            long long10 = iSOChronology0.getDateTimeMillis((int) ' ', 78538, 78537, 2000, 78542, (int) '#', 78554);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 331);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 331");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2019-W24-6", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-W24-6/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(78539);
        boolean boolean3 = dateTimeFormatter2.isParser();
        try {
            long long5 = dateTimeFormatter2.parseMillis("2019-W24-6");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W24-6\" is malformed at \"-W24-6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.era();
        boolean boolean18 = iSOChronology14.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTime dateTime19 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime21 = dateTime13.withMinuteOfHour(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78558 + "'", int9 == 78558);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property8 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
//        boolean boolean12 = property10.isLeap();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635369003L + "'", long7 == 1560635369003L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.secondOfDay();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(25, 78547, 78549, 78547, 78542, 78544, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78547 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 'a', (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3L) + "'", long2 == (-3L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfHalfday((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime12 = dateTime6.toDateTimeISO();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
//        long long14 = dateTime12.getMillis();
//        org.joda.time.DateTime.Property property15 = dateTime12.yearOfEra();
//        int int16 = dateTime12.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560635369450L + "'", long14 == 1560635369450L);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 450 + "'", int16 == 450);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("dayOfMonth");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'dayOfMonth' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.String str7 = dateTimeZone1.getID();
        long long10 = dateTimeZone1.convertLocalToUTC(1560635364842L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560635364842L + "'", long10 == 1560635364842L);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        int int7 = dateTime6.getSecondOfMinute();
//        int int8 = dateTime6.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 29 + "'", int7 == 29);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendClockhourOfHalfday((int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType9, 24, 331);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate10, 0L);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        try {
            long long21 = gregorianChronology0.getDateTimeMillis(20, (int) (byte) 1, (int) (byte) 0, (int) '4', 78555, 1963850, 78555);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560556800000L + "'", long12 == 1560556800000L);
        org.junit.Assert.assertNotNull(chronology13);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime.Property property4 = dateTime3.era();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = dateTime11.toDateTimeISO();
//        org.joda.time.DateTime dateTime16 = dateTime11.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.era();
//        boolean boolean21 = iSOChronology17.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.weekyear();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) dateTime11, (org.joda.time.Chronology) iSOChronology17);
//        boolean boolean25 = dateTime23.isAfter(0L);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = dateTimeZone27.getShortName(0L, locale29);
//        org.joda.time.DateTime dateTime31 = dateTime23.toDateTime(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = dateTime3.withZoneRetainFields(dateTimeZone27);
//        org.joda.time.LocalDateTime localDateTime33 = null;
//        boolean boolean34 = dateTimeZone27.isLocalDateTimeGap(localDateTime33);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UTC" + "'", str30.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
//        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long8 = dateTimeZone4.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone4);
//        int int10 = dateTime9.getSecondOfMinute();
//        org.joda.time.LocalDate localDate11 = dateTime9.toLocalDate();
//        int[] intArray13 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate11, (long) 78539);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.secondOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 30 + "'", int10 == 30);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        long long5 = cachedDateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone3, (long) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone8.getShortName(0L, locale10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter6.withZone(dateTimeZone8);
//        boolean boolean13 = cachedDateTimeZone3.equals((java.lang.Object) dateTimeZone8);
//        java.lang.String str15 = cachedDateTimeZone3.getShortName(1560635348561L);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long21 = dateTimeZone17.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime25 = dateTime22.toDateTimeISO();
//        org.joda.time.DateTime dateTime27 = dateTime22.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime28 = dateTime22.toDateTimeISO();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime28);
//        long long30 = dateTime28.getMillis();
//        org.joda.time.DateTime.Property property31 = dateTime28.yearOfEra();
//        int int32 = cachedDateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime28);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = cachedDateTimeZone3.getName((long) (short) 0, locale34);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560635370787L + "'", long30 == 1560635370787L);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Coordinated Universal Time" + "'", str35.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.era();
//        boolean boolean18 = iSOChronology14.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DateTime dateTime19 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime.Property property20 = dateTime13.millisOfDay();
//        org.joda.time.DurationField durationField21 = property20.getRangeDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78561 + "'", int9 == 78561);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(durationField21);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneId();
        boolean boolean3 = dateTimeFormatterBuilder1.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.minusMinutes((-28800000));
//        int int10 = dateTime6.getMonthOfYear();
//        org.joda.time.DateTime dateTime12 = dateTime6.plus((long) 999);
//        org.joda.time.DurationFieldType durationFieldType13 = null;
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime12.withFieldAdded(durationFieldType13, 78543);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635372487L + "'", long7 == 1560635372487L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths(0);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.lang.String str16 = dateTimeZone15.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long21 = dateTimeZone18.adjustOffset(1560635349338L, true);
        long long23 = dateTimeZone15.getMillisKeepLocal(dateTimeZone18, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone25 = cachedDateTimeZone24.getUncachedZone();
        org.joda.time.DateTime dateTime26 = dateTime13.withZoneRetainFields(dateTimeZone25);
        org.joda.time.DateTime.Property property27 = dateTime13.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560635349338L + "'", long21 == 1560635349338L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("15");
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        int int7 = dateTime6.getYear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear((int) '#');
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withTime(86399, 4, 78560, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        long long23 = offsetDateTimeField18.add((long) 24, (-51L));
//        java.util.Locale locale26 = null;
//        try {
//            long long27 = offsetDateTimeField18.set((long) 78541, "GregorianChronology[UTC]", locale26);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78562 + "'", int9 == 78562);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4406399976L) + "'", long23 == (-4406399976L));
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        long long23 = offsetDateTimeField18.addWrapField((long) 3, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long29 = dateTimeZone25.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone25);
//        int int31 = dateTime30.getSecondOfMinute();
//        org.joda.time.LocalDate localDate32 = dateTime30.toLocalDate();
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
//        org.joda.time.DurationField durationField37 = iSOChronology34.centuries();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long45 = dateTimeZone41.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone41);
//        org.joda.time.DateTime dateTime48 = dateTime46.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate49 = dateTime46.toLocalDate();
//        long long51 = gregorianChronology39.set((org.joda.time.ReadablePartial) localDate49, 0L);
//        java.lang.String str52 = dateTimeFormatter38.print((org.joda.time.ReadablePartial) localDate49);
//        int[] intArray54 = iSOChronology34.get((org.joda.time.ReadablePartial) localDate49, (long) 11);
//        try {
//            int[] intArray56 = offsetDateTimeField18.addWrapField((org.joda.time.ReadablePartial) localDate32, (int) (byte) 100, intArray54, 2000);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78563 + "'", int9 == 78563);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 345600003L + "'", long23 == 345600003L);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 33 + "'", int31 == 33);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560556800000L + "'", long51 == 1560556800000L);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2019" + "'", str52.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray54);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.millisOfSecond();
        java.lang.String str8 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(331);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfDay(0);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        java.lang.String str15 = property14.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        int int7 = dateTime6.getYear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths(0);
        int int10 = dateTime9.getCenturyOfEra();
        int int11 = dateTime9.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.lang.String str2 = dateTimeZone1.toString();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone1.getName((long) 78561, locale4);
//        java.lang.String str7 = dateTimeZone1.getShortName((long) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        org.joda.time.DurationField durationField15 = property12.getLeapDurationField();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        try {
            org.joda.time.DateTime dateTime18 = property12.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "38" + "'", str14.equals("38"));
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(78564);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(78542873, 450, 0, 78546, 78557);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78546 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
//        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long8 = dateTimeZone4.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone4);
//        int int10 = dateTime9.getSecondOfMinute();
//        org.joda.time.LocalDate localDate11 = dateTime9.toLocalDate();
//        int[] intArray13 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate11, (long) 78539);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.monthOfYear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 34 + "'", int10 == 34);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.era();
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.weekyear();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime6, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        org.joda.time.DateTime dateTime20 = property19.withMinimumValue();
        org.joda.time.DateTime dateTime22 = property19.addToCopy((long) (byte) 1);
        java.util.Locale locale24 = null;
        try {
            org.joda.time.DateTime dateTime25 = property19.setCopy("2019-09-20T21:49:07.284Z", locale24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-09-20T21:49:07.284Z\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(24);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.era();
//        boolean boolean18 = iSOChronology14.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DateTime dateTime19 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime21 = dateTime19.minusMinutes(2000);
//        org.joda.time.DateTime dateTime23 = dateTime19.minusHours(1);
//        int int24 = dateTime19.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78565 + "'", int9 == 78565);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 20 + "'", int24 == 20);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.era();
//        boolean boolean16 = iSOChronology12.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.weekyear();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime6, (org.joda.time.Chronology) iSOChronology12);
//        boolean boolean20 = dateTime18.isAfter(0L);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = dateTimeZone22.getShortName(0L, locale24);
//        org.joda.time.DateTime dateTime26 = dateTime18.toDateTime(dateTimeZone22);
//        int int27 = dateTime18.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 20 + "'", int27 == 20);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(0);
//        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear(100);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime13.withEra((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78565 + "'", int9 == 78565);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long9 = dateTimeZone1.convertUTCToLocal((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.era();
//        boolean boolean18 = iSOChronology14.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DateTime dateTime19 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology14.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78565 + "'", int9 == 78565);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        int int7 = dateTime6.getSecondOfMinute();
//        org.joda.time.DateTime.Property property8 = dateTime6.era();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitWeekyear((int) (short) -1, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendWeekOfWeekyear((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder10.appendClockhourOfHalfday((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder17.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfDay(2000, 78551);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long32 = dateTimeZone28.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone28);
//        org.joda.time.DateTime dateTime35 = dateTime33.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime36 = dateTime35.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime38 = dateTime35.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property39 = dateTime38.weekOfWeekyear();
//        org.joda.time.DateTime dateTime40 = property39.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property39.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder23.appendFraction(dateTimeFieldType41, 6, (int) (short) 100);
//        try {
//            org.joda.time.DateTime dateTime46 = dateTime6.withField(dateTimeFieldType41, 450);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 450 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(mutableDateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long5 = cachedDateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone3, (long) (byte) 0);
        long long7 = cachedDateTimeZone1.previousTransition((long) 78539);
        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone1.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long14 = dateTimeZone10.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 10);
        int int18 = cachedDateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime17);
        int int19 = dateTime17.getYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 78539L + "'", long7 == 78539L);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plusSeconds((int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime2.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime.Property property7 = dateTime2.minuteOfDay();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsText(locale8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1309" + "'", str9.equals("1309"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime13 = dateTime10.plusDays((int) 'a');
        org.joda.time.LocalDate localDate14 = dateTime10.toLocalDate();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("2019-06-15T21:49:09.045Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T21:49:09.045Z\" is malformed at \"19-06-15T21:49:09.045Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(78538);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendYearOfCentury(1, 78538);
        dateTimeFormatterBuilder1.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withLocale(locale7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder26.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray28 = new org.joda.time.format.DateTimeParser[] { dateTimeParser18, dateTimeParser27 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder3.appendHourOfDay(86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendYearOfCentury(78566, 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeParserArray28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withLocale(locale7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder26.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray28 = new org.joda.time.format.DateTimeParser[] { dateTimeParser18, dateTimeParser27 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeParserArray28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property8 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        int int11 = property10.getMaximumValueOverall();
//        long long12 = property10.remainder();
//        org.joda.time.DurationField durationField13 = property10.getRangeDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635377962L + "'", long7 == 1560635377962L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(0);
//        int int12 = dateTime8.getWeekyear();
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime8.withTime(0, 78566, 15, 17);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78566 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78568 + "'", int9 == 78568);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter1.getZone();
        java.lang.Appendable appendable3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone7.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        long long17 = gregorianChronology5.set((org.joda.time.ReadablePartial) localDate15, 0L);
        java.lang.String str18 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) localDate15);
        try {
            dateTimeFormatter1.printTo(appendable3, (org.joda.time.ReadablePartial) localDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560556800000L + "'", long17 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        int int10 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime dateTime12 = dateTime8.plusSeconds(30);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78568 + "'", int9 == 78568);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 78568127 + "'", int10 == 78568127);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfDay((int) (byte) 10);
        boolean boolean8 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        java.util.Locale locale81 = null;
//        try {
//            java.lang.String str82 = unsupportedDateTimeField79.getAsText(19, locale81);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78568 + "'", int24 == 78568);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78568 + "'", int44 == 78568);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(78538, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfHalfday((int) (short) 1);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        int int7 = dateTime6.getYear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths(0);
        try {
            org.joda.time.DateTime dateTime14 = dateTime6.withTime(0, (int) (short) 10, 78561, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78561 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withLocale(locale7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder26.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray28 = new org.joda.time.format.DateTimeParser[] { dateTimeParser18, dateTimeParser27 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder3.appendWeekyear(6, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendTwoDigitWeekyear((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeParserArray28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfEra();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = dateTime11.toLocalDate();
//        long long16 = gregorianChronology4.set((org.joda.time.ReadablePartial) localDate14, 0L);
//        int[] intArray18 = iSOChronology1.get((org.joda.time.ReadablePartial) localDate14, (long) 78538);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.secondOfDay();
//        org.joda.time.DurationField durationField21 = iSOChronology19.millis();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long27 = dateTimeZone23.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone23);
//        int int29 = dateTime28.getSecondOfMinute();
//        org.joda.time.LocalDate localDate30 = dateTime28.toLocalDate();
//        int[] intArray32 = iSOChronology19.get((org.joda.time.ReadablePartial) localDate30, (long) 78539);
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate14, intArray32);
//        try {
//            long long39 = gregorianChronology0.getDateTimeMillis((long) 999, 19, 78546, 10, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78546 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560556800000L + "'", long16 == 1560556800000L);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 38 + "'", int29 == 38);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(intArray32);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.getDifferenceAsLong(1560635367969L, 1560635349937L);
//        java.util.Locale locale84 = null;
//        try {
//            java.lang.String str85 = unsupportedDateTimeField79.getAsText(1560635361085L, locale84);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78568 + "'", int24 == 78568);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78568 + "'", int44 == 78568);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePeriod2, (long) (byte) 10, 1560635375552L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        int int7 = dateTime6.getSecondOfMinute();
//        org.joda.time.DateTime.Property property8 = dateTime6.era();
//        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((int) (short) 0);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39 + "'", int7 == 39);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 39, 78543);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100, false);
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime12 = dateTime6.toDateTimeISO();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
//        long long14 = dateTime12.getMillis();
//        org.joda.time.DateTime.Property property15 = dateTime12.yearOfEra();
//        org.joda.time.DateTime dateTime17 = dateTime12.plusSeconds(24);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.era();
//        boolean boolean22 = iSOChronology18.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DurationField durationField23 = iSOChronology18.minutes();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.Chronology chronology25 = iSOChronology18.withZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime12.toDateTime(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560635379263L + "'", long14 == 1560635379263L);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DurationField durationField3 = iSOChronology0.years();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone2.getName((long) (-28800000), locale5);
//        long long8 = dateTimeZone0.getMillisKeepLocal(dateTimeZone2, 1560635353669L);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        int int10 = dateTimeZone2.getOffset(readableInstant9);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560635353669L + "'", long8 == 1560635353669L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.getDifferenceAsLong(1560635367969L, 1560635349937L);
//        try {
//            long long84 = unsupportedDateTimeField79.roundFloor(1560556800000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78569 + "'", int24 == 78569);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78569 + "'", int44 == 78569);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(78559, 0, 78539, (int) '4', 0, 78544, 78563);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DurationField durationField3 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate13 = dateTime10.toLocalDate();
        int[] intArray15 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate13, (long) (short) 10);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1309", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1309/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.era();
//        boolean boolean18 = iSOChronology14.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DateTime dateTime19 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime21 = dateTime19.minusMinutes(2000);
//        boolean boolean22 = dateTime21.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78570 + "'", int9 == 78570);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate10, 0L);
        java.lang.String str13 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField14 = gregorianChronology0.months();
        org.joda.time.DurationField durationField15 = gregorianChronology0.millis();
        try {
            long long23 = gregorianChronology0.getDateTimeMillis(78546, 53, 2000, 100, 78557, 10, 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560556800000L + "'", long12 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        try {
//            long long81 = unsupportedDateTimeField79.roundHalfEven((long) 331);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78570 + "'", int24 == 78570);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78570 + "'", int44 == 78570);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(78556, 78545);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 78545");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long5 = cachedDateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone3, (long) (byte) 0);
        long long7 = cachedDateTimeZone1.previousTransition((long) 78539);
        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone1.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long14 = dateTimeZone10.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds((int) (short) 10);
        int int18 = cachedDateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime17);
        long long21 = cachedDateTimeZone1.convertLocalToUTC((long) 25, true);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 78539L + "'", long7 == 78539L);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 25L + "'", long21 == 25L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(331);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfDay(0);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.withPeriodAdded(readablePeriod14, 24);
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology0.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DurationField durationField5 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfDay(78546);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendLiteral("78569752");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) 100, false);
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZoneBuilder0, (java.lang.Object) dateTimeFormatterBuilder1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[UTC]", (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = dateTimeZoneBuilder17.toDateTimeZone("ISOChronology[UTC]", true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        int int7 = dateTime6.getYear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear((int) '#');
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
        org.joda.time.DateTime.Property property14 = dateTime11.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute(78552, 78551);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime15 = dateTime12.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property16 = dateTime15.weekOfWeekyear();
//        org.joda.time.DateTime dateTime17 = property16.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long24 = dateTimeZone20.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) (short) 10);
//        int int28 = dateTime27.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.withFields(readablePartial29);
//        org.joda.time.DateTime dateTime31 = dateTime27.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.dayOfMonth();
//        int int35 = dateTime27.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 78541);
//        java.lang.String str38 = offsetDateTimeField37.getName();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long44 = dateTimeZone40.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone40);
//        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds((int) (short) 10);
//        int int48 = dateTime47.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime47.withFields(readablePartial49);
//        org.joda.time.DateTime dateTime51 = dateTime47.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.dayOfMonth();
//        int int55 = dateTime47.get(dateTimeField54);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 78541);
//        long long59 = offsetDateTimeField57.roundFloor((long) 9);
//        long long62 = offsetDateTimeField57.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = iSOChronology63.era();
//        org.joda.time.DurationField durationField66 = iSOChronology63.seconds();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long72 = dateTimeZone68.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone68);
//        org.joda.time.DateTime dateTime75 = dateTime73.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate76 = dateTime73.toLocalDate();
//        int[] intArray78 = iSOChronology63.get((org.joda.time.ReadablePartial) localDate76, (long) (short) 10);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = offsetDateTimeField57.getAsText((org.joda.time.ReadablePartial) localDate76, locale79);
//        int int81 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) localDate76);
//        org.joda.time.DurationField durationField82 = offsetDateTimeField37.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField83 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField82);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType18);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder84.appendClockhourOfDay((-28800000));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 78571 + "'", int28 == 78571);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "dayOfMonth" + "'", str38.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 78571 + "'", int48 == 78571);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 15 + "'", int55 == 15);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-4406399976L) + "'", long62 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(durationField66);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertNotNull(intArray78);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "15" + "'", str80.equals("15"));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 78542 + "'", int81 == 78542);
//        org.junit.Assert.assertNotNull(durationField82);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField83);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths(0);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.lang.String str16 = dateTimeZone15.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long21 = dateTimeZone18.adjustOffset(1560635349338L, true);
        long long23 = dateTimeZone15.getMillisKeepLocal(dateTimeZone18, 0L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone25 = cachedDateTimeZone24.getUncachedZone();
        org.joda.time.DateTime dateTime26 = dateTime13.withZoneRetainFields(dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime26.withDayOfYear(17);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560635349338L + "'", long21 == 1560635349338L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate11 = dateTime8.toLocalDate();
        long long13 = gregorianChronology1.set((org.joda.time.ReadablePartial) localDate11, 0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withLocale(locale15);
        int int17 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560556800000L + "'", long13 == 1560556800000L);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2000 + "'", int17 == 2000);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(0);
//        int int12 = dateTime8.getWeekyear();
//        org.joda.time.DateTime dateTime14 = dateTime8.minusMonths(24);
//        org.joda.time.DateTime dateTime16 = dateTime8.withMinuteOfHour(25);
//        org.joda.time.DateTime.Property property17 = dateTime8.centuryOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78572 + "'", int9 == 78572);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(450);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withLocale(locale3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withLocale(locale5);
        java.io.Writer writer7 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long13 = dateTimeZone9.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime14.toDateTimeISO();
        org.joda.time.DateTime dateTime19 = dateTime14.minusMinutes(331);
        org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfDay(0);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.LocalDate localDate23 = dateTime19.toLocalDate();
        try {
            dateTimeFormatter0.printTo(writer7, (org.joda.time.ReadablePartial) localDate23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(localDate23);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        try {
            long long5 = dateTimeFormatter0.parseMillis("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(78537);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendYearOfEra(78537, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.lang.String str4 = dateTimeZone3.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long9 = dateTimeZone6.adjustOffset(1560635349338L, true);
//        long long11 = dateTimeZone3.getMillisKeepLocal(dateTimeZone6, 0L);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone3.getShortName((long) 10, locale13);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone3);
//        boolean boolean16 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone3);
//        java.lang.String str17 = jodaTimePermission1.getName();
//        org.joda.time.JodaTimePermission jodaTimePermission19 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.lang.String str22 = dateTimeZone21.toString();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long27 = dateTimeZone24.adjustOffset(1560635349338L, true);
//        long long29 = dateTimeZone21.getMillisKeepLocal(dateTimeZone24, 0L);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = dateTimeZone21.getShortName((long) 10, locale31);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone21);
//        boolean boolean34 = jodaTimePermission19.equals((java.lang.Object) dateTimeZone21);
//        java.lang.String str35 = jodaTimePermission19.getName();
//        boolean boolean36 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission19);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560635349338L + "'", long9 == 1560635349338L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560635349338L + "'", long27 == 1560635349338L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UTC" + "'", str32.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName(0L, locale3);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DurationField durationField5 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        java.lang.String str10 = dateTime8.toString();
//        org.joda.time.DateTime dateTime12 = dateTime8.withYearOfCentury(29);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06-15T21:49:33.257Z" + "'", str10.equals("2019-06-15T21:49:33.257Z"));
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long19 = dateTimeZone15.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime13.toMutableDateTime(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        long long23 = offsetDateTimeField18.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.era();
//        org.joda.time.DurationField durationField27 = iSOChronology24.seconds();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long33 = dateTimeZone29.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone29);
//        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate37 = dateTime34.toLocalDate();
//        int[] intArray39 = iSOChronology24.get((org.joda.time.ReadablePartial) localDate37, (long) (short) 10);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = offsetDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate37, locale40);
//        java.lang.String str42 = offsetDateTimeField18.getName();
//        boolean boolean44 = offsetDateTimeField18.isLeap((long) 17);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78573 + "'", int9 == 78573);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4406399976L) + "'", long23 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "15" + "'", str41.equals("15"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "dayOfMonth" + "'", str42.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        int int7 = dateTime6.getSecondOfMinute();
//        org.joda.time.DateTime.Property property8 = dateTime6.era();
//        org.joda.time.DateTime dateTime9 = property8.getDateTime();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) 100, false);
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZoneBuilder0, (java.lang.Object) dateTimeFormatterBuilder1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setFixedSavings("ISOChronology[UTC]", (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = dateTimeZoneBuilder0.addRecurringSavings("78569752", (int) (short) 100, 24, (int) (byte) 100, '4', 52, 19, (int) '4', true, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long17 = dateTimeZone13.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 10);
//        int int21 = dateTime20.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withFields(readablePartial22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        int int26 = dateTime11.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.minusMillis(100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
//        boolean boolean30 = dateTime28.isSupported(dateTimeFieldType29);
//        org.joda.time.DateTime.Property property31 = dateTime28.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78573 + "'", int9 == 78573);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78573 + "'", int21 == 78573);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(property31);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(0);
//        int int12 = dateTime8.getWeekyear();
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime15 = dateTime8.withDayOfYear(3);
//        java.util.Date date16 = dateTime15.toDate();
//        org.joda.time.DateTime dateTime18 = dateTime15.plusWeeks(0);
//        org.joda.time.DateTime.Property property19 = dateTime15.dayOfMonth();
//        org.joda.time.DateTime dateTime21 = property19.addToCopy(78546);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78573 + "'", int9 == 78573);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 78563);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendYearOfCentury((int) (byte) 1, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear((-1), true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendWeekOfWeekyear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendYearOfCentury(2000, 19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("UTC", "dayOfMonth", 1, 78541);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey(1560635348561L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 6787065600000L, "0");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType14, 0, 78542, 78564);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [78542,78564]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime9.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime12 = dateTime9.plusDays((int) 'a');
        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
        org.joda.time.DateTime dateTime14 = property13.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property13.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate13 = dateTime10.toLocalDate();
        long long15 = gregorianChronology3.set((org.joda.time.ReadablePartial) localDate13, 0L);
        int[] intArray17 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate13, (long) 78538);
        org.joda.time.DurationField durationField18 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560556800000L + "'", long15 == 1560556800000L);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(durationField18);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
//        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withLocale(locale4);
//        java.lang.StringBuffer stringBuffer6 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone8);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.minusMinutes((-28800000));
//        int int17 = dateTime13.getMonthOfYear();
//        org.joda.time.DateTime dateTime19 = dateTime13.plusMinutes(78568127);
//        try {
//            dateTimeFormatter5.printTo(stringBuffer6, (org.joda.time.ReadableInstant) dateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeParser3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560635384525L + "'", long14 == 1560635384525L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        java.util.Locale locale81 = null;
//        try {
//            java.lang.String str82 = unsupportedDateTimeField79.getAsShortText((-28800000), locale81);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78575 + "'", int24 == 78575);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78575 + "'", int44 == 78575);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long7 = dateTimeZone4.adjustOffset(1560635349338L, true);
//        long long9 = dateTimeZone1.getMillisKeepLocal(dateTimeZone4, 0L);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone1.getShortName((long) 10, locale11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long19 = dateTimeZone15.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone15);
//        int int21 = dateTime20.getYear();
//        org.joda.time.DateTime dateTime23 = dateTime20.plusMonths(0);
//        org.joda.time.DateTime dateTime25 = dateTime20.withCenturyOfEra(0);
//        int int26 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime20);
//        java.lang.Class<?> wildcardClass27 = dateTimeZone1.getClass();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635349338L + "'", long7 == 1560635349338L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("2019-09-20T21:49:07.284Z", 78558, (int) '#', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78558 for 2019-09-20T21:49:07.284Z must be in the range [35,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendClockhourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfHour(4, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "38", 78570, 78561);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        long long23 = offsetDateTimeField18.addWrapField((long) 3, (int) 'a');
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField18, 13, 1963850, 28);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 13 for dayOfMonth must be in the range [1963850,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78575 + "'", int9 == 78575);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 345600003L + "'", long23 == 345600003L);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        int int13 = property12.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField14 = property12.getField();
//        java.lang.String str15 = property12.getAsText();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long21 = dateTimeZone17.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) 10);
//        int int25 = dateTime24.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.withFields(readablePartial26);
//        org.joda.time.DateTime dateTime28 = dateTime24.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.dayOfMonth();
//        int int32 = dateTime24.get(dateTimeField31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 78541);
//        java.lang.String str35 = offsetDateTimeField34.getName();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, 78539);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = offsetDateTimeField34.getAsShortText((long) 0, locale39);
//        int int42 = offsetDateTimeField34.get(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.yearOfEra();
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology44);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long53 = dateTimeZone49.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone49);
//        org.joda.time.DateTime dateTime56 = dateTime54.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate57 = dateTime54.toLocalDate();
//        long long59 = gregorianChronology47.set((org.joda.time.ReadablePartial) localDate57, 0L);
//        int[] intArray61 = iSOChronology44.get((org.joda.time.ReadablePartial) localDate57, (long) 78538);
//        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField63 = iSOChronology62.secondOfDay();
//        org.joda.time.DurationField durationField64 = iSOChronology62.millis();
//        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long70 = dateTimeZone66.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime(dateTimeZone66);
//        int int72 = dateTime71.getSecondOfMinute();
//        org.joda.time.LocalDate localDate73 = dateTime71.toLocalDate();
//        int[] intArray75 = iSOChronology62.get((org.joda.time.ReadablePartial) localDate73, (long) 78539);
//        gregorianChronology43.validate((org.joda.time.ReadablePartial) localDate57, intArray75);
//        java.util.Locale locale77 = null;
//        java.lang.String str78 = offsetDateTimeField34.getAsShortText((org.joda.time.ReadablePartial) localDate57, locale77);
//        int int79 = property12.compareTo((org.joda.time.ReadablePartial) localDate57);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "38" + "'", str15.equals("38"));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 78576 + "'", int25 == 78576);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "dayOfMonth" + "'", str35.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "78542" + "'", str40.equals("78542"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 78542 + "'", int42 == 78542);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560556800000L + "'", long59 == 1560556800000L);
//        org.junit.Assert.assertNotNull(intArray61);
//        org.junit.Assert.assertNotNull(iSOChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 46 + "'", int72 == 46);
//        org.junit.Assert.assertNotNull(localDate73);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "15" + "'", str78.equals("15"));
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.era();
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.weekyear();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime6, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        org.joda.time.DateTime dateTime20 = property19.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 1560556800000L, "0");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(52);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate10, 0L);
        java.lang.String str13 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField15 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560556800000L + "'", long12 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.add((long) 78538, 78542873);
//        try {
//            int int84 = unsupportedDateTimeField79.get((long) 78549);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78577 + "'", int24 == 78577);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78577 + "'", int44 == 78577);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 6786104227278538L + "'", long82 == 6786104227278538L);
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.getDifferenceAsLong(1560635367969L, 1560635349937L);
//        try {
//            long long85 = unsupportedDateTimeField79.set((long) 78554, "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78577 + "'", int24 == 78577);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78577 + "'", int44 == 78577);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DurationField durationField5 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property12.getAsShortText(locale14);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "38" + "'", str15.equals("38"));
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.minusMinutes((-28800000));
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime6.withDurationAdded(readableDuration10, (int) (byte) 1);
//        org.joda.time.DateTime dateTime14 = dateTime12.minusYears((int) (short) 1);
//        org.joda.time.DateMidnight dateMidnight15 = dateTime12.toDateMidnight();
//        boolean boolean16 = dateTime12.isBeforeNow();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635387953L + "'", long7 == 1560635387953L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long17 = dateTimeZone13.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 10);
//        int int21 = dateTime20.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withFields(readablePartial22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        int int26 = dateTime11.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.minusMillis(100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
//        try {
//            org.joda.time.DateTime.Property property30 = dateTime28.property(dateTimeFieldType29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78578 + "'", int9 == 78578);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78578 + "'", int21 == 78578);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        try {
//            int int81 = unsupportedDateTimeField79.getMaximumValue(1560635387953L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78578 + "'", int24 == 78578);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78578 + "'", int44 == 78578);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(0);
//        int int12 = dateTime8.getWeekyear();
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime15 = dateTime8.withDayOfYear(3);
//        java.util.Date date16 = dateTime15.toDate();
//        org.joda.time.DateTime dateTime18 = dateTime15.plusWeeks(0);
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime15.withDayOfMonth(292278993);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78578 + "'", int9 == 78578);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long7 = dateTimeZone3.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds((int) (short) 10);
//        int int11 = dateTime10.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withFields(readablePartial12);
//        org.joda.time.DateTime dateTime14 = dateTime10.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime16 = dateTime10.withMillis((long) 'a');
//        org.joda.time.DateTime dateTime18 = dateTime10.plus((long) 331);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78578 + "'", int11 == 78578);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime.Property property3 = dateTime2.year();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
//        int int6 = dateTime5.getWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getShortName(0L, locale18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter14.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = dateTime13.toDateTime(dateTimeZone16);
//        int int22 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        boolean boolean24 = dateTime5.isSupported(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(78537);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder10.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatterBuilder20.toParser();
        boolean boolean22 = dateTimeFormatterBuilder20.canBuildFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withLocale(locale26);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatter27.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder20.append(dateTimePrinter28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder2.append(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(78537);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(78576, 1963850);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths(0);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks(39);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("78542");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.getDifferenceAsLong(1560635367969L, 1560635349937L);
//        org.joda.time.ReadablePartial readablePartial83 = null;
//        try {
//            int int84 = unsupportedDateTimeField79.getMaximumValue(readablePartial83);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78579 + "'", int24 == 78579);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78579 + "'", int44 == 78579);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("UTC", "dayOfMonth", 1, 78541);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) 39);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        java.lang.String str19 = offsetDateTimeField18.getName();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long25 = dateTimeZone21.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.DateTime dateTime28 = dateTime26.minusSeconds((int) (short) 10);
//        int int29 = dateTime28.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime28.withFields(readablePartial30);
//        org.joda.time.DateTime dateTime32 = dateTime28.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.dayOfMonth();
//        int int36 = dateTime28.get(dateTimeField35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 78541);
//        long long40 = offsetDateTimeField38.roundFloor((long) 9);
//        long long43 = offsetDateTimeField38.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology44.era();
//        org.joda.time.DurationField durationField47 = iSOChronology44.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long53 = dateTimeZone49.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone49);
//        org.joda.time.DateTime dateTime56 = dateTime54.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate57 = dateTime54.toLocalDate();
//        int[] intArray59 = iSOChronology44.get((org.joda.time.ReadablePartial) localDate57, (long) (short) 10);
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = offsetDateTimeField38.getAsText((org.joda.time.ReadablePartial) localDate57, locale60);
//        int int62 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) localDate57);
//        org.joda.time.DurationField durationField63 = offsetDateTimeField18.getDurationField();
//        int int65 = offsetDateTimeField18.get(0L);
//        java.lang.String str66 = offsetDateTimeField18.getName();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78579 + "'", int9 == 78579);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 78579 + "'", int29 == 78579);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 15 + "'", int36 == 15);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-4406399976L) + "'", long43 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "15" + "'", str61.equals("15"));
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 78542 + "'", int62 == 78542);
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 78542 + "'", int65 == 78542);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "dayOfMonth" + "'", str66.equals("dayOfMonth"));
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        boolean boolean8 = gregorianChronology6.equals((java.lang.Object) "GregorianChronology[America/Los_Angeles]");
        try {
            long long16 = gregorianChronology6.getDateTimeMillis(78542873, 78549, 78546, 78567, (int) (byte) -1, 0, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78567 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        long long23 = offsetDateTimeField18.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.era();
//        org.joda.time.DurationField durationField27 = iSOChronology24.seconds();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long33 = dateTimeZone29.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone29);
//        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate37 = dateTime34.toLocalDate();
//        int[] intArray39 = iSOChronology24.get((org.joda.time.ReadablePartial) localDate37, (long) (short) 10);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = offsetDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate37, locale40);
//        java.lang.String str42 = offsetDateTimeField18.getName();
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long48 = dateTimeZone44.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(dateTimeZone44);
//        org.joda.time.DateTime dateTime51 = dateTime49.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate52 = dateTime49.toLocalDate();
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = offsetDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate52, locale53);
//        long long56 = offsetDateTimeField18.roundHalfEven((long) 28);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78579 + "'", int9 == 78579);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4406399976L) + "'", long23 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "15" + "'", str41.equals("15"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "dayOfMonth" + "'", str42.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "15" + "'", str54.equals("15"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DurationField durationField5 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = iSOChronology0.add(readablePeriod7, (long) 53, 78570);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 53L + "'", long10 == 53L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 78564, 78571);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DurationField durationField5 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.dayOfMonth();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray11 = iSOChronology0.get(readablePeriod8, (long) 78562, (long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.era();
//        boolean boolean18 = iSOChronology14.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DateTime dateTime19 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DurationField durationField20 = iSOChronology14.halfdays();
//        org.joda.time.DurationFieldType durationFieldType21 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField23 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType21, 11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78579 + "'", int9 == 78579);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(durationField20);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("2019-06-15T21:49:09.045Z", 78542873, (int) (byte) 10, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78542873 for 2019-06-15T21:49:09.045Z must be in the range [10,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfHalfday((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendCenturyOfEra(78537, (-28800000));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendTimeZoneName();
        boolean boolean12 = dateTimeFormatterBuilder11.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.add((long) 78538, 78542873);
//        try {
//            int int84 = unsupportedDateTimeField79.getMaximumValue((long) 78558);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78579 + "'", int24 == 78579);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78579 + "'", int44 == 78579);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 6786104227278538L + "'", long82 == 6786104227278538L);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        int int20 = offsetDateTimeField18.getLeapAmount((long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long26 = dateTimeZone22.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime30 = dateTime29.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime32 = dateTime29.plusDays((int) 'a');
//        org.joda.time.LocalDate localDate33 = dateTime29.toLocalDate();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate33, locale34);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long41 = dateTimeZone37.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone37);
//        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
//        java.util.Locale locale44 = null;
//        try {
//            java.lang.String str45 = offsetDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localTime43, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78580 + "'", int9 == 78580);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "15" + "'", str35.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertNotNull(localTime43);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        long long23 = offsetDateTimeField18.addWrapField((long) 3, (int) 'a');
//        org.joda.time.DateTimeField dateTimeField24 = offsetDateTimeField18.getWrappedField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType25, 78544);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78580 + "'", int9 == 78580);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 345600003L + "'", long23 == 345600003L);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 1560635372010L, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("2019", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.minusMinutes((-28800000));
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay(48);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635390358L + "'", long7 == 1560635390358L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("38", "hi!");
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Coordinated Universal Time");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(263, 78538, 30, 2019, 100, 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "78542");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 78567);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        int int82 = unsupportedDateTimeField79.getDifference(1560635357478L, (long) 263);
//        try {
//            long long84 = unsupportedDateTimeField79.roundFloor((long) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78580 + "'", int24 == 78580);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78580 + "'", int44 == 78580);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 18062 + "'", int82 == 18062);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTwoDigitWeekyear((int) (short) -1, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendWeekOfWeekyear((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder22.appendClockhourOfHalfday((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder29.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendFractionOfDay(2000, 78551);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long44 = dateTimeZone40.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone40);
//        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime48 = dateTime47.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime50 = dateTime47.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property51 = dateTime50.weekOfWeekyear();
//        org.joda.time.DateTime dateTime52 = property51.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property51.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder35.appendFraction(dateTimeFieldType53, 6, (int) (short) 100);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType53, 263, 20, 0);
//        boolean boolean62 = offsetDateTimeField60.isLeap((long) 78542873);
//        java.lang.String str64 = offsetDateTimeField60.getAsText((long) 15);
//        int int66 = offsetDateTimeField60.getMinimumValue((long) 45);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78581 + "'", int9 == 78581);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "78805" + "'", str64.equals("78805"));
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 78805 + "'", int66 == 78805);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        long long23 = offsetDateTimeField18.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.era();
//        org.joda.time.DurationField durationField27 = iSOChronology24.seconds();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long33 = dateTimeZone29.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone29);
//        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate37 = dateTime34.toLocalDate();
//        int[] intArray39 = iSOChronology24.get((org.joda.time.ReadablePartial) localDate37, (long) (short) 10);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = offsetDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate37, locale40);
//        java.lang.String str42 = offsetDateTimeField18.getName();
//        org.joda.time.ReadablePartial readablePartial43 = null;
//        int int44 = offsetDateTimeField18.getMaximumValue(readablePartial43);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78581 + "'", int9 == 78581);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4406399976L) + "'", long23 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "15" + "'", str41.equals("15"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "dayOfMonth" + "'", str42.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78572 + "'", int44 == 78572);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute(78552, 78551);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("78556", true, 78568, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfEra();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = dateTime11.toLocalDate();
//        long long16 = gregorianChronology4.set((org.joda.time.ReadablePartial) localDate14, 0L);
//        int[] intArray18 = iSOChronology1.get((org.joda.time.ReadablePartial) localDate14, (long) 78538);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.secondOfDay();
//        org.joda.time.DurationField durationField21 = iSOChronology19.millis();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long27 = dateTimeZone23.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone23);
//        int int29 = dateTime28.getSecondOfMinute();
//        org.joda.time.LocalDate localDate30 = dateTime28.toLocalDate();
//        int[] intArray32 = iSOChronology19.get((org.joda.time.ReadablePartial) localDate30, (long) 78539);
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate14, intArray32);
//        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology0.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("UTC", "dayOfMonth", 1, 78541);
//        org.joda.time.Chronology chronology40 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone39);
//        java.util.TimeZone timeZone41 = fixedDateTimeZone39.toTimeZone();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560556800000L + "'", long16 == 1560556800000L);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 51 + "'", int29 == 51);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(timeZone41);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(331);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfDay(0);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendClockhourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfDay(2000, 78551);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long23 = dateTimeZone19.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime26 = dateTime24.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime27 = dateTime26.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime29 = dateTime26.plusDays((int) 'a');
        org.joda.time.DateTime.Property property30 = dateTime29.weekOfWeekyear();
        org.joda.time.DateTime dateTime31 = property30.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder14.appendFraction(dateTimeFieldType32, 6, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder14.appendPattern("1309");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withLocale(locale4);
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withLocale(locale6);
        int int8 = dateTimeFormatter7.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2000 + "'", int8 == 2000);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        int int7 = dateTime6.getYear();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths(0);
//        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear((int) '#');
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear((int) (short) -1, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendWeekOfWeekyear((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder15.appendClockhourOfHalfday((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder22.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendFractionOfDay(2000, 78551);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long37 = dateTimeZone33.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone33);
//        org.joda.time.DateTime dateTime40 = dateTime38.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime41 = dateTime40.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime43 = dateTime40.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property44 = dateTime43.weekOfWeekyear();
//        org.joda.time.DateTime dateTime45 = property44.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property44.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder28.appendFraction(dateTimeFieldType46, 6, (int) (short) 100);
//        boolean boolean50 = dateTime13.isSupported(dateTimeFieldType46);
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long56 = dateTimeZone52.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(dateTimeZone52);
//        org.joda.time.DateTime dateTime59 = dateTime57.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime60 = dateTime59.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime62 = dateTime59.withMillisOfSecond(9);
//        boolean boolean64 = dateTime62.isEqual((long) 78547);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale69 = null;
//        java.lang.String str70 = dateTimeZone67.getShortName(0L, locale69);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = dateTimeFormatter65.withZone(dateTimeZone67);
//        java.lang.String str72 = dateTime62.toString(dateTimeFormatter71);
//        int int73 = dateTime13.compareTo((org.joda.time.ReadableInstant) dateTime62);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(mutableDateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(mutableDateTime60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter65);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "UTC" + "'", str70.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "2019-W24-6" + "'", str72.equals("2019-W24-6"));
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatterBuilder9.toParser();
        boolean boolean11 = dateTimeFormatterBuilder9.canBuildFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter12.withLocale(locale15);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder9.append(dateTimePrinter17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter23.withLocale(locale26);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatter27.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder29.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder30.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder30.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder36.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder38.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder39.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder39.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder39.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder45.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray47 = new org.joda.time.format.DateTimeParser[] { dateTimeParser37, dateTimeParser46 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder22.append(dateTimePrinter28, dateTimeParserArray47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder1.append(dateTimePrinter17, dateTimeParserArray47);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long55 = dateTimeZone51.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(dateTimeZone51);
        org.joda.time.DateTime dateTime58 = dateTime56.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime59 = dateTime58.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime61 = dateTime58.plusDays((int) 'a');
        org.joda.time.DateTime.Property property62 = dateTime61.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
        int int70 = dateTime69.getYear();
        org.joda.time.DateTime dateTime72 = dateTime69.plusMonths(0);
        int int73 = dateTime72.getCenturyOfEra();
        long long74 = property62.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime72);
        boolean boolean75 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeParserArray47, (java.lang.Object) long74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeParser46);
        org.junit.Assert.assertNotNull(dateTimeParserArray47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(mutableDateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 20 + "'", int73 == 20);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 13L + "'", long74 == 13L);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
//        int int5 = dateTime4.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.getDifferenceAsLong(1560635367969L, 1560635349937L);
//        java.util.Locale locale84 = null;
//        try {
//            java.lang.String str85 = unsupportedDateTimeField79.getAsText((int) ' ', locale84);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78583 + "'", int24 == 78583);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78583 + "'", int44 == 78583);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        boolean boolean5 = dateTime4.isBeforeNow();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getShortName(0L, locale8);
//        try {
//            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(78539, 0, 0, 9, 331, dateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 331 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone9.getShortName(0L, locale11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter7.withZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime14 = dateTime6.toDateTime(dateTimeZone9);
//        int int15 = dateTime14.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 78593 + "'", int15 == 78593);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withLocale(locale7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder26.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray28 = new org.joda.time.format.DateTimeParser[] { dateTimeParser18, dateTimeParser27 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder3.appendHourOfHalfday(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendYearOfEra(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeParserArray28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(78539);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear(31);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 10);
//        java.lang.String str14 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20190615T214943Z" + "'", str14.equals("20190615T214943Z"));
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long17 = dateTimeZone13.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) (short) 10);
//        int int21 = dateTime20.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.withFields(readablePartial22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.minus(readablePeriod24);
//        int int26 = dateTime11.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime25.withMillisOfSecond(39);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime25.minus(readablePeriod29);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78583 + "'", int9 == 78583);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78583 + "'", int21 == 78583);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
//        long long12 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate10, 0L);
//        java.lang.String str13 = gregorianChronology0.toString();
//        int int14 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.dayOfWeek();
//        long long19 = gregorianChronology0.add(1560635370364L, (long) (short) 100, 78543);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560556800000L + "'", long12 == 1560556800000L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560643224664L + "'", long19 == 1560643224664L);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfSecond((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendTwoDigitYear(15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfSecond(78537);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder9.append(dateTimeParser18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder1.appendOptional(dateTimeParser18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder1.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) (byte) 0);
        org.joda.time.DurationField durationField5 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTwoDigitWeekyear((int) (short) -1, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendWeekOfWeekyear((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder22.appendClockhourOfHalfday((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder29.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendFractionOfDay(2000, 78551);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long44 = dateTimeZone40.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone40);
//        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime48 = dateTime47.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime50 = dateTime47.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property51 = dateTime50.weekOfWeekyear();
//        org.joda.time.DateTime dateTime52 = property51.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property51.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder35.appendFraction(dateTimeFieldType53, 6, (int) (short) 100);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType53, 263, 20, 0);
//        boolean boolean62 = offsetDateTimeField60.isLeap((long) 78542873);
//        org.joda.time.DateTimeField dateTimeField63 = offsetDateTimeField60.getWrappedField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78583 + "'", int9 == 78583);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTimeISO();
        org.joda.time.DateTime dateTime12 = dateTime7.minusMinutes(331);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfDay(0);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 78805, chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply(292278993, 78542873);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 292278993 * 78542873");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime.Property property4 = dateTime3.era();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = dateTime11.toDateTimeISO();
//        org.joda.time.DateTime dateTime16 = dateTime11.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.era();
//        boolean boolean21 = iSOChronology17.equals((java.lang.Object) (byte) 0);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.weekyear();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) dateTime11, (org.joda.time.Chronology) iSOChronology17);
//        boolean boolean25 = dateTime23.isAfter(0L);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = dateTimeZone27.getShortName(0L, locale29);
//        org.joda.time.DateTime dateTime31 = dateTime23.toDateTime(dateTimeZone27);
//        org.joda.time.DateTime dateTime32 = dateTime3.withZoneRetainFields(dateTimeZone27);
//        org.joda.time.DateTime.Property property33 = dateTime32.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UTC" + "'", str30.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
        int int8 = dateTime7.getYear();
        org.joda.time.DateTime dateTime10 = dateTime7.plusMonths(0);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) '#');
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder16.appendClockhourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder23.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendFractionOfDay(2000, 78551);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long38 = dateTimeZone34.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone34);
        org.joda.time.DateTime dateTime41 = dateTime39.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime42 = dateTime41.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime44 = dateTime41.plusDays((int) 'a');
        org.joda.time.DateTime.Property property45 = dateTime44.weekOfWeekyear();
        org.joda.time.DateTime dateTime46 = property45.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder29.appendFraction(dateTimeFieldType47, 6, (int) (short) 100);
        boolean boolean51 = dateTime14.isSupported(dateTimeFieldType47);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField52 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        try {
//            long long82 = unsupportedDateTimeField79.addWrapField(6786104227278538L, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78585 + "'", int24 == 78585);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78585 + "'", int44 == 78585);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long16 = dateTimeZone12.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone12);
        int int18 = dateTime17.getYear();
        org.joda.time.DateTime dateTime20 = dateTime17.plusMonths(0);
        org.joda.time.DateTime dateTime22 = dateTime20.withWeekyear((int) '#');
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder26.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder26.appendClockhourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder33.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder39.appendFractionOfDay(2000, 78551);
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long48 = dateTimeZone44.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(dateTimeZone44);
        org.joda.time.DateTime dateTime51 = dateTime49.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime52 = dateTime51.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime54 = dateTime51.plusDays((int) 'a');
        org.joda.time.DateTime.Property property55 = dateTime54.weekOfWeekyear();
        org.joda.time.DateTime dateTime56 = property55.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property55.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder39.appendFraction(dateTimeFieldType57, 6, (int) (short) 100);
        boolean boolean61 = dateTime24.isSupported(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder4.appendDecimal(dateTimeFieldType57, 78549, 4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("2019", 78539, 78577, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78539 for 2019 must be in the range [78577,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.add((long) 78538, 78542873);
//        try {
//            long long84 = unsupportedDateTimeField79.roundHalfCeiling((long) (-28800000));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78585 + "'", int24 == 78585);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78585 + "'", int44 == 78585);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 6786104227278538L + "'", long82 == 6786104227278538L);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfDay((int) (short) 1, 78578);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTwoDigitWeekyear((int) (short) -1, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendWeekOfWeekyear((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder22.appendClockhourOfHalfday((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder29.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendFractionOfDay(2000, 78551);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long44 = dateTimeZone40.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone40);
//        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime48 = dateTime47.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime50 = dateTime47.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property51 = dateTime50.weekOfWeekyear();
//        org.joda.time.DateTime dateTime52 = property51.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property51.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder35.appendFraction(dateTimeFieldType53, 6, (int) (short) 100);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType53, 263, 20, 0);
//        long long62 = offsetDateTimeField18.roundHalfEven(0L);
//        int int64 = offsetDateTimeField18.getMinimumValue((-5756400001L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78585 + "'", int9 == 78585);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 78542 + "'", int64 == 78542);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        org.joda.time.DurationField durationField80 = unsupportedDateTimeField79.getDurationField();
//        try {
//            long long82 = unsupportedDateTimeField79.roundHalfFloor((long) 78575);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78585 + "'", int24 == 78585);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78585 + "'", int44 == 78585);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertNotNull(durationField80);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.minusMinutes((-28800000));
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime6.withDurationAdded(readableDuration10, (int) (byte) 1);
//        java.util.Locale locale13 = null;
//        java.util.Calendar calendar14 = dateTime6.toCalendar(locale13);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635396027L + "'", long7 == 1560635396027L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(calendar14);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendClockhourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendFractionOfDay(2000, 78551);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long24 = dateTimeZone20.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime27.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime30 = dateTime27.plusDays((int) 'a');
        org.joda.time.DateTime.Property property31 = dateTime30.weekOfWeekyear();
        org.joda.time.DateTime dateTime32 = property31.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property31.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder15.appendFraction(dateTimeFieldType33, 6, (int) (short) 100);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        java.lang.String str19 = offsetDateTimeField18.getName();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.yearOfEra();
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long30 = dateTimeZone26.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.DateTime dateTime33 = dateTime31.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate34 = dateTime31.toLocalDate();
//        long long36 = gregorianChronology24.set((org.joda.time.ReadablePartial) localDate34, 0L);
//        int[] intArray38 = iSOChronology21.get((org.joda.time.ReadablePartial) localDate34, (long) 78538);
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.secondOfDay();
//        org.joda.time.DurationField durationField41 = iSOChronology39.millis();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long47 = dateTimeZone43.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone43);
//        int int49 = dateTime48.getSecondOfMinute();
//        org.joda.time.LocalDate localDate50 = dateTime48.toLocalDate();
//        int[] intArray52 = iSOChronology39.get((org.joda.time.ReadablePartial) localDate50, (long) 78539);
//        gregorianChronology20.validate((org.joda.time.ReadablePartial) localDate34, intArray52);
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology55.yearOfEra();
//        org.joda.time.Chronology chronology57 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology55);
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long64 = dateTimeZone60.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime(dateTimeZone60);
//        org.joda.time.DateTime dateTime67 = dateTime65.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate68 = dateTime65.toLocalDate();
//        long long70 = gregorianChronology58.set((org.joda.time.ReadablePartial) localDate68, 0L);
//        int[] intArray72 = iSOChronology55.get((org.joda.time.ReadablePartial) localDate68, (long) 78538);
//        java.util.Locale locale74 = null;
//        try {
//            int[] intArray75 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate34, 20, intArray72, "GregorianChronology[UTC]", locale74);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78586 + "'", int9 == 78586);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560556800000L + "'", long36 == 1560556800000L);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 56 + "'", int49 == 56);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(localDate68);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560556800000L + "'", long70 == 1560556800000L);
//        org.junit.Assert.assertNotNull(intArray72);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(17, 78579, 78575, 78805);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 78596 + "'", int4 == 78596);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        int int13 = property12.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField14 = property12.getField();
        org.joda.time.DateTime dateTime15 = property12.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        long long23 = offsetDateTimeField18.add((long) 24, (-51L));
//        org.joda.time.DurationField durationField24 = offsetDateTimeField18.getDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.secondOfDay();
//        org.joda.time.DurationField durationField27 = iSOChronology25.millis();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long33 = dateTimeZone29.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone29);
//        int int35 = dateTime34.getSecondOfMinute();
//        org.joda.time.LocalDate localDate36 = dateTime34.toLocalDate();
//        int[] intArray38 = iSOChronology25.get((org.joda.time.ReadablePartial) localDate36, (long) 78539);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.secondOfDay();
//        org.joda.time.DurationField durationField42 = iSOChronology40.millis();
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long48 = dateTimeZone44.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(dateTimeZone44);
//        int int50 = dateTime49.getSecondOfMinute();
//        org.joda.time.LocalDate localDate51 = dateTime49.toLocalDate();
//        int[] intArray53 = iSOChronology40.get((org.joda.time.ReadablePartial) localDate51, (long) 78539);
//        try {
//            int[] intArray55 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate36, 35, intArray53, 78542);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78586 + "'", int9 == 78586);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4406399976L) + "'", long23 == (-4406399976L));
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 56 + "'", int35 == 56);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 56 + "'", int50 == 56);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertNotNull(intArray53);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 78563);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfSecond(9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        long long17 = cachedDateTimeZone13.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone15, (long) (byte) 0);
        long long19 = cachedDateTimeZone13.previousTransition((long) 78539);
        org.joda.time.DateTime dateTime20 = dateTime11.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        boolean boolean21 = dateTime20.isAfterNow();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 78539L + "'", long19 == 78539L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType14, 78571, 78557, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78571 for weekOfWeekyear must be in the range [78557,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTwoDigitWeekyear((int) (short) -1, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendWeekOfWeekyear((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder22.appendClockhourOfHalfday((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder29.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendFractionOfDay(2000, 78551);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long44 = dateTimeZone40.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone40);
//        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime48 = dateTime47.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime50 = dateTime47.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property51 = dateTime50.weekOfWeekyear();
//        org.joda.time.DateTime dateTime52 = property51.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property51.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder35.appendFraction(dateTimeFieldType53, 6, (int) (short) 100);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType53, 263, 20, 0);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField60.getLeapDurationField();
//        java.util.Locale locale63 = null;
//        java.lang.String str64 = offsetDateTimeField60.getAsShortText((long) (-1), locale63);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78586 + "'", int9 == 78586);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNull(durationField61);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "78835" + "'", str64.equals("78835"));
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime.Property property4 = dateTime3.era();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) (short) 10);
//        int int14 = dateTime13.getSecondOfDay();
//        int int15 = dateTime13.getMillisOfDay();
//        try {
//            long long16 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 78586 + "'", int14 == 78586);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 78586664 + "'", int15 == 78586664);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        org.joda.time.DurationField durationField80 = unsupportedDateTimeField79.getDurationField();
//        try {
//            long long83 = unsupportedDateTimeField79.addWrapField((long) 78570, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78586 + "'", int24 == 78586);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78586 + "'", int44 == 78586);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertNotNull(durationField80);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(0);
//        int int12 = dateTime8.getWeekyear();
//        org.joda.time.DateTime dateTime14 = dateTime8.minusMonths(24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendFractionOfSecond((int) (byte) 10, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatterBuilder16.toParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatterBuilder16.toFormatter();
//        java.lang.String str23 = dateTime8.toString(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78586 + "'", int9 == 78586);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeParser21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Saturday8550000000Jun" + "'", str23.equals("Saturday8550000000Jun"));
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        int int8 = cachedDateTimeZone6.getOffset((long) (short) 1);
        java.util.TimeZone timeZone9 = cachedDateTimeZone6.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(78571245, 19, (int) (short) 0, 78560, (int) (short) 100, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78560 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (-28800000), 78575, 45);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for  must be in the range [78575,45]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("GregorianChronology[America/Los_Angeles]", 78542, 78543, (-1), ' ', 78542, 78542, (int) ' ', false, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder11.addCutover(0, '#', 78563, 78542, 78572, false, 78587);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
//        org.joda.time.DateTime dateTime12 = dateTime6.toDateTimeISO();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
//        long long14 = dateTime12.getMillis();
//        org.joda.time.DateTime.Property property15 = dateTime12.yearOfEra();
//        org.joda.time.DateTime dateTime17 = dateTime12.plusSeconds(24);
//        java.util.Locale locale18 = null;
//        java.util.Calendar calendar19 = dateTime17.toCalendar(locale18);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560635397218L + "'", long14 == 1560635397218L);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(calendar19);
//    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        java.lang.String str19 = offsetDateTimeField18.getName();
//        int int21 = offsetDateTimeField18.get((long) (byte) -1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.yearOfEra();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology22);
//        org.joda.time.DateTime.Property property25 = dateTime24.year();
//        org.joda.time.LocalDate localDate26 = dateTime24.toLocalDate();
//        int[] intArray34 = new int[] { 78565, 15, 78575, (byte) 0, (-28800000), 9 };
//        try {
//            int[] intArray36 = offsetDateTimeField18.add((org.joda.time.ReadablePartial) localDate26, 17, intArray34, 45);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 17");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78587 + "'", int9 == 78587);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78572 + "'", int21 == 78572);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Coordinated Universal Time");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundFloor((long) 9);
//        long long23 = offsetDateTimeField18.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.era();
//        org.joda.time.DurationField durationField27 = iSOChronology24.seconds();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long33 = dateTimeZone29.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone29);
//        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate37 = dateTime34.toLocalDate();
//        int[] intArray39 = iSOChronology24.get((org.joda.time.ReadablePartial) localDate37, (long) (short) 10);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = offsetDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate37, locale40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField18.getAsShortText((long) 31, locale43);
//        boolean boolean45 = offsetDateTimeField18.isLenient();
//        int int48 = offsetDateTimeField18.getDifference((long) (-28800000), (long) '#');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78587 + "'", int9 == 78587);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4406399976L) + "'", long23 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "15" + "'", str41.equals("15"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "78542" + "'", str44.equals("78542"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long10 = cachedDateTimeZone6.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone8, (long) (byte) 0);
        long long13 = cachedDateTimeZone6.convertLocalToUTC((long) 30, true);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(78566, 45, 292278993, 78568127, 0, (org.joda.time.DateTimeZone) cachedDateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78568127 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 30L + "'", long13 == 30L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        boolean boolean8 = gregorianChronology6.equals((java.lang.Object) "GregorianChronology[America/Los_Angeles]");
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate13 = dateTime10.toLocalDate();
//        long long15 = gregorianChronology3.set((org.joda.time.ReadablePartial) localDate13, 0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.yearOfEra();
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long26 = dateTimeZone22.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone22);
//        org.joda.time.DateTime dateTime29 = dateTime27.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = dateTime27.toLocalDate();
//        long long32 = gregorianChronology20.set((org.joda.time.ReadablePartial) localDate30, 0L);
//        int[] intArray34 = iSOChronology17.get((org.joda.time.ReadablePartial) localDate30, (long) 78538);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.secondOfDay();
//        org.joda.time.DurationField durationField37 = iSOChronology35.millis();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long43 = dateTimeZone39.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone39);
//        int int45 = dateTime44.getSecondOfMinute();
//        org.joda.time.LocalDate localDate46 = dateTime44.toLocalDate();
//        int[] intArray48 = iSOChronology35.get((org.joda.time.ReadablePartial) localDate46, (long) 78539);
//        gregorianChronology16.validate((org.joda.time.ReadablePartial) localDate30, intArray48);
//        iSOChronology0.validate((org.joda.time.ReadablePartial) localDate13, intArray48);
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long57 = dateTimeZone53.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone53);
//        org.joda.time.DateTime dateTime60 = dateTime58.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate61 = dateTime58.toLocalDate();
//        long long63 = gregorianChronology51.set((org.joda.time.ReadablePartial) localDate61, 0L);
//        boolean boolean64 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate61);
//        int[] intArray65 = null;
//        try {
//            iSOChronology0.validate((org.joda.time.ReadablePartial) localDate61, intArray65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560556800000L + "'", long15 == 1560556800000L);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560556800000L + "'", long32 == 1560556800000L);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 57 + "'", int45 == 57);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560556800000L + "'", long63 == 1560556800000L);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime5 = property3.setCopy(78585);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        int int7 = dateTime6.getSecondOfMinute();
//        org.joda.time.DateTime.Property property8 = dateTime6.era();
//        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long16 = dateTimeZone12.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds((int) (short) 10);
//        int int20 = dateTime19.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.withFields(readablePartial21);
//        org.joda.time.DateTime dateTime23 = dateTime19.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.dayOfMonth();
//        int int27 = dateTime19.get(dateTimeField26);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 78541);
//        long long31 = offsetDateTimeField29.roundFloor((long) 9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((int) (short) -1, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.appendWeekOfWeekyear((int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder33.appendClockhourOfHalfday((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder40.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendFractionOfDay(2000, 78551);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long55 = dateTimeZone51.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(dateTimeZone51);
//        org.joda.time.DateTime dateTime58 = dateTime56.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime59 = dateTime58.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime61 = dateTime58.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property62 = dateTime61.weekOfWeekyear();
//        org.joda.time.DateTime dateTime63 = property62.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property62.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder46.appendFraction(dateTimeFieldType64, 6, (int) (short) 100);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField29, dateTimeFieldType64, 263, 20, 0);
//        boolean boolean72 = dateTime10.isSupported(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57 + "'", int7 == 57);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 78587 + "'", int20 == 78587);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(mutableDateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("78835", 78557, 5, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78557 for 78835 must be in the range [5,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Coordinated Universal Time");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported"));
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property8 = dateTime6.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfCeilingCopy();
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
//        int int11 = dateTime9.getSecondOfDay();
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime9.withMinuteOfHour(78580);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78580 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635398701L + "'", long7 == 1560635398701L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.getDifferenceAsLong(1560635367969L, 1560635349937L);
//        org.joda.time.DurationField durationField83 = unsupportedDateTimeField79.getDurationField();
//        try {
//            long long85 = unsupportedDateTimeField79.roundHalfCeiling(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78588 + "'", int24 == 78588);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78588 + "'", int44 == 78588);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//        org.junit.Assert.assertNotNull(durationField83);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(78537, 78559, (int) (short) -1, 78588, 78569, 15, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78588 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName(0L, locale3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(property6);
//    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
//        int int24 = dateTime23.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
//        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
//        int int31 = dateTime23.get(dateTimeField30);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
//        java.lang.String str34 = offsetDateTimeField33.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
//        int int44 = dateTime43.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
//        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
//        int int51 = dateTime43.get(dateTimeField50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
//        long long55 = offsetDateTimeField53.roundFloor((long) 9);
//        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
//        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
//        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
//        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
//        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
//        long long82 = unsupportedDateTimeField79.add((long) 78538, 78542873);
//        try {
//            java.lang.String str84 = unsupportedDateTimeField79.getAsText(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78589 + "'", int24 == 78589);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78589 + "'", int44 == 78589);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "15" + "'", str76.equals("15"));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 6786104227278538L + "'", long82 == 6786104227278538L);
//    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute(78552, 78551);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime15 = dateTime12.plusDays((int) 'a');
//        org.joda.time.DateTime.Property property16 = dateTime15.weekOfWeekyear();
//        org.joda.time.DateTime dateTime17 = property16.withMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long24 = dateTimeZone20.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds((int) (short) 10);
//        int int28 = dateTime27.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.withFields(readablePartial29);
//        org.joda.time.DateTime dateTime31 = dateTime27.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.dayOfMonth();
//        int int35 = dateTime27.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 78541);
//        java.lang.String str38 = offsetDateTimeField37.getName();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long44 = dateTimeZone40.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone40);
//        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds((int) (short) 10);
//        int int48 = dateTime47.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime47.withFields(readablePartial49);
//        org.joda.time.DateTime dateTime51 = dateTime47.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.dayOfMonth();
//        int int55 = dateTime47.get(dateTimeField54);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 78541);
//        long long59 = offsetDateTimeField57.roundFloor((long) 9);
//        long long62 = offsetDateTimeField57.add((long) 24, (-51L));
//        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = iSOChronology63.era();
//        org.joda.time.DurationField durationField66 = iSOChronology63.seconds();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long72 = dateTimeZone68.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone68);
//        org.joda.time.DateTime dateTime75 = dateTime73.minusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate76 = dateTime73.toLocalDate();
//        int[] intArray78 = iSOChronology63.get((org.joda.time.ReadablePartial) localDate76, (long) (short) 10);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = offsetDateTimeField57.getAsText((org.joda.time.ReadablePartial) localDate76, locale79);
//        int int81 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) localDate76);
//        org.joda.time.DurationField durationField82 = offsetDateTimeField37.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField83 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField82);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder84.appendClockhourOfDay(13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 78589 + "'", int28 == 78589);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "dayOfMonth" + "'", str38.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 78589 + "'", int48 == 78589);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 15 + "'", int55 == 15);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-4406399976L) + "'", long62 == (-4406399976L));
//        org.junit.Assert.assertNotNull(iSOChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(durationField66);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertNotNull(intArray78);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "15" + "'", str80.equals("15"));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 78542 + "'", int81 == 78542);
//        org.junit.Assert.assertNotNull(durationField82);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField83);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder86);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        boolean boolean8 = gregorianChronology6.equals((java.lang.Object) "GregorianChronology[America/Los_Angeles]");
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
//        int int9 = dateTime8.getSecondOfDay();
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
//        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
//        int int16 = dateTime8.get(dateTimeField15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
//        long long20 = offsetDateTimeField18.roundHalfEven((long) (byte) 1);
//        java.util.Locale locale21 = null;
//        int int22 = offsetDateTimeField18.getMaximumTextLength(locale21);
//        int int24 = offsetDateTimeField18.get(1560635377962L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78589 + "'", int9 == 78589);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 78556 + "'", int24 == 78556);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.secondOfDay();
//        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfDay();
//        org.joda.time.DurationField durationField6 = iSOChronology4.millis();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone8);
//        int int14 = dateTime13.getSecondOfMinute();
//        org.joda.time.LocalDate localDate15 = dateTime13.toLocalDate();
//        int[] intArray17 = iSOChronology4.get((org.joda.time.ReadablePartial) localDate15, (long) 78539);
//        long long19 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate15, 25L);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        try {
//            int[] intArray23 = iSOChronology0.get(readablePeriod20, 6786104227278538L, (long) 78571245);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560556800025L + "'", long19 == 1560556800025L);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1560635352507L);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        long long5 = cachedDateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone3, (long) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone8.getShortName(0L, locale10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter6.withZone(dateTimeZone8);
//        boolean boolean13 = cachedDateTimeZone3.equals((java.lang.Object) dateTimeZone8);
//        long long16 = dateTimeZone8.convertLocalToUTC((long) 78584, false);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 78584L + "'", long16 == 78584L);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        java.lang.String str2 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime10.toDateTimeISO();
        org.joda.time.DateTime dateTime15 = dateTime10.minusMinutes(331);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay(0);
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.plusWeeks((int) '4');
        long long21 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        java.util.Locale locale23 = null;
        try {
            org.joda.time.DateTime dateTime24 = property3.setCopy("dayOfMonth", locale23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"dayOfMonth\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        int int7 = dateTime6.getYear();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear((int) '#');
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.joda.time.DateTime dateTime14 = dateTime11.withYearOfEra(52);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute(78552, 78551);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.LocalDate localDate4 = dateTime2.toLocalDate();
        int int5 = dateTime2.getMillisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 78552507 + "'", int5 == 78552507);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
        int int16 = dateTime8.get(dateTimeField15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
        java.lang.String str19 = offsetDateTimeField18.getName();
        long long21 = offsetDateTimeField18.roundHalfCeiling((long) 13);
        long long23 = offsetDateTimeField18.roundHalfFloor((long) 45);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78542 + "'", int9 == 78542);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfHalfday((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendCenturyOfEra(78537, (-28800000));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfMinute(78552, 78551);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long21 = dateTimeZone17.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime24.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime27 = dateTime24.plusDays((int) 'a');
        org.joda.time.DateTime.Property property28 = dateTime27.weekOfWeekyear();
        org.joda.time.DateTime dateTime29 = property28.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property28.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long36 = dateTimeZone32.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone32);
        org.joda.time.DateTime dateTime39 = dateTime37.minusSeconds((int) (short) 10);
        int int40 = dateTime39.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial41 = null;
        org.joda.time.DateTime dateTime42 = dateTime39.withFields(readablePartial41);
        org.joda.time.DateTime dateTime43 = dateTime39.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.secondOfDay();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology44.dayOfMonth();
        int int47 = dateTime39.get(dateTimeField46);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, 78541);
        java.lang.String str50 = offsetDateTimeField49.getName();
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long56 = dateTimeZone52.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.DateTime dateTime59 = dateTime57.minusSeconds((int) (short) 10);
        int int60 = dateTime59.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial61 = null;
        org.joda.time.DateTime dateTime62 = dateTime59.withFields(readablePartial61);
        org.joda.time.DateTime dateTime63 = dateTime59.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology64.secondOfDay();
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology64.dayOfMonth();
        int int67 = dateTime59.get(dateTimeField66);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, 78541);
        long long71 = offsetDateTimeField69.roundFloor((long) 9);
        long long74 = offsetDateTimeField69.add((long) 24, (-51L));
        org.joda.time.chrono.ISOChronology iSOChronology75 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField76 = iSOChronology75.secondOfDay();
        org.joda.time.DateTimeField dateTimeField77 = iSOChronology75.era();
        org.joda.time.DurationField durationField78 = iSOChronology75.seconds();
        org.joda.time.DateTimeZone dateTimeZone80 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long84 = dateTimeZone80.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime85 = new org.joda.time.DateTime(dateTimeZone80);
        org.joda.time.DateTime dateTime87 = dateTime85.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate88 = dateTime85.toLocalDate();
        int[] intArray90 = iSOChronology75.get((org.joda.time.ReadablePartial) localDate88, (long) (short) 10);
        java.util.Locale locale91 = null;
        java.lang.String str92 = offsetDateTimeField69.getAsText((org.joda.time.ReadablePartial) localDate88, locale91);
        int int93 = offsetDateTimeField49.getMinimumValue((org.joda.time.ReadablePartial) localDate88);
        org.joda.time.DurationField durationField94 = offsetDateTimeField49.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField95 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType30, durationField94);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder96 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder99 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType30, 78578, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 78542 + "'", int40 == 78542);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 15 + "'", int47 == 15);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 78542 + "'", int60 == 78542);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 15 + "'", int67 == 15);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-4406399976L) + "'", long74 == (-4406399976L));
        org.junit.Assert.assertNotNull(iSOChronology75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(dateTimeZone80);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(localDate88);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "15" + "'", str92.equals("15"));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 78542 + "'", int93 == 78542);
        org.junit.Assert.assertNotNull(durationField94);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField95);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder96);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder99);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate10, 0L);
        java.lang.String str13 = gregorianChronology0.toString();
        int int14 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560556800000L + "'", long12 == 1560556800000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[UTC]" + "'", str13.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        int int7 = dateTime6.getMillisOfDay();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-1), 25, 78593);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78568 + "'", int3 == 78568);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 78563);
        java.io.Writer writer3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (short) 10);
        int int13 = dateTime12.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withFields(readablePartial14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.era();
        boolean boolean22 = iSOChronology18.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTime dateTime23 = dateTime17.toDateTime((org.joda.time.Chronology) iSOChronology18);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfDay();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        long long30 = iSOChronology24.add(readablePeriod27, (long) 1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology24.millisOfDay();
        boolean boolean32 = dateTime23.equals((java.lang.Object) dateTimeField31);
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 78542 + "'", int13 == 78542);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long12 = gregorianChronology7.getDateTimeMillis(9, 78561, (int) (short) 100, 78805);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78561 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 78589, (long) 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 314356 + "'", int2 == 314356);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
        int int16 = dateTime8.get(dateTimeField15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
        long long20 = offsetDateTimeField18.roundFloor((long) 9);
        long long23 = offsetDateTimeField18.add((long) 24, (-51L));
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfDay();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.era();
        org.joda.time.DurationField durationField27 = iSOChronology24.seconds();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long33 = dateTimeZone29.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate37 = dateTime34.toLocalDate();
        int[] intArray39 = iSOChronology24.get((org.joda.time.ReadablePartial) localDate37, (long) (short) 10);
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDate37, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField18.getAsShortText((long) 31, locale43);
        int int46 = offsetDateTimeField18.getLeapAmount((long) 314356);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78542 + "'", int9 == 78542);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4406399976L) + "'", long23 == (-4406399976L));
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "15" + "'", str41.equals("15"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "78542" + "'", str44.equals("78542"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property8.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
        int int11 = property10.getMaximumValueOverall();
        long long12 = property10.remainder();
        try {
            org.joda.time.DateTime dateTime14 = property10.addToCopy(1560635372010L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 1560635372010 * 86400000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560635352507L + "'", long7 == 1560635352507L);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100, false);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long11 = dateTimeZone7.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone7);
        int int13 = dateTime12.getYear();
        org.joda.time.DateTime dateTime15 = dateTime12.plusMonths(0);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekyear((int) '#');
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder21.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder21.appendClockhourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder28.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendFractionOfDay(2000, 78551);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long43 = dateTimeZone39.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime dateTime46 = dateTime44.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime47 = dateTime46.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime49 = dateTime46.plusDays((int) 'a');
        org.joda.time.DateTime.Property property50 = dateTime49.weekOfWeekyear();
        org.joda.time.DateTime dateTime51 = property50.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property50.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder34.appendFraction(dateTimeFieldType52, 6, (int) (short) 100);
        boolean boolean56 = dateTime19.isSupported(dateTimeFieldType52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType52);
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long63 = dateTimeZone59.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(dateTimeZone59);
        org.joda.time.DateTime dateTime66 = dateTime64.minusSeconds((int) (short) 10);
        int int67 = dateTime66.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial68 = null;
        org.joda.time.DateTime dateTime69 = dateTime66.withFields(readablePartial68);
        org.joda.time.DateTime dateTime70 = dateTime66.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology71.secondOfDay();
        org.joda.time.DateTimeField dateTimeField73 = iSOChronology71.dayOfMonth();
        int int74 = dateTime66.get(dateTimeField73);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField73, 78541);
        long long78 = offsetDateTimeField76.roundHalfEven((long) (byte) 1);
        java.util.Locale locale79 = null;
        int int80 = offsetDateTimeField76.getMaximumTextLength(locale79);
        org.joda.time.DurationField durationField81 = offsetDateTimeField76.getRangeDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology82 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField83 = iSOChronology82.secondOfDay();
        org.joda.time.DateTimeField dateTimeField84 = iSOChronology82.minuteOfHour();
        org.joda.time.DurationField durationField85 = iSOChronology82.centuries();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField86 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType52, durationField81, durationField85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 78542 + "'", int67 == 78542);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 15 + "'", int74 == 15);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 5 + "'", int80 == 5);
        org.junit.Assert.assertNotNull(durationField81);
        org.junit.Assert.assertNotNull(iSOChronology82);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(durationField85);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
        int int16 = dateTime8.get(dateTimeField15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
        int int20 = offsetDateTimeField18.getLeapAmount((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial21 = null;
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField18.getAsShortText(readablePartial21, 24, locale23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78542 + "'", int9 == 78542);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "24" + "'", str24.equals("24"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfDay((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendWeekOfWeekyear(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendFractionOfHour(78571, 86399);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withLocale(locale7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder26.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray28 = new org.joda.time.format.DateTimeParser[] { dateTimeParser18, dateTimeParser27 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder3.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendFractionOfDay(78584, (int) (short) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder31.appendTimeZoneOffset("", "15", false, 78564, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeParserArray28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 29);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime2.withLaterOffsetAtOverlap();
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 78585);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(78537);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitYear(78591);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
        int int24 = dateTime23.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
        int int31 = dateTime23.get(dateTimeField30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
        java.lang.String str34 = offsetDateTimeField33.getName();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
        int int44 = dateTime43.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
        int int51 = dateTime43.get(dateTimeField50);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
        long long55 = offsetDateTimeField53.roundFloor((long) 9);
        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
        java.util.Locale locale75 = null;
        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
        long long82 = unsupportedDateTimeField79.getDifferenceAsLong(1560635367969L, 1560635349937L);
        org.joda.time.DurationField durationField83 = unsupportedDateTimeField79.getDurationField();
        try {
            boolean boolean85 = unsupportedDateTimeField79.isLeap((long) 78552);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 68 + "'", int24 == 68);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 68 + "'", int44 == 68);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(localDate72);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "1" + "'", str76.equals("1"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
        org.junit.Assert.assertNotNull(durationField83);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.plusDays((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = property12.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime21.minusSeconds((int) (short) 10);
        int int24 = dateTime23.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.withFields(readablePartial25);
        org.joda.time.DateTime dateTime27 = dateTime23.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfDay();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.dayOfMonth();
        int int31 = dateTime23.get(dateTimeField30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 78541);
        java.lang.String str34 = offsetDateTimeField33.getName();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long40 = dateTimeZone36.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.DateTime dateTime43 = dateTime41.minusSeconds((int) (short) 10);
        int int44 = dateTime43.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.DateTime dateTime46 = dateTime43.withFields(readablePartial45);
        org.joda.time.DateTime dateTime47 = dateTime43.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.secondOfDay();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfMonth();
        int int51 = dateTime43.get(dateTimeField50);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 78541);
        long long55 = offsetDateTimeField53.roundFloor((long) 9);
        long long58 = offsetDateTimeField53.add((long) 24, (-51L));
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfDay();
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.era();
        org.joda.time.DurationField durationField62 = iSOChronology59.seconds();
        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long68 = dateTimeZone64.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone64);
        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate72 = dateTime69.toLocalDate();
        int[] intArray74 = iSOChronology59.get((org.joda.time.ReadablePartial) localDate72, (long) (short) 10);
        java.util.Locale locale75 = null;
        java.lang.String str76 = offsetDateTimeField53.getAsText((org.joda.time.ReadablePartial) localDate72, locale75);
        int int77 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDate72);
        org.joda.time.DurationField durationField78 = offsetDateTimeField33.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField79 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField78);
        long long82 = unsupportedDateTimeField79.add((long) 78538, 78542873);
        java.util.Locale locale85 = null;
        try {
            long long86 = unsupportedDateTimeField79.set((long) '4', "2019-06-15T21:49:33.257Z", locale85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 68 + "'", int24 == 68);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 68 + "'", int44 == 68);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-4406399976L) + "'", long58 == (-4406399976L));
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(localDate72);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "1" + "'", str76.equals("1"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 78542 + "'", int77 == 78542);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField79);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 6786104227278538L + "'", long82 == 6786104227278538L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime6.withWeekOfWeekyear((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.era();
        boolean boolean16 = iSOChronology12.equals((java.lang.Object) (byte) 0);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.weekyear();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime6, (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        org.joda.time.DateTime dateTime20 = property19.withMinimumValue();
        org.joda.time.DateTime dateTime22 = property19.addToCopy((long) (byte) 1);
        int int23 = dateTime22.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMinuteOfHour((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withLocale(locale7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder26.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray28 = new org.joda.time.format.DateTimeParser[] { dateTimeParser18, dateTimeParser27 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder3.append(dateTimePrinter9, dateTimeParserArray28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder3.appendHourOfHalfday(0);
        dateTimeFormatterBuilder31.clear();
        boolean boolean33 = dateTimeFormatterBuilder31.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeParserArray28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("UTC", "dayOfMonth", 1, 78541);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getStandardOffset((long) 11);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 78541 + "'", int7 == 78541);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "78569752");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        org.joda.time.ReadableInstant readableInstant12 = null;
        long long13 = property11.getDifferenceAsLong(readableInstant12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
        int int16 = dateTime8.get(dateTimeField15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
        long long20 = offsetDateTimeField18.roundFloor((long) 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTwoDigitWeekyear((int) (short) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendWeekOfWeekyear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder22.appendClockhourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder29.appendTimeZoneOffset("GregorianChronology[UTC]", "UTC", false, 13, 52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendFractionOfDay(2000, 78551);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long44 = dateTimeZone40.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone40);
        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime48 = dateTime47.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime50 = dateTime47.plusDays((int) 'a');
        org.joda.time.DateTime.Property property51 = dateTime50.weekOfWeekyear();
        org.joda.time.DateTime dateTime52 = property51.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property51.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder35.appendFraction(dateTimeFieldType53, 6, (int) (short) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType53, 263, 20, 0);
        boolean boolean62 = offsetDateTimeField60.isLeap((long) 78542873);
        long long64 = offsetDateTimeField60.roundHalfFloor((long) 78558);
        long long66 = offsetDateTimeField60.roundHalfFloor(6787065600000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 68 + "'", int9 == 68);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(mutableDateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 6787065600000L + "'", long66 == 6787065600000L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 0, false, (long) (byte) 1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((int) (short) 10);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withFields(readablePartial10);
        org.joda.time.DateTime dateTime12 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.dayOfMonth();
        int int16 = dateTime8.get(dateTimeField15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 78541);
        long long20 = offsetDateTimeField18.roundFloor((long) 9);
        long long23 = offsetDateTimeField18.add((long) 24, (-51L));
        java.lang.String str24 = offsetDateTimeField18.toString();
        long long27 = offsetDateTimeField18.add((long) 331, 78572);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 68 + "'", int9 == 68);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-4406399976L) + "'", long23 == (-4406399976L));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str24.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 6788620800331L + "'", long27 == 6788620800331L);
    }
}

