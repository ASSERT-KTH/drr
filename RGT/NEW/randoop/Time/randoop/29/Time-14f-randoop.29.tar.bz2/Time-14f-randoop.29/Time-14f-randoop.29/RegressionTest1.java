import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, 2000);
        long long10 = offsetDateTimeField8.roundHalfEven((long) 9);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField8.getMaximumTextLength(locale11);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DurationField durationField11 = property10.getLeapDurationField();
//        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property10.getAsShortText(locale13);
//        java.lang.String str15 = property10.getAsText();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu" + "'", str14.equals("Thu"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Thursday" + "'", str15.equals("Thursday"));
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int4 = skipUndoDateTimeField3.getMinimumValue();
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
//        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
//        org.joda.time.DateTime dateTime25 = property23.getDateTime();
//        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
//        int int35 = dateTime30.getYear();
//        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        int int40 = dateTime26.get(dateTimeFieldType39);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = offsetDateTimeField42.getAsShortText((int) '4', locale44);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter46.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter46.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter46.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter46.withOffsetParsed();
//        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MonthDay monthDay54 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology53);
//        java.lang.String str55 = dateTimeFormatter46.print((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.MonthDay monthDay57 = monthDay54.plus(readablePeriod56);
//        int int58 = offsetDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.Chronology chronology59 = monthDay54.getChronology();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(iSOChronology53);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "����-06-15T��:��:��" + "'", str55.equals("����-06-15T��:��:��"));
//        org.junit.Assert.assertNotNull(monthDay57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-292274953) + "'", int58 == (-292274953));
//        org.junit.Assert.assertNotNull(chronology59);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("--06-15", "Coordinated Universal Time");
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int4 = skipUndoDateTimeField3.getMinimumValue();
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
//        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
//        org.joda.time.DateTime dateTime25 = property23.getDateTime();
//        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
//        int int35 = dateTime30.getYear();
//        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        int int40 = dateTime26.get(dateTimeFieldType39);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
//        org.joda.time.MonthDay monthDay43 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.MonthDay monthDay45 = monthDay43.minus(readablePeriod44);
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.MonthDay monthDay48 = monthDay43.withPeriodAdded(readablePeriod46, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay50 = monthDay43.minusDays((-1));
//        int[] intArray51 = monthDay50.getValues();
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.minus(readablePeriod53);
//        org.joda.time.ReadablePeriod readablePeriod55 = null;
//        org.joda.time.MonthDay monthDay57 = monthDay52.withPeriodAdded(readablePeriod55, (int) (byte) 0);
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology58, dateTimeField60);
//        boolean boolean62 = monthDay57.equals((java.lang.Object) skipUndoDateTimeField61);
//        boolean boolean63 = skipUndoDateTimeField61.isSupported();
//        long long66 = skipUndoDateTimeField61.set(0L, (int) (short) 1);
//        org.joda.time.ReadablePartial readablePartial67 = null;
//        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology70 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField71 = iSOChronology70.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField72 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology69, dateTimeField71);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.MonthDay monthDay75 = monthDay73.minusMonths((-1));
//        int[] intArray78 = new int[] { (short) 100 };
//        int[] intArray80 = skipUndoDateTimeField72.add((org.joda.time.ReadablePartial) monthDay73, (-28800000), intArray78, (int) (byte) 0);
//        int[] intArray82 = skipUndoDateTimeField61.addWrapPartial(readablePartial67, (-292275053), intArray80, 0);
//        int int83 = offsetDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) monthDay50, intArray82);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(monthDay43);
//        org.junit.Assert.assertNotNull(monthDay45);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertNotNull(intArray51);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(monthDay57);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-62135337600000L) + "'", long66 == (-62135337600000L));
//        org.junit.Assert.assertNotNull(gJChronology69);
//        org.junit.Assert.assertNotNull(iSOChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray78);
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertNotNull(intArray82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-292274953) + "'", int83 == (-292274953));
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.year();
        org.joda.time.DurationField durationField3 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField5 = gJChronology0.months();
        try {
            long long10 = gJChronology0.getDateTimeMillis(9, (int) (byte) -1, 0, 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10.0d, (java.lang.Number) (byte) 10, (java.lang.Number) (-62135337600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime dateTime11 = dateTime8.minusMinutes(1969);
        org.joda.time.DateTime dateTime13 = dateTime8.withWeekyear(9);
        org.joda.time.Chronology chronology14 = dateTime8.getChronology();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology7);
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay8.withPeriodAdded(readablePeriod10, 100);
//        org.joda.time.MonthDay monthDay14 = monthDay8.plusMonths((int) '#');
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "����-06-15T��:��:��" + "'", str9.equals("����-06-15T��:��:��"));
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(monthDay14);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
//        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
//        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
//        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
//        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = skipUndoDateTimeField35.getAsText(0, locale37);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, 2000);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, (org.joda.time.DateTimeField) offsetDateTimeField40, (-28800000));
//        java.lang.String str44 = offsetDateTimeField40.getAsText((long) 4);
//        int int46 = offsetDateTimeField40.getLeapAmount(10L);
//        int int47 = offsetDateTimeField40.getMaximumValue();
//        org.joda.time.ReadablePartial readablePartial48 = null;
//        java.util.Locale locale50 = null;
//        java.lang.String str51 = offsetDateTimeField40.getAsShortText(readablePartial48, 3971, locale50);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "3970" + "'", str44.equals("3970"));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292280993 + "'", int47 == 292280993);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "3971" + "'", str51.equals("3971"));
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendMonthOfYearText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendDayOfMonth((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.DateTime dateTime12 = property10.getDateTime();
//        org.joda.time.DateTime dateTime13 = property10.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime15 = dateTime13.minusWeeks(0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendPattern("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfHalfday(5044);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear(0, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        try {
            org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, (-292274953), 1582, 1970, 3971);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.DateTime dateTime12 = property10.getDateTime();
//        org.joda.time.Interval interval13 = property10.toInterval();
//        long long14 = property10.remainder();
//        org.joda.time.DateTime dateTime15 = property10.roundHalfCeilingCopy();
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime15.toMutableDateTime((org.joda.time.Chronology) julianChronology16);
//        org.joda.time.DateTime dateTime19 = dateTime15.withYear((int) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(interval13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800010L + "'", long14 == 28800010L);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = julianChronology0.add(readablePeriod1, (long) (-10), (int) (short) 10);
        int int5 = julianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str6 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-10L) + "'", long4 == (-10L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JulianChronology[UTC]" + "'", str6.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, 2000);
        int int10 = offsetDateTimeField8.get(32054400010L);
        int int13 = offsetDateTimeField8.getDifference((long) '4', 97L);
        long long16 = offsetDateTimeField8.add(1560633530340L, 31);
        int int18 = offsetDateTimeField8.getLeapAmount((long) 2069);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3971 + "'", int10 == 3971);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2539199930340L + "'", long16 == 2539199930340L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(1969);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder2.setFixedSavings("278", (-10));
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeZoneBuilder2.toDateTimeZone("", true);
        org.joda.time.Chronology chronology11 = gJChronology0.withZone(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
//        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
//        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
//        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
//        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = skipUndoDateTimeField35.getAsText(0, locale37);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, 2000);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, (org.joda.time.DateTimeField) offsetDateTimeField40, (-28800000));
//        java.lang.String str44 = offsetDateTimeField40.getAsText((long) 4);
//        long long47 = offsetDateTimeField40.add((-9071994956L), 35);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "3970" + "'", str44.equals("3970"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1095292805044L + "'", long47 == 1095292805044L);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
//        int int8 = dateTime3.getYear();
//        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(100);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime10.withMonthOfYear((-28800000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
//        boolean boolean5 = gJChronology0.equals((java.lang.Object) gJChronology2);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
//        boolean boolean9 = gJChronology2.equals((java.lang.Object) gJChronology6);
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
//        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.MonthDay monthDay16 = monthDay14.minus(readablePeriod15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipUndoDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) monthDay14, 278, locale18);
//        int int20 = monthDay14.getDayOfMonth();
//        long long22 = gJChronology6.set((org.joda.time.ReadablePartial) monthDay14, 1560633530340L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(instant1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "278" + "'", str19.equals("278"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560633530340L + "'", long22 == 1560633530340L);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.String str5 = instant3.toString(dateTimeFormatter4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant3.minus(readableDuration6);
        org.joda.time.Instant instant9 = instant3.minus(28800010L);
        boolean boolean11 = instant3.isAfter(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1582-288T00:00:00Z" + "'", str5.equals("1582-288T00:00:00Z"));
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 60000L + "'", long11 == 60000L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
        try {
            long long13 = limitChronology3.getDateTimeMillis(1686L, (int) '4', 9, 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipUndoDateTimeField3.getType();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        boolean boolean13 = skipUndoDateTimeField11.isLeap((long) (-1));
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField11.getAsShortText((long) (-1), locale15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.minus(readablePeriod18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay17.withPeriodAdded(readablePeriod20, (int) (byte) 0);
        org.joda.time.MonthDay monthDay24 = monthDay17.minusDays((-1));
        int[] intArray25 = monthDay24.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology29, readableDateTime30, readableDateTime31);
        org.joda.time.DateTime dateTime33 = limitChronology32.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField34 = limitChronology32.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology26, dateTimeField34, (int) 'a');
        long long39 = skipDateTimeField36.add(0L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipDateTimeField36.getType();
        boolean boolean41 = monthDay24.isSupported(dateTimeFieldType40);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology42, dateTimeField44);
        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay48 = monthDay46.minusMonths((-1));
        int[] intArray51 = new int[] { (short) 100 };
        int[] intArray53 = skipUndoDateTimeField45.add((org.joda.time.ReadablePartial) monthDay46, (-28800000), intArray51, (int) (byte) 0);
        int int54 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) monthDay24, intArray53);
        java.util.Locale locale55 = null;
        try {
            java.lang.String str56 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay24, locale55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970" + "'", str16.equals("1970"));
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-292275054) + "'", int54 == (-292275054));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1969);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("", (int) (short) 10, 292278993, (-292274953), ' ', (-292275054), 0, (int) (byte) 1, true, (-28800000));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder21 = dateTimeZoneBuilder2.addCutover(1969, 'a', 6, (-28378000), (int) (short) 100, false, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
//        int int8 = dateTime3.getYear();
//        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(100);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology11, obj12);
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology11.secondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology11.getZone();
//        org.joda.time.DateTime dateTime16 = dateTime3.toDateTime((org.joda.time.Chronology) julianChronology11);
//        boolean boolean17 = dateTime16.isAfterNow();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(16, (int) (byte) 0, (int) (byte) 100, (int) (byte) 1, (int) (short) 10, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property10.getAsText(locale12);
//        int int14 = property10.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime15 = property10.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thursday" + "'", str13.equals("Thursday"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        int int7 = property6.getMaximumValueOverall();
//        int int8 = property6.get();
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        try {
//            int int10 = property6.compareTo(readablePartial9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        long long12 = dateTimeZone5.getMillisKeepLocal(dateTimeZone9, (long) '4');
        java.util.TimeZone timeZone13 = dateTimeZone5.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
        org.joda.time.LocalDate localDate3 = monthDay1.toLocalDate(1686);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1969);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("278", (-10));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder0.addRecurringSavings("Coordinated Universal Time", 292280993, 2, 2000, 'a', (int) (byte) 100, 0, (int) (byte) 1, false, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((-28800000), 9, 0, 3969, (int) (byte) 100, 292280993, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
//        int int4 = dateTime3.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = dateTime10.withZone(dateTimeZone12);
//        int int15 = dateTime10.getYear();
//        org.joda.time.DateTime dateTime17 = dateTime10.minusMonths(100);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.DateTime.Property property20 = dateTime6.property(dateTimeFieldType19);
//        int int21 = property20.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        int int12 = property10.getLeapAmount();
//        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
//        int int14 = dateTime13.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime12.withZone(dateTimeZone14);
//        int int17 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(dateTimeZone3);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(100L, dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.minus(readablePeriod4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay3.withPeriodAdded(readablePeriod6, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        boolean boolean13 = monthDay8.equals((java.lang.Object) skipUndoDateTimeField12);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField12);
        org.joda.time.Chronology chronology15 = gregorianChronology0.withUTC();
        int int16 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekyear();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
        org.joda.time.DateTime dateTime25 = limitChronology24.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField26 = limitChronology24.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField26, (int) 'a');
        long long31 = skipDateTimeField28.add(0L, 0);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now(dateTimeZone34);
        int[] intArray39 = new int[] { 31, 31, '4' };
        int int40 = skipDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) monthDay35, intArray39);
        try {
            gregorianChronology0.validate(readablePartial17, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 53 + "'", int40 == 53);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        boolean boolean6 = dateTimeZone1.isStandardOffset(0L);
//        boolean boolean8 = dateTimeZone1.isStandardOffset(9118L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusWeeks(10);
//        org.joda.time.DateTime dateTime14 = dateTime12.withCenturyOfEra(0);
//        int int15 = dateTime14.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 69 + "'", int15 == 69);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        org.joda.time.DurationField durationField7 = property6.getRangeDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        int int13 = dateTimeZone11.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean15 = dateTimeZone11.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter9.withZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(28800010L, dateTimeZone11);
//        org.joda.time.DateTime.Property property18 = dateTime17.dayOfWeek();
//        org.joda.time.DateTime dateTime19 = property18.roundFloorCopy();
//        org.joda.time.DateTime.Property property20 = dateTime19.dayOfWeek();
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(2000L, 3971);
//        int int24 = property6.compareTo((org.joda.time.ReadableInstant) dateTime19);
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1560633530340L, (long) (-292275053));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560925805393L + "'", long2 == 1560925805393L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology0.months();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        int int10 = dateTimeZone8.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean12 = dateTimeZone8.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter6.withZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(28800010L, dateTimeZone8);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        org.joda.time.DateTime dateTime17 = property15.getDateTime();
//        org.joda.time.DateTime dateTime18 = property15.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime22.withZone(dateTimeZone24);
//        int int27 = dateTime22.getYear();
//        org.joda.time.DateTime dateTime29 = dateTime22.minusMonths(100);
//        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        int int32 = dateTime18.get(dateTimeFieldType31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType31, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendDayOfMonth((int) (byte) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1970 + "'", int27 == 1970);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = limitChronology3.getLowerLimit();
        try {
            long long14 = limitChronology3.getDateTimeMillis(15, 0, 2069, 0, (int) (byte) 0, 4, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(dateTime6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(chronology0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0.0f, number2, (java.lang.Number) 32054400010L);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        java.lang.String str8 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32054400010L + "'", number5.equals(32054400010L));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0.0 for  must not be larger than 32054400010" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value 0.0 for  must not be larger than 32054400010"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        long long7 = skipUndoDateTimeField3.set((long) 5044, (int) (byte) 10);
        int int8 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str9 = skipUndoDateTimeField3.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = skipUndoDateTimeField3.getType();
        long long12 = skipUndoDateTimeField3.roundHalfFloor((-10L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851081594956L) + "'", long7 == (-61851081594956L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275053) + "'", int8 == (-292275053));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "weekyear" + "'", str9.equals("weekyear"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
//        boolean boolean4 = dateTimeFormatter2.isOffsetParsed();
//        org.joda.time.Instant instant5 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime6 = instant5.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime();
//        boolean boolean8 = mutableDateTime7.isBeforeNow();
//        int int11 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "Thursday", 0);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime7);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeParser3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.ReadWritableInstant readWritableInstant2 = null;
        try {
            int int5 = dateTimeFormatter0.parseInto(readWritableInstant2, "5044", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundFloorCopy();
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfWeek();
//        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(2000L, 3971);
//        java.util.GregorianCalendar gregorianCalendar16 = dateTime15.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gregorianCalendar16);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundFloorCopy();
//        org.joda.time.DateTime dateTime13 = property10.addWrapFieldToCopy((int) (byte) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.minus(readablePeriod4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay3.withPeriodAdded(readablePeriod6, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        boolean boolean13 = monthDay8.equals((java.lang.Object) skipUndoDateTimeField12);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField12);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType2, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone3);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, 278);
//        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime8.centuryOfEra();
//        int int11 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology0, obj1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.minus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay5.withPeriodAdded(readablePeriod8, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField13);
        boolean boolean15 = monthDay10.equals((java.lang.Object) skipUndoDateTimeField14);
        boolean boolean16 = skipUndoDateTimeField14.isSupported();
        long long19 = skipUndoDateTimeField14.set(0L, (int) (short) 1);
        int int20 = skipUndoDateTimeField14.getMinimumValue();
        java.lang.String str21 = skipUndoDateTimeField14.toString();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField14, 2);
        int int25 = skipDateTimeField23.get((long) (short) 100);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62135337600000L) + "'", long19 == (-62135337600000L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275053) + "'", int20 == (-292275053));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DateTimeField[weekyear]" + "'", str21.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        boolean boolean11 = skipUndoDateTimeField9.isSupported();
        java.lang.String str12 = skipUndoDateTimeField9.toString();
        long long15 = skipUndoDateTimeField9.set(9118L, 3971);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[weekyear]" + "'", str12.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 63145958409118L + "'", long15 == 63145958409118L);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = limitChronology3.equals(obj6);
//        org.joda.time.DurationField durationField8 = limitChronology3.months();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime13 = null;
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
//        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
//        long long22 = skipDateTimeField19.add(0L, 0);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, (org.joda.time.DateTimeField) skipDateTimeField19);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone25);
//        int int28 = dateTime27.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.toDateTime(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.DateTime dateTime38 = dateTime34.withZone(dateTimeZone36);
//        int int39 = dateTime34.getYear();
//        org.joda.time.DateTime dateTime41 = dateTime34.minusMonths(100);
//        org.joda.time.DateTime.Property property42 = dateTime41.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
//        org.joda.time.DateTime.Property property44 = dateTime30.property(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType43, 53, 2, (-292275053));
//        long long50 = offsetDateTimeField48.roundCeiling((long) (byte) 1);
//        try {
//            long long53 = offsetDateTimeField48.add(94L, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 64 for secondOfDay must be in the range [54,-292275053]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1970 + "'", int39 == 1970);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 345600000L + "'", long50 == 345600000L);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = limitChronology3.equals(obj6);
//        org.joda.time.DurationField durationField8 = limitChronology3.months();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime13 = null;
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
//        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
//        long long22 = skipDateTimeField19.add(0L, 0);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, (org.joda.time.DateTimeField) skipDateTimeField19);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone25);
//        int int28 = dateTime27.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.toDateTime(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.DateTime dateTime38 = dateTime34.withZone(dateTimeZone36);
//        int int39 = dateTime34.getYear();
//        org.joda.time.DateTime dateTime41 = dateTime34.minusMonths(100);
//        org.joda.time.DateTime.Property property42 = dateTime41.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
//        org.joda.time.DateTime.Property property44 = dateTime30.property(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType43, 53, 2, (-292275053));
//        long long50 = offsetDateTimeField48.roundCeiling((long) (byte) 1);
//        int int52 = offsetDateTimeField48.get(0L);
//        java.util.Locale locale53 = null;
//        int int54 = offsetDateTimeField48.getMaximumTextLength(locale53);
//        org.joda.time.MonthDay monthDay55 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.MonthDay monthDay57 = monthDay55.minus(readablePeriod56);
//        org.joda.time.ReadablePeriod readablePeriod58 = null;
//        org.joda.time.MonthDay monthDay60 = monthDay55.withPeriodAdded(readablePeriod58, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay62 = monthDay55.minusDays((-1));
//        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay((java.lang.Object) monthDay55);
//        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.MonthDay monthDay67 = monthDay65.minus(readablePeriod66);
//        org.joda.time.ReadablePeriod readablePeriod68 = null;
//        org.joda.time.MonthDay monthDay70 = monthDay65.withPeriodAdded(readablePeriod68, (int) (byte) 0);
//        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField73 = iSOChronology72.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField74 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology71, dateTimeField73);
//        boolean boolean75 = monthDay70.equals((java.lang.Object) skipUndoDateTimeField74);
//        boolean boolean76 = skipUndoDateTimeField74.isSupported();
//        long long79 = skipUndoDateTimeField74.set(0L, (int) (short) 1);
//        org.joda.time.ReadablePartial readablePartial80 = null;
//        org.joda.time.chrono.GJChronology gJChronology82 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology83 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField84 = iSOChronology83.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField85 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology82, dateTimeField84);
//        org.joda.time.MonthDay monthDay86 = org.joda.time.MonthDay.now();
//        org.joda.time.MonthDay monthDay88 = monthDay86.minusMonths((-1));
//        int[] intArray91 = new int[] { (short) 100 };
//        int[] intArray93 = skipUndoDateTimeField85.add((org.joda.time.ReadablePartial) monthDay86, (-28800000), intArray91, (int) (byte) 0);
//        int[] intArray95 = skipUndoDateTimeField74.addWrapPartial(readablePartial80, (-292275053), intArray93, 0);
//        try {
//            int[] intArray97 = offsetDateTimeField48.set((org.joda.time.ReadablePartial) monthDay63, 69, intArray93, 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for secondOfDay must be in the range [54,-292275053]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1970 + "'", int39 == 1970);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 345600000L + "'", long50 == 345600000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 69 + "'", int52 == 69);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 10 + "'", int54 == 10);
//        org.junit.Assert.assertNotNull(monthDay55);
//        org.junit.Assert.assertNotNull(monthDay57);
//        org.junit.Assert.assertNotNull(monthDay60);
//        org.junit.Assert.assertNotNull(monthDay62);
//        org.junit.Assert.assertNotNull(monthDay65);
//        org.junit.Assert.assertNotNull(monthDay67);
//        org.junit.Assert.assertNotNull(monthDay70);
//        org.junit.Assert.assertNotNull(gJChronology71);
//        org.junit.Assert.assertNotNull(iSOChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-62135337600000L) + "'", long79 == (-62135337600000L));
//        org.junit.Assert.assertNotNull(gJChronology82);
//        org.junit.Assert.assertNotNull(iSOChronology83);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertNotNull(monthDay88);
//        org.junit.Assert.assertNotNull(intArray91);
//        org.junit.Assert.assertNotNull(intArray93);
//        org.junit.Assert.assertNotNull(intArray95);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology0, obj1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) 1);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone3);
//        long long9 = dateTimeZone3.adjustOffset((long) 19, false);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 19L + "'", long9 == 19L);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = property10.roundFloorCopy();
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        int int10 = dateTimeZone8.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean12 = dateTimeZone8.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter6.withZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(28800010L, dateTimeZone8);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        org.joda.time.DateTime dateTime17 = property15.getDateTime();
//        org.joda.time.DateTime dateTime18 = property15.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime22.withZone(dateTimeZone24);
//        int int27 = dateTime22.getYear();
//        org.joda.time.DateTime dateTime29 = dateTime22.minusMonths(100);
//        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        int int32 = dateTime18.get(dateTimeFieldType31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType31, 1969);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendFractionOfSecond(1970, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder35.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter41.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter41.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter41.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter47 = dateTimeFormatter46.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder40.append(dateTimePrinter47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.append(dateTimePrinter47);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter51.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = dateTimeFormatter51.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter51.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter57 = dateTimeFormatter56.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder50.append(dateTimePrinter57);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendLiteral("AD");
//        org.joda.time.format.DateTimeParser dateTimeParser61 = dateTimeFormatterBuilder58.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder0.append(dateTimePrinter47, dateTimeParser61);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder62.appendFractionOfDay(100, (int) 'a');
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1970 + "'", int27 == 1970);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(dateTimePrinter47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(dateTimeFormatter54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(dateTimePrinter57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(dateTimeParser61);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int4 = skipUndoDateTimeField3.getMinimumValue();
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
//        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
//        int int29 = skipUndoDateTimeField28.getMinimumValue();
//        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
//        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
//        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
//        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
//        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
//        org.joda.time.DateTime dateTime50 = property48.getDateTime();
//        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
//        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
//        int int60 = dateTime55.getYear();
//        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
//        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
//        int int65 = dateTime51.get(dateTimeFieldType64);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
//        int int72 = skipUndoDateTimeField71.getMaximumValue();
//        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
//        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
//        java.util.Locale locale77 = null;
//        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
//        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
//        long long85 = dividedDateTimeField83.roundFloor(0L);
//        int int86 = dividedDateTimeField83.getDivisor();
//        long long89 = dividedDateTimeField83.set((-62135337598418L), 15);
//        org.joda.time.DurationField durationField90 = dividedDateTimeField83.getRangeDurationField();
//        long long93 = dividedDateTimeField83.getDifferenceAsLong(97L, (long) ' ');
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimePrinter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(iSOChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType79);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-315360000000L) + "'", long85 == (-315360000000L));
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 35 + "'", int86 == 35);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-45568051198418L) + "'", long89 == (-45568051198418L));
//        org.junit.Assert.assertNull(durationField90);
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 0L + "'", long93 == 0L);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
//        int int8 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra((int) (short) 1);
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime3.withDayOfWeek(3971);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3971 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int4 = skipUndoDateTimeField3.getMinimumValue();
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
//        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
//        org.joda.time.DateTime dateTime25 = property23.getDateTime();
//        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
//        int int35 = dateTime30.getYear();
//        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        int int40 = dateTime26.get(dateTimeFieldType39);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
//        int int44 = offsetDateTimeField42.getMinimumValue(32054400010L);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = offsetDateTimeField42.getAsShortText((long) 10, locale46);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-292274953) + "'", int44 == (-292274953));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2070" + "'", str47.equals("2070"));
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime3.era();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsShortText(locale6);
        int int8 = property5.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AD" + "'", str7.equals("AD"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        int int10 = dateTimeZone8.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean12 = dateTimeZone8.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter6.withZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(28800010L, dateTimeZone8);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
//        org.joda.time.DateTime dateTime17 = property15.getDateTime();
//        org.joda.time.DateTime dateTime18 = property15.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime22.withZone(dateTimeZone24);
//        int int27 = dateTime22.getYear();
//        org.joda.time.DateTime dateTime29 = dateTime22.minusMonths(100);
//        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        int int32 = dateTime18.get(dateTimeFieldType31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType31, 1969);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatter35.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.append(dateTimeParser36);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder37.appendMonthOfYearShortText();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1970 + "'", int27 == 1970);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeParser36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        boolean boolean2 = dateTime1.isEqualNow();
//        try {
//            org.joda.time.DateTime dateTime4 = dateTime1.withEra(12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
//        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withDefaultYear(5044);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter13.withZone(dateTimeZone16);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = copticChronology13.add(readablePeriod14, 3061497603971L, (-1));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3061497603971L + "'", long17 == 3061497603971L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long12 = skipDateTimeField10.roundHalfFloor((long) 1);
        boolean boolean13 = skipDateTimeField10.isLenient();
        long long15 = skipDateTimeField10.roundHalfCeiling(28800100L);
        int int16 = skipDateTimeField10.getMinimumValue();
        long long18 = skipDateTimeField10.roundHalfFloor((long) (byte) 0);
        long long21 = skipDateTimeField10.set((long) (short) -1, (int) '4');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-259200000L) + "'", long18 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 21772799999L + "'", long21 == 21772799999L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getYear();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(100);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean14 = dateTime10.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        long long15 = durationField12.subtract(0L, (int) (short) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField5 = gJChronology0.halfdays();
        int int6 = gJChronology0.getMinimumDaysInFirstWeek();
        try {
            long long14 = gJChronology0.getDateTimeMillis(0, (-10), 1582, (int) (short) 100, (int) (byte) 1, 4, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField9.getDurationField();
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField9, 4, 1, 10);
        try {
            long long18 = skipUndoDateTimeField9.set(0L, "����0101T������");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����0101T������\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone1);
        long long11 = dateTimeZone1.convertLocalToUTC((long) 278, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 278L + "'", long11 == 278L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = skipUndoDateTimeField46.getAsText(0, locale48);
        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now();
        int int51 = skipUndoDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) monthDay50);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) monthDay50, 1, locale53);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 292278993 + "'", int51 == 292278993);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "1" + "'", str54.equals("1"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        int int14 = dateTimeZone12.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone12);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant20 = instant18.minus(readableDuration19);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) instant20, (org.joda.time.Chronology) copticChronology21);
        int int26 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime25);
        boolean boolean27 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime25);
        try {
            java.lang.String str29 = dateTime9.toString("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(3969, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3969 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        long long3 = dateTimeZone0.convertUTCToLocal((long) 5044);
        long long5 = dateTimeZone0.convertUTCToLocal(27831L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5044L + "'", long3 == 5044L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27831L + "'", long5 == 27831L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime dateTime10 = dateTime8.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        int int44 = offsetDateTimeField42.get(97L);
        long long47 = offsetDateTimeField42.add((long) 3971, (long) 'a');
        java.util.Locale locale50 = null;
        try {
            long long51 = offsetDateTimeField42.set((long) (short) 100, "LimitChronology[CopticChronology[UTC], NoLimit, NoLimit]", locale50);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"LimitChronology[CopticChronology[UTC], NoLimit, NoLimit]\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2070 + "'", int44 == 2070);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3061497603971L + "'", long47 == 3061497603971L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear(16, 12);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder7.appendTimeZoneOffset("UTC", "1970-01-01T00:00:00", true, (int) (short) 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipUndoDateTimeField3.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 5044, "hi!");
        java.lang.String str11 = illegalFieldValueException10.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType12 = illegalFieldValueException10.getDurationFieldType();
        java.lang.Number number13 = illegalFieldValueException10.getLowerBound();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5044" + "'", str11.equals("5044"));
        org.junit.Assert.assertNull(durationFieldType12);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        long long13 = skipUndoDateTimeField3.roundCeiling((-259200000L));
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField3.getRangeDurationField();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
        int int19 = skipUndoDateTimeField18.getMinimumValue();
        java.lang.String str21 = skipUndoDateTimeField18.getAsText(97L);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField18.getAsText((org.joda.time.ReadablePartial) monthDay23, (int) (short) -1, locale25);
        org.joda.time.DurationField durationField27 = skipUndoDateTimeField18.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
        int int33 = dateTimeZone31.getOffsetFromLocal((long) (byte) 10);
        boolean boolean35 = dateTimeZone31.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter29.withZone(dateTimeZone31);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(28800010L, dateTimeZone31);
        org.joda.time.DateTime.Property property38 = dateTime37.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField39 = property38.getField();
        org.joda.time.DateTime dateTime40 = property38.getDateTime();
        org.joda.time.DateTime dateTime41 = property38.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeUtils.getZone(dateTimeZone43);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone43);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeUtils.getZone(dateTimeZone46);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeUtils.getZone(dateTimeZone47);
        org.joda.time.DateTime dateTime49 = dateTime45.withZone(dateTimeZone47);
        int int50 = dateTime45.getYear();
        org.joda.time.DateTime dateTime52 = dateTime45.minusMonths(100);
        org.joda.time.DateTime.Property property53 = dateTime52.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        int int55 = dateTime41.get(dateTimeFieldType54);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType54, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology58, dateTimeField60);
        int int62 = skipUndoDateTimeField61.getMaximumValue();
        org.joda.time.MonthDay monthDay64 = new org.joda.time.MonthDay((long) 53);
        int int65 = skipUndoDateTimeField61.getMinimumValue((org.joda.time.ReadablePartial) monthDay64);
        java.util.Locale locale67 = null;
        java.lang.String str68 = offsetDateTimeField57.getAsShortText((org.joda.time.ReadablePartial) monthDay64, 53, locale67);
        java.util.Locale locale70 = null;
        java.lang.String str71 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay64, 0, locale70);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-292275053) + "'", int19 == (-292275053));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-1" + "'", str26.equals("-1"));
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1970 + "'", int50 == 1970);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 292278993 + "'", int62 == 292278993);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-292275054) + "'", int65 == (-292275054));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "53" + "'", str68.equals("53"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.String str5 = instant3.toString(dateTimeFormatter4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant3.minus(readableDuration6);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        int int12 = skipUndoDateTimeField11.getMinimumValue();
        java.lang.String str14 = skipUndoDateTimeField11.getAsText(97L);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) monthDay16, (int) (short) -1, locale18);
        java.lang.String str21 = skipUndoDateTimeField11.getAsText(94L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter23.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter23.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter29 = dateTimeFormatter28.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder22.append(dateTimePrinter29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendLiteral("AD");
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField35);
        int int37 = skipUndoDateTimeField36.getMinimumValue();
        java.lang.String str39 = skipUndoDateTimeField36.getAsText(97L);
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipUndoDateTimeField36.getAsText((org.joda.time.ReadablePartial) monthDay41, (int) (short) -1, locale43);
        org.joda.time.DurationField durationField45 = skipUndoDateTimeField36.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone48);
        int int51 = dateTimeZone49.getOffsetFromLocal((long) (byte) 10);
        boolean boolean53 = dateTimeZone49.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = dateTimeFormatter47.withZone(dateTimeZone49);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(28800010L, dateTimeZone49);
        org.joda.time.DateTime.Property property56 = dateTime55.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField57 = property56.getField();
        org.joda.time.DateTime dateTime58 = property56.getDateTime();
        org.joda.time.DateTime dateTime59 = property56.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeUtils.getZone(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone61);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeUtils.getZone(dateTimeZone64);
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeUtils.getZone(dateTimeZone65);
        org.joda.time.DateTime dateTime67 = dateTime63.withZone(dateTimeZone65);
        int int68 = dateTime63.getYear();
        org.joda.time.DateTime dateTime70 = dateTime63.minusMonths(100);
        org.joda.time.DateTime.Property property71 = dateTime70.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property71.getFieldType();
        int int73 = dateTime59.get(dateTimeFieldType72);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField36, dateTimeFieldType72, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology77 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField78 = iSOChronology77.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology76, dateTimeField78);
        int int80 = skipUndoDateTimeField79.getMaximumValue();
        org.joda.time.MonthDay monthDay82 = new org.joda.time.MonthDay((long) 53);
        int int83 = skipUndoDateTimeField79.getMinimumValue((org.joda.time.ReadablePartial) monthDay82);
        java.util.Locale locale85 = null;
        java.lang.String str86 = offsetDateTimeField75.getAsShortText((org.joda.time.ReadablePartial) monthDay82, 53, locale85);
        org.joda.time.DateTimeFieldType dateTimeFieldType87 = offsetDateTimeField75.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder89 = dateTimeFormatterBuilder30.appendFixedSignedDecimal(dateTimeFieldType87, (int) '4');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField91 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType87, (int) '#');
        int int92 = instant3.get(dateTimeFieldType87);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1582-288T00:00:00Z" + "'", str5.equals("1582-288T00:00:00Z"));
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292275053) + "'", int12 == (-292275053));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970" + "'", str14.equals("1970"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1" + "'", str19.equals("-1"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimePrinter29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-292275053) + "'", int37 == (-292275053));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970" + "'", str39.equals("1970"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "-1" + "'", str44.equals("-1"));
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1970 + "'", int68 == 1970);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(iSOChronology77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 292278993 + "'", int80 == 292278993);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-292275054) + "'", int83 == (-292275054));
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "53" + "'", str86.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType87);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder89);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        long long9 = copticChronology0.getDateTimeMillis((long) 10, 0, (int) ' ', (int) (byte) 0, (int) 'a');
        java.lang.String str10 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1920097L + "'", long9 == 1920097L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CopticChronology[UTC]" + "'", str10.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.Chronology chronology13 = buddhistChronology5.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField45);
        int int47 = skipUndoDateTimeField46.getMaximumValue();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((long) 53);
        int int50 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) monthDay49, 53, locale52);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeUtils.getZone(dateTimeZone55);
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeUtils.getZone(dateTimeZone58);
        int int61 = dateTimeZone59.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone59);
        org.joda.time.chrono.BuddhistChronology buddhistChronology63 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone59);
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone59);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.minus(readablePeriod66);
        int[] intArray69 = iSOChronology64.get((org.joda.time.ReadablePartial) monthDay67, 0L);
        int int70 = offsetDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) monthDay57, intArray69);
        java.lang.String str72 = offsetDateTimeField42.getAsShortText((long) 3);
        java.util.Locale locale75 = null;
        try {
            long long76 = offsetDateTimeField42.set(0L, "", locale75);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292278993 + "'", int47 == 292278993);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292275054) + "'", int50 == (-292275054));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "53" + "'", str53.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology63);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-292274953) + "'", int70 == (-292274953));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "2070" + "'", str72.equals("2070"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        boolean boolean10 = dateTimeZone2.isStandardOffset((long) (byte) -1);
        long long13 = dateTimeZone2.convertLocalToUTC((long) 2000, true);
        org.joda.time.Chronology chronology14 = gregorianChronology0.withZone(dateTimeZone2);
        java.lang.String str15 = dateTimeZone2.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2000L + "'", long13 == 2000L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.Chronology chronology32 = limitChronology3.withUTC();
        try {
            long long38 = limitChronology3.getDateTimeMillis((long) (short) 100, 3971, 1970, 6, 278);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3971 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        int int12 = property10.getLeapAmount();
        java.util.Locale locale13 = null;
        int int14 = property10.getMaximumTextLength(locale13);
        org.joda.time.DateTime dateTime15 = property10.withMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime15.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) limitChronology3);
//        org.joda.time.DurationField durationField5 = limitChronology3.weeks();
//        org.joda.time.DateTimeZone dateTimeZone6 = limitChronology3.getZone();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone6.getName((-9071994956L), locale8);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendFractionOfSecond(53, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfDay(292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendYear(292278993, 53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder14.appendFractionOfHour(16, 278);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap22 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendTimeZoneShortName(strMap22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", number1, (java.lang.Number) 19L, (java.lang.Number) 259200004L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime3.era();
        org.joda.time.DurationField durationField6 = property5.getRangeDurationField();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("DateTimeField[weekyear]", false, 1970, 2069);
        dateTimeFormatterBuilder5.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        java.lang.String str2 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfEra(1970);
        org.joda.time.DateTime dateTime11 = dateTime7.withYear(278);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField14);
        int int16 = skipUndoDateTimeField15.getMinimumValue();
        long long19 = skipUndoDateTimeField15.set((long) 5044, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = dateTime23.withZone(dateTimeZone25);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology28, dateTimeField30);
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipUndoDateTimeField31.getAsText(0, locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField31.getType();
        org.joda.time.DateTime dateTime37 = dateTime27.withField(dateTimeFieldType35, 1582);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField15, dateTimeFieldType35);
        org.joda.time.DateTime.Property property39 = dateTime11.property(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-292275053) + "'", int16 == (-292275053));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61851081594956L) + "'", long19 == (-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property39);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfEra(1970);
        org.joda.time.DateTime dateTime11 = dateTime7.minusWeeks(15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            java.lang.String str13 = dateTime11.toString(dateTimeFormatter12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendYear(292278993, 53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder14.appendFractionOfHour(16, 278);
        boolean boolean22 = dateTimeFormatterBuilder21.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        long long13 = skipUndoDateTimeField3.roundCeiling((-259200000L));
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay18.minus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay18, 278, locale22);
        int int24 = skipUndoDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay18);
        long long26 = skipUndoDateTimeField3.roundHalfEven(2010L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "278" + "'", str23.equals("278"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 292278993 + "'", int24 == 292278993);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-259200000L) + "'", long26 == (-259200000L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime dateTime11 = dateTime8.minusMinutes(1969);
        org.joda.time.DateTime dateTime13 = dateTime8.withWeekyear(9);
        try {
            org.joda.time.DateTime dateTime17 = dateTime8.withDate(1686, 3969, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3969 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = copticChronology0.minutes();
        int int6 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(69);
        org.joda.time.Chronology chronology9 = copticChronology0.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField11.getAsText(0, locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField11.getType();
        org.joda.time.DateTime dateTime17 = dateTime7.withField(dateTimeFieldType15, 1582);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, 3971, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3971 for weekyear must be in the range [6,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 100);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.String str5 = instant3.toString(dateTimeFormatter4);
        org.joda.time.Chronology chronology6 = instant3.getChronology();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1582-288T00:00:00Z" + "'", str5.equals("1582-288T00:00:00Z"));
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology0);
        try {
            org.joda.time.DateTimeField dateTimeField4 = monthDay2.getField(278);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 278");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime4 = instant3.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime();
        boolean boolean6 = mutableDateTime5.isBeforeNow();
        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "Thursday", 0);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeFormatter0.getZone();
        boolean boolean11 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology0, obj1);
        org.joda.time.DurationField durationField3 = julianChronology0.weekyears();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
//        int int8 = dateTime7.getMinuteOfHour();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay9.withPeriodAdded(readablePeriod12, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay16 = monthDay9.minusDays((-1));
//        int[] intArray17 = monthDay16.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekyear();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.ReadableDateTime readableDateTime23 = null;
//        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
//        org.joda.time.DateTime dateTime25 = limitChronology24.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField26 = limitChronology24.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField26, (int) 'a');
//        long long31 = skipDateTimeField28.add(0L, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField28.getType();
//        boolean boolean33 = monthDay16.isSupported(dateTimeFieldType32);
//        org.joda.time.DateTime.Property property34 = dateTime7.property(dateTimeFieldType32);
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime36 = null;
//        org.joda.time.ReadableDateTime readableDateTime37 = null;
//        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology35, readableDateTime36, readableDateTime37);
//        org.joda.time.DateTime dateTime39 = limitChronology38.getLowerLimit();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
//        long long46 = dateTimeZone41.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
//        org.joda.time.Chronology chronology47 = limitChronology38.withZone(dateTimeZone41);
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone50 = gJChronology48.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        int int56 = dateTimeZone54.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean58 = dateTimeZone54.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = dateTimeFormatter52.withZone(dateTimeZone54);
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(28800010L, dateTimeZone54);
//        org.joda.time.DateTime.Property property61 = dateTime60.dayOfWeek();
//        org.joda.time.DateTime dateTime63 = dateTime60.minusWeeks(10);
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) dateTime63, (int) (byte) 1);
//        org.joda.time.Chronology chronology66 = limitChronology38.withZone(dateTimeZone50);
//        org.joda.time.chrono.GJChronology gJChronology67 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology68 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField69 = iSOChronology68.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField70 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology67, dateTimeField69);
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = skipUndoDateTimeField70.getAsText(0, locale72);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField70, 2000);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField77 = new org.joda.time.field.SkipUndoDateTimeField(chronology66, (org.joda.time.DateTimeField) offsetDateTimeField75, (-28800000));
//        java.lang.String str79 = offsetDateTimeField75.getAsText((long) 4);
//        int int81 = offsetDateTimeField75.getLeapAmount(10L);
//        org.joda.time.DurationField durationField82 = offsetDateTimeField75.getDurationField();
//        int int83 = dateTime7.get((org.joda.time.DateTimeField) offsetDateTimeField75);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(limitChronology24);
//        org.junit.Assert.assertNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(limitChronology38);
//        org.junit.Assert.assertNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
//        org.junit.Assert.assertNotNull(chronology47);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(chronology66);
//        org.junit.Assert.assertNotNull(gJChronology67);
//        org.junit.Assert.assertNotNull(iSOChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "0" + "'", str73.equals("0"));
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "3970" + "'", str79.equals("3970"));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
//        org.junit.Assert.assertNotNull(durationField82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 4019 + "'", int83 == 4019);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withDefaultYear(5044);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter13.withZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone16);
        try {
            long long27 = zonedChronology19.getDateTimeMillis((int) (short) 0, 1686, 292278993, (int) (byte) 100, 31, 278, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(zonedChronology19);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.DateTime dateTime50 = property48.getDateTime();
        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
        int int60 = dateTime55.getYear();
        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
        int int72 = skipUndoDateTimeField71.getMaximumValue();
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
        long long85 = dividedDateTimeField83.roundFloor(0L);
        java.lang.String str86 = dividedDateTimeField83.toString();
        long long88 = dividedDateTimeField83.remainder((long) 10);
        long long90 = dividedDateTimeField83.remainder((long) (-292275053));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-315360000000L) + "'", long85 == (-315360000000L));
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "DateTimeField[secondOfDay]" + "'", str86.equals("DateTimeField[secondOfDay]"));
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 10L + "'", long88 == 10L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-292275053L) + "'", long90 == (-292275053L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) limitChronology3);
        org.joda.time.DurationField durationField5 = limitChronology3.weeks();
        org.joda.time.DurationField durationField6 = limitChronology3.eras();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, 292279093);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
        boolean boolean14 = dateTimeZone10.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter8.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(28800010L, dateTimeZone10);
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = property17.getField();
        org.joda.time.DateTime dateTime19 = property17.getDateTime();
        org.joda.time.Instant instant20 = dateTime19.toInstant();
        int int21 = dateTime19.getDayOfWeek();
        org.joda.time.DateTime dateTime23 = dateTime19.withMinuteOfHour(3);
        int int24 = property6.compareTo((org.joda.time.ReadableInstant) dateTime19);
        int int25 = dateTime19.getSecondOfMinute();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.DateTime dateTime12 = property10.getDateTime();
        org.joda.time.DateTime dateTime13 = property10.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = dateTime17.withZone(dateTimeZone19);
        int int22 = dateTime17.getYear();
        org.joda.time.DateTime dateTime24 = dateTime17.minusMonths(100);
        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
        int int27 = dateTime13.get(dateTimeFieldType26);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType26, 292279093, 0, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279093 for secondOfDay must be in the range [0,1969]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1970 + "'", int22 == 1970);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        boolean boolean6 = dateTimeZone2.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.withZone(dateTimeZone13);
        int int16 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        int int18 = dateTime15.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1970 + "'", int18 == 1970);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        long long13 = skipUndoDateTimeField3.roundCeiling((-259200000L));
        long long15 = skipUndoDateTimeField3.roundHalfCeiling((long) 2);
        int int17 = skipUndoDateTimeField3.get((-8899200000L));
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay18.minus(readablePeriod19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay23 = monthDay18.withPeriodAdded(readablePeriod21, (int) (byte) 0);
        org.joda.time.MonthDay monthDay25 = monthDay18.minusDays((-1));
        int[] intArray26 = monthDay25.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.weekyear();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.chrono.LimitChronology limitChronology33 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology30, readableDateTime31, readableDateTime32);
        org.joda.time.DateTime dateTime34 = limitChronology33.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField35 = limitChronology33.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology27, dateTimeField35, (int) 'a');
        long long40 = skipDateTimeField37.add(0L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField37.getType();
        boolean boolean42 = monthDay25.isSupported(dateTimeFieldType41);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.MonthDay monthDay44 = monthDay25.minus(readablePeriod43);
        int int45 = skipUndoDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay25);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(copticChronology30);
        org.junit.Assert.assertNotNull(limitChronology33);
        org.junit.Assert.assertNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-292275054) + "'", int45 == (-292275054));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getDayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        int int13 = skipUndoDateTimeField12.getMinimumValue();
        long long16 = skipUndoDateTimeField12.set((long) 5044, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = dateTime20.withZone(dateTimeZone22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(0, locale30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipUndoDateTimeField28.getType();
        org.joda.time.DateTime dateTime34 = dateTime24.withField(dateTimeFieldType32, 1582);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType32);
        org.joda.time.DateTime.Property property36 = dateTime3.property(dateTimeFieldType32);
        java.lang.String str37 = property36.getAsText();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-292275053) + "'", int13 == (-292275053));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851081594956L) + "'", long16 == (-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1970" + "'", str37.equals("1970"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = buddhistChronology0.withZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        java.lang.Object obj6 = null;
        boolean boolean7 = limitChronology3.equals(obj6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = limitChronology3.withZone(dateTimeZone8);
        try {
            long long17 = limitChronology3.getDateTimeMillis(2, (int) (short) 10, 0, (-28800000), 3969, 53, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = copticChronology9.add(readablePeriod10, (long) (short) 10, (int) '#');
        org.joda.time.DateTime dateTime14 = dateTime7.toDateTime((org.joda.time.Chronology) copticChronology9);
        try {
            long long19 = copticChronology9.getDateTimeMillis(20, 0, 292279093, 5044);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
        long long6 = dateTimeZone1.convertLocalToUTC((long) 4019, false, (-62135337598418L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4019L + "'", long6 == 4019L);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
//        int int8 = dateTime7.getMinuteOfHour();
//        org.joda.time.DateTime dateTime10 = dateTime7.withMillis(0L);
//        int int11 = dateTime10.getYear();
//        long long12 = dateTime10.getMillis();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1686 + "'", int11 == 1686);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        long long7 = skipUndoDateTimeField3.set((long) 5044, (int) (byte) 10);
        int int8 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str9 = skipUndoDateTimeField3.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = skipUndoDateTimeField3.getType();
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField3.getAsText(0L, locale12);
        long long15 = skipUndoDateTimeField3.roundHalfCeiling((long) (-1));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851081594956L) + "'", long7 == (-61851081594956L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275053) + "'", int8 == (-292275053));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "weekyear" + "'", str9.equals("weekyear"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long12 = skipDateTimeField10.roundHalfFloor((long) 1);
        java.lang.String str14 = skipDateTimeField10.getAsText(52L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "17" + "'", str14.equals("17"));
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.MonthDay monthDay3 = monthDay1.minus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay1.withPeriodAdded(readablePeriod4, (int) (byte) 0);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField9);
//        boolean boolean11 = monthDay6.equals((java.lang.Object) skipUndoDateTimeField10);
//        java.lang.String str12 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay6);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        try {
//            int int14 = monthDay6.compareTo(readablePartial13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����0615T������" + "'", str12.equals("����0615T������"));
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        int int4 = gJChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology5 = gJChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone7);
        int int10 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone18);
        int int21 = dateTime16.getYear();
        org.joda.time.DateTime dateTime23 = dateTime16.minusMonths(100);
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.DateTime.Property property26 = dateTime12.property(dateTimeFieldType25);
        boolean boolean27 = gJChronology1.equals((java.lang.Object) dateTimeFieldType25);
        try {
            org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((java.lang.Object) gJChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1970 + "'", int21 == 1970);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, dateTimeField34);
        org.joda.time.DurationField durationField37 = limitChronology3.hours();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField37);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0.0f, number2, (java.lang.Number) 32054400010L);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32054400010L + "'", number5.equals(32054400010L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 32054400010L + "'", number6.equals(32054400010L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
        int int7 = property6.getMaximumValueOverall();
        int int8 = property6.getMinimumValue();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long12 = skipDateTimeField10.roundHalfFloor((long) 1);
        boolean boolean13 = skipDateTimeField10.isLenient();
        long long15 = skipDateTimeField10.roundHalfCeiling(28800100L);
        java.lang.String str17 = skipDateTimeField10.getAsShortText(0L);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField24);
        int int26 = skipUndoDateTimeField25.getMinimumValue();
        java.lang.String str28 = skipUndoDateTimeField25.getAsText(97L);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField25.getAsText((org.joda.time.ReadablePartial) monthDay30, (int) (short) -1, locale32);
        org.joda.time.DurationField durationField34 = skipUndoDateTimeField25.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeUtils.getZone(dateTimeZone37);
        int int40 = dateTimeZone38.getOffsetFromLocal((long) (byte) 10);
        boolean boolean42 = dateTimeZone38.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter36.withZone(dateTimeZone38);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(28800010L, dateTimeZone38);
        org.joda.time.DateTime.Property property45 = dateTime44.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField46 = property45.getField();
        org.joda.time.DateTime dateTime47 = property45.getDateTime();
        org.joda.time.DateTime dateTime48 = property45.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeUtils.getZone(dateTimeZone50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
        org.joda.time.DateTime dateTime56 = dateTime52.withZone(dateTimeZone54);
        int int57 = dateTime52.getYear();
        org.joda.time.DateTime dateTime59 = dateTime52.minusMonths(100);
        org.joda.time.DateTime.Property property60 = dateTime59.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property60.getFieldType();
        int int62 = dateTime48.get(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField25, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = iSOChronology66.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField68 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology65, dateTimeField67);
        int int69 = skipUndoDateTimeField68.getMaximumValue();
        org.joda.time.MonthDay monthDay71 = new org.joda.time.MonthDay((long) 53);
        int int72 = skipUndoDateTimeField68.getMinimumValue((org.joda.time.ReadablePartial) monthDay71);
        java.util.Locale locale74 = null;
        java.lang.String str75 = offsetDateTimeField64.getAsShortText((org.joda.time.ReadablePartial) monthDay71, 53, locale74);
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeUtils.getZone(dateTimeZone76);
        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeUtils.getZone(dateTimeZone77);
        org.joda.time.MonthDay monthDay79 = org.joda.time.MonthDay.now(dateTimeZone78);
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.DateTimeZone dateTimeZone81 = org.joda.time.DateTimeUtils.getZone(dateTimeZone80);
        int int83 = dateTimeZone81.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone81);
        org.joda.time.chrono.BuddhistChronology buddhistChronology85 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone81);
        org.joda.time.chrono.ISOChronology iSOChronology86 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone81);
        org.joda.time.MonthDay monthDay87 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod88 = null;
        org.joda.time.MonthDay monthDay89 = monthDay87.minus(readablePeriod88);
        int[] intArray91 = iSOChronology86.get((org.joda.time.ReadablePartial) monthDay89, 0L);
        int int92 = offsetDateTimeField64.getMinimumValue((org.joda.time.ReadablePartial) monthDay79, intArray91);
        int int93 = skipDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) monthDay21, intArray91);
        long long95 = skipDateTimeField10.roundHalfEven((long) 9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "17" + "'", str17.equals("17"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292275053) + "'", int26 == (-292275053));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-1" + "'", str33.equals("-1"));
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1970 + "'", int57 == 1970);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(gJChronology65);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 292278993 + "'", int69 == 292278993);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-292275054) + "'", int72 == (-292275054));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "53" + "'", str75.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeZone77);
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertNotNull(dateTimeZone81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology85);
        org.junit.Assert.assertNotNull(iSOChronology86);
        org.junit.Assert.assertNotNull(monthDay87);
        org.junit.Assert.assertNotNull(monthDay89);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-292274953) + "'", int92 == (-292274953));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 53 + "'", int93 == 53);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + (-259200000L) + "'", long95 == (-259200000L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        long long7 = skipUndoDateTimeField3.set((long) 5044, (int) (byte) 10);
        org.joda.time.DurationField durationField8 = skipUndoDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851081594956L) + "'", long7 == (-61851081594956L));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(315705600002L, (-315360000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 345600002L + "'", long2 == 345600002L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendFractionOfDay(1, 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfDay(4, (int) (byte) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendTimeZoneOffset("", "CopticChronology[UTC]", true, 278, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendPattern("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfHalfday(5044);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendMinuteOfDay(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(1686);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYear(69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1969);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (byte) 1, 3969, 0, 'a', 10, (-28378000), 31, false, 292279093);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(100, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMonthOfYear((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay4, 278, locale8);
//        int int10 = monthDay4.getDayOfMonth();
//        java.lang.String str11 = monthDay4.toString();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "278" + "'", str9.equals("278"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "--06-15" + "'", str11.equals("--06-15"));
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        java.util.Locale locale44 = null;
        java.lang.String str45 = offsetDateTimeField42.getAsShortText((int) '4', locale44);
        long long48 = offsetDateTimeField42.add((long) 2069, 100L);
        java.util.Locale locale51 = null;
        try {
            long long52 = offsetDateTimeField42.set((long) 0, "DateTimeField[weekyear]", locale51);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[weekyear]\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 3155846402069L + "'", long48 == 3155846402069L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        int int14 = dateTimeZone12.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone12);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant20 = instant18.minus(readableDuration19);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) instant20, (org.joda.time.Chronology) copticChronology21);
        int int26 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime25);
        boolean boolean27 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime29 = dateTime25.plusHours(12);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        java.lang.Object obj6 = null;
        boolean boolean7 = limitChronology3.equals(obj6);
        org.joda.time.DurationField durationField8 = limitChronology3.months();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
        long long22 = skipDateTimeField19.add(0L, 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, (org.joda.time.DateTimeField) skipDateTimeField19);
        int int24 = skipDateTimeField19.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(16, (int) 'a', (-292275053), 2069, 100, 5044, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2069 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.DateTime dateTime50 = property48.getDateTime();
        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
        int int60 = dateTime55.getYear();
        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
        int int72 = skipUndoDateTimeField71.getMaximumValue();
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
        long long85 = dividedDateTimeField83.roundFloor(0L);
        int int86 = dividedDateTimeField83.getDivisor();
        long long89 = dividedDateTimeField83.set((-62135337598418L), 15);
        org.joda.time.DurationField durationField90 = dividedDateTimeField83.getRangeDurationField();
        int int91 = dividedDateTimeField83.getDivisor();
        int int93 = dividedDateTimeField83.get(345600002L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-315360000000L) + "'", long85 == (-315360000000L));
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 35 + "'", int86 == 35);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-45568051198418L) + "'", long89 == (-45568051198418L));
        org.junit.Assert.assertNull(durationField90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 35 + "'", int91 == 35);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 56 + "'", int93 == 56);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(28800100L, dateTimeZone1);
        int int3 = dateTime2.getMinuteOfDay();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 480 + "'", int3 == 480);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime9.minusWeeks(10);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withYear(292280993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292280993 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay4, 278, locale8);
//        int int10 = monthDay4.getDayOfMonth();
//        org.joda.time.DateTimeField[] dateTimeFieldArray11 = monthDay4.getFields();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "278" + "'", str9.equals("278"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter12, dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime5.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime9.withTimeAtStartOfDay();
        boolean boolean12 = dateTime9.isBefore((long) (byte) -1);
        org.joda.time.DateTime dateTime14 = dateTime9.plusWeeks(53);
        org.joda.time.LocalDateTime localDateTime15 = dateTime9.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDateTime15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDateTime15);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(0L);
        org.joda.time.DateTime.Property property7 = dateTime3.era();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone9);
        try {
            long long12 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (-28800000));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        java.util.Locale locale12 = null;
        java.lang.String str13 = property10.getAsText(locale12);
        int int14 = property10.getMinimumValueOverall();
        java.util.Locale locale15 = null;
        int int16 = property10.getMaximumShortTextLength(locale15);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thursday" + "'", str13.equals("Thursday"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        int int4 = gJChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology5 = gJChronology1.withUTC();
        org.joda.time.Instant instant6 = gJChronology1.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        boolean boolean10 = dateTime7.isBefore((long) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime7.plusWeeks(53);
        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime15 = dateTime12.minusMillis((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        int int4 = instant1.get(dateTimeField3);
        boolean boolean6 = instant1.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant1.withDurationAdded(readableDuration7, 10);
        org.joda.time.Instant instant11 = instant9.withMillis(1920097L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 278 + "'", int4 == 278);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTime dateTime12 = property9.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime13 = property9.roundFloorCopy();
        java.util.Locale locale14 = null;
        java.util.Calendar calendar15 = dateTime13.toCalendar(locale14);
        org.joda.time.DateTime dateTime17 = dateTime13.minusYears((-292275053));
        org.joda.time.DateTime dateTime19 = dateTime17.plusMinutes(292280993);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(calendar15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        try {
            long long8 = copticChronology0.getDateTimeMillis(1095292805044L, 0, 1969, (int) (byte) 10, 69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        boolean boolean2 = dateTime1.isEqualNow();
//        int int3 = dateTime1.getDayOfWeek();
//        org.joda.time.Chronology chronology4 = dateTime1.getChronology();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(chronology4);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime3.era();
        org.joda.time.DurationField durationField6 = property5.getRangeDurationField();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.DateTime.Property property10 = dateTime7.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        int int7 = property6.getMaximumValueOverall();
//        int int8 = property6.get();
//        java.lang.String str9 = property6.getName();
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfMonth" + "'", str9.equals("dayOfMonth"));
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMaximumValue();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) 53);
        int int7 = skipUndoDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = monthDay6.getFieldType((int) (short) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292275054) + "'", int7 == (-292275054));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
//        int int8 = dateTime7.getMinuteOfHour();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay9.withPeriodAdded(readablePeriod12, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay16 = monthDay9.minusDays((-1));
//        int[] intArray17 = monthDay16.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekyear();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.ReadableDateTime readableDateTime23 = null;
//        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
//        org.joda.time.DateTime dateTime25 = limitChronology24.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField26 = limitChronology24.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField26, (int) 'a');
//        long long31 = skipDateTimeField28.add(0L, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField28.getType();
//        boolean boolean33 = monthDay16.isSupported(dateTimeFieldType32);
//        org.joda.time.DateTime.Property property34 = dateTime7.property(dateTimeFieldType32);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone36);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.DateTime dateTime41 = dateTime38.withPeriodAdded(readablePeriod39, 278);
//        org.joda.time.DateTime dateTime42 = dateTime41.withTimeAtStartOfDay();
//        int int43 = dateTime42.getMinuteOfDay();
//        int int44 = property34.getDifference((org.joda.time.ReadableInstant) dateTime42);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(limitChronology24);
//        org.junit.Assert.assertNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2580 + "'", int44 == 2580);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.MonthDay monthDay9 = monthDay7.minus(readablePeriod8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay7.withPeriodAdded(readablePeriod10, (int) (byte) 0);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField15);
//        boolean boolean17 = monthDay12.equals((java.lang.Object) skipUndoDateTimeField16);
//        java.lang.String str18 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter6.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter22.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter24.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray32 = new org.joda.time.format.DateTimeParser[] { dateTimeParser21, dateTimeParser23, dateTimeParser25, dateTimeParser27, dateTimeParser29, dateTimeParser31 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder4.append(dateTimePrinter19, dateTimeParserArray32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendMillisOfDay(1970);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.appendYearOfCentury(3969, 3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "����0615T������" + "'", str18.equals("����0615T������"));
//        org.junit.Assert.assertNotNull(dateTimePrinter19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimeParser21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimeParser25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTimeParser29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeParser31);
//        org.junit.Assert.assertNotNull(dateTimeParserArray32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        boolean boolean6 = dateTimeZone2.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime15.withTimeAtStartOfDay();
        boolean boolean18 = dateTime15.isBefore((long) (byte) -1);
        org.joda.time.DateTime dateTime20 = dateTime15.plusWeeks(53);
        org.joda.time.LocalDateTime localDateTime21 = dateTime15.toLocalDateTime();
        boolean boolean22 = dateTimeZone2.isLocalDateTimeGap(localDateTime21);
        long long26 = dateTimeZone2.convertLocalToUTC(0L, false, (long) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField11.getAsText(0, locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField11.getType();
        org.joda.time.DateTime dateTime17 = dateTime7.withField(dateTimeFieldType15, 1582);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) (short) -1, (java.lang.Number) 31795200000L, (java.lang.Number) (-61851081594956L));
        java.lang.Throwable[] throwableArray22 = illegalFieldValueException21.getSuppressed();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime3.era();
        org.joda.time.DurationField durationField6 = property5.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone8);
        int int11 = dateTime10.getSecondOfMinute();
        int int12 = property5.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        int int7 = dateTimeZone5.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime11 = instant1.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        java.lang.String str12 = iSOChronology10.toString();
        org.joda.time.DurationField durationField13 = iSOChronology10.hours();
        java.lang.Object obj14 = null;
        boolean boolean15 = iSOChronology10.equals(obj14);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.year();
        org.joda.time.DurationField durationField3 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyearOfCentury();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0.0f, number2, (java.lang.Number) 32054400010L);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32054400010L + "'", number5.equals(32054400010L));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0" + "'", str7.equals("0.0"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        int int44 = offsetDateTimeField42.get(97L);
        long long46 = offsetDateTimeField42.roundHalfEven((-10L));
        int int48 = offsetDateTimeField42.getMinimumValue(28800010L);
        long long50 = offsetDateTimeField42.roundHalfCeiling((long) (byte) -1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2070 + "'", int44 == 2070);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-259200000L) + "'", long46 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-292274953) + "'", int48 == (-292274953));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-259200000L) + "'", long50 == (-259200000L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DurationField durationField11 = property10.getLeapDurationField();
        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
        java.util.Locale locale14 = null;
        try {
            org.joda.time.DateTime dateTime15 = property10.setCopy("1970-01-01T00:00:00", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-01-01T00:00:00\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendYearOfEra((int) '#', (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfSecond(278, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        int int44 = offsetDateTimeField42.getMinimumValue(32054400010L);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((long) 53);
        org.joda.time.MonthDay monthDay47 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay47.minus(readablePeriod48);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.MonthDay monthDay52 = monthDay47.withPeriodAdded(readablePeriod50, (int) (byte) 0);
        org.joda.time.MonthDay monthDay54 = monthDay47.minusDays((-1));
        int[] intArray55 = monthDay54.getValues();
        int int56 = offsetDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) monthDay46, intArray55);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-292274953) + "'", int44 == (-292274953));
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292279093 + "'", int56 == 292279093);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        boolean boolean5 = skipUndoDateTimeField3.isLeap((long) (-1));
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3);
        org.joda.time.DurationField durationField7 = skipUndoDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.DateTime dateTime12 = property10.getDateTime();
        org.joda.time.Interval interval13 = property10.toInterval();
        long long14 = property10.remainder();
        org.joda.time.DateTime dateTime15 = property10.roundHalfCeilingCopy();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime15.toMutableDateTime((org.joda.time.Chronology) julianChronology16);
        int int18 = dateTime15.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(interval13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800010L + "'", long14 == 28800010L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1970 + "'", int18 == 1970);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay5.minus(readablePeriod11);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(monthDay12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1969);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("278", (-10));
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset((-292274953));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder0.addCutover(1970, ' ', (-10), 20, (int) (byte) 10, true, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        int int6 = property4.getMinimumValueOverall();
        org.joda.time.MonthDay monthDay8 = property4.addToCopy(2069);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.DateTime dateTime50 = property48.getDateTime();
        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
        int int60 = dateTime55.getYear();
        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
        int int72 = skipUndoDateTimeField71.getMaximumValue();
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
        java.util.Locale locale85 = null;
        java.lang.String str86 = skipUndoDateTimeField3.getAsText(2580, locale85);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "2580" + "'", str86.equals("2580"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField45);
        int int47 = skipUndoDateTimeField46.getMaximumValue();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((long) 53);
        int int50 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) monthDay49, 53, locale52);
        int int55 = offsetDateTimeField42.getMaximumValue(0L);
        long long57 = offsetDateTimeField42.roundHalfEven((long) ' ');
        int int59 = offsetDateTimeField42.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292278993 + "'", int47 == 292278993);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292275054) + "'", int50 == (-292275054));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "53" + "'", str53.equals("53"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 292279093 + "'", int55 == 292279093);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-259200000L) + "'", long57 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 292279093 + "'", int59 == 292279093);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        long long13 = skipUndoDateTimeField3.roundCeiling((-259200000L));
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay18.minus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay18, 278, locale22);
        int int24 = skipUndoDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay18);
        java.util.Locale locale26 = null;
        try {
            java.lang.String str27 = monthDay18.toString("", locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "278" + "'", str23.equals("278"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 292278993 + "'", int24 == 292278993);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(3061497603971L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay0.minus(readablePeriod6);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean6 = dateTimeZone2.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime11.withZone(dateTimeZone13);
//        int int16 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(dateTimeZone2);
//        java.lang.String str19 = dateTimeZone2.getShortName(28800100L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) limitChronology3);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.DateTime dateTime6 = monthDay4.toDateTime(readableInstant5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay10 = monthDay8.minus(readablePeriod9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay8.withPeriodAdded(readablePeriod11, (int) (byte) 0);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
//        boolean boolean18 = monthDay13.equals((java.lang.Object) skipUndoDateTimeField17);
//        java.lang.String str19 = dateTimeFormatter7.print((org.joda.time.ReadablePartial) monthDay13);
//        boolean boolean20 = monthDay4.isEqual((org.joda.time.ReadablePartial) monthDay13);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "����0620T������" + "'", str19.equals("����0620T������"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime10.withZone(dateTimeZone12);
        int int15 = dateTime10.getYear();
        org.joda.time.DateTime dateTime17 = dateTime10.minusMonths(100);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.DateTime.Property property20 = dateTime6.property(dateTimeFieldType19);
        org.joda.time.DateTimeField dateTimeField21 = property20.getField();
        int int22 = property20.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 86399 + "'", int22 == 86399);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("53");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField35.getAsText(0, locale37);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, 2000);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, (org.joda.time.DateTimeField) offsetDateTimeField40, (-28800000));
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeUtils.getZone(dateTimeZone44);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone44);
        int int47 = dateTime46.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.DateTime dateTime49 = dateTime46.toDateTime(dateTimeZone48);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeUtils.getZone(dateTimeZone51);
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeUtils.getZone(dateTimeZone55);
        org.joda.time.DateTime dateTime57 = dateTime53.withZone(dateTimeZone55);
        int int58 = dateTime53.getYear();
        org.joda.time.DateTime dateTime60 = dateTime53.minusMonths(100);
        org.joda.time.DateTime.Property property61 = dateTime60.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.DateTime.Property property63 = dateTime49.property(dateTimeFieldType62);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField64 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField40, dateTimeFieldType62);
        boolean boolean65 = delegatedDateTimeField64.isLenient();
        java.util.Locale locale67 = null;
        java.lang.String str68 = delegatedDateTimeField64.getAsShortText(35, locale67);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1970 + "'", int58 == 1970);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "35" + "'", str68.equals("35"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.DateTime dateTime50 = property48.getDateTime();
        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
        int int60 = dateTime55.getYear();
        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
        int int72 = skipUndoDateTimeField71.getMaximumValue();
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
        long long85 = dividedDateTimeField83.roundFloor(0L);
        int int88 = dividedDateTimeField83.getDifference((long) (short) 10, (long) 31);
        org.joda.time.DurationField durationField89 = dividedDateTimeField83.getDurationField();
        org.joda.time.DurationField durationField90 = dividedDateTimeField83.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-315360000000L) + "'", long85 == (-315360000000L));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(durationField89);
        org.junit.Assert.assertNotNull(durationField90);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = copticChronology7.add(readablePeriod8, (long) (short) 10, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(1, (int) (short) 100, 69, 3971, (int) '#', 69, 2580, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3971 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withDefaultYear(5044);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter13.withZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone16);
        org.joda.time.Chronology chronology20 = zonedChronology19.withUTC();
        long long26 = zonedChronology19.getDateTimeMillis((long) 10, 0, 0, 19, (int) (byte) 10);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 19010L + "'", long26 == 19010L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        long long6 = dateTimeZone1.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        int int13 = dateTimeZone11.getOffsetFromLocal((long) (byte) 10);
        boolean boolean15 = dateTimeZone11.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter9.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(28800010L, dateTimeZone11);
        org.joda.time.DateTime.Property property18 = dateTime17.dayOfWeek();
        org.joda.time.DateTime dateTime19 = property18.roundFloorCopy();
        org.joda.time.DateTime.Property property20 = dateTime19.dayOfWeek();
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(2000L, 3971);
        try {
            org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime23, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        long long13 = skipUndoDateTimeField3.roundCeiling((-259200000L));
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField3.getRangeDurationField();
        long long16 = skipUndoDateTimeField3.roundHalfEven(1686L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        boolean boolean5 = dateTimeZone1.isStandardOffset(28800100L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone6.previousTransition((long) (-292275054));
        int int10 = cachedDateTimeZone6.getStandardOffset((long) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-292275054L) + "'", long8 == (-292275054L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.MonthDay monthDay9 = monthDay7.minus(readablePeriod8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay7.withPeriodAdded(readablePeriod10, (int) (byte) 0);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField15);
//        boolean boolean17 = monthDay12.equals((java.lang.Object) skipUndoDateTimeField16);
//        java.lang.String str18 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter6.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter22.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter24.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray32 = new org.joda.time.format.DateTimeParser[] { dateTimeParser21, dateTimeParser23, dateTimeParser25, dateTimeParser27, dateTimeParser29, dateTimeParser31 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder4.append(dateTimePrinter19, dateTimeParserArray32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder4.appendWeekOfWeekyear(6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "����0620T������" + "'", str18.equals("����0620T������"));
//        org.junit.Assert.assertNotNull(dateTimePrinter19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimeParser21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimeParser25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTimeParser29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeParser31);
//        org.junit.Assert.assertNotNull(dateTimeParserArray32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
//        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
//        int int11 = monthDay5.getDayOfMonth();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter13.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter18.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder12.append(dateTimePrinter19);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone22);
//        int int25 = dateTime24.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.toDateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = dateTime31.withZone(dateTimeZone33);
//        int int36 = dateTime31.getYear();
//        org.joda.time.DateTime dateTime38 = dateTime31.minusMonths(100);
//        org.joda.time.DateTime.Property property39 = dateTime38.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
//        org.joda.time.DateTime.Property property41 = dateTime27.property(dateTimeFieldType40);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder12.appendSignedDecimal(dateTimeFieldType40, 0, (int) '4');
//        int int45 = monthDay5.indexOf(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimePrinter19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1970 + "'", int36 == 1970);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField11.getAsText(0, locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField11.getType();
        org.joda.time.DateTime dateTime17 = dateTime7.withField(dateTimeFieldType15, 1582);
        java.util.Locale locale18 = null;
        java.util.Calendar calendar19 = dateTime7.toCalendar(locale18);
        org.joda.time.DateTime dateTime21 = dateTime7.minusWeeks(86399);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(calendar19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("dayOfWeek");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: O");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendPattern("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(292279093, 278);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitWeekyear(292280993, false);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendHourOfDay((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.minus(readablePeriod8);
        int[] intArray11 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology6.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.minus(readablePeriod18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay17.withPeriodAdded(readablePeriod20, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField25);
        boolean boolean27 = monthDay22.equals((java.lang.Object) skipUndoDateTimeField26);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, (org.joda.time.DateTimeField) skipUndoDateTimeField26);
        java.lang.String str30 = skipUndoDateTimeField26.getAsText((-10L));
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeField) skipUndoDateTimeField26, 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970" + "'", str30.equals("1970"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.DateTime dateTime50 = property48.getDateTime();
        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
        int int60 = dateTime55.getYear();
        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
        int int72 = skipUndoDateTimeField71.getMaximumValue();
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
        long long85 = dividedDateTimeField83.roundFloor(0L);
        int int88 = dividedDateTimeField83.getDifference((long) (short) 10, (long) 31);
        java.lang.Object obj89 = null;
        org.joda.time.DateTime dateTime90 = new org.joda.time.DateTime(obj89);
        org.joda.time.MonthDay monthDay91 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay93 = monthDay91.minusMonths((-1));
        org.joda.time.DateTime dateTime94 = dateTime90.withFields((org.joda.time.ReadablePartial) monthDay91);
        int int95 = dividedDateTimeField83.getMaximumValue((org.joda.time.ReadablePartial) monthDay91);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-315360000000L) + "'", long85 == (-315360000000L));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(monthDay91);
        org.junit.Assert.assertNotNull(monthDay93);
        org.junit.Assert.assertNotNull(dateTime94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 8350828 + "'", int95 == 8350828);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (short) 10, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = copticChronology0.getZone();
        long long9 = dateTimeZone5.convertLocalToUTC((long) 56, true, (long) 1686);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 56L + "'", long9 == 56L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        java.util.Locale locale43 = null;
        int int44 = offsetDateTimeField42.getMaximumTextLength(locale43);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 9 + "'", int44 == 9);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitYear(53, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.minus(readableDuration4);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getYear();
        org.joda.time.DateTime dateTime10 = dateTime3.minusDays((-28378000));
        boolean boolean11 = dateTime3.isEqualNow();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology4.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean14 = dateTimeZone10.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter8.withZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(28800010L, dateTimeZone10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        org.joda.time.DateTime dateTime19 = dateTime16.minusWeeks(10);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) dateTime19, (int) (byte) 1);
//        org.joda.time.DateTime dateTime22 = dateTime2.withZoneRetainFields(dateTimeZone6);
//        int int23 = dateTime2.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2116172T212016Z" + "'", str3.equals("2116172T212016Z"));
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 528 + "'", int23 == 528);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1582-10-15T00:00:00.000Z", dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1582-10-15T00:00:00.000Z\" is malformed at \"82-10-15T00:00:00.000Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendTimeZoneOffset("Coordinated Universal Time", true, (int) (byte) 1, 53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale3 = null;
        java.lang.String str6 = defaultNameProvider0.getName(locale3, "52", "52");
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTime dateTime12 = property9.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime13 = property9.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        boolean boolean3 = mutableDateTime1.isBefore((long) 16);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay4.withPeriodAdded(readablePeriod7, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        boolean boolean14 = monthDay9.equals((java.lang.Object) skipUndoDateTimeField13);
        boolean boolean15 = skipUndoDateTimeField13.isSupported();
        long long18 = skipUndoDateTimeField13.set((long) 1582, 1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField13.getAsText((long) 1582, locale20);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField13, (int) (short) 0);
        long long25 = skipUndoDateTimeField13.roundHalfCeiling((-65322633599990L));
        boolean boolean27 = skipUndoDateTimeField13.isLeap(28800100L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135337598418L) + "'", long18 == (-62135337598418L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-65322892800000L) + "'", long25 == (-65322892800000L));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        boolean boolean13 = dateTimeZone9.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(28800010L, dateTimeZone9);
        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime15.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime18, (int) (byte) 1);
        int int21 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime22 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property23 = dateTime18.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long13 = skipDateTimeField10.add(0L, 0);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone16);
        int[] intArray21 = new int[] { 31, 31, '4' };
        int int22 = skipDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) monthDay17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology24, dateTimeField26);
        boolean boolean29 = skipUndoDateTimeField27.isLeap((long) (-1));
        java.util.Locale locale31 = null;
        java.lang.String str32 = skipUndoDateTimeField27.getAsShortText((long) (-1), locale31);
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.minus(readablePeriod34);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.MonthDay monthDay38 = monthDay33.withPeriodAdded(readablePeriod36, (int) (byte) 0);
        org.joda.time.MonthDay monthDay40 = monthDay33.minusDays((-1));
        int[] intArray41 = monthDay40.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.weekyear();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.ReadableDateTime readableDateTime47 = null;
        org.joda.time.chrono.LimitChronology limitChronology48 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology45, readableDateTime46, readableDateTime47);
        org.joda.time.DateTime dateTime49 = limitChronology48.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField50 = limitChronology48.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology42, dateTimeField50, (int) 'a');
        long long55 = skipDateTimeField52.add(0L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = skipDateTimeField52.getType();
        boolean boolean57 = monthDay40.isSupported(dateTimeFieldType56);
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology58, dateTimeField60);
        org.joda.time.MonthDay monthDay62 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay64 = monthDay62.minusMonths((-1));
        int[] intArray67 = new int[] { (short) 100 };
        int[] intArray69 = skipUndoDateTimeField61.add((org.joda.time.ReadablePartial) monthDay62, (-28800000), intArray67, (int) (byte) 0);
        int int70 = skipUndoDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) monthDay40, intArray69);
        int int71 = skipDateTimeField10.getMaximumValue(readablePartial23, intArray69);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1970" + "'", str32.equals("1970"));
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(copticChronology45);
        org.junit.Assert.assertNotNull(limitChronology48);
        org.junit.Assert.assertNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(monthDay62);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-292275054) + "'", int70 == (-292275054));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 53 + "'", int71 == 53);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(94L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        org.joda.time.DurationField durationField7 = property6.getRangeDurationField();
//        int int8 = property6.get();
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(94L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime.Property property4 = dateTime3.weekyear();
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = dateTime3.toString("Thursday, January 1, 1970 12:00:00 AM UTC", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        int int44 = offsetDateTimeField42.get(97L);
        long long46 = offsetDateTimeField42.roundHalfEven((-10L));
        long long49 = offsetDateTimeField42.add((-61851081594956L), (long) 1969);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2070 + "'", int44 == 2070);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-259200000L) + "'", long46 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 284256005044L + "'", long49 == 284256005044L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
        org.joda.time.DurationField durationField7 = property6.getRangeDurationField();
        long long10 = durationField7.subtract((-259200000L), (long) 9);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-24019200000L) + "'", long10 == (-24019200000L));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("CopticChronology[UTC]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        int int7 = property6.getMaximumValueOverall();
//        int int8 = property6.get();
//        org.joda.time.MonthDay monthDay10 = property6.setCopy((int) (short) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property6.getFieldType();
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        java.util.Locale locale44 = null;
        java.lang.String str45 = offsetDateTimeField42.getAsShortText((int) '4', locale44);
        java.util.Locale locale46 = null;
        int int47 = offsetDateTimeField42.getMaximumShortTextLength(locale46);
        org.joda.time.ReadablePartial readablePartial48 = null;
        int int49 = offsetDateTimeField42.getMinimumValue(readablePartial48);
        java.util.Locale locale50 = null;
        int int51 = offsetDateTimeField42.getMaximumTextLength(locale50);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-292274953) + "'", int49 == (-292274953));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 9 + "'", int51 == 9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        boolean boolean5 = skipUndoDateTimeField3.isLeap((long) (-1));
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipUndoDateTimeField3.getAsShortText((long) (-1), locale7);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay9.withPeriodAdded(readablePeriod12, (int) (byte) 0);
        org.joda.time.MonthDay monthDay16 = monthDay9.minusDays((-1));
        int[] intArray17 = monthDay16.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekyear();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
        org.joda.time.DateTime dateTime25 = limitChronology24.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField26 = limitChronology24.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField26, (int) 'a');
        long long31 = skipDateTimeField28.add(0L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField28.getType();
        boolean boolean33 = monthDay16.isSupported(dateTimeFieldType32);
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField36);
        org.joda.time.MonthDay monthDay38 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay40 = monthDay38.minusMonths((-1));
        int[] intArray43 = new int[] { (short) 100 };
        int[] intArray45 = skipUndoDateTimeField37.add((org.joda.time.ReadablePartial) monthDay38, (-28800000), intArray43, (int) (byte) 0);
        int int46 = skipUndoDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay16, intArray45);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3);
        org.joda.time.DurationField durationField48 = skipUndoDateTimeField3.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970" + "'", str8.equals("1970"));
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-292275054) + "'", int46 == (-292275054));
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = copticChronology0.minutes();
        org.joda.time.DurationField durationField6 = copticChronology0.eras();
        try {
            long long12 = copticChronology0.getDateTimeMillis(2010L, (int) (short) 0, 56, (int) (byte) 100, 2069);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property6.getAsText(locale7);
//        java.lang.String str9 = property6.getName();
//        int int10 = property6.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "20" + "'", str8.equals("20"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfMonth" + "'", str9.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, 2000);
        long long10 = offsetDateTimeField8.roundHalfEven((long) 9);
        long long13 = offsetDateTimeField8.add((long) 278, 19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 599961600278L + "'", long13 == 599961600278L);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology7);
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.plus(readablePeriod10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter13.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter18.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder12.append(dateTimePrinter19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendLiteral("AD");
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatterBuilder20.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder20.appendHourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendMinuteOfHour(31);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = dateTime31.withZone(dateTimeZone33);
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology36, dateTimeField38);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = skipUndoDateTimeField39.getAsText(0, locale41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipUndoDateTimeField39.getType();
//        org.joda.time.DateTime dateTime45 = dateTime35.withField(dateTimeFieldType43, 1582);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder27.appendFraction(dateTimeFieldType43, 5044, 292279093);
//        int int49 = monthDay11.indexOf(dateTimeFieldType43);
//        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        long long54 = copticChronology50.add(readablePeriod51, (long) (short) 10, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.Instant instant57 = gJChronology56.getGregorianCutover();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField59 = gJChronology58.dayOfYear();
//        int int60 = instant57.get(dateTimeField59);
//        boolean boolean62 = instant57.equals((java.lang.Object) 1.0f);
//        org.joda.time.ReadableDuration readableDuration63 = null;
//        org.joda.time.Instant instant65 = instant57.withDurationAdded(readableDuration63, 10);
//        int int66 = dateTimeZone55.getOffset((org.joda.time.ReadableInstant) instant65);
//        org.joda.time.Chronology chronology67 = copticChronology50.withZone(dateTimeZone55);
//        org.joda.time.Chronology chronology68 = copticChronology50.withUTC();
//        org.joda.time.chrono.CopticChronology copticChronology69 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime70 = null;
//        org.joda.time.ReadableDateTime readableDateTime71 = null;
//        org.joda.time.chrono.LimitChronology limitChronology72 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology69, readableDateTime70, readableDateTime71);
//        org.joda.time.DateTimeField dateTimeField73 = copticChronology69.hourOfDay();
//        org.joda.time.DurationField durationField74 = copticChronology69.minutes();
//        boolean boolean75 = copticChronology50.equals((java.lang.Object) durationField74);
//        org.joda.time.MonthDay monthDay76 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod77 = null;
//        org.joda.time.MonthDay monthDay78 = monthDay76.minus(readablePeriod77);
//        org.joda.time.ReadablePeriod readablePeriod79 = null;
//        org.joda.time.MonthDay monthDay81 = monthDay76.withPeriodAdded(readablePeriod79, (int) (byte) 0);
//        org.joda.time.MonthDay.Property property82 = monthDay81.dayOfMonth();
//        org.joda.time.DurationField durationField83 = property82.getRangeDurationField();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField84 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType43, durationField74, durationField83);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "����-06-20T��:��:��" + "'", str9.equals("����-06-20T��:��:��"));
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimePrinter19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNotNull(copticChronology50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 10L + "'", long54 == 10L);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(gJChronology56);
//        org.junit.Assert.assertNotNull(instant57);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 278 + "'", int60 == 278);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(instant65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(chronology67);
//        org.junit.Assert.assertNotNull(chronology68);
//        org.junit.Assert.assertNotNull(copticChronology69);
//        org.junit.Assert.assertNotNull(limitChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(durationField74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(monthDay76);
//        org.junit.Assert.assertNotNull(monthDay78);
//        org.junit.Assert.assertNotNull(monthDay81);
//        org.junit.Assert.assertNotNull(property82);
//        org.junit.Assert.assertNotNull(durationField83);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral("AD");
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder8.appendMinuteOfHour(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendYear(2070, (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology1 = monthDay0.getChronology();
        org.joda.time.MonthDay monthDay3 = monthDay0.plusDays((int) (byte) 0);
        org.joda.time.MonthDay monthDay5 = monthDay3.minusMonths(1970);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay15 = monthDay13.minus(readablePeriod14);
        int[] intArray17 = iSOChronology12.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        int int18 = monthDay15.size();
        int int19 = monthDay3.compareTo((org.joda.time.ReadablePartial) monthDay15);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int4 = skipUndoDateTimeField3.getMinimumValue();
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
//        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
//        int int29 = skipUndoDateTimeField28.getMinimumValue();
//        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
//        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
//        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
//        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
//        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
//        org.joda.time.DateTime dateTime50 = property48.getDateTime();
//        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
//        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
//        int int60 = dateTime55.getYear();
//        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
//        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
//        int int65 = dateTime51.get(dateTimeFieldType64);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
//        int int72 = skipUndoDateTimeField71.getMaximumValue();
//        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
//        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
//        java.util.Locale locale77 = null;
//        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
//        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
//        long long85 = dividedDateTimeField83.remainder((long) 'a');
//        org.joda.time.MonthDay monthDay86 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod87 = null;
//        org.joda.time.MonthDay monthDay88 = monthDay86.minus(readablePeriod87);
//        org.joda.time.ReadablePeriod readablePeriod89 = null;
//        org.joda.time.MonthDay monthDay91 = monthDay86.withPeriodAdded(readablePeriod89, (int) (byte) 0);
//        java.lang.String str92 = monthDay91.toString();
//        org.joda.time.MonthDay monthDay94 = monthDay91.minusMonths(15);
//        org.joda.time.MonthDay monthDay96 = monthDay91.withMonthOfYear(1);
//        java.util.Locale locale98 = null;
//        java.lang.String str99 = dividedDateTimeField83.getAsText((org.joda.time.ReadablePartial) monthDay96, 6, locale98);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimePrinter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(iSOChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType79);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 97L + "'", long85 == 97L);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertNotNull(monthDay88);
//        org.junit.Assert.assertNotNull(monthDay91);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "--06-20" + "'", str92.equals("--06-20"));
//        org.junit.Assert.assertNotNull(monthDay94);
//        org.junit.Assert.assertNotNull(monthDay96);
//        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "6" + "'", str99.equals("6"));
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology0, obj1);
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.MonthDay monthDay7 = monthDay5.minus(readablePeriod6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.MonthDay monthDay10 = monthDay5.withPeriodAdded(readablePeriod8, (int) (byte) 0);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField13);
//        boolean boolean15 = monthDay10.equals((java.lang.Object) skipUndoDateTimeField14);
//        boolean boolean16 = skipUndoDateTimeField14.isSupported();
//        long long19 = skipUndoDateTimeField14.set(0L, (int) (short) 1);
//        int int20 = skipUndoDateTimeField14.getMinimumValue();
//        java.lang.String str21 = skipUndoDateTimeField14.toString();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField14, 2);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology24, dateTimeField26);
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.MonthDay monthDay30 = monthDay28.minus(readablePeriod29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipUndoDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) monthDay28, 278, locale32);
//        int int34 = monthDay28.getDayOfMonth();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.weekyear();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology38 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime39 = null;
//        org.joda.time.ReadableDateTime readableDateTime40 = null;
//        org.joda.time.chrono.LimitChronology limitChronology41 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology38, readableDateTime39, readableDateTime40);
//        org.joda.time.DateTime dateTime42 = limitChronology41.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField43 = limitChronology41.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology35, dateTimeField43, (int) 'a');
//        long long48 = skipDateTimeField45.add(0L, 0);
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeUtils.getZone(dateTimeZone50);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now(dateTimeZone51);
//        int[] intArray56 = new int[] { 31, 31, '4' };
//        int int57 = skipDateTimeField45.getMaximumValue((org.joda.time.ReadablePartial) monthDay52, intArray56);
//        int int58 = skipUndoDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay28, intArray56);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray59 = monthDay28.getFieldTypes();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62135337600000L) + "'", long19 == (-62135337600000L));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275053) + "'", int20 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DateTimeField[weekyear]" + "'", str21.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "278" + "'", str33.equals("278"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 20 + "'", int34 == 20);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(copticChronology38);
//        org.junit.Assert.assertNotNull(limitChronology41);
//        org.junit.Assert.assertNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(intArray56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 292278993 + "'", int58 == 292278993);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray59);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1969);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("278", (-10));
        java.io.DataOutput dataOutput7 = null;
        try {
            dateTimeZoneBuilder0.writeTo("PST", dataOutput7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        long long7 = skipUndoDateTimeField3.set((long) 5044, (int) (byte) 10);
        int int8 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str9 = skipUndoDateTimeField3.getName();
        java.lang.String str11 = skipUndoDateTimeField3.getAsShortText((-6L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851081594956L) + "'", long7 == (-61851081594956L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275053) + "'", int8 == (-292275053));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "weekyear" + "'", str9.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology0.months();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfEra(1970);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int4 = skipUndoDateTimeField3.getMinimumValue();
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
//        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
//        org.joda.time.DateTime dateTime25 = property23.getDateTime();
//        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
//        int int35 = dateTime30.getYear();
//        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        int int40 = dateTime26.get(dateTimeFieldType39);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
//        int int44 = offsetDateTimeField42.get(97L);
//        long long46 = offsetDateTimeField42.roundHalfEven((-10L));
//        int int48 = offsetDateTimeField42.getMinimumValue(28800010L);
//        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime50 = null;
//        org.joda.time.ReadableDateTime readableDateTime51 = null;
//        org.joda.time.chrono.LimitChronology limitChronology52 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology49, readableDateTime50, readableDateTime51);
//        org.joda.time.DateTime dateTime53 = limitChronology52.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField54 = limitChronology52.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField55 = limitChronology52.yearOfEra();
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology52);
//        int int57 = dateTime56.getMinuteOfHour();
//        org.joda.time.MonthDay monthDay58 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod59 = null;
//        org.joda.time.MonthDay monthDay60 = monthDay58.minus(readablePeriod59);
//        org.joda.time.ReadablePeriod readablePeriod61 = null;
//        org.joda.time.MonthDay monthDay63 = monthDay58.withPeriodAdded(readablePeriod61, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay65 = monthDay58.minusDays((-1));
//        int[] intArray66 = monthDay65.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.weekyear();
//        org.joda.time.DateTimeField dateTimeField69 = iSOChronology67.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology70 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime71 = null;
//        org.joda.time.ReadableDateTime readableDateTime72 = null;
//        org.joda.time.chrono.LimitChronology limitChronology73 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology70, readableDateTime71, readableDateTime72);
//        org.joda.time.DateTime dateTime74 = limitChronology73.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField75 = limitChronology73.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField77 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology67, dateTimeField75, (int) 'a');
//        long long80 = skipDateTimeField77.add(0L, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType81 = skipDateTimeField77.getType();
//        boolean boolean82 = monthDay65.isSupported(dateTimeFieldType81);
//        org.joda.time.DateTime.Property property83 = dateTime56.property(dateTimeFieldType81);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField87 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField42, dateTimeFieldType81, 9, (-292275054), 0);
//        long long89 = offsetDateTimeField87.roundCeiling((long) 19);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2070 + "'", int44 == 2070);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-259200000L) + "'", long46 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-292274953) + "'", int48 == (-292274953));
//        org.junit.Assert.assertNotNull(copticChronology49);
//        org.junit.Assert.assertNotNull(limitChronology52);
//        org.junit.Assert.assertNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 20 + "'", int57 == 20);
//        org.junit.Assert.assertNotNull(monthDay58);
//        org.junit.Assert.assertNotNull(monthDay60);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertNotNull(monthDay65);
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertNotNull(iSOChronology67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(copticChronology70);
//        org.junit.Assert.assertNotNull(limitChronology73);
//        org.junit.Assert.assertNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 31795200000L + "'", long89 == 31795200000L);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay4.withPeriodAdded(readablePeriod7, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        boolean boolean14 = monthDay9.equals((java.lang.Object) skipUndoDateTimeField13);
        boolean boolean15 = skipUndoDateTimeField13.isSupported();
        long long18 = skipUndoDateTimeField13.set((long) 1582, 1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField13.getAsText((long) 1582, locale20);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField13, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135337598418L) + "'", long18 == (-62135337598418L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        java.util.Locale locale12 = null;
        java.lang.String str13 = property10.getAsText(locale12);
        org.joda.time.DateTime dateTime14 = property10.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thursday" + "'", str13.equals("Thursday"));
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        long long5 = skipUndoDateTimeField3.roundHalfFloor((long) (short) 10);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipUndoDateTimeField3.getAsShortText((long) 480, locale7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-259200000L) + "'", long5 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970" + "'", str8.equals("1970"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.eras();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1969);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("15", (int) (short) 1, 16, 0, '4', (-28378000), 0, 5044, true, (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField45);
        int int47 = skipUndoDateTimeField46.getMaximumValue();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((long) 53);
        int int50 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) monthDay49, 53, locale52);
        long long56 = offsetDateTimeField42.set((long) (short) 10, (int) (byte) 1);
        boolean boolean57 = offsetDateTimeField42.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292278993 + "'", int47 == 292278993);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292275054) + "'", int50 == (-292275054));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "53" + "'", str53.equals("53"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-65322633599990L) + "'", long56 == (-65322633599990L));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int4 = skipUndoDateTimeField3.getMinimumValue();
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
//        long long13 = skipUndoDateTimeField3.roundCeiling((-259200000L));
//        long long15 = skipUndoDateTimeField3.roundHalfCeiling((long) 2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter16.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter16.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter16.withOffsetParsed();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology23);
//        java.lang.String str25 = dateTimeFormatter16.print((org.joda.time.ReadablePartial) monthDay24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.MonthDay monthDay28 = monthDay24.withPeriodAdded(readablePeriod26, 100);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology30, dateTimeField32);
//        org.joda.time.MonthDay monthDay34 = org.joda.time.MonthDay.now();
//        org.joda.time.MonthDay monthDay36 = monthDay34.minusMonths((-1));
//        int[] intArray39 = new int[] { (short) 100 };
//        int[] intArray41 = skipUndoDateTimeField33.add((org.joda.time.ReadablePartial) monthDay34, (-28800000), intArray39, (int) (byte) 0);
//        int[] intArray43 = skipUndoDateTimeField3.add((org.joda.time.ReadablePartial) monthDay28, 10, intArray41, (int) (short) 0);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "����-06-20T��:��:��" + "'", str25.equals("����-06-20T��:��:��"));
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertNotNull(intArray43);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = dateTime3.minus((long) (byte) -1);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.Chronology chronology11 = dateTime9.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral("AD");
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfHour(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendFractionOfSecond(0, 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType19, (int) (short) 0, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3, 1);
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant8.minus(readableDuration9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.String str12 = instant10.toString(dateTimeFormatter11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant14 = instant10.minus(readableDuration13);
        int int15 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) instant10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1582-288T00:00:00Z" + "'", str12.equals("1582-288T00:00:00Z"));
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        int int5 = property4.getMinimumValueOverall();
        try {
            org.joda.time.MonthDay monthDay7 = property4.setCopy(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
        boolean boolean14 = dateTimeZone10.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter8.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(28800010L, dateTimeZone10);
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = property17.getField();
        org.joda.time.DateTime dateTime19 = property17.getDateTime();
        org.joda.time.Instant instant20 = dateTime19.toInstant();
        int int21 = dateTime19.getDayOfWeek();
        org.joda.time.DateTime dateTime23 = dateTime19.withMinuteOfHour(3);
        int int24 = property6.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTimeField dateTimeField25 = property6.getField();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        boolean boolean5 = dateTimeZone1.isStandardOffset(28800100L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long8 = cachedDateTimeZone6.nextTransition(288000010L);
        int int10 = cachedDateTimeZone6.getOffset((long) 4019);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 288000010L + "'", long8 == 288000010L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5044);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone3);
        boolean boolean6 = dateTimeFormatter5.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.MonthDay monthDay7 = monthDay0.minusDays((-1));
        int[] intArray8 = monthDay7.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
        long long22 = skipDateTimeField19.add(0L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        boolean boolean24 = monthDay7.isSupported(dateTimeFieldType23);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = copticChronology25.dayOfMonth();
        org.joda.time.DurationField durationField27 = copticChronology25.days();
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.minus(readablePeriod29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay33 = monthDay28.withPeriodAdded(readablePeriod31, (int) (byte) 0);
        org.joda.time.MonthDay.Property property34 = monthDay33.dayOfMonth();
        org.joda.time.DurationField durationField35 = property34.getRangeDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField36 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType23, durationField27, durationField35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(durationField35);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        org.joda.time.DurationField durationField2 = copticChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now(dateTimeZone1);
        long long5 = dateTimeZone1.convertLocalToUTC(32054400010L, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32054400010L + "'", long5 == 32054400010L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5044);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = dateTime3.minusHours(20);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime9.minusWeeks(10);
        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
        org.joda.time.DateTimeField dateTimeField15 = localDateTime13.getField((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = dateTime19.withZone(dateTimeZone21);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology24, dateTimeField26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipUndoDateTimeField27.getAsText(0, locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipUndoDateTimeField27.getType();
        org.joda.time.DateTime dateTime33 = dateTime23.withField(dateTimeFieldType31, 1582);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField15, dateTimeFieldType31, 3);
        long long38 = dividedDateTimeField35.getDifferenceAsLong((long) 'a', (long) 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear((-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) julianChronology3);
        boolean boolean5 = dateTimeFormatter4.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (short) 10, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfYear();
        int int10 = instant7.get(dateTimeField9);
        boolean boolean12 = instant7.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant15 = instant7.withDurationAdded(readableDuration13, 10);
        int int16 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology17 = copticChronology0.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology18 = copticChronology0.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology19, readableDateTime20, readableDateTime21);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology19.hourOfDay();
        org.joda.time.DurationField durationField24 = copticChronology19.minutes();
        boolean boolean25 = copticChronology0.equals((java.lang.Object) durationField24);
        org.joda.time.DurationField durationField26 = copticChronology0.minutes();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 278 + "'", int10 == 278);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendFractionOfDay(1, 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendFractionOfDay(31, 2069);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField9.getDurationField();
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField9, 4, 1, 10);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now();
        int int17 = skipUndoDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
        long long20 = skipUndoDateTimeField9.getDifferenceAsLong((-9071994956L), 1560925805393L);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278993 + "'", int17 == 292278993);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-49L) + "'", long20 == (-49L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime8.toMutableDateTime((org.joda.time.Chronology) buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField45);
        int int47 = skipUndoDateTimeField46.getMaximumValue();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((long) 53);
        int int50 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) monthDay49, 53, locale52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = offsetDateTimeField42.getType();
        java.util.Locale locale56 = null;
        java.lang.String str57 = offsetDateTimeField42.getAsText(0, locale56);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292278993 + "'", int47 == 292278993);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292275054) + "'", int50 == (-292275054));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "53" + "'", str53.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "0" + "'", str57.equals("0"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(28800100L, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfMonth();
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
        boolean boolean14 = dateTimeZone10.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter8.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(28800010L, dateTimeZone10);
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = property17.getField();
        org.joda.time.DateTime dateTime19 = property17.getDateTime();
        org.joda.time.Instant instant20 = dateTime19.toInstant();
        int int21 = dateTime19.getDayOfWeek();
        org.joda.time.DateTime dateTime23 = dateTime19.withMinuteOfHour(3);
        int int24 = property6.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology25);
        int int27 = monthDay26.size();
        int int28 = property6.compareTo((org.joda.time.ReadablePartial) monthDay26);
        java.util.Locale locale30 = null;
        try {
            org.joda.time.MonthDay monthDay31 = property6.setCopy("CopticChronology[UTC]", locale30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[UTC]\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfMonth();
        org.joda.time.DateTime.Property property11 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime13 = dateTime8.minus(288000010L);
        org.joda.time.LocalTime localTime14 = dateTime8.toLocalTime();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localTime14);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime10.withZone(dateTimeZone12);
        int int15 = dateTime10.getYear();
        org.joda.time.DateTime dateTime17 = dateTime10.minusMonths(100);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.DateTime.Property property20 = dateTime6.property(dateTimeFieldType19);
        try {
            org.joda.time.DateTime dateTime25 = dateTime6.withTime(4, (int) (byte) 100, (int) (byte) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        boolean boolean10 = dateTime7.isBefore((long) (byte) -1);
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime7.toCalendar(locale11);
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.append(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendPattern("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfHalfday(5044);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendHalfdayOfDayText();
        boolean boolean11 = dateTimeFormatterBuilder9.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfEra(1970);
        org.joda.time.DateTime dateTime11 = dateTime7.minusWeeks(15);
        org.joda.time.DateTime.Property property12 = dateTime11.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DurationField durationField11 = property10.getDurationField();
        java.util.Locale locale13 = null;
        try {
            org.joda.time.DateTime dateTime14 = property10.setCopy("-01:00", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-01:00\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone2.getName((-61851081594956L), locale5);
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, 3);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(julianChronology8);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.DateTime dateTime50 = property48.getDateTime();
        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
        int int60 = dateTime55.getYear();
        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
        int int72 = skipUndoDateTimeField71.getMaximumValue();
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
        long long85 = dividedDateTimeField83.roundFloor(0L);
        int int88 = dividedDateTimeField83.getDifference((long) (short) 10, (long) 31);
        org.joda.time.DurationField durationField89 = dividedDateTimeField83.getDurationField();
        int int90 = dividedDateTimeField83.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-315360000000L) + "'", long85 == (-315360000000L));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(durationField89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 8350828 + "'", int90 == 8350828);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getDayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        int int13 = skipUndoDateTimeField12.getMinimumValue();
        long long16 = skipUndoDateTimeField12.set((long) 5044, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = dateTime20.withZone(dateTimeZone22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(0, locale30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipUndoDateTimeField28.getType();
        org.joda.time.DateTime dateTime34 = dateTime24.withField(dateTimeFieldType32, 1582);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType32);
        org.joda.time.DateTime.Property property36 = dateTime3.property(dateTimeFieldType32);
        org.joda.time.DateTime.Property property37 = dateTime3.dayOfYear();
        org.joda.time.DateTime.Property property38 = dateTime3.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-292275053) + "'", int13 == (-292275053));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851081594956L) + "'", long16 == (-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        boolean boolean5 = skipUndoDateTimeField3.isLeap((long) (-1));
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipUndoDateTimeField3.getAsShortText((long) (-1), locale7);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay9.withPeriodAdded(readablePeriod12, (int) (byte) 0);
        org.joda.time.MonthDay monthDay16 = monthDay9.minusDays((-1));
        int[] intArray17 = monthDay16.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekyear();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
        org.joda.time.DateTime dateTime25 = limitChronology24.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField26 = limitChronology24.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField26, (int) 'a');
        long long31 = skipDateTimeField28.add(0L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField28.getType();
        boolean boolean33 = monthDay16.isSupported(dateTimeFieldType32);
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField36);
        org.joda.time.MonthDay monthDay38 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay40 = monthDay38.minusMonths((-1));
        int[] intArray43 = new int[] { (short) 100 };
        int[] intArray45 = skipUndoDateTimeField37.add((org.joda.time.ReadablePartial) monthDay38, (-28800000), intArray43, (int) (byte) 0);
        int int46 = skipUndoDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay16, intArray45);
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        long long51 = copticChronology47.add(readablePeriod48, (long) (short) 10, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant54 = gJChronology53.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gJChronology55.dayOfYear();
        int int57 = instant54.get(dateTimeField56);
        boolean boolean59 = instant54.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration60 = null;
        org.joda.time.Instant instant62 = instant54.withDurationAdded(readableDuration60, 10);
        int int63 = dateTimeZone52.getOffset((org.joda.time.ReadableInstant) instant62);
        org.joda.time.Chronology chronology64 = copticChronology47.withZone(dateTimeZone52);
        org.joda.time.Chronology chronology65 = copticChronology47.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology66 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime67 = null;
        org.joda.time.ReadableDateTime readableDateTime68 = null;
        org.joda.time.chrono.LimitChronology limitChronology69 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology66, readableDateTime67, readableDateTime68);
        org.joda.time.DateTimeField dateTimeField70 = copticChronology66.hourOfDay();
        org.joda.time.DurationField durationField71 = copticChronology66.minutes();
        boolean boolean72 = copticChronology47.equals((java.lang.Object) durationField71);
        org.joda.time.MonthDay monthDay73 = monthDay16.withChronologyRetainFields((org.joda.time.Chronology) copticChronology47);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970" + "'", str8.equals("1970"));
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-292275054) + "'", int46 == (-292275054));
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertNotNull(instant54);
        org.junit.Assert.assertNotNull(gJChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 278 + "'", int57 == 278);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(instant62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(copticChronology66);
        org.junit.Assert.assertNotNull(limitChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(durationField71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(monthDay73);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, dateTimeField34);
        int int38 = skipDateTimeField36.get((long) (short) 100);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1970 + "'", int38 == 1970);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfDay();
        org.joda.time.TimeOfDay timeOfDay12 = dateTime8.toTimeOfDay();
        org.joda.time.DateTime.Property property13 = dateTime8.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(timeOfDay12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime10.withZone(dateTimeZone12);
        int int15 = dateTime10.getYear();
        org.joda.time.DateTime dateTime17 = dateTime10.minusMonths(100);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.DateTime.Property property20 = dateTime6.property(dateTimeFieldType19);
        java.lang.String str21 = property20.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        java.lang.String str23 = property20.getAsText();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "secondOfDay" + "'", str21.equals("secondOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        long long13 = skipUndoDateTimeField3.roundCeiling((-259200000L));
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay18.minus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay18, 278, locale22);
        int int24 = skipUndoDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay18);
        try {
            int int26 = monthDay18.getValue(8350828);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8350828");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "278" + "'", str23.equals("278"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 292278993 + "'", int24 == 292278993);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay4, 278, locale8);
        org.joda.time.DurationField durationField10 = skipUndoDateTimeField3.getRangeDurationField();
        long long12 = skipUndoDateTimeField3.remainder((long) 1582);
        int int14 = skipUndoDateTimeField3.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "278" + "'", str9.equals("278"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259201582L + "'", long12 == 259201582L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.minus(readablePeriod4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay3.withPeriodAdded(readablePeriod6, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        boolean boolean13 = monthDay8.equals((java.lang.Object) skipUndoDateTimeField12);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField12);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField14.getAsText(3969, locale16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3969" + "'", str17.equals("3969"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.minus(readablePeriod8);
        int[] intArray11 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        int int12 = monthDay9.size();
        int[] intArray13 = monthDay9.getValues();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withMonthOfYear(2580);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2580 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(localTime9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        int int12 = property10.getLeapAmount();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        java.lang.String str14 = property10.getAsShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu" + "'", str14.equals("Thu"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology0, obj1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.minus(readablePeriod6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay5.withPeriodAdded(readablePeriod8, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField13);
        boolean boolean15 = monthDay10.equals((java.lang.Object) skipUndoDateTimeField14);
        boolean boolean16 = skipUndoDateTimeField14.isSupported();
        long long19 = skipUndoDateTimeField14.set(0L, (int) (short) 1);
        int int20 = skipUndoDateTimeField14.getMinimumValue();
        java.lang.String str21 = skipUndoDateTimeField14.toString();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField14, 2);
        int int24 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62135337600000L) + "'", long19 == (-62135337600000L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275053) + "'", int20 == (-292275053));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DateTimeField[weekyear]" + "'", str21.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfMonth();
        org.joda.time.DateTime dateTime11 = property10.withMinimumValue();
        int int12 = dateTime11.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property6.getAsText(locale7);
//        org.joda.time.MonthDay monthDay9 = property6.getMonthDay();
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "20" + "'", str8.equals("20"));
//        org.junit.Assert.assertNotNull(monthDay9);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        int int10 = dateTimeZone8.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.Chronology chronology16 = iSOChronology6.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(0L);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.minus(readableDuration7);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime3.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        int int44 = offsetDateTimeField42.get(97L);
        long long46 = offsetDateTimeField42.roundHalfEven(1560633530340L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2070 + "'", int44 == 2070);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546214400000L + "'", long46 == 1546214400000L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        int int5 = property4.getMinimumValueOverall();
        org.joda.time.DateTimeField dateTimeField6 = property4.getField();
        org.joda.time.DateTimeField dateTimeField7 = property4.getField();
        java.lang.String str8 = property4.getAsString();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property4.getAsShortText(locale9);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Jan" + "'", str10.equals("Jan"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        long long13 = dateTimeZone6.getMillisKeepLocal(dateTimeZone10, (long) '4');
        int int15 = dateTimeZone6.getOffsetFromLocal(0L);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone6);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(1095292805044L, dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale3 = null;
        java.lang.String str6 = defaultNameProvider0.getShortName(locale3, "JulianChronology[UTC]", "");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, dateTimeField34);
        org.joda.time.Chronology chronology37 = limitChronology3.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (short) 10, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfYear();
        int int10 = instant7.get(dateTimeField9);
        boolean boolean12 = instant7.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant15 = instant7.withDurationAdded(readableDuration13, 10);
        int int16 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology17 = copticChronology0.withZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
        org.joda.time.Chronology chronology22 = copticChronology0.withZone(dateTimeZone20);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology23, readableDateTime24, readableDateTime25);
        org.joda.time.DateTime dateTime27 = limitChronology26.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField28 = limitChronology26.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField29 = limitChronology26.yearOfEra();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology26);
        org.joda.time.DateTime dateTime32 = dateTime30.plusWeeks(16);
        int int33 = dateTimeZone20.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime35 = dateTime30.minusMinutes((int) ' ');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 278 + "'", int10 == 278);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = julianChronology0.add(readablePeriod1, (long) (-10), (int) (short) 10);
        int int5 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.chrono.LimitChronology limitChronology9 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology6, readableDateTime7, readableDateTime8);
        org.joda.time.DateTime dateTime10 = limitChronology9.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        long long17 = dateTimeZone12.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology18 = limitChronology9.withZone(dateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withDefaultYear(5044);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter19.withZone(dateTimeZone22);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance(chronology18, dateTimeZone22);
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-10L) + "'", long4 == (-10L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(limitChronology9);
        org.junit.Assert.assertNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(zonedChronology26);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime11 = property10.roundFloorCopy();
        org.joda.time.DateTime.Property property12 = dateTime11.dayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(2000L, 3971);
        org.joda.time.DateTime dateTime17 = dateTime11.withMillisOfDay(15);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("DateTimeField[secondOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: DateTimeField[secondOfDay]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        long long5 = gregorianChronology0.add((long) 31, (long) (short) 100, 278);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 27831L + "'", long5 == 27831L);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-10), 0, 0, 1969);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1960 + "'", int4 == 1960);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks(16);
        org.joda.time.DateTime dateTime11 = dateTime7.minusWeeks(0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime3.withYearOfEra(15);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        boolean boolean13 = dateTimeZone9.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(28800010L, dateTimeZone9);
        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime15.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime18, (int) (byte) 1);
        int int21 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime22 = dateTime18.withLaterOffsetAtOverlap();
        int int23 = dateTime22.getYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        boolean boolean6 = dateTimeZone1.isStandardOffset(0L);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DurationField durationField11 = property10.getLeapDurationField();
        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
        int int13 = property10.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("-1", "����0101T������");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0.0f, number2, (java.lang.Number) 32054400010L);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32054400010L + "'", number5.equals(32054400010L));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 32054400010L + "'", number7.equals(32054400010L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0" + "'", str8.equals("0.0"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, 2000);
        int int10 = offsetDateTimeField8.get(32054400010L);
        long long12 = offsetDateTimeField8.roundHalfFloor((long) 1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3971 + "'", int10 == 3971);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField35.getAsText(0, locale37);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, 2000);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, (org.joda.time.DateTimeField) offsetDateTimeField40, (-28800000));
        java.lang.String str44 = offsetDateTimeField40.getAsText((long) 4);
        org.joda.time.DurationField durationField45 = offsetDateTimeField40.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "3970" + "'", str44.equals("3970"));
        org.junit.Assert.assertNull(durationField45);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.DateTime dateTime50 = property48.getDateTime();
        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
        int int60 = dateTime55.getYear();
        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
        int int72 = skipUndoDateTimeField71.getMaximumValue();
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
        long long85 = dividedDateTimeField83.roundFloor(0L);
        java.lang.String str86 = dividedDateTimeField83.toString();
        long long88 = dividedDateTimeField83.remainder((long) 10);
        long long90 = dividedDateTimeField83.remainder((long) 0);
        org.joda.time.DurationField durationField91 = dividedDateTimeField83.getDurationField();
        long long94 = durationField91.subtract(9118L, (long) 2000);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-315360000000L) + "'", long85 == (-315360000000L));
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "DateTimeField[secondOfDay]" + "'", str86.equals("DateTimeField[secondOfDay]"));
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 10L + "'", long88 == 10L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 0L + "'", long90 == 0L);
        org.junit.Assert.assertNotNull(durationField91);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + (-2208986639990882L) + "'", long94 == (-2208986639990882L));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long13 = skipDateTimeField10.add(0L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = skipDateTimeField10.getType();
        org.joda.time.DateTimeField dateTimeField15 = skipDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
//        int int8 = dateTime7.getMinuteOfHour();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay9.withPeriodAdded(readablePeriod12, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay16 = monthDay9.minusDays((-1));
//        int[] intArray17 = monthDay16.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekyear();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.ReadableDateTime readableDateTime23 = null;
//        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
//        org.joda.time.DateTime dateTime25 = limitChronology24.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField26 = limitChronology24.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField26, (int) 'a');
//        long long31 = skipDateTimeField28.add(0L, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField28.getType();
//        boolean boolean33 = monthDay16.isSupported(dateTimeFieldType32);
//        org.joda.time.DateTime.Property property34 = dateTime7.property(dateTimeFieldType32);
//        org.joda.time.DateTime dateTime36 = property34.addToCopy(56);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeUtils.getZone(dateTimeZone38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
//        org.joda.time.DateTime dateTime44 = dateTime40.withZone(dateTimeZone42);
//        org.joda.time.DateTime dateTime46 = dateTime44.withYearOfEra(1970);
//        org.joda.time.DateTime dateTime48 = dateTime44.minusWeeks(15);
//        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime36, (org.joda.time.ReadableInstant) dateTime48);
//        try {
//            org.joda.time.DateTime dateTime51 = dateTime36.withMonthOfYear(292278993);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for monthOfYear must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(limitChronology24);
//        org.junit.Assert.assertNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(chronology49);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        long long13 = skipUndoDateTimeField9.getDifferenceAsLong((long) 278, (long) 0);
        long long16 = skipUndoDateTimeField9.add(5044L, 5044);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 159173683205044L + "'", long16 == 159173683205044L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = julianChronology0.get(readablePeriod2, (long) 1582);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime3.era();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        int int10 = skipUndoDateTimeField9.getMinimumValue();
        java.lang.String str12 = skipUndoDateTimeField9.getAsText(97L);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField9.getAsText((org.joda.time.ReadablePartial) monthDay14, (int) (short) -1, locale16);
        long long19 = skipUndoDateTimeField9.roundCeiling((-259200000L));
        boolean boolean20 = dateTime3.equals((java.lang.Object) (-259200000L));
        int int21 = dateTime3.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-292275053) + "'", int10 == (-292275053));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970" + "'", str12.equals("1970"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1" + "'", str17.equals("-1"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long12 = skipDateTimeField10.roundHalfFloor((long) 1);
        boolean boolean13 = skipDateTimeField10.isLenient();
        long long15 = skipDateTimeField10.roundHalfCeiling(28800100L);
        int int16 = skipDateTimeField10.getMinimumValue();
        int int17 = skipDateTimeField10.getMinimumValue();
        int int18 = skipDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        java.lang.String str13 = skipUndoDateTimeField3.getAsText(94L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter15.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = dateTimeFormatter20.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.append(dateTimePrinter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("AD");
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        int int29 = skipUndoDateTimeField28.getMinimumValue();
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(97L);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField28.getAsText((org.joda.time.ReadablePartial) monthDay33, (int) (short) -1, locale35);
        org.joda.time.DurationField durationField37 = skipUndoDateTimeField28.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        int int43 = dateTimeZone41.getOffsetFromLocal((long) (byte) 10);
        boolean boolean45 = dateTimeZone41.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter39.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(28800010L, dateTimeZone41);
        org.joda.time.DateTime.Property property48 = dateTime47.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.DateTime dateTime50 = property48.getDateTime();
        org.joda.time.DateTime dateTime51 = property48.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
        int int60 = dateTime55.getYear();
        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        int int65 = dateTime51.get(dateTimeFieldType64);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType64, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology68, dateTimeField70);
        int int72 = skipUndoDateTimeField71.getMaximumValue();
        org.joda.time.MonthDay monthDay74 = new org.joda.time.MonthDay((long) 53);
        int int75 = skipUndoDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay74);
        java.util.Locale locale77 = null;
        java.lang.String str78 = offsetDateTimeField67.getAsShortText((org.joda.time.ReadablePartial) monthDay74, 53, locale77);
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = offsetDateTimeField67.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType79, (int) '4');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType79, (int) '#');
        long long85 = dividedDateTimeField83.roundFloor(0L);
        int int88 = dividedDateTimeField83.getDifference((long) (short) 10, (long) 31);
        int int90 = dividedDateTimeField83.get(1546214400000L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimePrinter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275053) + "'", int29 == (-292275053));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1970" + "'", str31.equals("1970"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 292278993 + "'", int72 == 292278993);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-292275054) + "'", int75 == (-292275054));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "53" + "'", str78.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-315360000000L) + "'", long85 == (-315360000000L));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 57 + "'", int90 == 57);
    }
}

