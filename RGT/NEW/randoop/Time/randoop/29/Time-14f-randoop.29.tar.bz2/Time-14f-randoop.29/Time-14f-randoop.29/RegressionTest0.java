import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 10, (int) (byte) 100, (int) (byte) 100, (-10), (-10), dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.lang.Appendable appendable2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        try {
            org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((-1), 10, (org.joda.time.Chronology) gJChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.ReadablePartial readablePartial2 = null;
        int[] intArray8 = new int[] { 0, (byte) 1, (-10), (short) 10, 278 };
        try {
            gJChronology0.validate(readablePartial2, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = gJChronology0.get(readablePartial2, (long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            int int2 = monthDay0.get(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        boolean boolean2 = dateTimeFormatter1.isParser();
        try {
            java.lang.String str3 = monthDay0.toString(dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        try {
//            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) -1, (int) (byte) -1, (-28800000), (-28800000), (int) '4', (int) (byte) 1, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant2.minus(readableDuration3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.String str6 = instant4.toString(dateTimeFormatter5);
        try {
            java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1582-288T00:00:00Z" + "'", str6.equals("1582-288T00:00:00Z"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        try {
            long long6 = buddhistChronology0.getDateTimeMillis((long) '4', (int) (byte) 0, (int) (byte) 100, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5044 + "'", int2 == 5044);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        try {
            long long9 = limitChronology3.getDateTimeMillis((int) (byte) -1, 0, (-10), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withFieldAdded(durationFieldType8, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        try {
            org.joda.time.LocalTime localTime3 = dateTimeFormatter0.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType4, (int) (short) 100, (int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.MonthDay.Property property4 = monthDay0.property(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1.0f), number2, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        long long12 = skipUndoDateTimeField9.roundFloor((long) (byte) 0);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay15 = monthDay13.minus(readablePeriod14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay13.withPeriodAdded(readablePeriod16, (int) (byte) 0);
        org.joda.time.MonthDay monthDay20 = monthDay13.minusDays((-1));
        int[] intArray25 = new int[] { (-10), (short) 1, (byte) 0 };
        try {
            int[] intArray27 = skipUndoDateTimeField9.addWrapField((org.joda.time.ReadablePartial) monthDay20, 0, intArray25, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withMonthOfYear((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        long long6 = dateTimeZone2.convertLocalToUTC((long) (byte) 10, true, (long) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800010L + "'", long6 == 28800010L);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.minus(readableDuration4);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) instant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 31, (int) (byte) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean6 = dateTimeZone2.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
//        try {
//            org.joda.time.LocalDateTime localDateTime9 = dateTimeFormatter0.parseLocalDateTime("1582-288T00:00:00Z");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1582-288T00:00:00Z\" is malformed at \"-288T00:00:00Z\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28800000) + "'", int4 == (-28800000));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) 100, (int) (short) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone1);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.Instant instant9 = instant7.minus(readableDuration8);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime11 = null;
//        org.joda.time.ReadableDateTime readableDateTime12 = null;
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology10, readableDateTime11, readableDateTime12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) instant9, (org.joda.time.Chronology) copticChronology10);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime14.toTimeOfDay();
//        try {
//            boolean boolean17 = monthDay5.isAfter((org.joda.time.ReadablePartial) timeOfDay16);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.io.Writer writer1 = null;
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay4 = monthDay2.minusMonths((-1));
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        java.io.Writer writer6 = null;
        try {
            dateTimeFormatter0.printTo(writer6, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1582-10-15T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        try {
//            int[] intArray9 = iSOChronology6.get(readablePeriod7, (-10L));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        try {
            long long7 = dateTimeFormatter5.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withMinuteOfHour((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(5044, 278, (int) ' ', (int) '#', 1, (int) (short) 1, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        long long1 = instant0.getMillis();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560633530340L + "'", long1 == 1560633530340L);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "278");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial5 = null;
        int[] intArray11 = new int[] { 1, (byte) 1, (byte) -1, 100 };
        try {
            int[] intArray13 = skipUndoDateTimeField3.add(readablePartial5, 100, intArray11, 5044);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1582-10-15T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1582-10-15T00:00:00.000Z", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1582-10-15T00:00:00.000Z/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        long long13 = dateTimeZone8.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(5044, (int) (short) 0, (int) '4', 0, 0, 278, (int) (short) 100, dateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 278 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800100L + "'", long13 == 28800100L);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 28800010L, "1582-10-15T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = dateTime8.toString("", locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withOffsetParsed();
        try {
            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withField(dateTimeFieldType8, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DurationField durationField2 = gJChronology0.weekyears();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        try {
            org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((java.lang.Object) dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        java.lang.String str11 = property10.getName();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "dayOfWeek" + "'", str11.equals("dayOfWeek"));
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        try {
//            boolean boolean9 = dateTimeZone5.isLocalDateTimeGap(localDateTime8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.field.FieldUtils.verifyValueBounds("278", (-10), (-10), (int) 'a');
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        org.joda.time.Chronology chronology10 = gJChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(278, (-28378000), (int) ' ', 1969, 0, (int) '#', chronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        try {
            org.joda.time.MonthDay monthDay12 = monthDay5.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime8 = dateTime3.withYearOfCentury(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        int int4 = instant1.get(dateTimeField3);
        boolean boolean6 = instant1.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant1.withDurationAdded(readableDuration7, 10);
        org.joda.time.MutableDateTime mutableDateTime10 = instant1.toMutableDateTimeISO();
        try {
            java.lang.String str12 = mutableDateTime10.toString("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 278 + "'", int4 == 278);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        try {
            org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.parse("CopticChronology[UTC]", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        java.lang.String str4 = copticChronology0.toString();
        try {
            long long10 = copticChronology0.getDateTimeMillis((long) '#', (int) '#', (int) (byte) 100, (int) (short) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1), (-10), 0, (-28378000), (int) (short) 1, (-28378000), (org.joda.time.Chronology) copticChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 278);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay2.minus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay2.withPeriodAdded(readablePeriod5, (int) (byte) 0);
        org.joda.time.MonthDay monthDay9 = monthDay2.minusDays((-1));
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay4, 278, locale8);
        org.joda.time.DurationField durationField10 = skipUndoDateTimeField3.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType11, (int) (byte) -1, (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "278" + "'", str9.equals("278"));
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((-28800000), (int) (short) 100, (int) (byte) 1, 0, (-28800000), (int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        try {
            org.joda.time.MonthDay monthDay7 = monthDay0.withDayOfMonth(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime dateTime11 = dateTime8.minusMinutes(1969);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        int int16 = dateTimeZone14.getOffsetFromLocal((long) (byte) 10);
        boolean boolean18 = dateTimeZone14.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter12.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime20 = dateTime8.withZone(dateTimeZone14);
        try {
            org.joda.time.DateTime dateTime22 = dateTime20.withWeekyear((-292275053));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275053 for weekyear must be in the range [-292269338,292272708]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.MonthDay.Property property3 = monthDay1.property(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime9.minusWeeks(10);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withEra((-292275053));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275053 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter0.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-28378000), (java.lang.Number) 1L, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "-1", "");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5044);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis((-28378000), (int) ' ', 0, 0, (int) ' ', (int) '4', 292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        int int14 = dateTimeZone12.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        int int22 = dateTimeZone20.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.MonthDay monthDay28 = monthDay26.minus(readablePeriod27);
        int[] intArray30 = iSOChronology25.get((org.joda.time.ReadablePartial) monthDay28, 0L);
        try {
            int[] intArray32 = skipUndoDateTimeField9.set((org.joda.time.ReadablePartial) monthDay17, (int) '#', intArray30, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((-1), (-10), (int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("dayOfWeek", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DurationField durationField11 = property10.getLeapDurationField();
        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((long) (byte) 100);
        try {
            int int15 = property10.compareTo((org.joda.time.ReadablePartial) monthDay14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("-1", (int) '4', (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for -1 must be in the range [10,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        boolean boolean2 = dateTimeFormatter1.isParser();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("1582-288T00:00:00Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1582-288T00:00:00Z\" is malformed at \"T00:00:00Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 278, (int) (byte) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 'a');
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        int int4 = instant1.get(dateTimeField3);
        boolean boolean6 = instant1.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant1.withDurationAdded(readableDuration7, 10);
        org.joda.time.MutableDateTime mutableDateTime10 = instant1.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = instant1.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField15.getAsText(0, locale17);
        int int19 = instant1.get((org.joda.time.DateTimeField) skipUndoDateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 278 + "'", int4 == 278);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1582 + "'", int19 == 1582);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant7.minus(readableDuration8);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology10, readableDateTime11, readableDateTime12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) instant9, (org.joda.time.Chronology) copticChronology10);
        int int15 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime14);
        try {
            java.lang.String str17 = dateTime14.toString("Thursday");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-10), 1582, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.TimeOfDay timeOfDay10 = dateTime8.toTimeOfDay();
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay13 = monthDay11.minusMonths((-1));
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = monthDay11.getFields();
        try {
            boolean boolean15 = timeOfDay10.isEqual((org.joda.time.ReadablePartial) monthDay11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(timeOfDay10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long12 = skipDateTimeField10.roundHalfFloor((long) 1);
        boolean boolean13 = skipDateTimeField10.isLenient();
        long long15 = skipDateTimeField10.roundHalfCeiling(28800100L);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay18 = monthDay16.minusMonths((-1));
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        int int23 = dateTimeZone21.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone21);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.MonthDay monthDay29 = monthDay27.minus(readablePeriod28);
        int[] intArray31 = iSOChronology26.get((org.joda.time.ReadablePartial) monthDay29, 0L);
        try {
            int[] intArray33 = skipDateTimeField10.addWrapPartial((org.joda.time.ReadablePartial) monthDay18, 1, intArray31, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Fields invalid for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        java.lang.Integer int4 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNull(int4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime3.era();
        try {
            org.joda.time.DateTime dateTime7 = property5.setCopy("PST");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "CopticChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DurationField durationField11 = property10.getDurationField();
        long long14 = durationField11.subtract((-259200000L), 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-8899200000L) + "'", long14 == (-8899200000L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        try {
            long long13 = skipDateTimeField10.set((long) 2, 292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for weekOfWeekyear must be in the range [0,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(0L);
        org.joda.time.DateTime.Property property7 = dateTime3.era();
        org.joda.time.DateTime.Property property8 = dateTime3.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "278");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant8.minus(readableDuration9);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology11, readableDateTime12, readableDateTime13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) instant10, (org.joda.time.Chronology) copticChronology11);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMillis((int) (byte) 0);
        try {
            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime17, 1582);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1582");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long5 = julianChronology0.getDateTimeMillis(2, (-10), (-1), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        java.lang.Object obj6 = null;
        boolean boolean7 = limitChronology3.equals(obj6);
        org.joda.time.DurationField durationField8 = limitChronology3.months();
        try {
            long long11 = durationField8.subtract((long) 31, 1560633530340L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Magnitude of add amount is too large: -1560633530340");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        int int10 = dateTimeZone8.getOffsetFromLocal((long) (byte) 10);
        boolean boolean12 = dateTimeZone8.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter6.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(28800010L, dateTimeZone8);
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
        org.joda.time.DateTime dateTime17 = dateTime14.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime17, (int) (byte) 1);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gJChronology19);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        boolean boolean13 = dateTimeZone9.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(28800010L, dateTimeZone9);
        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime15.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime18, (int) (byte) 1);
        int int21 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = dateTime18.toString("", locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        int int10 = dateTimeZone8.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
//        boolean boolean16 = dateTimeZone8.isStandardOffset((long) (byte) -1);
//        java.lang.String str18 = dateTimeZone8.getShortName(100L);
//        try {
//            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((int) '#', (int) (byte) 100, (int) 'a', 0, 1, 1, 100, dateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 5044);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 5044");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("JulianChronology[UTC]", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        java.lang.Object obj6 = null;
        boolean boolean7 = limitChronology3.equals(obj6);
        org.joda.time.DurationField durationField8 = limitChronology3.months();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
        long long22 = skipDateTimeField19.add(0L, 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, (org.joda.time.DateTimeField) skipDateTimeField19);
        java.lang.String str24 = limitChronology3.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "LimitChronology[CopticChronology[UTC], NoLimit, NoLimit]" + "'", str24.equals("LimitChronology[CopticChronology[UTC], NoLimit, NoLimit]"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("CopticChronology[UTC]", 5044, (int) (byte) 0, (int) '#', ' ', (-292275053), 1, 278, false, (-292275053));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.io.Writer writer1 = null;
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay2.minus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay2.withPeriodAdded(readablePeriod5, (int) (byte) 0);
        org.joda.time.MonthDay monthDay9 = monthDay2.minusDays((-1));
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DurationField durationField11 = property10.getLeapDurationField();
        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
        int int13 = dateTime12.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gJChronology0.add(readablePeriod2, (long) 'a', (int) (short) 10);
        org.joda.time.DurationField durationField6 = gJChronology0.days();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-292275053), (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -10229626855");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.plus(readablePeriod12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime8.withMillisOfDay((-292275053));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275053 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.io.Writer writer2 = null;
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.minus(readablePeriod4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay3.withPeriodAdded(readablePeriod6, (int) (byte) 0);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) monthDay8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        boolean boolean2 = dateTime1.isEqualNow();
        int int3 = dateTime1.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("����0101T������", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"����0101T������/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        java.util.Locale locale12 = null;
        java.lang.String str13 = property10.getAsText(locale12);
        java.lang.String str14 = property10.getAsText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thursday" + "'", str13.equals("Thursday"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thursday" + "'", str14.equals("Thursday"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DateTime dateTime9 = limitChronology8.getLowerLimit();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(5044, 1582, (-292275053), 1, 5044, (org.joda.time.Chronology) limitChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5044 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNull(dateTime9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay2 = monthDay0.minusMonths((-1));
        try {
            org.joda.time.DateTimeField dateTimeField4 = monthDay2.getField((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: -28800000");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay12.minus(readablePeriod13);
        int[] intArray16 = iSOChronology11.get((org.joda.time.ReadablePartial) monthDay14, 0L);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) (short) 100, (int) '4', 278, (int) (byte) 1, 292278993, (org.joda.time.Chronology) iSOChronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant7.minus(readableDuration8);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology10, readableDateTime11, readableDateTime12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) instant9, (org.joda.time.Chronology) copticChronology10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime17 = dateTime14.minusMinutes(1969);
        try {
            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime14, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        try {
            org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 292278993");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        long long10 = dateTime8.getMillis();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-12219292800000L) + "'", long10 == (-12219292800000L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        int int7 = dateTimeZone5.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime11 = instant1.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.Chronology chronology12 = instant1.getChronology();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((-292275053));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("CopticChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        int int7 = dateTimeZone5.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime11 = instant1.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.Instant instant13 = instant1.minus((long) (short) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(instant13);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 4, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6L) + "'", long2 == (-6L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, (-28378000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology0, obj1);
        org.joda.time.DurationField durationField3 = julianChronology0.eras();
        try {
            long long11 = julianChronology0.getDateTimeMillis(5044, (-10), 5044, (-1), (-10), 278, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5044);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime6 = instant5.toDateTime();
        try {
            dateTimeFormatter0.printTo(stringBuffer4, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) "����0615T������", chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����0615T������\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipUndoDateTimeField3.getType();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField11.getAsText(0, locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField11.getType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType7, dateTimeFieldType15 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList17 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList17, dateTimeFieldTypeArray16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList17, true, true);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int int5 = monthDay3.compareTo(readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "LimitChronology[CopticChronology[UTC], NoLimit, NoLimit]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime9.minusWeeks(10);
        int int13 = dateTime12.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        boolean boolean11 = skipUndoDateTimeField9.isSupported();
        long long13 = skipUndoDateTimeField9.remainder(28800010L);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 288000010L + "'", long13 == 288000010L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (short) 10, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfYear();
        int int10 = instant7.get(dateTimeField9);
        boolean boolean12 = instant7.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant15 = instant7.withDurationAdded(readableDuration13, 10);
        int int16 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology17 = copticChronology0.withZone(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 278 + "'", int10 == 278);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology2);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) -1, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-98L) + "'", long2 == (-98L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        long long5 = dateTimeZone2.adjustOffset((long) 1, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.MonthDay monthDay7 = monthDay0.minusDays((-1));
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone9);
        int int12 = dateTime11.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.toDateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime18.withZone(dateTimeZone20);
        int int23 = dateTime18.getYear();
        org.joda.time.DateTime dateTime25 = dateTime18.minusMonths(100);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.DateTime.Property property28 = dateTime14.property(dateTimeFieldType27);
        try {
            org.joda.time.MonthDay monthDay30 = monthDay0.withField(dateTimeFieldType27, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = julianChronology0.get(readablePeriod2, 0L, (long) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5044);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime5 = dateTimeFormatter3.parseDateTime("CopticChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime8 = dateTime3.withTime((int) (short) 10, (-10), (int) (byte) 100, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1969);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("DateTimeField[weekyear]", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5044);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer4, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField9.getDurationField();
        java.lang.String str13 = skipUndoDateTimeField9.getAsShortText(10L);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970" + "'", str13.equals("1970"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTime dateTime5 = limitChronology3.getLowerLimit();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNull(dateTime5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        try {
            org.joda.time.DateTimeField dateTimeField12 = monthDay5.getField((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: -10");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.TimeOfDay timeOfDay10 = dateTime8.toTimeOfDay();
        org.joda.time.DateTime dateTime12 = dateTime8.withMillis((long) (short) 0);
        try {
            java.lang.String str14 = dateTime12.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(timeOfDay10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getYear();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(100);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.DurationField durationField13 = property11.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant5 = gJChronology4.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        int int8 = instant5.get(dateTimeField7);
        boolean boolean10 = instant5.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant13 = instant5.withDurationAdded(readableDuration11, 10);
        int int14 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) instant5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 278 + "'", int8 == 278);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        int int10 = dateTimeZone8.getOffsetFromLocal((long) (byte) 10);
        boolean boolean12 = dateTimeZone8.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter6.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(28800010L, dateTimeZone8);
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
        org.joda.time.DateTime dateTime17 = property15.getDateTime();
        org.joda.time.DateTime dateTime18 = property15.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime22.withZone(dateTimeZone24);
        int int27 = dateTime22.getYear();
        org.joda.time.DateTime dateTime29 = dateTime22.minusMonths(100);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        int int32 = dateTime18.get(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType31, 1969);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendClockhourOfHalfday((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1970 + "'", int27 == 1970);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone4);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime10 = instant9.toDateTime();
        try {
            org.joda.time.chrono.LimitChronology limitChronology11 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) dateTime6, (org.joda.time.ReadableDateTime) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay4, 278, locale8);
        int int10 = monthDay4.getDayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        int int16 = dateTimeZone14.getOffsetFromLocal((long) (byte) 10);
        boolean boolean18 = dateTimeZone14.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter12.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(28800010L, dateTimeZone14);
        org.joda.time.DateTime.Property property21 = dateTime20.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField22 = property21.getField();
        org.joda.time.DateTime dateTime23 = property21.getDateTime();
        org.joda.time.DateTime dateTime24 = property21.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = dateTime28.withZone(dateTimeZone30);
        int int33 = dateTime28.getYear();
        org.joda.time.DateTime dateTime35 = dateTime28.minusMonths(100);
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
        int int38 = dateTime24.get(dateTimeFieldType37);
        try {
            int int39 = monthDay4.get(dateTimeFieldType37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "278" + "'", str9.equals("278"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1970 + "'", int33 == 1970);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        int int5 = dateTime3.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DurationField durationField2 = copticChronology0.halfdays();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfSecond((-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        java.lang.Object obj6 = null;
        boolean boolean7 = limitChronology3.equals(obj6);
        org.joda.time.DurationField durationField8 = limitChronology3.months();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
        long long22 = skipDateTimeField19.add(0L, 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, (org.joda.time.DateTimeField) skipDateTimeField19);
        int int25 = skipDateTimeField19.get((long) (short) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 16 + "'", int25 == 16);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            long long2 = dateTimeFormatter0.parseMillis("CopticChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Instant instant4 = instant3.toInstant();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone6);
        long long13 = dateTimeZone6.convertUTCToLocal(0L);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(278, (-28800000), (int) (short) 100, 9, 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter6, dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((int) (short) -1, 0, (-292275053), 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfEra();
        try {
            long long12 = gJChronology1.getDateTimeMillis((int) (byte) 100, 5044, 53, (-10), (-28800000), (-1), 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, (int) (byte) 1, 53, (-28800000), (int) '#', dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.DateTime dateTime5 = dateTimeFormatter0.parseDateTime("Thursday");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Thursday\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (short) 1, 9, 0, 0, 9, (int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        int int13 = skipUndoDateTimeField3.getMaximumValue(288000010L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292278993 + "'", int13 == 292278993);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withYearOfCentury((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfMonth();
        java.util.Locale locale12 = null;
        try {
            org.joda.time.DateTime dateTime13 = property10.setCopy("1582-10-15T00:00:00.000Z", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1582-10-15T00:00:00.000Z\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("");
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay2.minus(readablePeriod3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay2.withPeriodAdded(readablePeriod5, (int) (byte) 0);
        org.joda.time.MonthDay monthDay9 = monthDay2.minusDays((-1));
        int[] intArray10 = monthDay9.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.weekyear();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology14, readableDateTime15, readableDateTime16);
        org.joda.time.DateTime dateTime18 = limitChronology17.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField19 = limitChronology17.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology11, dateTimeField19, (int) 'a');
        long long24 = skipDateTimeField21.add(0L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = skipDateTimeField21.getType();
        boolean boolean26 = monthDay9.isSupported(dateTimeFieldType25);
        try {
            int int27 = monthDay1.get(dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        long long7 = skipUndoDateTimeField3.set((long) 5044, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.withZone(dateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipUndoDateTimeField19.getAsText(0, locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField19.getType();
        org.joda.time.DateTime dateTime25 = dateTime15.withField(dateTimeFieldType23, 1582);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType23);
        java.util.Locale locale27 = null;
        int int28 = delegatedDateTimeField26.getMaximumShortTextLength(locale27);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851081594956L) + "'", long7 == (-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = julianChronology0.add(readablePeriod1, (long) (-10), (int) (short) 10);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-10L) + "'", long4 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        boolean boolean3 = dateTimeFormatter2.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser13 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.append(dateTimePrinter12, dateTimeParser13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (short) 10, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfYear();
        int int10 = instant7.get(dateTimeField9);
        boolean boolean12 = instant7.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant15 = instant7.withDurationAdded(readableDuration13, 10);
        int int16 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology17 = copticChronology0.withZone(dateTimeZone5);
        try {
            org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 278 + "'", int10 == 278);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipUndoDateTimeField3, 100, (int) (byte) 100, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekyear must be in the range [100,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("weekyear", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5044);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter3.printTo(appendable4, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        boolean boolean13 = dateTimeZone9.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(28800010L, dateTimeZone9);
        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime15.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime18, (int) (byte) 1);
        int int21 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology7);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime13.withZone(dateTimeZone15);
        int int18 = dateTime13.getDayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField21);
        int int23 = skipUndoDateTimeField22.getMinimumValue();
        long long26 = skipUndoDateTimeField22.set((long) 5044, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology35, dateTimeField37);
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipUndoDateTimeField38.getAsText(0, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField38.getType();
        org.joda.time.DateTime dateTime44 = dateTime34.withField(dateTimeFieldType42, 1582);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField22, dateTimeFieldType42);
        org.joda.time.DateTime.Property property46 = dateTime13.property(dateTimeFieldType42);
        try {
            org.joda.time.MonthDay monthDay48 = monthDay8.withField(dateTimeFieldType42, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "����-01-01T��:��:��" + "'", str9.equals("����-01-01T��:��:��"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-292275053) + "'", int23 == (-292275053));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851081594956L) + "'", long26 == (-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "0" + "'", str41.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property46);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(0L);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.minus(readableDuration7);
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.fromDateFields(date9);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(monthDay10);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        boolean boolean7 = skipUndoDateTimeField3.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = julianChronology0.add(readablePeriod1, (long) (-10), (int) (short) 10);
        org.joda.time.DurationField durationField5 = julianChronology0.seconds();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-10L) + "'", long4 == (-10L));
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 292278993, (int) (short) 0, (-28378000), 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(31, 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5044);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone3);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone3.getShortName((-12219292800000L), locale7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant6 = gJChronology5.getGregorianCutover();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology5);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay15 = monthDay13.minusMonths((-1));
        int[] intArray18 = new int[] { (short) 100 };
        int[] intArray20 = skipUndoDateTimeField12.add((org.joda.time.ReadablePartial) monthDay13, (-28800000), intArray18, (int) (byte) 0);
        try {
            int[] intArray22 = skipUndoDateTimeField3.addWrapField((org.joda.time.ReadablePartial) monthDay7, (int) (byte) 10, intArray18, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        int int14 = dateTimeZone12.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone12);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant18 = gJChronology17.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant20 = instant18.minus(readableDuration19);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) instant20, (org.joda.time.Chronology) copticChronology21);
        int int26 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime25);
        boolean boolean27 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime29 = dateTime25.withDayOfMonth(4);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, 278);
        boolean boolean8 = dateTime6.isAfter((-259200000L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(5044);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter5.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, 278);
        org.joda.time.DateTime.Property property7 = dateTime3.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) 100, (-1), 100, (int) (short) 1, (int) (short) 1, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfWeek", "hi!");
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter2.parseLocalDateTime("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay9.withPeriodAdded(readablePeriod12, (int) (byte) 0);
        org.joda.time.DateTime dateTime15 = dateTime8.withFields((org.joda.time.ReadablePartial) monthDay9);
        org.joda.time.DateTime dateTime17 = dateTime8.withMillis(0L);
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = dateTime8.toString("LimitChronology[CopticChronology[UTC], NoLimit, NoLimit]", locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: L");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime();
        boolean boolean3 = mutableDateTime2.isBeforeNow();
        int int4 = mutableDateTime2.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField7 = limitChronology3.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipUndoDateTimeField3.getType();
        long long9 = skipUndoDateTimeField3.roundCeiling((long) (short) 100);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.minus(readablePeriod11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay10.withPeriodAdded(readablePeriod13, (int) (byte) 0);
        org.joda.time.MonthDay monthDay17 = monthDay10.minusDays((-1));
        int[] intArray18 = monthDay17.getValues();
        int[] intArray24 = new int[] { 1970, 'a', (short) 0, '#' };
        try {
            int[] intArray26 = skipUndoDateTimeField3.set((org.joda.time.ReadablePartial) monthDay17, (int) (byte) 10, intArray24, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31795200000L + "'", long9 == 31795200000L);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        boolean boolean13 = dateTimeZone9.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(28800010L, dateTimeZone9);
        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime15.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime18, (int) (byte) 1);
        int int21 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        boolean boolean23 = dateTimeZone2.isStandardOffset(28800010L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PST", "AD");
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology43);
        int int45 = monthDay44.size();
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology47, dateTimeField49);
        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay53 = monthDay51.minusMonths((-1));
        int[] intArray56 = new int[] { (short) 100 };
        int[] intArray58 = skipUndoDateTimeField50.add((org.joda.time.ReadablePartial) monthDay51, (-28800000), intArray56, (int) (byte) 0);
        java.util.Locale locale60 = null;
        try {
            int[] intArray61 = offsetDateTimeField42.set((org.joda.time.ReadablePartial) monthDay44, (int) 'a', intArray56, "CopticChronology[UTC]", locale60);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[UTC]\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.minus(readablePeriod45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.MonthDay monthDay49 = monthDay44.withPeriodAdded(readablePeriod47, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology50, dateTimeField52);
        boolean boolean54 = monthDay49.equals((java.lang.Object) skipUndoDateTimeField53);
        java.lang.String str55 = dateTimeFormatter43.print((org.joda.time.ReadablePartial) monthDay49);
        int int56 = monthDay49.getDayOfMonth();
        org.joda.time.DateTimeField[] dateTimeFieldArray57 = monthDay49.getFields();
        java.util.Locale locale58 = null;
        try {
            java.lang.String str59 = offsetDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) monthDay49, locale58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "����0101T������" + "'", str55.equals("����0101T������"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray57);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay6 = monthDay4.minusMonths((-1));
        int[] intArray9 = new int[] { (short) 100 };
        int[] intArray11 = skipUndoDateTimeField3.add((org.joda.time.ReadablePartial) monthDay4, (-28800000), intArray9, (int) (byte) 0);
        long long13 = skipUndoDateTimeField3.roundHalfEven(100L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.minus(readablePeriod4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay3.withPeriodAdded(readablePeriod6, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        boolean boolean13 = monthDay8.equals((java.lang.Object) skipUndoDateTimeField12);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField12);
        try {
            long long19 = gregorianChronology0.getDateTimeMillis((int) (byte) -1, (-292275053), (int) (byte) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275053 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(0L);
        org.joda.time.DateTime.Property property7 = dateTime3.era();
        boolean boolean8 = property7.isLeap();
        int int9 = property7.get();
        java.lang.String str10 = property7.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.year();
        org.joda.time.DurationField durationField3 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DurationField durationField8 = gregorianChronology6.years();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology6.getZone();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant10);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (byte) 100, 292278993, (int) (short) 0, 1970, (-292274953), (-28378000), dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = dateTime3.minus((long) (byte) -1);
        int int10 = dateTime3.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        boolean boolean11 = skipUndoDateTimeField9.isSupported();
        long long14 = skipUndoDateTimeField9.set(0L, (int) (short) 1);
        int int15 = skipUndoDateTimeField9.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipUndoDateTimeField9.getType();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62135337600000L) + "'", long14 == (-62135337600000L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-292275053) + "'", int15 == (-292275053));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = copticChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        int int10 = dateTimeZone8.getOffsetFromLocal((long) (byte) 10);
        boolean boolean12 = dateTimeZone8.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter6.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(28800010L, dateTimeZone8);
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField16 = property15.getField();
        org.joda.time.DateTime dateTime17 = property15.getDateTime();
        org.joda.time.DateTime dateTime18 = property15.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime22.withZone(dateTimeZone24);
        int int27 = dateTime22.getYear();
        org.joda.time.DateTime dateTime29 = dateTime22.minusMonths(100);
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        int int32 = dateTime18.get(dateTimeFieldType31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType31, 1969);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay36.minus(readablePeriod37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.MonthDay monthDay41 = monthDay36.withPeriodAdded(readablePeriod39, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology42, dateTimeField44);
        boolean boolean46 = monthDay41.equals((java.lang.Object) skipUndoDateTimeField45);
        java.lang.String str47 = dateTimeFormatter35.print((org.joda.time.ReadablePartial) monthDay41);
        org.joda.time.format.DateTimePrinter dateTimePrinter48 = dateTimeFormatter35.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder49.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder49.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder53.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.MonthDay monthDay56 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.MonthDay monthDay58 = monthDay56.minus(readablePeriod57);
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.MonthDay monthDay61 = monthDay56.withPeriodAdded(readablePeriod59, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology63.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField65 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology62, dateTimeField64);
        boolean boolean66 = monthDay61.equals((java.lang.Object) skipUndoDateTimeField65);
        java.lang.String str67 = dateTimeFormatter55.print((org.joda.time.ReadablePartial) monthDay61);
        org.joda.time.format.DateTimePrinter dateTimePrinter68 = dateTimeFormatter55.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser70 = dateTimeFormatter69.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser72 = dateTimeFormatter71.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser74 = dateTimeFormatter73.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter75 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser76 = dateTimeFormatter75.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter77 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser78 = dateTimeFormatter77.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser80 = dateTimeFormatter79.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray81 = new org.joda.time.format.DateTimeParser[] { dateTimeParser70, dateTimeParser72, dateTimeParser74, dateTimeParser76, dateTimeParser78, dateTimeParser80 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder53.append(dateTimePrinter68, dateTimeParserArray81);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder34.append(dateTimePrinter48, dateTimeParserArray81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1970 + "'", int27 == 1970);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "����0101T������" + "'", str47.equals("����0101T������"));
        org.junit.Assert.assertNotNull(dateTimePrinter48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertNotNull(gJChronology62);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "����0101T������" + "'", str67.equals("����0101T������"));
        org.junit.Assert.assertNotNull(dateTimePrinter68);
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
        org.junit.Assert.assertNotNull(dateTimeParser70);
        org.junit.Assert.assertNotNull(dateTimeFormatter71);
        org.junit.Assert.assertNotNull(dateTimeParser72);
        org.junit.Assert.assertNotNull(dateTimeFormatter73);
        org.junit.Assert.assertNotNull(dateTimeParser74);
        org.junit.Assert.assertNotNull(dateTimeFormatter75);
        org.junit.Assert.assertNotNull(dateTimeParser76);
        org.junit.Assert.assertNotNull(dateTimeFormatter77);
        org.junit.Assert.assertNotNull(dateTimeParser78);
        org.junit.Assert.assertNotNull(dateTimeFormatter79);
        org.junit.Assert.assertNotNull(dateTimeParser80);
        org.junit.Assert.assertNotNull(dateTimeParserArray81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime10.withZone(dateTimeZone12);
        int int15 = dateTime10.getYear();
        org.joda.time.DateTime dateTime17 = dateTime10.minusMonths(100);
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.DateTime.Property property20 = dateTime6.property(dateTimeFieldType19);
        java.lang.String str21 = property20.getName();
        java.util.Locale locale22 = null;
        java.lang.String str23 = property20.getAsShortText(locale22);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "secondOfDay" + "'", str21.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime44 = null;
        org.joda.time.ReadableDateTime readableDateTime45 = null;
        org.joda.time.chrono.LimitChronology limitChronology46 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology43, readableDateTime44, readableDateTime45);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay((org.joda.time.Chronology) limitChronology46);
        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.MonthDay monthDay50 = monthDay48.minus(readablePeriod49);
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.MonthDay monthDay53 = monthDay48.withPeriodAdded(readablePeriod51, (int) (byte) 0);
        org.joda.time.MonthDay monthDay55 = monthDay48.minusDays((-1));
        int int56 = monthDay47.compareTo((org.joda.time.ReadablePartial) monthDay55);
        boolean boolean57 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay55);
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.weekyear();
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime63 = null;
        org.joda.time.ReadableDateTime readableDateTime64 = null;
        org.joda.time.chrono.LimitChronology limitChronology65 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology62, readableDateTime63, readableDateTime64);
        org.joda.time.DateTime dateTime66 = limitChronology65.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField67 = limitChronology65.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField69 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology59, dateTimeField67, (int) 'a');
        long long72 = skipDateTimeField69.add(0L, 0);
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeUtils.getZone(dateTimeZone73);
        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeUtils.getZone(dateTimeZone74);
        org.joda.time.MonthDay monthDay76 = org.joda.time.MonthDay.now(dateTimeZone75);
        int[] intArray80 = new int[] { 31, 31, '4' };
        int int81 = skipDateTimeField69.getMaximumValue((org.joda.time.ReadablePartial) monthDay76, intArray80);
        java.util.Locale locale83 = null;
        try {
            int[] intArray84 = offsetDateTimeField42.set((org.joda.time.ReadablePartial) monthDay55, 15, intArray80, "weekyear", locale83);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"weekyear\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(limitChronology46);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertNotNull(limitChronology65);
        org.junit.Assert.assertNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(dateTimeZone75);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 53 + "'", int81 == 53);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (short) 10, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant7 = gJChronology6.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.dayOfYear();
        int int10 = instant7.get(dateTimeField9);
        boolean boolean12 = instant7.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant15 = instant7.withDurationAdded(readableDuration13, 10);
        int int16 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology17 = copticChronology0.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology18 = copticChronology0.withUTC();
        int int19 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 278 + "'", int10 == 278);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField5 = gJChronology0.halfdays();
        int int6 = gJChronology0.getMinimumDaysInFirstWeek();
        long long10 = gJChronology0.add((-6L), (long) (byte) 10, (int) (short) 10);
        org.joda.time.Instant instant11 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 94L + "'", long10 == 94L);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, 288000010L, (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -292275054");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 0, 1970, 1, (-292275053), (int) (short) -1, 4, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275053 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        int int8 = skipUndoDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay7);
        int[] intArray9 = monthDay7.getValues();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292278993 + "'", int8 == 292278993);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology0, obj1);
        try {
            long long7 = julianChronology0.getDateTimeMillis(4, 2, 1969, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,29]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Chronology chronology4 = instant3.getChronology();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.Instant instant4 = instant0.withDurationAdded((long) (-292275053), (int) (byte) 10);
        org.joda.time.Chronology chronology5 = instant0.getChronology();
        org.joda.time.Instant instant6 = instant0.toInstant();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) 0, 1969);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.DateTime dateTime12 = property10.getDateTime();
        int int13 = property10.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (byte) 10);
        boolean boolean10 = dateTimeZone6.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter4.withZone(dateTimeZone6);
        boolean boolean12 = gJChronology0.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((long) 1970, locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:00" + "'", str4.equals("-01:00"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DurationField durationField11 = property10.getLeapDurationField();
        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime14 = dateTime12.minusWeeks(278);
        int int15 = dateTime14.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        boolean boolean11 = skipUndoDateTimeField9.isSupported();
        long long14 = skipUndoDateTimeField9.set((long) 1582, 1);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        int int23 = dateTimeZone21.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone21);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone21);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.MonthDay monthDay29 = monthDay27.minus(readablePeriod28);
        int[] intArray31 = iSOChronology26.get((org.joda.time.ReadablePartial) monthDay29, 0L);
        try {
            int[] intArray33 = skipUndoDateTimeField9.set((org.joda.time.ReadablePartial) monthDay18, 0, intArray31, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 99");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62135337598418L) + "'", long14 == (-62135337598418L));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long12 = skipDateTimeField10.roundHalfFloor((long) 1);
        boolean boolean13 = skipDateTimeField10.isLenient();
        long long15 = skipDateTimeField10.roundHalfCeiling(28800100L);
        int int16 = skipDateTimeField10.getMinimumValue();
        long long18 = skipDateTimeField10.roundHalfFloor((long) (byte) 0);
        long long21 = skipDateTimeField10.set((long) 5044, (int) (short) 1);
        org.joda.time.DurationField durationField22 = skipDateTimeField10.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-259200000L) + "'", long18 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9071994956L) + "'", long21 == (-9071994956L));
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        boolean boolean6 = dateTimeZone2.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.withZone(dateTimeZone13);
        int int16 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        java.util.Locale locale18 = null;
        java.lang.String str19 = property17.getAsText(locale18);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970" + "'", str19.equals("1970"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        try {
            org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1969");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withMonthOfYear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(5044L, (long) (-28800000));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-145267200000L) + "'", long2 == (-145267200000L));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0.0f, number2, (java.lang.Number) 32054400010L);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 32054400010L + "'", number5.equals(32054400010L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay4, 278, locale8);
        org.joda.time.MonthDay monthDay11 = monthDay4.withDayOfMonth(31);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.MonthDay monthDay14 = monthDay4.withFieldAdded(durationFieldType12, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "278" + "'", str9.equals("278"));
        org.junit.Assert.assertNotNull(monthDay11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        int int8 = skipUndoDateTimeField3.get((long) (-292274953));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = limitChronology7.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField9 = limitChronology7.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField9, (int) 'a');
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        int int44 = offsetDateTimeField42.get(97L);
        long long46 = offsetDateTimeField42.roundHalfEven((-10L));
        int int48 = offsetDateTimeField42.getMinimumValue(28800010L);
        boolean boolean50 = offsetDateTimeField42.isLeap((long) 1970);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2070 + "'", int44 == 2070);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-259200000L) + "'", long46 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-292274953) + "'", int48 == (-292274953));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 10L + "'", long0 == 10L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withDefaultYear(5044);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter13.withZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone16);
        java.lang.String str20 = zonedChronology19.toString();
        try {
            long long26 = zonedChronology19.getDateTimeMillis(0L, (int) '4', 1, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ZonedChronology[LimitChronology[CopticChronology[UTC], NoLimit, NoLimit], UTC]" + "'", str20.equals("ZonedChronology[LimitChronology[CopticChronology[UTC], NoLimit, NoLimit], UTC]"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        long long7 = skipUndoDateTimeField3.set((long) 5044, (int) (byte) 10);
        int int8 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str9 = skipUndoDateTimeField3.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851081594956L) + "'", long7 == (-61851081594956L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275053) + "'", int8 == (-292275053));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[weekyear]" + "'", str9.equals("DateTimeField[weekyear]"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.io.Writer writer2 = null;
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.minus(readablePeriod4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay3.withPeriodAdded(readablePeriod6, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        boolean boolean13 = monthDay8.equals((java.lang.Object) skipUndoDateTimeField12);
        int int14 = monthDay8.getDayOfMonth();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) monthDay8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        int int12 = property10.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField13 = property10.getField();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1969);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("278", (-10));
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("--01-01", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        boolean boolean11 = skipUndoDateTimeField9.isSupported();
        long long14 = skipUndoDateTimeField9.set((long) 1582, 1);
        int int16 = skipUndoDateTimeField9.getMinimumValue((long) (short) 0);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62135337598418L) + "'", long14 == (-62135337598418L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-292275054) + "'", int16 == (-292275054));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        int int2 = dateTime1.getDayOfWeek();
        org.joda.time.DateTime dateTime4 = dateTime1.withYear(4);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        long long9 = copticChronology0.getDateTimeMillis((long) 10, 0, (int) ' ', (int) (byte) 0, (int) 'a');
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        try {
            int[] intArray13 = copticChronology0.get(readablePeriod10, 0L, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1920097L + "'", long9 == 1920097L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
        int int8 = dateTime7.getMinuteOfHour();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillis(0L);
        org.joda.time.DateTime dateTime12 = dateTime7.withSecondOfMinute(53);
        boolean boolean14 = dateTime7.isAfter((long) (short) 100);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (byte) 0);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        int int6 = dateTimeZone4.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        boolean boolean12 = julianChronology1.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 4, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField14 = julianChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(94L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        long long7 = skipUndoDateTimeField3.set((long) 5044, (int) (byte) 10);
        long long10 = skipUndoDateTimeField3.add((long) 2, (int) (byte) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851081594956L) + "'", long7 == (-61851081594956L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 315705600002L + "'", long10 == 315705600002L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime4 = instant3.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime();
        boolean boolean6 = mutableDateTime5.isBeforeNow();
        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "Thursday", 0);
        int int10 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2000 + "'", int10 == 2000);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getYear();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(100);
        try {
            java.lang.String str12 = dateTime3.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay4, 278, locale8);
        long long12 = skipUndoDateTimeField3.addWrapField(10L, (int) (short) 1);
        long long14 = skipUndoDateTimeField3.remainder((long) 4);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now((org.joda.time.Chronology) buddhistChronology20);
        int[] intArray23 = null;
        int[] intArray25 = skipUndoDateTimeField3.add((org.joda.time.ReadablePartial) monthDay21, (int) (byte) 0, intArray23, 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "278" + "'", str9.equals("278"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32054400010L + "'", long12 == 32054400010L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 259200004L + "'", long14 == 259200004L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNull(intArray25);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withDefaultYear(5044);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter13.withZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone16);
        java.lang.String str20 = zonedChronology19.toString();
        try {
            long long25 = zonedChronology19.getDateTimeMillis((int) (short) 0, 2, 53, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ZonedChronology[LimitChronology[CopticChronology[UTC], NoLimit, NoLimit], UTC]" + "'", str20.equals("ZonedChronology[LimitChronology[CopticChronology[UTC], NoLimit, NoLimit], UTC]"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField8);
        boolean boolean10 = monthDay5.equals((java.lang.Object) skipUndoDateTimeField9);
        boolean boolean11 = skipUndoDateTimeField9.isSupported();
        int int12 = skipUndoDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292275053) + "'", int12 == (-292275053));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipUndoDateTimeField3.getType();
        int int10 = skipUndoDateTimeField3.getDifference(259201582L, (long) (short) 10);
        long long12 = skipUndoDateTimeField3.roundHalfFloor((long) 9);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.io.Writer writer2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfYear();
        int int7 = instant4.get(dateTimeField6);
        boolean boolean9 = instant4.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant12 = instant4.withDurationAdded(readableDuration10, 10);
        org.joda.time.MutableDateTime mutableDateTime13 = instant4.toMutableDateTimeISO();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) instant4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 278 + "'", int7 == 278);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((-61851081594956L), locale3);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        int int44 = offsetDateTimeField42.get(97L);
        long long46 = offsetDateTimeField42.roundHalfEven((-10L));
        int int48 = offsetDateTimeField42.getMinimumValue(28800010L);
        try {
            long long51 = offsetDateTimeField42.add(94L, 292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292280963 for weekyear must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2070 + "'", int44 == 2070);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-259200000L) + "'", long46 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-292274953) + "'", int48 == (-292274953));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-1), (int) (byte) 0, (int) (short) -1, (int) (short) -1, (-28800000), (int) '4', dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("ZonedChronology[LimitChronology[CopticChronology[UTC], NoLimit, NoLimit], UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'ZonedChronology[LimitChronology[CopticChronology[UTC], NoLimit, NoLimit], UTC]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime8.withDayOfMonth(4);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (byte) 10);
        boolean boolean10 = dateTimeZone6.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(28800010L, dateTimeZone6);
        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime12.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime15, (int) (byte) 1);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.weekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 0, (int) (short) 1, (int) (short) 1, (int) (byte) 10, (int) (short) -1, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime5.withZone(dateTimeZone7);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long13 = skipDateTimeField10.add(0L, 0);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone16);
        int[] intArray21 = new int[] { 31, 31, '4' };
        int int22 = skipDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) monthDay17, intArray21);
        int int23 = skipDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        long long13 = skipUndoDateTimeField3.roundCeiling((-259200000L));
        int int14 = skipUndoDateTimeField3.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275053) + "'", int14 == (-292275053));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        java.lang.Class<?> wildcardClass4 = instant3.getClass();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone10);
        int int13 = dateTime12.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.toDateTime(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = dateTime19.withZone(dateTimeZone21);
        int int24 = dateTime19.getYear();
        org.joda.time.DateTime dateTime26 = dateTime19.minusMonths(100);
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.DateTime.Property property29 = dateTime15.property(dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType28, 0, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1970 + "'", int24 == 1970);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField32 = limitChronology3.weekOfWeekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
        org.joda.time.DateTime dateTime7 = limitChronology3.getUpperLimit();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNull(dateTime7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(1969);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("-01:00", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-292274953), (int) (byte) 0, 0, (int) (short) 1, 1, (-28378000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.minus(readablePeriod8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) monthDay7, 278, locale11);
        int int13 = monthDay7.getDayOfMonth();
        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "278" + "'", str12.equals("278"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "����-W��-�" + "'", str14.equals("����-W��-�"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withDefaultYear(5044);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter13.withZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone16);
        org.joda.time.DurationField durationField20 = zonedChronology19.weeks();
        try {
            long long28 = zonedChronology19.getDateTimeMillis((-292274953), 4, 10, 0, 15, 10, 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292274953 for year must be in the range [-292269337,292272708]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTime dateTime12 = property9.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DurationField durationField13 = property9.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone10);
        int int13 = dateTime12.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.toDateTime(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = dateTime19.withZone(dateTimeZone21);
        int int24 = dateTime19.getYear();
        org.joda.time.DateTime dateTime26 = dateTime19.minusMonths(100);
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.DateTime.Property property29 = dateTime15.property(dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType28, 0, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendMillisOfDay(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendTwoDigitWeekyear(10, false);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1970 + "'", int24 == 1970);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology0, obj1);
        org.joda.time.DurationField durationField3 = julianChronology0.weekyears();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getYear();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(100);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType12, 292278993, 53, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for secondOfDay must be in the range [53,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '4', 5044, 0, (-1), (int) ' ', 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        java.util.Locale locale44 = null;
        java.lang.String str45 = offsetDateTimeField42.getAsShortText((int) '4', locale44);
        java.lang.String str46 = offsetDateTimeField42.getName();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "secondOfDay" + "'", str46.equals("secondOfDay"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(94L, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9118L + "'", long2 == 9118L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        java.lang.Object obj6 = null;
        boolean boolean7 = limitChronology3.equals(obj6);
        org.joda.time.DurationField durationField8 = limitChronology3.months();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
        long long22 = skipDateTimeField19.add(0L, 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, (org.joda.time.DateTimeField) skipDateTimeField19);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone25);
        int int28 = dateTime27.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.toDateTime(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
        org.joda.time.DateTime dateTime38 = dateTime34.withZone(dateTimeZone36);
        int int39 = dateTime34.getYear();
        org.joda.time.DateTime dateTime41 = dateTime34.minusMonths(100);
        org.joda.time.DateTime.Property property42 = dateTime41.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.DateTime.Property property44 = dateTime30.property(dateTimeFieldType43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType43, 53, 2, (-292275053));
        long long50 = offsetDateTimeField48.roundCeiling((long) (byte) 1);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField48, (-1), 2, 292279093);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfDay must be in the range [2,292279093]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1970 + "'", int39 == 1970);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 345600000L + "'", long50 == 345600000L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0.0f, number2, (java.lang.Number) 32054400010L);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, 2000);
        long long10 = offsetDateTimeField8.roundHalfEven((long) 9);
        int int12 = offsetDateTimeField8.get((-8899200000L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3969 + "'", int12 == 3969);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipUndoDateTimeField3.getType();
        int int10 = skipUndoDateTimeField3.getDifference(259201582L, (long) (short) 10);
        long long12 = skipUndoDateTimeField3.roundHalfCeiling((-61851081594956L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61851340800000L) + "'", long12 == (-61851340800000L));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField35.getAsText(0, locale37);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, 2000);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, (org.joda.time.DateTimeField) offsetDateTimeField40, (-28800000));
        java.lang.String str44 = offsetDateTimeField40.getAsText((long) 4);
        java.lang.String str45 = offsetDateTimeField40.getName();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "3970" + "'", str44.equals("3970"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "weekyear" + "'", str45.equals("weekyear"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime3.era();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsShortText(locale6);
        java.util.Locale locale8 = null;
        java.lang.String str9 = property5.getAsText(locale8);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AD" + "'", str7.equals("AD"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AD" + "'", str9.equals("AD"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        long long5 = durationField2.subtract((long) 1686, 0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1686L + "'", long5 == 1686L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        boolean boolean6 = dateTimeZone2.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime13 = limitChronology3.getLowerLimit();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNull(dateTime13);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(0L);
        org.joda.time.DateTime.Property property7 = dateTime3.era();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(10);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks(2000);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(0L);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.minus(readableDuration7);
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology7);
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay8);
//        try {
//            org.joda.time.MonthDay monthDay11 = monthDay8.withDayOfMonth((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "����-06-15T��:��:��" + "'", str9.equals("����-06-15T��:��:��"));
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.String str5 = instant3.toString(dateTimeFormatter4);
        org.joda.time.Chronology chronology6 = dateTimeFormatter4.getChronolgy();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1582-288T00:00:00Z" + "'", str5.equals("1582-288T00:00:00Z"));
        org.junit.Assert.assertNull(chronology6);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
//        java.lang.String str9 = dateTimeZone5.getShortName((long) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-28378000), (long) (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 8294181482412000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        int int7 = property6.getMaximumValueOverall();
//        int int8 = property6.get();
//        try {
//            org.joda.time.MonthDay monthDay10 = property6.setCopy("53");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        int int9 = dateTime8.getMonthOfYear();
        int int10 = dateTime8.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.year();
        try {
            long long7 = gJChronology0.getDateTimeMillis((int) ' ', (-292274953), (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292274953 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField45);
        int int47 = skipUndoDateTimeField46.getMaximumValue();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((long) 53);
        int int50 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) monthDay49, 53, locale52);
        int int55 = offsetDateTimeField42.getMaximumValue(0L);
        boolean boolean57 = offsetDateTimeField42.isLeap((long) 292279093);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292278993 + "'", int47 == 292278993);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292275054) + "'", int50 == (-292275054));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "53" + "'", str53.equals("53"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 292279093 + "'", int55 == 292279093);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField45);
        int int47 = skipUndoDateTimeField46.getMaximumValue();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((long) 53);
        int int50 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) monthDay49, 53, locale52);
        org.joda.time.MonthDay monthDay55 = monthDay49.plusDays(12);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292278993 + "'", int47 == 292278993);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292275054) + "'", int50 == (-292275054));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "53" + "'", str53.equals("53"));
        org.junit.Assert.assertNotNull(monthDay55);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        int int11 = dateTime10.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
//        int int8 = dateTime7.getMinuteOfHour();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay9.withPeriodAdded(readablePeriod12, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay16 = monthDay9.minusDays((-1));
//        int[] intArray17 = monthDay16.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekyear();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.ReadableDateTime readableDateTime23 = null;
//        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
//        org.joda.time.DateTime dateTime25 = limitChronology24.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField26 = limitChronology24.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField26, (int) 'a');
//        long long31 = skipDateTimeField28.add(0L, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField28.getType();
//        boolean boolean33 = monthDay16.isSupported(dateTimeFieldType32);
//        org.joda.time.DateTime.Property property34 = dateTime7.property(dateTimeFieldType32);
//        org.joda.time.DateTime dateTime35 = property34.roundHalfCeilingCopy();
//        int int36 = dateTime35.getMonthOfYear();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(limitChronology24);
//        org.junit.Assert.assertNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) gJChronology3);
        org.joda.time.Instant instant6 = gJChronology3.getGregorianCutover();
        org.joda.time.MutableDateTime mutableDateTime7 = instant6.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime7.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        int int8 = skipUndoDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) monthDay7);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292278993 + "'", int8 == 292278993);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0.0f, number2, (java.lang.Number) 32054400010L);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 32054400010L + "'", number7.equals(32054400010L));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (byte) 10);
        boolean boolean10 = dateTimeZone6.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(28800010L, dateTimeZone6);
        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime12.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime15, (int) (byte) 1);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
        try {
            long long24 = gJChronology17.getDateTimeMillis((long) 16, (int) (byte) 10, (int) '4', 278, 5044);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 278 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology17);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        boolean boolean6 = dateTimeZone2.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.withZone(dateTimeZone13);
        int int16 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            int int18 = dateTime15.get(dateTimeFieldType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getMillisOfSecond();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.Object obj6 = null;
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology5, obj6);
        org.joda.time.DurationField durationField8 = julianChronology5.eras();
        java.lang.Class<?> wildcardClass9 = julianChronology5.getClass();
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime3, (java.lang.Object) wildcardClass9);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField35.getAsText(0, locale37);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, 2000);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, (org.joda.time.DateTimeField) offsetDateTimeField40, (-28800000));
        java.lang.String str44 = offsetDateTimeField40.getAsText((long) 4);
        org.joda.time.DurationField durationField45 = offsetDateTimeField40.getDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "3970" + "'", str44.equals("3970"));
        org.junit.Assert.assertNotNull(durationField45);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long12 = skipDateTimeField10.roundHalfFloor((long) 1);
        boolean boolean13 = skipDateTimeField10.isLenient();
        long long15 = skipDateTimeField10.roundHalfCeiling(28800100L);
        int int16 = skipDateTimeField10.getMinimumValue();
        int int18 = skipDateTimeField10.get(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        boolean boolean6 = dateTimeZone2.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        java.io.Writer writer8 = null;
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime10 = instant9.toDateTime();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((java.lang.Object) dateTime10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((java.lang.Object) monthDay11);
        try {
            dateTimeFormatter7.printTo(writer8, (org.joda.time.ReadablePartial) monthDay12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral("AD");
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfHour(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendDayOfYear(1970);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) gJChronology3);
        try {
            long long10 = iSOChronology0.getDateTimeMillis((int) (byte) 0, (int) 'a', 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime13 = dateTime8.minusDays((int) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getYear();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(100);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.Instant instant14 = new org.joda.time.Instant((java.lang.Object) dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
//        int int8 = dateTime3.getYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.fullDateTime();
//        java.util.Locale locale10 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withLocale(locale10);
//        java.util.Locale locale12 = dateTimeFormatter11.getLocale();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone15.getName((-61851081594956L), locale18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter11.withZone(dateTimeZone15);
//        java.lang.String str21 = dateTime3.toString(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNull(locale12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordinated Universal Time" + "'", str19.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Thursday, January 1, 1970 12:00:00 AM UTC" + "'", str21.equals("Thursday, January 1, 1970 12:00:00 AM UTC"));
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getYear();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(100);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        boolean boolean24 = dateTimeZone16.isStandardOffset((long) (byte) -1);
        long long27 = dateTimeZone16.convertLocalToUTC((long) 2000, true);
        org.joda.time.Chronology chronology28 = gregorianChronology14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime29 = dateTime10.toDateTime((org.joda.time.Chronology) gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2000L + "'", long27 == 2000L);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.ReadableDateTime readableDateTime7 = null;
        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology5, readableDateTime6, readableDateTime7);
        org.joda.time.DateTime dateTime9 = limitChronology8.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField10 = limitChronology8.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField10, (int) 'a');
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) iSOChronology2);
        try {
            org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(limitChronology8);
        org.junit.Assert.assertNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        boolean boolean10 = dateTime7.isSupported(dateTimeFieldType9);
        org.joda.time.DateTime.Property property11 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime13 = dateTime7.minusMonths(9);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfEra();
        try {
            long long12 = gJChronology1.getDateTimeMillis(0, 16, 1686, 53, 15, (int) (short) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfMonth();
        org.joda.time.DateTime.Property property11 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime13 = dateTime8.minus(288000010L);
        org.joda.time.DateTime dateTime15 = dateTime13.withYearOfCentury(0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipUndoDateTimeField3.getType();
        int int9 = skipUndoDateTimeField3.get((long) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.DateTime dateTime12 = property10.getDateTime();
        org.joda.time.Instant instant13 = dateTime12.toInstant();
        long long14 = instant13.getMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800010L + "'", long14 == 28800010L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getDayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        int int13 = skipUndoDateTimeField12.getMinimumValue();
        long long16 = skipUndoDateTimeField12.set((long) 5044, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = dateTime20.withZone(dateTimeZone22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(0, locale30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipUndoDateTimeField28.getType();
        org.joda.time.DateTime dateTime34 = dateTime24.withField(dateTimeFieldType32, 1582);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType32);
        org.joda.time.DateTime.Property property36 = dateTime3.property(dateTimeFieldType32);
        java.util.Locale locale37 = null;
        int int38 = property36.getMaximumShortTextLength(locale37);
        java.util.Locale locale39 = null;
        java.lang.String str40 = property36.getAsShortText(locale39);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-292275053) + "'", int13 == (-292275053));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851081594956L) + "'", long16 == (-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1970" + "'", str40.equals("1970"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
        org.joda.time.DurationField durationField7 = property6.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField7, (java.lang.Object) dateTimeZone10);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        int int5 = property4.getMaximumValue();
        org.joda.time.DurationField durationField6 = property4.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        int int5 = instant2.get(dateTimeField4);
        boolean boolean7 = instant2.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant10 = instant2.withDurationAdded(readableDuration8, 10);
        int int11 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) instant10);
        org.joda.time.DateTime dateTime12 = instant10.toDateTimeISO();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant14 = instant10.plus(readableDuration13);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.Instant instant16 = instant10.plus(readableDuration15);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 278 + "'", int5 == 278);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(instant16);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DurationField durationField11 = property10.getLeapDurationField();
        org.joda.time.DateTime dateTime12 = property10.roundHalfFloorCopy();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property10.getAsShortText(locale13);
        java.util.Locale locale15 = null;
        java.lang.String str16 = property10.getAsShortText(locale15);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu" + "'", str14.equals("Thu"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Thu" + "'", str16.equals("Thu"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (byte) 10);
        boolean boolean10 = dateTimeZone6.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(28800010L, dateTimeZone6);
        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime12.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime15, (int) (byte) 1);
        java.util.TimeZone timeZone18 = dateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        java.lang.Object obj6 = null;
        boolean boolean7 = limitChronology3.equals(obj6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Chronology chronology9 = limitChronology3.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = limitChronology3.getLowerLimit();
        org.joda.time.DurationField durationField11 = limitChronology3.months();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNull(dateTime10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getDayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        int int13 = skipUndoDateTimeField12.getMinimumValue();
        long long16 = skipUndoDateTimeField12.set((long) 5044, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = dateTime20.withZone(dateTimeZone22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(0, locale30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipUndoDateTimeField28.getType();
        org.joda.time.DateTime dateTime34 = dateTime24.withField(dateTimeFieldType32, 1582);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType32);
        org.joda.time.DateTime.Property property36 = dateTime3.property(dateTimeFieldType32);
        try {
            org.joda.time.DateTime dateTime38 = property36.setCopy("--06-15");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"--06-15\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-292275053) + "'", int13 == (-292275053));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851081594956L) + "'", long16 == (-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property36);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
        boolean boolean7 = dateTime5.isAfter((-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        boolean boolean6 = dateTimeZone2.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.withZone(dateTimeZone13);
        int int16 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.weekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
        org.joda.time.DurationField durationField20 = gregorianChronology18.years();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology18.getZone();
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) property17, (org.joda.time.Chronology) gJChronology23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gJChronology23);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        int int6 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withDefaultYear(5044);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter13.withZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone16);
        org.joda.time.DurationField durationField20 = zonedChronology19.weeks();
        try {
            long long28 = zonedChronology19.getDateTimeMillis(3971, (-28378000), 53, 69, (int) 'a', (-10), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getDayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        int int13 = skipUndoDateTimeField12.getMinimumValue();
        long long16 = skipUndoDateTimeField12.set((long) 5044, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = dateTime20.withZone(dateTimeZone22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField28.getAsText(0, locale30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipUndoDateTimeField28.getType();
        org.joda.time.DateTime dateTime34 = dateTime24.withField(dateTimeFieldType32, 1582);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType32);
        org.joda.time.DateTime.Property property36 = dateTime3.property(dateTimeFieldType32);
        org.joda.time.DateTime dateTime38 = dateTime3.withYearOfCentury(0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-292275053) + "'", int13 == (-292275053));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851081594956L) + "'", long16 == (-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime38);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField11.getAsText(0, locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipUndoDateTimeField11.getType();
        org.joda.time.DateTime dateTime17 = dateTime7.withField(dateTimeFieldType15, 1582);
        java.util.Locale locale18 = null;
        java.util.Calendar calendar19 = dateTime7.toCalendar(locale18);
        org.joda.time.DateTime dateTime21 = dateTime7.plusMillis(1969);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(calendar19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        java.lang.String str5 = property4.getAsString();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        int int4 = instant1.get(dateTimeField3);
        boolean boolean6 = instant1.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant1.withDurationAdded(readableDuration7, 10);
        org.joda.time.MutableDateTime mutableDateTime10 = instant1.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime11 = instant1.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withTime((int) 'a', 2070, 9, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 278 + "'", int4 == 278);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        boolean boolean6 = dateTimeZone1.isStandardOffset(0L);
        java.util.TimeZone timeZone7 = dateTimeZone1.toTimeZone();
        long long11 = dateTimeZone1.convertLocalToUTC((long) '4', true, (long) (-292275053));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.MonthDay monthDay3 = monthDay1.minus(readablePeriod2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay1.withPeriodAdded(readablePeriod4, (int) (byte) 0);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField9);
//        boolean boolean11 = monthDay6.equals((java.lang.Object) skipUndoDateTimeField10);
//        java.lang.String str12 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay6);
//        try {
//            java.lang.String str14 = monthDay6.toString("Coordinated Universal Time");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����0615T������" + "'", str12.equals("����0615T������"));
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) limitChronology3);
        org.joda.time.DurationField durationField5 = limitChronology3.weeks();
        org.joda.time.DurationField durationField6 = limitChronology3.hours();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime3 = null;
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology2, readableDateTime3, readableDateTime4);
        org.joda.time.DateTime dateTime6 = limitChronology5.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        long long13 = dateTimeZone8.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology14 = limitChronology5.withZone(dateTimeZone8);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        int int23 = dateTimeZone21.getOffsetFromLocal((long) (byte) 10);
        boolean boolean25 = dateTimeZone21.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter19.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(28800010L, dateTimeZone21);
        org.joda.time.DateTime.Property property28 = dateTime27.dayOfWeek();
        org.joda.time.DateTime dateTime30 = dateTime27.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (org.joda.time.ReadableInstant) dateTime30, (int) (byte) 1);
        org.joda.time.Chronology chronology33 = limitChronology5.withZone(dateTimeZone17);
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField36);
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipUndoDateTimeField37.getAsText(0, locale39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField37, 2000);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField(chronology33, (org.joda.time.DateTimeField) offsetDateTimeField42, (-28800000));
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeUtils.getZone(dateTimeZone46);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone46);
        int int49 = dateTime48.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = dateTime48.toDateTime(dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone57);
        int int60 = dateTime55.getYear();
        org.joda.time.DateTime dateTime62 = dateTime55.minusMonths(100);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        org.joda.time.DateTime.Property property65 = dateTime51.property(dateTimeFieldType64);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField66 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField42, dateTimeFieldType64);
        try {
            org.joda.time.MonthDay.Property property67 = monthDay1.property(dateTimeFieldType64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(limitChronology5);
        org.junit.Assert.assertNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(property65);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral("AD");
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfHour(31);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendFixedDecimal(dateTimeFieldType16, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
        boolean boolean11 = dateTimeZone7.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter5.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(28800010L, dateTimeZone7);
        org.joda.time.DateTime.Property property14 = dateTime13.dayOfWeek();
        org.joda.time.DateTime dateTime16 = dateTime13.minusWeeks(10);
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        org.joda.time.DateTimeField dateTimeField19 = localDateTime17.getField((int) (short) 0);
        boolean boolean20 = dateTimeZone2.isLocalDateTimeGap(localDateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
//        int int8 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra((int) (short) 1);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField13);
//        int int15 = skipUndoDateTimeField14.getMinimumValue();
//        java.lang.String str17 = skipUndoDateTimeField14.getAsText(97L);
//        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) monthDay19, (int) (short) -1, locale21);
//        org.joda.time.DurationField durationField23 = skipUndoDateTimeField14.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean31 = dateTimeZone27.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter25.withZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(28800010L, dateTimeZone27);
//        org.joda.time.DateTime.Property property34 = dateTime33.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField35 = property34.getField();
//        org.joda.time.DateTime dateTime36 = property34.getDateTime();
//        org.joda.time.DateTime dateTime37 = property34.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeUtils.getZone(dateTimeZone39);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone39);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeUtils.getZone(dateTimeZone43);
//        org.joda.time.DateTime dateTime45 = dateTime41.withZone(dateTimeZone43);
//        int int46 = dateTime41.getYear();
//        org.joda.time.DateTime dateTime48 = dateTime41.minusMonths(100);
//        org.joda.time.DateTime.Property property49 = dateTime48.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property49.getFieldType();
//        int int51 = dateTime37.get(dateTimeFieldType50);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField14, dateTimeFieldType50, (int) (byte) 100);
//        int int55 = offsetDateTimeField53.get(97L);
//        long long57 = offsetDateTimeField53.roundHalfEven((-10L));
//        int int59 = offsetDateTimeField53.getMinimumValue(28800010L);
//        org.joda.time.chrono.CopticChronology copticChronology60 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime61 = null;
//        org.joda.time.ReadableDateTime readableDateTime62 = null;
//        org.joda.time.chrono.LimitChronology limitChronology63 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology60, readableDateTime61, readableDateTime62);
//        org.joda.time.DateTime dateTime64 = limitChronology63.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField65 = limitChronology63.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField66 = limitChronology63.yearOfEra();
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology63);
//        int int68 = dateTime67.getMinuteOfHour();
//        org.joda.time.MonthDay monthDay69 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod70 = null;
//        org.joda.time.MonthDay monthDay71 = monthDay69.minus(readablePeriod70);
//        org.joda.time.ReadablePeriod readablePeriod72 = null;
//        org.joda.time.MonthDay monthDay74 = monthDay69.withPeriodAdded(readablePeriod72, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay76 = monthDay69.minusDays((-1));
//        int[] intArray77 = monthDay76.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField79 = iSOChronology78.weekyear();
//        org.joda.time.DateTimeField dateTimeField80 = iSOChronology78.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology81 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime82 = null;
//        org.joda.time.ReadableDateTime readableDateTime83 = null;
//        org.joda.time.chrono.LimitChronology limitChronology84 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology81, readableDateTime82, readableDateTime83);
//        org.joda.time.DateTime dateTime85 = limitChronology84.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField86 = limitChronology84.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField88 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology78, dateTimeField86, (int) 'a');
//        long long91 = skipDateTimeField88.add(0L, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType92 = skipDateTimeField88.getType();
//        boolean boolean93 = monthDay76.isSupported(dateTimeFieldType92);
//        org.joda.time.DateTime.Property property94 = dateTime67.property(dateTimeFieldType92);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField98 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField53, dateTimeFieldType92, 9, (-292275054), 0);
//        boolean boolean99 = dateTime3.isSupported(dateTimeFieldType92);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-292275053) + "'", int15 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970" + "'", str17.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1" + "'", str22.equals("-1"));
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1970 + "'", int46 == 1970);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2070 + "'", int55 == 2070);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-259200000L) + "'", long57 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-292274953) + "'", int59 == (-292274953));
//        org.junit.Assert.assertNotNull(copticChronology60);
//        org.junit.Assert.assertNotNull(limitChronology63);
//        org.junit.Assert.assertNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 19 + "'", int68 == 19);
//        org.junit.Assert.assertNotNull(monthDay69);
//        org.junit.Assert.assertNotNull(monthDay71);
//        org.junit.Assert.assertNotNull(monthDay74);
//        org.junit.Assert.assertNotNull(monthDay76);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertNotNull(iSOChronology78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertNotNull(dateTimeField80);
//        org.junit.Assert.assertNotNull(copticChronology81);
//        org.junit.Assert.assertNotNull(limitChronology84);
//        org.junit.Assert.assertNull(dateTime85);
//        org.junit.Assert.assertNotNull(dateTimeField86);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType92);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//        org.junit.Assert.assertNotNull(property94);
//        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + true + "'", boolean99 == true);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getYear();
        org.joda.time.DateTime dateTime10 = dateTime3.minusMonths(100);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DurationField durationField12 = property11.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.DateTime dateTime25 = property23.getDateTime();
        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
        int int35 = dateTime30.getYear();
        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        int int40 = dateTime26.get(dateTimeFieldType39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField45);
        int int47 = skipUndoDateTimeField46.getMaximumValue();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((long) 53);
        int int50 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) monthDay49, 53, locale52);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeUtils.getZone(dateTimeZone55);
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeUtils.getZone(dateTimeZone58);
        int int61 = dateTimeZone59.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone59);
        org.joda.time.chrono.BuddhistChronology buddhistChronology63 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone59);
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone59);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.minus(readablePeriod66);
        int[] intArray69 = iSOChronology64.get((org.joda.time.ReadablePartial) monthDay67, 0L);
        int int70 = offsetDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) monthDay57, intArray69);
        java.lang.String str72 = offsetDateTimeField42.getAsShortText((long) 3);
        int int74 = offsetDateTimeField42.get((long) (-292274953));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292278993 + "'", int47 == 292278993);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-292275054) + "'", int50 == (-292275054));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "53" + "'", str53.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology63);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-292274953) + "'", int70 == (-292274953));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "2070" + "'", str72.equals("2070"));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2069 + "'", int74 == 2069);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay4, 278, locale8);
        long long12 = skipUndoDateTimeField3.addWrapField(10L, (int) (short) 1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField15);
        int int17 = skipUndoDateTimeField16.getMaximumValue();
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((long) 53);
        int int20 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay19);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.minus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay22.withPeriodAdded(readablePeriod25, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology28, dateTimeField30);
        boolean boolean32 = monthDay27.equals((java.lang.Object) skipUndoDateTimeField31);
        boolean boolean33 = skipUndoDateTimeField31.isSupported();
        long long36 = skipUndoDateTimeField31.set(0L, (int) (short) 1);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField41);
        org.joda.time.MonthDay monthDay43 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay45 = monthDay43.minusMonths((-1));
        int[] intArray48 = new int[] { (short) 100 };
        int[] intArray50 = skipUndoDateTimeField42.add((org.joda.time.ReadablePartial) monthDay43, (-28800000), intArray48, (int) (byte) 0);
        int[] intArray52 = skipUndoDateTimeField31.addWrapPartial(readablePartial37, (-292275053), intArray50, 0);
        try {
            int[] intArray54 = skipUndoDateTimeField3.addWrapPartial((org.joda.time.ReadablePartial) monthDay19, (-28800000), intArray50, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -28800000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "278" + "'", str9.equals("278"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32054400010L + "'", long12 == 32054400010L);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278993 + "'", int17 == 292278993);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292275054) + "'", int20 == (-292275054));
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62135337600000L) + "'", long36 == (-62135337600000L));
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (byte) 10);
        boolean boolean13 = dateTimeZone9.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(28800010L, dateTimeZone9);
        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
        org.joda.time.DateTime dateTime18 = dateTime15.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime18, (int) (byte) 1);
        int int21 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime18);
        try {
            org.joda.time.DateTime dateTime26 = dateTime18.withTime(31, (-28378000), (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime9.minusWeeks(10);
        org.joda.time.DateTime dateTime14 = dateTime9.minusMinutes(9);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipUndoDateTimeField3.getType();
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipUndoDateTimeField3.getAsShortText((long) 10, locale9);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant12 = gJChronology11.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant14 = instant12.minus(readableDuration13);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology15, readableDateTime16, readableDateTime17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) instant14, (org.joda.time.Chronology) copticChronology15);
        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.minus(readablePeriod23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay22.withPeriodAdded(readablePeriod25, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology28, dateTimeField30);
        boolean boolean32 = monthDay27.equals((java.lang.Object) skipUndoDateTimeField31);
        boolean boolean33 = skipUndoDateTimeField31.isSupported();
        long long36 = skipUndoDateTimeField31.set(0L, (int) (short) 1);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField41);
        org.joda.time.MonthDay monthDay43 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay45 = monthDay43.minusMonths((-1));
        int[] intArray48 = new int[] { (short) 100 };
        int[] intArray50 = skipUndoDateTimeField42.add((org.joda.time.ReadablePartial) monthDay43, (-28800000), intArray48, (int) (byte) 0);
        int[] intArray52 = skipUndoDateTimeField31.addWrapPartial(readablePartial37, (-292275053), intArray50, 0);
        try {
            int[] intArray54 = skipUndoDateTimeField3.addWrapPartial((org.joda.time.ReadablePartial) localTime20, (int) (short) 10, intArray52, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(localTime20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62135337600000L) + "'", long36 == (-62135337600000L));
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.dayOfYear();
        int int7 = instant4.get(dateTimeField6);
        boolean boolean9 = instant4.equals((java.lang.Object) 1.0f);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant12 = instant4.withDurationAdded(readableDuration10, 10);
        int int13 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) instant12);
        org.joda.time.DateTime dateTime14 = instant12.toDateTimeISO();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) instant12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 278 + "'", int7 == 278);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime7.withTimeAtStartOfDay();
        int int9 = dateTime8.getMonthOfYear();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfMonth();
        org.joda.time.DateTime dateTime11 = property10.withMinimumValue();
        int int12 = dateTime11.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone5);
        int int8 = dateTime3.getYear();
        org.joda.time.DateTime dateTime10 = dateTime3.minusDays((-28378000));
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withFieldAdded(durationFieldType11, 2070);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        java.lang.String str6 = property4.toString();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[monthOfYear]" + "'", str6.equals("Property[monthOfYear]"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = julianChronology0.add(readablePeriod1, (long) (-10), (int) (short) 10);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-10L) + "'", long4 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("1", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        boolean boolean1 = instant0.isBeforeNow();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(97L);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int4 = skipUndoDateTimeField3.getMinimumValue();
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
//        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
//        org.joda.time.DateTime dateTime25 = property23.getDateTime();
//        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
//        int int35 = dateTime30.getYear();
//        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        int int40 = dateTime26.get(dateTimeFieldType39);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
//        int int44 = offsetDateTimeField42.get(97L);
//        long long46 = offsetDateTimeField42.roundHalfEven((-10L));
//        int int48 = offsetDateTimeField42.getMinimumValue(28800010L);
//        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime50 = null;
//        org.joda.time.ReadableDateTime readableDateTime51 = null;
//        org.joda.time.chrono.LimitChronology limitChronology52 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology49, readableDateTime50, readableDateTime51);
//        org.joda.time.DateTime dateTime53 = limitChronology52.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField54 = limitChronology52.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField55 = limitChronology52.yearOfEra();
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology52);
//        int int57 = dateTime56.getMinuteOfHour();
//        org.joda.time.MonthDay monthDay58 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod59 = null;
//        org.joda.time.MonthDay monthDay60 = monthDay58.minus(readablePeriod59);
//        org.joda.time.ReadablePeriod readablePeriod61 = null;
//        org.joda.time.MonthDay monthDay63 = monthDay58.withPeriodAdded(readablePeriod61, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay65 = monthDay58.minusDays((-1));
//        int[] intArray66 = monthDay65.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.weekyear();
//        org.joda.time.DateTimeField dateTimeField69 = iSOChronology67.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology70 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime71 = null;
//        org.joda.time.ReadableDateTime readableDateTime72 = null;
//        org.joda.time.chrono.LimitChronology limitChronology73 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology70, readableDateTime71, readableDateTime72);
//        org.joda.time.DateTime dateTime74 = limitChronology73.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField75 = limitChronology73.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField77 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology67, dateTimeField75, (int) 'a');
//        long long80 = skipDateTimeField77.add(0L, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType81 = skipDateTimeField77.getType();
//        boolean boolean82 = monthDay65.isSupported(dateTimeFieldType81);
//        org.joda.time.DateTime.Property property83 = dateTime56.property(dateTimeFieldType81);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField87 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField42, dateTimeFieldType81, 9, (-292275054), 0);
//        org.joda.time.DateTimeField dateTimeField88 = offsetDateTimeField87.getWrappedField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2070 + "'", int44 == 2070);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-259200000L) + "'", long46 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-292274953) + "'", int48 == (-292274953));
//        org.junit.Assert.assertNotNull(copticChronology49);
//        org.junit.Assert.assertNotNull(limitChronology52);
//        org.junit.Assert.assertNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 19 + "'", int57 == 19);
//        org.junit.Assert.assertNotNull(monthDay58);
//        org.junit.Assert.assertNotNull(monthDay60);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertNotNull(monthDay65);
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertNotNull(iSOChronology67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(copticChronology70);
//        org.junit.Assert.assertNotNull(limitChronology73);
//        org.junit.Assert.assertNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertNotNull(dateTimeField88);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendYear(292278993, 53);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder14.appendFractionOfMinute((-292275053), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfYear();
        int int4 = instant1.get(dateTimeField3);
        org.joda.time.MutableDateTime mutableDateTime5 = instant1.toMutableDateTime();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 278 + "'", int4 == 278);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        java.lang.String str2 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime13.withTimeAtStartOfDay();
        int int15 = dateTime14.getMonthOfYear();
        org.joda.time.DateTime.Property property16 = dateTime14.dayOfMonth();
        org.joda.time.DateTime.Property property17 = dateTime14.centuryOfEra();
        java.lang.String str18 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00" + "'", str18.equals("1970-01-01T00:00:00"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long12 = skipDateTimeField10.roundHalfFloor((long) 1);
        boolean boolean13 = skipDateTimeField10.isLenient();
        long long15 = skipDateTimeField10.roundHalfCeiling(28800100L);
        int int16 = skipDateTimeField10.getMinimumValue();
        int int18 = skipDateTimeField10.get((long) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTime();
//        boolean boolean3 = mutableDateTime2.isBeforeNow();
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560633582335L + "'", long4 == 1560633582335L);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(0, locale5);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, 2000);
        long long10 = offsetDateTimeField8.roundHalfFloor((long) 1970);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        int int6 = dateTimeZone4.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone4);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay9.withPeriodAdded(readablePeriod12, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField17);
        boolean boolean19 = monthDay14.equals((java.lang.Object) skipUndoDateTimeField18);
        boolean boolean20 = skipUndoDateTimeField18.isSupported();
        long long23 = skipUndoDateTimeField18.set(0L, (int) (short) 1);
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField28);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay32 = monthDay30.minusMonths((-1));
        int[] intArray35 = new int[] { (short) 100 };
        int[] intArray37 = skipUndoDateTimeField29.add((org.joda.time.ReadablePartial) monthDay30, (-28800000), intArray35, (int) (byte) 0);
        int[] intArray39 = skipUndoDateTimeField18.addWrapPartial(readablePartial24, (-292275053), intArray37, 0);
        try {
            gregorianChronology0.validate((org.joda.time.ReadablePartial) monthDay8, intArray39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135337600000L) + "'", long23 == (-62135337600000L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now(dateTimeZone7);
        boolean boolean12 = buddhistChronology5.equals((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone7);
        long long15 = dateTimeZone7.convertUTCToLocal((long) 15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 15L + "'", long15 == 15L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        boolean boolean10 = dateTimeZone2.isStandardOffset((long) (byte) -1);
        long long13 = dateTimeZone2.convertLocalToUTC((long) 2000, true);
        org.joda.time.Chronology chronology14 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2000L + "'", long13 == 2000L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withDate((-1), 2070, 292280993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2070 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        long long7 = skipUndoDateTimeField3.set((long) 5044, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.withZone(dateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipUndoDateTimeField19.getAsText(0, locale21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipUndoDateTimeField19.getType();
        org.joda.time.DateTime dateTime25 = dateTime15.withField(dateTimeFieldType23, 1582);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType23);
        java.util.Locale locale27 = null;
        int int28 = skipUndoDateTimeField3.getMaximumTextLength(locale27);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851081594956L) + "'", long7 == (-61851081594956L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.DateTime dateTime12 = property10.getDateTime();
        org.joda.time.DateTime dateTime13 = property10.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = dateTime17.withZone(dateTimeZone19);
        int int22 = dateTime17.getYear();
        org.joda.time.DateTime dateTime24 = dateTime17.minusMonths(100);
        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
        int int27 = dateTime13.get(dateTimeFieldType26);
        try {
            org.joda.time.DateTime dateTime29 = dateTime13.withMonthOfYear(292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1970 + "'", int22 == 1970);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField12.getAsText(0, locale14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipUndoDateTimeField12.getType();
        org.joda.time.DateTime dateTime18 = dateTime8.withField(dateTimeFieldType16, 1582);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
//        int int8 = dateTime7.getMinuteOfHour();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay9.minus(readablePeriod10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay14 = monthDay9.withPeriodAdded(readablePeriod12, (int) (byte) 0);
//        org.joda.time.MonthDay monthDay16 = monthDay9.minusDays((-1));
//        int[] intArray17 = monthDay16.getValues();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.weekyear();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.ReadableDateTime readableDateTime23 = null;
//        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology21, readableDateTime22, readableDateTime23);
//        org.joda.time.DateTime dateTime25 = limitChronology24.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField26 = limitChronology24.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField26, (int) 'a');
//        long long31 = skipDateTimeField28.add(0L, 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipDateTimeField28.getType();
//        boolean boolean33 = monthDay16.isSupported(dateTimeFieldType32);
//        org.joda.time.DateTime.Property property34 = dateTime7.property(dateTimeFieldType32);
//        org.joda.time.DateTime dateTime35 = property34.roundHalfCeilingCopy();
//        org.joda.time.DurationFieldType durationFieldType36 = null;
//        try {
//            org.joda.time.DateTime dateTime38 = dateTime35.withFieldAdded(durationFieldType36, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertNotNull(limitChronology24);
//        org.junit.Assert.assertNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.minus(readablePeriod4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay3.withPeriodAdded(readablePeriod6, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField11);
        boolean boolean13 = monthDay8.equals((java.lang.Object) skipUndoDateTimeField12);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField12);
        java.util.Locale locale15 = null;
        int int16 = skipUndoDateTimeField12.getMaximumTextLength(locale15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.weekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime8.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfSecond((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone1);
        int int4 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(0L);
        org.joda.time.DateTime.Property property7 = dateTime3.era();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(10);
        try {
            org.joda.time.DateTime dateTime14 = dateTime8.withDate(12, 2000, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.minus(readablePeriod1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay0.withPeriodAdded(readablePeriod3, (int) (byte) 0);
        org.joda.time.MonthDay monthDay7 = monthDay0.minusDays((-1));
        int[] intArray8 = monthDay7.getValues();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
        long long22 = skipDateTimeField19.add(0L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        boolean boolean24 = monthDay7.isSupported(dateTimeFieldType23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay7.minus(readablePeriod25);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray27 = monthDay26.getFieldTypes();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray27);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long12 = skipDateTimeField10.roundHalfFloor((long) 1);
        boolean boolean13 = skipDateTimeField10.isLenient();
        long long15 = skipDateTimeField10.roundHalfCeiling(28800100L);
        java.lang.String str17 = skipDateTimeField10.getAsShortText(0L);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone20);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField24);
        int int26 = skipUndoDateTimeField25.getMinimumValue();
        java.lang.String str28 = skipUndoDateTimeField25.getAsText(97L);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField25.getAsText((org.joda.time.ReadablePartial) monthDay30, (int) (short) -1, locale32);
        org.joda.time.DurationField durationField34 = skipUndoDateTimeField25.getDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeUtils.getZone(dateTimeZone37);
        int int40 = dateTimeZone38.getOffsetFromLocal((long) (byte) 10);
        boolean boolean42 = dateTimeZone38.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter36.withZone(dateTimeZone38);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(28800010L, dateTimeZone38);
        org.joda.time.DateTime.Property property45 = dateTime44.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField46 = property45.getField();
        org.joda.time.DateTime dateTime47 = property45.getDateTime();
        org.joda.time.DateTime dateTime48 = property45.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeUtils.getZone(dateTimeZone50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
        org.joda.time.DateTime dateTime56 = dateTime52.withZone(dateTimeZone54);
        int int57 = dateTime52.getYear();
        org.joda.time.DateTime dateTime59 = dateTime52.minusMonths(100);
        org.joda.time.DateTime.Property property60 = dateTime59.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property60.getFieldType();
        int int62 = dateTime48.get(dateTimeFieldType61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField25, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = iSOChronology66.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField68 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology65, dateTimeField67);
        int int69 = skipUndoDateTimeField68.getMaximumValue();
        org.joda.time.MonthDay monthDay71 = new org.joda.time.MonthDay((long) 53);
        int int72 = skipUndoDateTimeField68.getMinimumValue((org.joda.time.ReadablePartial) monthDay71);
        java.util.Locale locale74 = null;
        java.lang.String str75 = offsetDateTimeField64.getAsShortText((org.joda.time.ReadablePartial) monthDay71, 53, locale74);
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeUtils.getZone(dateTimeZone76);
        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeUtils.getZone(dateTimeZone77);
        org.joda.time.MonthDay monthDay79 = org.joda.time.MonthDay.now(dateTimeZone78);
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.DateTimeZone dateTimeZone81 = org.joda.time.DateTimeUtils.getZone(dateTimeZone80);
        int int83 = dateTimeZone81.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone81);
        org.joda.time.chrono.BuddhistChronology buddhistChronology85 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone81);
        org.joda.time.chrono.ISOChronology iSOChronology86 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone81);
        org.joda.time.MonthDay monthDay87 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod88 = null;
        org.joda.time.MonthDay monthDay89 = monthDay87.minus(readablePeriod88);
        int[] intArray91 = iSOChronology86.get((org.joda.time.ReadablePartial) monthDay89, 0L);
        int int92 = offsetDateTimeField64.getMinimumValue((org.joda.time.ReadablePartial) monthDay79, intArray91);
        int int93 = skipDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) monthDay21, intArray91);
        org.joda.time.MonthDay monthDay95 = monthDay21.plusDays(69);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "17" + "'", str17.equals("17"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292275053) + "'", int26 == (-292275053));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970" + "'", str28.equals("1970"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-1" + "'", str33.equals("-1"));
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1970 + "'", int57 == 1970);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(gJChronology65);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 292278993 + "'", int69 == 292278993);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-292275054) + "'", int72 == (-292275054));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "53" + "'", str75.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeZone77);
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertNotNull(dateTimeZone81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology85);
        org.junit.Assert.assertNotNull(iSOChronology86);
        org.junit.Assert.assertNotNull(monthDay87);
        org.junit.Assert.assertNotNull(monthDay89);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-292274953) + "'", int92 == (-292274953));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 53 + "'", int93 == 53);
        org.junit.Assert.assertNotNull(monthDay95);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
//        int int4 = skipUndoDateTimeField3.getMinimumValue();
//        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
//        org.joda.time.DurationField durationField12 = skipUndoDateTimeField3.getDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
//        boolean boolean20 = dateTimeZone16.isStandardOffset(28800100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(28800010L, dateTimeZone16);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
//        org.joda.time.DateTime dateTime25 = property23.getDateTime();
//        org.joda.time.DateTime dateTime26 = property23.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone32);
//        int int35 = dateTime30.getYear();
//        org.joda.time.DateTime dateTime37 = dateTime30.minusMonths(100);
//        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        int int40 = dateTime26.get(dateTimeFieldType39);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType39, (int) (byte) 100);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = offsetDateTimeField42.getAsShortText((int) '4', locale44);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter46.withPivotYear((int) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter46.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter46.withPivotYear((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter46.withOffsetParsed();
//        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.MonthDay monthDay54 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology53);
//        java.lang.String str55 = dateTimeFormatter46.print((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.MonthDay monthDay57 = monthDay54.plus(readablePeriod56);
//        int int58 = offsetDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) monthDay54);
//        boolean boolean60 = offsetDateTimeField42.isLeap((long) 3);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "52" + "'", str45.equals("52"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(iSOChronology53);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "����-06-15T��:��:��" + "'", str55.equals("����-06-15T��:��:��"));
//        org.junit.Assert.assertNotNull(monthDay57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-292274953) + "'", int58 == (-292274953));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay4.withPeriodAdded(readablePeriod7, (int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField12);
        boolean boolean14 = monthDay9.equals((java.lang.Object) skipUndoDateTimeField13);
        boolean boolean15 = skipUndoDateTimeField13.isSupported();
        long long18 = skipUndoDateTimeField13.set((long) 1582, 1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField13.getAsText((long) 1582, locale20);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField13, (int) (short) 0);
        int int25 = skipUndoDateTimeField23.get(288000010L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135337598418L) + "'", long18 == (-62135337598418L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970" + "'", str21.equals("1970"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        long long7 = skipUndoDateTimeField3.set((long) 5044, (int) (byte) 10);
        int int8 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str9 = skipUndoDateTimeField3.getName();
        boolean boolean10 = skipUndoDateTimeField3.isLenient();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851081594956L) + "'", long7 == (-61851081594956L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275053) + "'", int8 == (-292275053));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "weekyear" + "'", str9.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime1 = null;
//        org.joda.time.ReadableDateTime readableDateTime2 = null;
//        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
//        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = limitChronology3.equals(obj6);
//        org.joda.time.DurationField durationField8 = limitChronology3.months();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.ReadableDateTime readableDateTime13 = null;
//        org.joda.time.ReadableDateTime readableDateTime14 = null;
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
//        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
//        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
//        long long22 = skipDateTimeField19.add(0L, 0);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, (org.joda.time.DateTimeField) skipDateTimeField19);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone25);
//        int int28 = dateTime27.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime27.toDateTime(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.DateTime dateTime38 = dateTime34.withZone(dateTimeZone36);
//        int int39 = dateTime34.getYear();
//        org.joda.time.DateTime dateTime41 = dateTime34.minusMonths(100);
//        org.joda.time.DateTime.Property property42 = dateTime41.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
//        org.joda.time.DateTime.Property property44 = dateTime30.property(dateTimeFieldType43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType43, 53, 2, (-292275053));
//        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.MonthDay monthDay51 = monthDay49.minus(readablePeriod50);
//        int int52 = skipDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) monthDay49);
//        int int53 = monthDay49.getDayOfMonth();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(limitChronology3);
//        org.junit.Assert.assertNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1970 + "'", int39 == 1970);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(monthDay49);
//        org.junit.Assert.assertNotNull(monthDay51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 53 + "'", int52 == 53);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 15 + "'", int53 == 15);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 10, (long) 2000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2010L + "'", long2 == 2010L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime4 = instant3.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTime();
        boolean boolean6 = mutableDateTime5.isBeforeNow();
        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "Thursday", 0);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime11 = instant10.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime12 = instant10.toMutableDateTime();
        boolean boolean13 = mutableDateTime12.isEqualNow();
        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime12, "weekyear", (int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) gJChronology1);
        int int4 = gJChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology5 = gJChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone7);
        int int10 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone18);
        int int21 = dateTime16.getYear();
        org.joda.time.DateTime dateTime23 = dateTime16.minusMonths(100);
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.DateTime.Property property26 = dateTime12.property(dateTimeFieldType25);
        boolean boolean27 = gJChronology1.equals((java.lang.Object) dateTimeFieldType25);
        org.joda.time.Chronology chronology28 = gJChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology1.minuteOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1970 + "'", int21 == 1970);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        java.lang.Object obj6 = null;
        boolean boolean7 = limitChronology3.equals(obj6);
        org.joda.time.DurationField durationField8 = limitChronology3.months();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology12, readableDateTime13, readableDateTime14);
        org.joda.time.DateTime dateTime16 = limitChronology15.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField17 = limitChronology15.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField17, (int) 'a');
        long long22 = skipDateTimeField19.add(0L, 0);
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, (org.joda.time.DateTimeField) skipDateTimeField19);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone25);
        int int28 = dateTime27.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.toDateTime(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((java.lang.Object) 10L, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
        org.joda.time.DateTime dateTime38 = dateTime34.withZone(dateTimeZone36);
        int int39 = dateTime34.getYear();
        org.joda.time.DateTime dateTime41 = dateTime34.minusMonths(100);
        org.joda.time.DateTime.Property property42 = dateTime41.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.DateTime.Property property44 = dateTime30.property(dateTimeFieldType43);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType43, 53, 2, (-292275053));
        boolean boolean49 = offsetDateTimeField48.isLenient();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1970 + "'", int39 == 1970);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField5 = limitChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = limitChronology3.yearOfEra();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) limitChronology3);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks(16);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis(35);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) (byte) 100, true, (long) (byte) 10);
        org.joda.time.Chronology chronology12 = limitChronology3.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology13.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        boolean boolean23 = dateTimeZone19.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(28800010L, dateTimeZone19);
        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
        org.joda.time.DateTime dateTime28 = dateTime25.minusWeeks(10);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime28, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = limitChronology3.withZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField34);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology3, dateTimeField34);
        try {
            long long44 = limitChronology3.getDateTimeMillis((int) (short) -1, 31, (-10), (int) (short) 10, 1582, 3, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1582 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.chrono.LimitChronology limitChronology6 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology3, readableDateTime4, readableDateTime5);
        org.joda.time.DateTime dateTime7 = limitChronology6.getLowerLimit();
        org.joda.time.DateTimeField dateTimeField8 = limitChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField8, (int) 'a');
        long long13 = skipDateTimeField10.add(0L, 0);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone16);
        int[] intArray21 = new int[] { 31, 31, '4' };
        int int22 = skipDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) monthDay17, intArray21);
        long long25 = skipDateTimeField10.addWrapField(52L, 100);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(limitChronology6);
        org.junit.Assert.assertNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-3628799948L) + "'", long25 == (-3628799948L));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipUndoDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) monthDay4, 278, locale8);
        long long12 = skipUndoDateTimeField3.addWrapField(10L, (int) (short) 1);
        long long14 = skipUndoDateTimeField3.remainder((long) 4);
        int int17 = skipUndoDateTimeField3.getDifference((long) 0, (long) (-28800000));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "278" + "'", str9.equals("278"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32054400010L + "'", long12 == 32054400010L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 259200004L + "'", long14 == 259200004L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
        int int4 = skipUndoDateTimeField3.getMinimumValue();
        java.lang.String str6 = skipUndoDateTimeField3.getAsText(97L);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, locale10);
        long long13 = skipUndoDateTimeField3.roundCeiling((-259200000L));
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.weekyear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField16);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay18.minus(readablePeriod19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay18, 278, locale22);
        int int24 = skipUndoDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay18);
        int int26 = skipUndoDateTimeField3.get((-98L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-292275053) + "'", int4 == (-292275053));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970" + "'", str6.equals("1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "278" + "'", str23.equals("278"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 292278993 + "'", int24 == 292278993);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1970 + "'", int26 == 1970);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(1970, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.append(dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear((int) (byte) 1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
        boolean boolean7 = dateTimeZone3.isStandardOffset(28800100L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(28800010L, dateTimeZone3);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime11 = property10.roundFloorCopy();
        org.joda.time.DateTime.Property property12 = dateTime11.dayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(2000L, 3971);
        org.joda.time.DateTime dateTime17 = dateTime11.minusMinutes(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, readableDateTime1, readableDateTime2);
        org.joda.time.DateTime dateTime4 = limitChronology3.getLowerLimit();
        try {
            long long12 = limitChronology3.getDateTimeMillis(1582, 16, 2069, (int) 'a', 53, 292279093, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(limitChronology3);
        org.junit.Assert.assertNull(dateTime4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadableDateTime readableDateTime5 = null;
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology4, readableDateTime5, readableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) instant3, (org.joda.time.Chronology) copticChronology4);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        org.joda.time.DateTime dateTime11 = dateTime8.plus((long) 19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(limitChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(2000, 1970, (-10), 19);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }
}

