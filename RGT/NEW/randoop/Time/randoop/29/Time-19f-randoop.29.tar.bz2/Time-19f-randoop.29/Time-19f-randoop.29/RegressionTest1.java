import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        java.util.Locale locale7 = null;
//        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
//        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
//        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
//        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        int[] intArray26 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int27 = offsetDateTimeField6.getMaximumValue(readablePartial19, intArray26);
//        long long29 = offsetDateTimeField6.roundHalfFloor((long) 946);
//        try {
//            long long32 = offsetDateTimeField6.set((long) 33, "2019-03-10T15:19:29.264-07:00");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-03-10T15:19:29.264-07:00\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 292279045 + "'", int27 == 292279045);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2019L) + "'", long29 == (-2019L));
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(dateTimeZone11);
        boolean boolean13 = dateTime12.isEqualNow();
        boolean boolean14 = dateTime12.isEqualNow();
        int int15 = property6.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = property6.getDateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        long long6 = gregorianChronology0.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
//        int int6 = dateTime5.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        long long4 = dateTimeZone1.adjustOffset((long) 3, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3L + "'", long4 == 3L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        boolean boolean6 = dateTime5.isEqualNow();
        boolean boolean7 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime10 = dateTime5.plusMonths(2019);
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        java.util.Locale locale7 = null;
//        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
//        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
//        long long13 = offsetDateTimeField6.set(1552256374735L, "960");
//        long long15 = offsetDateTimeField6.remainder((long) (-3));
//        long long17 = offsetDateTimeField6.roundHalfEven(33L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-33507481225265L) + "'", long13 == (-33507481225265L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2016L + "'", long15 == 2016L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2019L) + "'", long17 == (-2019L));
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        long long6 = gregorianChronology0.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        boolean boolean6 = cachedDateTimeZone5.isFixed();
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone5.getUncachedZone();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
//        boolean boolean14 = dateTime13.isEqualNow();
//        boolean boolean15 = dateTime13.isEqualNow();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        java.lang.String str17 = dateTime13.toString(dateTimeFormatter16);
//        org.joda.time.DateTime dateTime19 = dateTime13.withMillisOfSecond((int) '4');
//        org.joda.time.DateTime.Property property20 = dateTime13.weekyear();
//        int int21 = cachedDateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime13);
//        int int22 = dateTime13.getHourOfDay();
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-W39-5T00:00:02+00:00:02.019" + "'", str17.equals("1969-W39-5T00:00:02+00:00:02.019"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime4 = dateTime1.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
        org.joda.time.DateTime dateTime13 = dateTime10.minusDays((int) 'a');
        java.util.Date date14 = dateTime10.toDate();
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight17 = dateTime16.toDateMidnight();
        org.joda.time.DateTime dateTime19 = dateTime16.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.minusYears((int) (byte) 1);
        boolean boolean24 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime26 = dateTime23.plusMonths(28);
        org.joda.time.TimeOfDay timeOfDay27 = dateTime26.toTimeOfDay();
        int[] intArray29 = iSOChronology0.get((org.joda.time.ReadablePartial) timeOfDay27, (long) ' ');
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale32 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withLocale(locale32);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone39 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter33.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone39);
        long long42 = cachedDateTimeZone39.previousTransition(2019L);
        org.joda.time.Chronology chronology43 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(timeOfDay27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(cachedDateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertNotNull(chronology43);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(57600000, 729, (int) (short) 10, 39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 729 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int7 = fixedDateTimeZone5.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long10 = fixedDateTimeZone5.nextTransition(0L);
        int int12 = fixedDateTimeZone5.getOffsetFromLocal((long) 2019);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 3, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        org.joda.time.Chronology chronology4 = dateTimeFormatter2.getChronology();
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property2.addWrapFieldToCopy(12);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName(100L, locale2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getName(0L, locale5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone7.getUncachedZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        java.lang.String str10 = cachedDateTimeZone9.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) 'a');
//        java.util.Date date9 = dateTime5.toDate();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime5);
//        int int11 = dateTime2.getYear();
//        java.util.Date date12 = dateTime2.toDate();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        int int5 = property4.getMinimumValue();
//        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
//        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
//        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight18 = dateTime17.toDateMidnight();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(dateTimeZone21);
//        org.joda.time.DateTime.Property property23 = dateTime20.year();
//        org.joda.time.DateTime dateTime25 = property23.addToCopy((int) 'a');
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight27 = dateTime26.toDateMidnight();
//        org.joda.time.DateTime dateTime29 = dateTime26.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime29.toDateTime(dateTimeZone30);
//        org.joda.time.DateTime.Property property32 = dateTime29.year();
//        org.joda.time.DateTime dateTime34 = property32.addToCopy((long) 4);
//        boolean boolean35 = property23.equals((java.lang.Object) 4);
//        org.joda.time.DateTime dateTime36 = property23.withMinimumValue();
//        org.joda.time.TimeOfDay timeOfDay37 = dateTime36.toTimeOfDay();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight44 = dateTime43.toDateMidnight();
//        org.joda.time.DateTime dateTime45 = dateTime43.toDateTimeISO();
//        org.joda.time.Chronology chronology46 = null;
//        org.joda.time.DateTime dateTime47 = dateTime45.toDateTime(chronology46);
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight49 = dateTime48.toDateMidnight();
//        org.joda.time.DateTime dateTime51 = dateTime48.minusDays((int) 'a');
//        java.util.Date date52 = dateTime48.toDate();
//        int int53 = dateTime45.compareTo((org.joda.time.ReadableInstant) dateTime48);
//        int int54 = dateTime45.getYearOfEra();
//        org.joda.time.YearMonthDay yearMonthDay55 = dateTime45.toYearMonthDay();
//        java.lang.String str56 = dateTimeFormatter42.print((org.joda.time.ReadablePartial) yearMonthDay55);
//        int[] intArray58 = gregorianChronology41.get((org.joda.time.ReadablePartial) yearMonthDay55, (long) (byte) -1);
//        java.util.Locale locale60 = null;
//        try {
//            int[] intArray61 = unsupportedDateTimeField16.set((org.joda.time.ReadablePartial) timeOfDay37, 80414, intArray58, "2019069", locale60);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateMidnight27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(timeOfDay37);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateMidnight44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateMidnight49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1970 + "'", int54 == 1970);
//        org.junit.Assert.assertNotNull(yearMonthDay55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "��" + "'", str56.equals("��"));
//        org.junit.Assert.assertNotNull(intArray58);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths(16);
//        java.lang.String str8 = dateTime7.toString();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1968-05-26T00:01:00.000+00:00:02.019" + "'", str8.equals("1968-05-26T00:01:00.000+00:00:02.019"));
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
//        int int17 = dateTime7.get(dateTimeField12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
//        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
//        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
//        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
//        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
//        int int51 = property50.getMinimumValue();
//        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField57);
//        long long60 = remainderDateTimeField58.roundFloor((long) ' ');
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateMidnight47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-2019L) + "'", long60 == (-2019L));
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = offsetDateTimeField6.getAsShortText(963, locale8);
//        boolean boolean11 = offsetDateTimeField6.isLeap((long) 4);
//        boolean boolean12 = offsetDateTimeField6.isSupported();
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField6.getMaximumShortTextLength(locale13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField6.getAsShortText((long) (byte) 10, locale16);
//        int int20 = offsetDateTimeField6.getDifference(1136073597981L, (-139680L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "963" + "'", str9.equals("963"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2022" + "'", str17.equals("2022"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 36 + "'", int20 == 36);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths(16);
//        long long8 = dateTime5.getMillis();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-8380742019L) + "'", long8 == (-8380742019L));
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.getName();
        try {
            long long19 = unsupportedDateTimeField16.roundCeiling(2177481600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "minuteOfDay" + "'", str17.equals("minuteOfDay"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology8.getZone();
        java.lang.String str11 = zonedChronology8.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeFormatter12);
        try {
            long long18 = zonedChronology8.getDateTimeMillis(1, 729, 16, 729);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 729 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]" + "'", str11.equals("ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        java.lang.String str6 = property4.getAsShortText();
//        java.lang.Class<?> wildcardClass7 = property4.getClass();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.getName();
        try {
            long long20 = unsupportedDateTimeField16.add((long) 36, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "minuteOfDay" + "'", str17.equals("minuteOfDay"));
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime11.year();
//        org.joda.time.DateTime dateTime16 = dateTime11.withWeekOfWeekyear((int) ' ');
//        boolean boolean17 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime16.withDurationAdded(readableDuration18, (int) (byte) -1);
//        int int21 = dateTime16.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        boolean boolean6 = dateTime5.isEqualNow();
        boolean boolean7 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readablePeriod9);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0", 10);
        boolean boolean15 = dateTime10.equals((java.lang.Object) dateTimeZoneBuilder11);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder11.setStandardOffset((-56));
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(59);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter5.getZone();
//        java.lang.String str7 = dateTime3.toString(dateTimeFormatter5);
//        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths(18);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969269" + "'", str7.equals("1969269"));
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight3 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
        boolean boolean8 = dateTime7.isEqualNow();
        boolean boolean9 = dateTime7.isEqualNow();
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
//        boolean boolean6 = dateTime5.isEqualNow();
//        boolean boolean7 = dateTime5.isEqualNow();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        java.lang.String str9 = dateTime5.toString(dateTimeFormatter8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
//        org.joda.time.DurationField durationField13 = gregorianChronology10.seconds();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology10.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) '4');
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField16.getMaximumTextLength(locale17);
//        boolean boolean20 = offsetDateTimeField16.isLeap((long) ' ');
//        long long23 = offsetDateTimeField16.set((long) 264, (-1));
//        org.joda.time.DurationField durationField24 = offsetDateTimeField16.getLeapDurationField();
//        boolean boolean25 = dateTime5.equals((java.lang.Object) offsetDateTimeField16);
//        long long27 = offsetDateTimeField16.roundHalfEven((long) 25);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        java.util.Locale locale29 = null;
//        try {
//            java.lang.String str30 = offsetDateTimeField16.getAsShortText(readablePartial28, locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-W39-5T00:00:02+00:00:02.019" + "'", str9.equals("1969-W39-5T00:00:02+00:00:02.019"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-63839750399736L) + "'", long23 == (-63839750399736L));
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2019L) + "'", long27 == (-2019L));
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.secondOfMinute();
        try {
            long long16 = zonedChronology8.getDateTimeMillis(5044L, 53, 836, (int) (short) -1, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
        try {
            long long20 = unsupportedDateTimeField16.getDifferenceAsLong((long) 2021, (-6057L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime11.year();
//        org.joda.time.DateTime dateTime16 = dateTime11.withWeekOfWeekyear((int) ' ');
//        boolean boolean17 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        java.lang.Class<?> wildcardClass18 = dateTime2.getClass();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) 4);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number2, (java.lang.Number) 100.0f);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 0 + "'", number6.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0"));
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(28);
        org.joda.time.Chronology chronology5 = iSOChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.util.Locale locale19 = null;
        try {
            long long20 = unsupportedDateTimeField16.set(0L, "", locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withLocale(locale10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter11.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        long long20 = cachedDateTimeZone17.previousTransition(2019L);
        org.joda.time.DateTime dateTime21 = dateTime8.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("UTC");
        java.lang.String str4 = jodaTimePermission3.toString();
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("UTC");
        boolean boolean9 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission8);
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean12 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission11);
        org.joda.time.JodaTimePermission jodaTimePermission14 = new org.joda.time.JodaTimePermission("2019-03-10T15:19:30.351-07:00");
        boolean boolean15 = jodaTimePermission11.implies((java.security.Permission) jodaTimePermission14);
        boolean boolean16 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission11);
        java.lang.String str17 = jodaTimePermission3.getActions();
        boolean boolean18 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"UTC\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"UTC\")"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property4 = dateTime3.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        java.util.Locale locale7 = null;
//        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
//        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
//        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
//        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
//        long long20 = offsetDateTimeField6.roundHalfEven((long) 946);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField6.getAsText((long) 35, locale22);
//        long long25 = offsetDateTimeField6.roundHalfFloor(0L);
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        java.util.Locale locale27 = null;
//        try {
//            java.lang.String str28 = offsetDateTimeField6.getAsShortText(readablePartial26, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2019L) + "'", long20 == (-2019L));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2022" + "'", str23.equals("2022"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2019L) + "'", long25 == (-2019L));
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight18 = dateTime17.toDateMidnight();
        org.joda.time.DateTime dateTime20 = dateTime17.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime22.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property25 = dateTime24.weekOfWeekyear();
        org.joda.time.DateTime dateTime26 = property25.roundFloorCopy();
        org.joda.time.DateTime dateTime28 = dateTime26.plusMinutes(573);
        org.joda.time.DateTime dateTime30 = dateTime28.plusDays(0);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        try {
            int int32 = unsupportedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        java.util.Locale locale7 = null;
//        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
//        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
//        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
//        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
//        long long20 = offsetDateTimeField6.roundHalfEven((long) 946);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField6.getAsText((long) 35, locale22);
//        int int25 = offsetDateTimeField6.getMinimumValue((long) (-100));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2019L) + "'", long20 == (-2019L));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2022" + "'", str23.equals("2022"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275002) + "'", int25 == (-292275002));
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.getName();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField16.getAsShortText(0L, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "minuteOfDay" + "'", str17.equals("minuteOfDay"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.util.Locale locale17 = null;
        try {
            int int18 = unsupportedDateTimeField16.getMaximumShortTextLength(locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("UTC");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("2019-03-10T15:19:30.351-07:00");
        boolean boolean10 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission9);
        java.lang.Class<?> wildcardClass11 = jodaTimePermission9.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.days();
        org.joda.time.DurationField durationField7 = gregorianChronology5.halfdays();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology5);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(19, 57, 264, 2000, 2000, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str10 = cachedDateTimeZone7.getName((long) '#');
        java.lang.String str12 = cachedDateTimeZone7.getShortName(62135590802518L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:02.019" + "'", str10.equals("+00:00:02.019"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:02.019" + "'", str12.equals("+00:00:02.019"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.util.Locale locale19 = null;
        try {
            long long20 = unsupportedDateTimeField16.set((long) (byte) -1, "1969269", locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        java.lang.String str6 = property4.getAsShortText();
//        boolean boolean7 = property4.isLeap();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        boolean boolean11 = dateTime8.isAfter(100L);
//        boolean boolean12 = dateTime8.isAfterNow();
//        long long13 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
//        java.util.Date date14 = dateTime8.toDate();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-139680L) + "'", long13 == (-139680L));
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        java.lang.String str10 = zonedChronology8.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField13, (int) (byte) 10, 4, (int) (byte) 10);
        boolean boolean18 = zonedChronology8.equals((java.lang.Object) (byte) 10);
        java.lang.String str19 = zonedChronology8.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]" + "'", str10.equals("ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]" + "'", str19.equals("ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]"));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        java.util.Locale locale7 = null;
//        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
//        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
//        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
//        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
//        int int19 = offsetDateTimeField6.getOffset();
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology22 = iSOChronology21.withUTC();
//        org.joda.time.Chronology chronology23 = iSOChronology21.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis(28);
//        org.joda.time.Chronology chronology26 = iSOChronology21.withZone(dateTimeZone25);
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology21.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.dayOfWeek();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight33 = dateTime32.toDateMidnight();
//        org.joda.time.DateTime dateTime35 = dateTime32.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime35.toDateTime(dateTimeZone36);
//        org.joda.time.DateTime dateTime39 = dateTime37.minusYears((int) (byte) 1);
//        org.joda.time.DateTime.Property property40 = dateTime37.minuteOfHour();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight42 = dateTime41.toDateMidnight();
//        org.joda.time.DateTime dateTime44 = dateTime41.minusDays((int) 'a');
//        java.util.Date date45 = dateTime41.toDate();
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime37, (org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight48 = dateTime47.toDateMidnight();
//        org.joda.time.DateTime dateTime50 = dateTime47.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime50.toDateTime(dateTimeZone51);
//        org.joda.time.DateTime dateTime54 = dateTime52.minusYears((int) (byte) 1);
//        boolean boolean55 = dateTime37.isAfter((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.DateTime dateTime57 = dateTime54.plusMonths(28);
//        org.joda.time.TimeOfDay timeOfDay58 = dateTime57.toTimeOfDay();
//        int[] intArray60 = iSOChronology31.get((org.joda.time.ReadablePartial) timeOfDay58, (long) ' ');
//        long long62 = gregorianChronology28.set((org.joda.time.ReadablePartial) timeOfDay58, (-139680L));
//        int[] intArray64 = iSOChronology21.get((org.joda.time.ReadablePartial) timeOfDay58, (long) 33);
//        int int65 = offsetDateTimeField6.getMaximumValue(readablePartial20, intArray64);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateMidnight33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateMidnight42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateMidnight48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(timeOfDay58);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-86400000L) + "'", long62 == (-86400000L));
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 292279045 + "'", int65 == 292279045);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number2, (java.lang.Number) 100.0f);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number9 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number9, (java.lang.Number) 100.0f);
        java.lang.Number number14 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number14, (java.lang.Number) 100.0f);
        org.joda.time.DurationFieldType durationFieldType17 = illegalFieldValueException16.getDurationFieldType();
        java.lang.Number number18 = illegalFieldValueException16.getIllegalNumberValue();
        java.lang.String str19 = illegalFieldValueException16.getIllegalStringValue();
        illegalFieldValueException11.addSuppressed((java.lang.Throwable) illegalFieldValueException16);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = illegalFieldValueException16.getDateTimeFieldType();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException16);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) 0 + "'", number18.equals((byte) 0));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(dateTimeFieldType21);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getName(1560637164357L, locale7);
//        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone(dateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:02.019" + "'", str8.equals("+00:00:02.019"));
//        org.junit.Assert.assertNotNull(chronology9);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTimeISO();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(chronology12);
        org.joda.time.DateTime.Property property14 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.toDateTime(dateTimeZone15);
        boolean boolean17 = property8.equals((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime18 = property8.roundCeilingCopy();
        org.joda.time.DateTime dateTime19 = property8.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = fixedDateTimeZone4.getOffset((long) 28);
        long long13 = fixedDateTimeZone4.convertLocalToUTC((long) 292278993, false, 28800000L);
        long long15 = fixedDateTimeZone4.nextTransition((long) 852);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292276974L + "'", long13 == 292276974L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 852L + "'", long15 == 852L);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
//        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
//        int int6 = dateTime5.getMonthOfYear();
//        int int7 = dateTime5.getWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime dateTime6 = dateTime2.plusWeeks(0);
        org.joda.time.DateTime dateTime8 = dateTime6.plusYears(573);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime6.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra(28, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[Coordinated Universal Time]" + "'", str1.equals("ISOChronology[Coordinated Universal Time]"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[Coordinated Universal Time]" + "'", str2.equals("ISOChronology[Coordinated Universal Time]"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(573);
        org.joda.time.DateTime dateTime13 = dateTime11.plusDays(0);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder16.addCutover(963, '#', 39, 0, (int) (short) 100, false, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTimeZoneBuilder16.toDateTimeZone("919", true);
        java.lang.String str28 = dateTimeZone27.toString();
        long long31 = dateTimeZone27.convertLocalToUTC((long) 'a', true);
        org.joda.time.DateTime dateTime32 = dateTime11.withZoneRetainFields(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "919" + "'", str28.equals("919"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 97L + "'", long31 == 97L);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        java.lang.Object obj7 = null;
        boolean boolean8 = property4.equals(obj7);
        org.joda.time.DateTime dateTime10 = property4.addToCopy(19L);
        org.joda.time.DateTime.Property property11 = dateTime10.hourOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("UTC");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("UTC");
        java.lang.String str10 = jodaTimePermission9.toString();
        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean13 = jodaTimePermission9.implies((java.security.Permission) jodaTimePermission12);
        boolean boolean14 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"UTC\")" + "'", str10.equals("(\"org.joda.time.JodaTimePermission\" \"UTC\")"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName(100L, locale2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getName(0L, locale5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfYear();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusMillis(100);
//        boolean boolean15 = cachedDateTimeZone7.equals((java.lang.Object) dateTime14);
//        long long17 = cachedDateTimeZone7.previousTransition((long) 33);
//        boolean boolean19 = cachedDateTimeZone7.isStandardOffset((-62255958427387L));
//        long long21 = cachedDateTimeZone7.nextTransition((long) 52);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 33L + "'", long17 == 33L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        long long9 = offsetDateTimeField6.add((long) 25, (-139740L));
//        long long11 = offsetDateTimeField6.roundHalfCeiling((long) 59);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
//        org.joda.time.DateTime dateTime14 = dateTime12.toDateTimeISO();
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.toDateTime(chronology15);
//        org.joda.time.DateTime.Property property17 = dateTime14.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.toDateTime(dateTimeZone18);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.hourOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField24, (int) (byte) 10, 4, (int) (byte) 10);
//        int int29 = dateTime19.get(dateTimeField24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.hourOfDay();
//        org.joda.time.DurationField durationField33 = gregorianChronology30.seconds();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology30.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) '4');
//        java.util.Locale locale37 = null;
//        int int38 = offsetDateTimeField36.getMaximumTextLength(locale37);
//        boolean boolean40 = offsetDateTimeField36.isLeap((long) ' ');
//        long long42 = offsetDateTimeField36.roundHalfEven((long) 846);
//        int int45 = offsetDateTimeField36.getDifference((long) 25, 101L);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = offsetDateTimeField36.getAsText(2019, locale47);
//        org.joda.time.ReadablePartial readablePartial49 = null;
//        int[] intArray56 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int57 = offsetDateTimeField36.getMaximumValue(readablePartial49, intArray56);
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight59 = dateTime58.toDateMidnight();
//        org.joda.time.DateTime dateTime61 = dateTime58.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property62 = dateTime61.minuteOfDay();
//        int int63 = property62.getMinimumValue();
//        org.joda.time.DateTime dateTime64 = property62.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property62.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField36, dateTimeFieldType65, 2091);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(dateTimeField24, dateTimeFieldType65, 292278993);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType65, 57600000);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4409768476799975L) + "'", long9 == (-4409768476799975L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2019L) + "'", long11 == (-2019L));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2019L) + "'", long42 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019" + "'", str48.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 292279045 + "'", int57 == 292279045);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateMidnight59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = iSOChronology0.add(readablePeriod6, (long) 52, 573);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int16 = fixedDateTimeZone14.getOffsetFromLocal((long) 351);
        org.joda.time.Chronology chronology17 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        java.lang.String str10 = zonedChronology8.toString();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray13 = zonedChronology8.get(readablePeriod11, (long) 53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]" + "'", str10.equals("ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]"));
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
//        int int17 = dateTime7.get(dateTimeField12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
//        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
//        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
//        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
//        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
//        int int51 = property50.getMinimumValue();
//        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
//        int int58 = dividedDateTimeField57.getMinimumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField57);
//        int int62 = dividedDateTimeField57.getDifference(0L, (-33507481225265L));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateMidnight47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(100, (int) (short) 1, 91, 57600, 2091);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, chronology1);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(readableDuration3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury((int) 'a');
//        int int7 = dateTime4.getSecondOfDay();
//        boolean boolean8 = dateTime4.isAfterNow();
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getLeapDurationField();
        try {
            long long19 = unsupportedDateTimeField16.roundFloor((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMonths(18);
        try {
            java.lang.String str9 = dateTime7.toString("T142000-0752");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis(100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int13 = fixedDateTimeZone11.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        long long16 = fixedDateTimeZone11.nextTransition(0L);
        int int18 = fixedDateTimeZone11.getOffsetFromLocal((long) ' ');
        org.joda.time.DateTime dateTime19 = dateTime6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        int int5 = property4.getMinimumValue();
//        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
//        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
//        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight19 = dateTime18.toDateMidnight();
//        org.joda.time.DateTime dateTime20 = dateTime18.toDateTimeISO();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(chronology21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight24 = dateTime23.toDateMidnight();
//        org.joda.time.DateTime dateTime26 = dateTime23.minusDays((int) 'a');
//        java.util.Date date27 = dateTime23.toDate();
//        int int28 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime23);
//        int int29 = dateTime20.getYearOfEra();
//        org.joda.time.YearMonthDay yearMonthDay30 = dateTime20.toYearMonthDay();
//        java.util.Locale locale31 = null;
//        try {
//            java.lang.String str32 = unsupportedDateTimeField16.getAsText((org.joda.time.ReadablePartial) yearMonthDay30, locale31);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateMidnight19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1970 + "'", int29 == 1970);
//        org.junit.Assert.assertNotNull(yearMonthDay30);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
//        org.joda.time.DateTime dateTime4 = dateTime1.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(dateTimeZone5);
//        boolean boolean7 = dateTime6.isEqualNow();
//        boolean boolean8 = dateTime6.isEqualNow();
//        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
//        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime9);
//        try {
//            org.joda.time.DateTime dateTime12 = dateTimeFormatter0.parseDateTime("ISOChronology[UTC]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "00" + "'", str10.equals("00"));
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
//        java.lang.String str9 = property8.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "39" + "'", str9.equals("39"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number2, (java.lang.Number) 100.0f);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number8 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 0 + "'", number6.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 0 + "'", number7.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100.0f + "'", number8.equals(100.0f));
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        int int4 = dateTime3.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = gregorianChronology1.withZone(dateTimeZone2);
        long long7 = gregorianChronology1.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField8 = gregorianChronology1.years();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfYear();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis(14, 0, 351, 0, 0, 292279045, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279045 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long13 = offsetDateTimeField6.set((long) 264, (-1));
        org.joda.time.DurationField durationField14 = offsetDateTimeField6.getLeapDurationField();
        long long17 = durationField14.subtract((long) 836, 18);
        org.joda.time.DurationFieldType durationFieldType18 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField20 = new org.joda.time.field.ScaledDurationField(durationField14, durationFieldType18, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-63839750399736L) + "'", long13 == (-63839750399736L));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1555199164L) + "'", long17 == (-1555199164L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 57, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number2, (java.lang.Number) 100.0f);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.String str8 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 0 + "'", number6.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1970001T000000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 28800000L, 289);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(chronology10);
        int int12 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime9.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfDay(57600);
        boolean boolean17 = fixedDateTimeZone4.equals((java.lang.Object) dateTime16);
        int int19 = fixedDateTimeZone4.getOffset((long) (byte) 0);
        long long21 = fixedDateTimeZone4.convertUTCToLocal(0L);
        boolean boolean22 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight24 = dateTime23.toDateMidnight();
        org.joda.time.DateTime dateTime25 = dateTime23.toDateTimeISO();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = dateTime25.toDateTime(chronology26);
        org.joda.time.DateTime.Property property28 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime29 = property28.withMinimumValue();
        org.joda.time.DateTime dateTime31 = dateTime29.withHourOfDay(0);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.minus(readableDuration32);
        boolean boolean34 = fixedDateTimeZone4.equals((java.lang.Object) dateTime33);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateMidnight24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime0.dayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime0.withDurationAdded((-10560L), 289);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        org.joda.time.DateTime dateTime10 = dateTime7.minusWeeks(39);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        boolean boolean6 = dateTime3.isEqual((long) 12);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = unsupportedDateTimeField16.getAsText((-31536000000L), locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0", 10);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("1970001T000000Z", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number2, (java.lang.Number) 100.0f);
        java.lang.Number number7 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number7, (java.lang.Number) 100.0f);
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException9.getDurationFieldType();
        java.lang.Number number11 = illegalFieldValueException9.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException9.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = illegalFieldValueException9.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray15 = illegalFieldValueException9.getSuppressed();
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long13 = offsetDateTimeField6.set((long) 264, (-1));
        org.joda.time.DurationField durationField14 = offsetDateTimeField6.getLeapDurationField();
        try {
            long long17 = offsetDateTimeField6.add((long) 289, 292279045);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292281015 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-63839750399736L) + "'", long13 == (-63839750399736L));
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
        int int19 = offsetDateTimeField6.getOffset();
        java.lang.String str20 = offsetDateTimeField6.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[year]" + "'", str20.equals("DateTimeField[year]"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = gregorianChronology1.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology5);
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "T142004-0752", 24);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25) + "'", int10 == (-25));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime12 = dateTime2.withTime((-292275002), (-1), (int) (byte) 0, 14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275002 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime(dateTimeZone4);
//        int int6 = mutableDateTime5.getMonthOfYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        java.util.Locale locale7 = null;
//        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
//        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
//        long long13 = offsetDateTimeField6.set((long) 264, (-1));
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology17 = iSOChronology16.withUTC();
//        org.joda.time.Chronology chronology18 = iSOChronology16.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis(28);
//        org.joda.time.Chronology chronology21 = iSOChronology16.withZone(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology16.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfWeek();
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight28 = dateTime27.toDateMidnight();
//        org.joda.time.DateTime dateTime30 = dateTime27.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime30.toDateTime(dateTimeZone31);
//        org.joda.time.DateTime dateTime34 = dateTime32.minusYears((int) (byte) 1);
//        org.joda.time.DateTime.Property property35 = dateTime32.minuteOfHour();
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight37 = dateTime36.toDateMidnight();
//        org.joda.time.DateTime dateTime39 = dateTime36.minusDays((int) 'a');
//        java.util.Date date40 = dateTime36.toDate();
//        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime32, (org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight43 = dateTime42.toDateMidnight();
//        org.joda.time.DateTime dateTime45 = dateTime42.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.DateTime dateTime47 = dateTime45.toDateTime(dateTimeZone46);
//        org.joda.time.DateTime dateTime49 = dateTime47.minusYears((int) (byte) 1);
//        boolean boolean50 = dateTime32.isAfter((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.DateTime dateTime52 = dateTime49.plusMonths(28);
//        org.joda.time.TimeOfDay timeOfDay53 = dateTime52.toTimeOfDay();
//        int[] intArray55 = iSOChronology26.get((org.joda.time.ReadablePartial) timeOfDay53, (long) ' ');
//        long long57 = gregorianChronology23.set((org.joda.time.ReadablePartial) timeOfDay53, (-139680L));
//        int[] intArray59 = iSOChronology16.get((org.joda.time.ReadablePartial) timeOfDay53, (long) 33);
//        java.util.Locale locale61 = null;
//        try {
//            int[] intArray62 = offsetDateTimeField6.set(readablePartial14, 52, intArray59, "", locale61);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for year is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-63839750399736L) + "'", long13 == (-63839750399736L));
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateMidnight28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateMidnight37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateMidnight43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(timeOfDay53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-86400000L) + "'", long57 == (-86400000L));
//        org.junit.Assert.assertNotNull(intArray59);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField6.getAsShortText(963, locale8);
        long long11 = offsetDateTimeField6.remainder((long) (short) -1);
        long long14 = offsetDateTimeField6.add(101L, (long) '#');
        long long17 = offsetDateTimeField6.getDifferenceAsLong(5044L, (long) 292279045);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "963" + "'", str9.equals("963"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2018L + "'", long11 == 2018L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1104537600101L + "'", long14 == 1104537600101L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(846, 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray26 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int27 = offsetDateTimeField6.getMaximumValue(readablePartial19, intArray26);
        long long29 = offsetDateTimeField6.roundHalfFloor(2177452799999L);
        boolean boolean31 = offsetDateTimeField6.isLeap((long) 56);
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField6.getAsShortText(2048L, locale33);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 292279045 + "'", int27 == 292279045);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2177452797981L + "'", long29 == 2177452797981L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2022" + "'", str34.equals("2022"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(2019L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology0.years();
        long long7 = durationField4.subtract((-63839750401755L), (long) 2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-63902822401755L) + "'", long7 == (-63902822401755L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter3);
        java.lang.String str5 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[Coordinated Universal Time]" + "'", str5.equals("ISOChronology[Coordinated Universal Time]"));
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
//        int int8 = dateTime5.getMillisOfSecond();
//        java.lang.String str9 = dateTime5.toString();
//        org.joda.time.DateTime.Property property10 = dateTime5.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 399 + "'", int8 == 399);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-03-10T22:20:40.399+00:00:02.019" + "'", str9.equals("2019-03-10T22:20:40.399+00:00:02.019"));
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumTextLength(locale7);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        boolean boolean6 = dateTime5.isEqualNow();
        boolean boolean7 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readablePeriod9);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0", 10);
        boolean boolean15 = dateTime10.equals((java.lang.Object) dateTimeZoneBuilder11);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder11.setFixedSavings("2019-W10-7T22:20:17+00:00:02.019", 25);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder18);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(963, '#', 39, 0, (int) (short) 100, false, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("919", true);
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "919" + "'", str12.equals("919"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        int int5 = property4.getMinimumValue();
//        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
//        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
//        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str19 = iSOChronology18.toString();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight21 = dateTime20.toDateMidnight();
//        org.joda.time.DateTime dateTime22 = dateTime20.toDateTimeISO();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.toDateTime(chronology23);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight26 = dateTime25.toDateMidnight();
//        org.joda.time.DateTime dateTime28 = dateTime25.minusDays((int) 'a');
//        java.util.Date date29 = dateTime25.toDate();
//        int int30 = dateTime22.compareTo((org.joda.time.ReadableInstant) dateTime25);
//        int int31 = dateTime22.getYearOfEra();
//        org.joda.time.YearMonthDay yearMonthDay32 = dateTime22.toYearMonthDay();
//        int[] intArray34 = iSOChronology18.get((org.joda.time.ReadablePartial) yearMonthDay32, (long) 52);
//        try {
//            int int35 = unsupportedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay32);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[Coordinated Universal Time]" + "'", str19.equals("ISOChronology[Coordinated Universal Time]"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateMidnight26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(yearMonthDay32);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField6.getMaximumValue(readablePartial7);
        java.lang.String str9 = offsetDateTimeField6.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292279045 + "'", int8 == 292279045);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[year]" + "'", str9.equals("DateTimeField[year]"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long13 = offsetDateTimeField6.set(1552256374735L, "960");
        long long15 = offsetDateTimeField6.roundHalfEven((long) '#');
        long long17 = offsetDateTimeField6.roundHalfEven((long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField6.getType();
        org.joda.time.DurationField durationField19 = offsetDateTimeField6.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-33507481225265L) + "'", long13 == (-33507481225265L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2019L) + "'", long15 == (-2019L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2019L) + "'", long17 == (-2019L));
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.getName();
        try {
            int int18 = unsupportedDateTimeField16.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "minuteOfDay" + "'", str17.equals("minuteOfDay"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getLeapDurationField();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight19 = dateTime18.toDateMidnight();
        org.joda.time.DateTime dateTime21 = dateTime18.minusDays((int) 'a');
        org.joda.time.DateTime.Property property22 = dateTime21.minuteOfDay();
        org.joda.time.DateTime dateTime23 = property22.roundCeilingCopy();
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfSecond();
        java.lang.Class<?> wildcardClass25 = dateTime23.getClass();
        org.joda.time.LocalTime localTime26 = dateTime23.toLocalTime();
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = unsupportedDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localTime26, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateMidnight19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(localTime26);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.DateTime dateTime8 = dateTime3.withWeekOfWeekyear((int) ' ');
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withDayOfWeek((-292275002));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275002 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long3 = dateTimeZone1.convertUTCToLocal((long) 22);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2041L + "'", long3 == 2041L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 351);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 351 + "'", int1 == 351);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        java.util.Locale locale7 = null;
//        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
//        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
//        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
//        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        int[] intArray26 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int27 = offsetDateTimeField6.getMaximumValue(readablePartial19, intArray26);
//        long long29 = offsetDateTimeField6.roundHalfFloor((long) 946);
//        long long31 = offsetDateTimeField6.roundHalfCeiling((long) 573);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.dayOfWeek();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight37 = dateTime36.toDateMidnight();
//        org.joda.time.DateTime dateTime39 = dateTime36.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = dateTime39.toDateTime(dateTimeZone40);
//        org.joda.time.DateTime dateTime43 = dateTime41.minusYears((int) (byte) 1);
//        org.joda.time.DateTime.Property property44 = dateTime41.minuteOfHour();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight46 = dateTime45.toDateMidnight();
//        org.joda.time.DateTime dateTime48 = dateTime45.minusDays((int) 'a');
//        java.util.Date date49 = dateTime45.toDate();
//        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime41, (org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight52 = dateTime51.toDateMidnight();
//        org.joda.time.DateTime dateTime54 = dateTime51.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTime dateTime56 = dateTime54.toDateTime(dateTimeZone55);
//        org.joda.time.DateTime dateTime58 = dateTime56.minusYears((int) (byte) 1);
//        boolean boolean59 = dateTime41.isAfter((org.joda.time.ReadableInstant) dateTime58);
//        org.joda.time.DateTime dateTime61 = dateTime58.plusMonths(28);
//        org.joda.time.TimeOfDay timeOfDay62 = dateTime61.toTimeOfDay();
//        int[] intArray64 = iSOChronology35.get((org.joda.time.ReadablePartial) timeOfDay62, (long) ' ');
//        long long66 = gregorianChronology32.set((org.joda.time.ReadablePartial) timeOfDay62, (-139680L));
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) timeOfDay62, 729, locale68);
//        java.lang.String str71 = offsetDateTimeField6.getAsShortText((long) 2019);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 292279045 + "'", int27 == 292279045);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2019L) + "'", long29 == (-2019L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2019L) + "'", long31 == (-2019L));
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateMidnight37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateMidnight46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateMidnight52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(timeOfDay62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-5960595L) + "'", long66 == (-5960595L));
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "729" + "'", str69.equals("729"));
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "2022" + "'", str71.equals("2022"));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
        org.joda.time.DateTime dateTime16 = dateTime13.minusDays((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfDay();
        int int18 = property17.getMinimumValue();
        org.joda.time.DateTime dateTime19 = property17.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType20, 846);
        long long24 = remainderDateTimeField22.roundFloor((long) 6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2019L) + "'", long24 == (-2019L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.getName();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField16.getAsText(91, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "minuteOfDay" + "'", str17.equals("minuteOfDay"));
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusMillis(50);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((-56));
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
//        org.joda.time.DateTime dateTime15 = dateTime13.toDateTimeISO();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.toDateTime(chronology16);
//        org.joda.time.DateTime.Property property18 = dateTime15.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime15.toDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight22 = dateTime21.toDateMidnight();
//        org.joda.time.DateTime dateTime24 = dateTime21.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.toDateTime(dateTimeZone25);
//        org.joda.time.DateTime.Property property27 = dateTime24.year();
//        org.joda.time.DateTime dateTime29 = dateTime24.withWeekOfWeekyear((int) ' ');
//        boolean boolean30 = dateTime15.isBefore((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight32 = dateTime31.toDateMidnight();
//        org.joda.time.DateTime dateTime33 = dateTime31.toDateTimeISO();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime33.toDateTime(chronology34);
//        org.joda.time.DateTime.Property property36 = dateTime33.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime33.toDateTime(dateTimeZone37);
//        org.joda.time.ReadableDuration readableDuration39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime38.minus(readableDuration39);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.hourOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField43, (int) (byte) 10, 4, (int) (byte) 10);
//        int int48 = dateTime38.get(dateTimeField43);
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.hourOfDay();
//        org.joda.time.DurationField durationField52 = gregorianChronology49.seconds();
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology49.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, (int) '4');
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField55.getMaximumTextLength(locale56);
//        boolean boolean59 = offsetDateTimeField55.isLeap((long) ' ');
//        long long61 = offsetDateTimeField55.roundHalfEven((long) 846);
//        int int64 = offsetDateTimeField55.getDifference((long) 25, 101L);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = offsetDateTimeField55.getAsText(2019, locale66);
//        org.joda.time.ReadablePartial readablePartial68 = null;
//        int[] intArray75 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int76 = offsetDateTimeField55.getMaximumValue(readablePartial68, intArray75);
//        org.joda.time.DateTime dateTime77 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight78 = dateTime77.toDateMidnight();
//        org.joda.time.DateTime dateTime80 = dateTime77.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property81 = dateTime80.minuteOfDay();
//        int int82 = property81.getMinimumValue();
//        org.joda.time.DateTime dateTime83 = property81.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType84 = property81.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField86 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField55, dateTimeFieldType84, 2091);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField88 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType84, 292278993);
//        int int89 = dateTime29.get(dateTimeFieldType84);
//        org.joda.time.DateTime.Property property90 = dateTime12.property(dateTimeFieldType84);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateMidnight14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateMidnight22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateMidnight32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 22 + "'", int48 == 22);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 9 + "'", int57 == 9);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-2019L) + "'", long61 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2019" + "'", str67.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 292279045 + "'", int76 == 292279045);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(dateMidnight78);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//        org.junit.Assert.assertNotNull(dateTime83);
//        org.junit.Assert.assertNotNull(dateTimeFieldType84);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1340 + "'", int89 == 1340);
//        org.junit.Assert.assertNotNull(property90);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        int int5 = property4.getMinimumValue();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
//        int int8 = property4.compareTo((org.joda.time.ReadableInstant) dateMidnight7);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
//        org.joda.time.DateTime dateTime11 = dateTime9.toDateTimeISO();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(chronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.withYear((int) (byte) 10);
//        long long16 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        java.lang.String str17 = property4.getAsString();
//        java.lang.String str18 = property4.getAsString();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1056491999L + "'", long16 == 1056491999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1340" + "'", str17.equals("1340"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1340" + "'", str18.equals("1340"));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getLeapDurationField();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight19 = dateTime18.toDateMidnight();
        org.joda.time.DateTime dateTime21 = dateTime18.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property26 = dateTime23.minuteOfHour();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight28 = dateTime27.toDateMidnight();
        org.joda.time.DateTime dateTime30 = dateTime27.minusDays((int) 'a');
        java.util.Date date31 = dateTime27.toDate();
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight34 = dateTime33.toDateMidnight();
        org.joda.time.DateTime dateTime36 = dateTime33.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = dateTime36.toDateTime(dateTimeZone37);
        org.joda.time.DateTime dateTime40 = dateTime38.minusYears((int) (byte) 1);
        boolean boolean41 = dateTime23.isAfter((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime43 = dateTime40.plusMonths(28);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime43.toTimeOfDay();
        int[] intArray47 = new int[] { ' ', 39 };
        try {
            int int48 = unsupportedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay44, intArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateMidnight19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateMidnight34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
        java.util.Date date13 = dateTime9.toDate();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime16 = dateTime5.withEra(1);
        org.joda.time.DateTime dateTime17 = dateTime5.withEarlierOffsetAtOverlap();
        try {
            java.lang.String str19 = dateTime5.toString("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property13 = dateTime9.dayOfMonth();
//        int int14 = dateTime9.getSecondOfDay();
//        int int15 = property8.getDifference((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DurationField durationField16 = property8.getDurationField();
//        long long19 = durationField16.subtract(1546726814905L, 0L);
//        org.joda.time.DurationFieldType durationFieldType20 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField21 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 80444 + "'", int14 == 80444);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546726814905L + "'", long19 == 1546726814905L);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight3 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTimeISO();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTime(chronology5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays((int) 'a');
        java.util.Date date11 = dateTime7.toDate();
        int int12 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime7);
        int int13 = dateTime4.getYear();
        org.joda.time.DateTime.Property property14 = dateTime4.dayOfWeek();
        int int15 = dateTime4.getMonthOfYear();
        boolean boolean16 = iSOChronology0.equals((java.lang.Object) int15);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder17.addCutover(963, '#', 39, 0, (int) (short) 100, false, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTimeZoneBuilder17.toDateTimeZone("919", true);
        java.lang.String str29 = dateTimeZone28.toString();
        long long32 = dateTimeZone28.convertLocalToUTC((long) 'a', true);
        java.util.TimeZone timeZone33 = dateTimeZone28.toTimeZone();
        org.joda.time.Chronology chronology34 = iSOChronology0.withZone(dateTimeZone28);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "919" + "'", str29.equals("919"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 97L + "'", long32 == 97L);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 1104537600101L, "��");
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField12 = gregorianChronology11.weeks();
        org.joda.time.DurationField durationField13 = gregorianChronology11.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField13);
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = unsupportedDateTimeField14.getAsShortText((int) (short) -1, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField14);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray26 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int27 = offsetDateTimeField6.getMaximumValue(readablePartial19, intArray26);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight29 = dateTime28.toDateMidnight();
        org.joda.time.DateTime dateTime31 = dateTime28.minusDays((int) 'a');
        org.joda.time.DateTime.Property property32 = dateTime31.minuteOfDay();
        int int33 = property32.getMinimumValue();
        org.joda.time.DateTime dateTime34 = property32.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property32.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType35, 2091);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) (-31536000000L), "-0003-03-09T14:19:55.852-07:52:58");
        java.lang.Number number43 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) 729, (java.lang.Number) 292278993, number43);
        java.lang.Number number45 = illegalFieldValueException44.getLowerBound();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 292279045 + "'", int27 == 292279045);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateMidnight29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 292278993 + "'", number45.equals(292278993));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfDay();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((-139680L), (-100), 2, 80444, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(1340);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property13 = dateTime9.dayOfMonth();
//        int int14 = dateTime9.getSecondOfDay();
//        int int15 = property8.getDifference((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime17 = property8.addWrapFieldToCopy(573);
//        org.joda.time.DateTime.Property property18 = dateTime17.monthOfYear();
//        java.util.Locale locale19 = null;
//        int int20 = property18.getMaximumTextLength(locale19);
//        int int21 = property18.get();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 80445 + "'", int14 == 80445);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        java.lang.String str6 = property4.getAsShortText();
//        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusYears((int) (byte) 1);
//        org.joda.time.DateTime.Property property16 = dateTime13.minuteOfHour();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight18 = dateTime17.toDateMidnight();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusDays((int) 'a');
//        java.util.Date date21 = dateTime17.toDate();
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime24 = dateTime17.minusYears(25);
//        boolean boolean26 = dateTime24.isEqual(1L);
//        java.util.GregorianCalendar gregorianCalendar27 = dateTime24.toGregorianCalendar();
//        int int28 = property4.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime30 = dateTime24.plusMonths(20);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1340" + "'", str6.equals("1340"));
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13008959 + "'", int28 == 13008959);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        boolean boolean10 = dateTime9.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 1970, 729);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
        org.joda.time.DurationField durationField16 = offsetDateTimeField6.getLeapDurationField();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight18 = dateTime17.toDateMidnight();
        org.joda.time.DateTime dateTime20 = dateTime17.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.toDateTime(dateTimeZone21);
        boolean boolean23 = dateTime22.isEqualNow();
        boolean boolean24 = dateTime22.isEqualNow();
        org.joda.time.LocalDateTime localDateTime25 = dateTime22.toLocalDateTime();
        int[] intArray27 = null;
        try {
            int[] intArray29 = offsetDateTimeField6.addWrapPartial((org.joda.time.ReadablePartial) localDateTime25, (int) ' ', intArray27, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(localDateTime25);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 51603312);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2019-W10-7T22:20:09+00:00:02.019");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName(100L, locale2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getName(0L, locale5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone7.getUncachedZone();
//        int int10 = cachedDateTimeZone7.getStandardOffset((-2015L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
//        int int17 = dateTime7.get(dateTimeField12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
//        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
//        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
//        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
//        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
//        int int51 = property50.getMinimumValue();
//        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
//        int int58 = dividedDateTimeField57.getMinimumValue();
//        try {
//            long long61 = dividedDateTimeField57.addWrapField((long) 22, 59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 22 + "'", int17 == 22);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateMidnight47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
//        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property13 = dateTime9.dayOfMonth();
//        int int14 = dateTime9.getSecondOfDay();
//        int int15 = property8.getDifference((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime17 = property8.addWrapFieldToCopy(573);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight19 = dateTime18.toDateMidnight();
//        org.joda.time.DateTime dateTime21 = dateTime18.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
//        org.joda.time.DateTime dateTime25 = dateTime23.minusYears((int) (byte) 1);
//        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime27 = property26.roundFloorCopy();
//        org.joda.time.DateTime dateTime29 = dateTime27.plusMinutes(573);
//        org.joda.time.DateTime dateTime31 = dateTime29.plusDays(0);
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime31.toTimeOfDay();
//        try {
//            int int33 = property8.getDifference((org.joda.time.ReadableInstant) dateTime31);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 40394865917");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 80445 + "'", int14 == 80445);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateMidnight19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(timeOfDay32);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime0.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumShortTextLength(locale7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
        org.joda.time.DateTime dateTime13 = dateTime10.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.minuteOfHour();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight20 = dateTime19.toDateMidnight();
        org.joda.time.DateTime dateTime22 = dateTime19.minusDays((int) 'a');
        java.util.Date date23 = dateTime19.toDate();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime15, (org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight26 = dateTime25.toDateMidnight();
        org.joda.time.DateTime dateTime28 = dateTime25.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime28.toDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.minusYears((int) (byte) 1);
        boolean boolean33 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime35 = dateTime32.plusMonths(28);
        org.joda.time.TimeOfDay timeOfDay36 = dateTime35.toTimeOfDay();
        int[] intArray38 = iSOChronology9.get((org.joda.time.ReadablePartial) timeOfDay36, (long) ' ');
        try {
            int int39 = property4.compareTo((org.joda.time.ReadablePartial) timeOfDay36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateMidnight26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(timeOfDay36);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
        java.util.Date date13 = dateTime9.toDate();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime16 = dateTime5.withEra(1);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        org.joda.time.DateTime dateTime18 = property17.getDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.clockhourOfHalfday();
        long long10 = gregorianChronology0.add((-5997482L), (-31536000000L), 946);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-29833061997482L) + "'", long10 == (-29833061997482L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        java.lang.Object obj7 = null;
        boolean boolean8 = property4.equals(obj7);
        org.joda.time.DateTime dateTime10 = property4.addToCopy(19L);
        org.joda.time.DateTime.Property property11 = dateTime10.hourOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.year();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight3 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime5 = dateTime2.minusDays((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfDay();
        int int7 = property6.getMinimumValue();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        int int10 = property6.compareTo((org.joda.time.ReadableInstant) dateMidnight9);
        java.lang.Class<?> wildcardClass11 = property6.getClass();
        org.joda.time.DateTime dateTime12 = property6.withMaximumValue();
        int int13 = dateTime12.getYearOfEra();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateMidnight3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
//        boolean boolean6 = dateTime5.isEqualNow();
//        boolean boolean7 = dateTime5.isEqualNow();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        java.lang.String str9 = dateTime5.toString(dateTimeFormatter8);
//        org.joda.time.DateTime dateTime11 = dateTime5.withMillisOfSecond((int) '4');
//        org.joda.time.DateTime dateTime12 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime12.minusHours(729);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-W10-7T22:20:46+00:00:02.019" + "'", str9.equals("2019-W10-7T22:20:46+00:00:02.019"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number2, (java.lang.Number) 100.0f);
        java.lang.Number number7 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number7, (java.lang.Number) 100.0f);
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException9.getDurationFieldType();
        java.lang.Number number11 = illegalFieldValueException9.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException9.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        illegalFieldValueException9.prependMessage("24");
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(573);
        org.joda.time.DateTime dateTime13 = dateTime11.plusDays(0);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime13.toTimeOfDay();
        org.joda.time.DateTime.Property property15 = dateTime13.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(property15);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        boolean boolean5 = dateTime2.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(963, '#', 39, 0, (int) (short) 100, false, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("919", true);
        java.lang.String str12 = dateTimeZone11.toString();
        long long15 = dateTimeZone11.convertLocalToUTC((long) 'a', true);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight17 = dateTime16.toDateMidnight();
        org.joda.time.DateTime dateTime19 = dateTime16.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(dateTimeZone20);
        boolean boolean22 = dateTime21.isEqualNow();
        boolean boolean23 = dateTime21.isEqualNow();
        org.joda.time.LocalDateTime localDateTime24 = dateTime21.toLocalDateTime();
        boolean boolean25 = dateTimeZone11.isLocalDateTimeGap(localDateTime24);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "919" + "'", str12.equals("919"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        boolean boolean6 = dateTime5.isEqualNow();
        boolean boolean7 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.plus(readablePeriod9);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0", 10);
        boolean boolean15 = dateTime10.equals((java.lang.Object) dateTimeZoneBuilder11);
        org.joda.time.DateTime dateTime16 = dateTime10.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) 'a');
//        java.util.Date date9 = dateTime5.toDate();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime5);
//        int int11 = dateTime2.getYearOfEra();
//        org.joda.time.YearMonthDay yearMonthDay12 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTime dateTime14 = dateTime2.plusHours(12);
//        org.joda.time.DateTime dateTime15 = dateTime2.withEarlierOffsetAtOverlap();
//        org.joda.time.Chronology chronology16 = dateTime15.getChronology();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(yearMonthDay12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology16);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField6.getAsShortText(963, locale8);
        boolean boolean11 = offsetDateTimeField6.isLeap((long) 4);
        boolean boolean12 = offsetDateTimeField6.isSupported();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField6.getMaximumShortTextLength(locale13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField6.getAsShortText((long) (byte) 10, locale16);
        long long20 = offsetDateTimeField6.set((-33507478047265L), 29);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "963" + "'", str9.equals("963"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2022" + "'", str17.equals("2022"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62887020447265L) + "'", long20 == (-62887020447265L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.DurationField durationField4 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(62135590802518L, (-1056L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62135590801462L + "'", long2 == 62135590801462L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int7 = fixedDateTimeZone5.getOffsetFromLocal((long) 351);
        java.lang.String str9 = fixedDateTimeZone5.getName((long) 3);
        java.lang.String str11 = fixedDateTimeZone5.getNameKey(0L);
        org.joda.time.Chronology chronology12 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DurationField durationField13 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:02.019" + "'", str9.equals("+00:00:02.019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "T151935-0700" + "'", str11.equals("T151935-0700"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray26 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int27 = offsetDateTimeField6.getMaximumValue(readablePartial19, intArray26);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight29 = dateTime28.toDateMidnight();
        org.joda.time.DateTime dateTime31 = dateTime28.minusDays((int) 'a');
        org.joda.time.DateTime.Property property32 = dateTime31.minuteOfDay();
        int int33 = property32.getMinimumValue();
        org.joda.time.DateTime dateTime34 = property32.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property32.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType35, 2091);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) (-31536000000L), "-0003-03-09T14:19:55.852-07:52:58");
        java.lang.Number number43 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) 729, (java.lang.Number) 292278993, number43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) (-100), (java.lang.Number) 35, (java.lang.Number) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 292279045 + "'", int27 == 292279045);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateMidnight29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.getName();
        try {
            boolean boolean19 = unsupportedDateTimeField16.isLeap((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "minuteOfDay" + "'", str17.equals("minuteOfDay"));
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
//        int int17 = dateTime7.get(dateTimeField12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
//        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
//        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
//        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
//        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
//        int int51 = property50.getMinimumValue();
//        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
//        int int58 = dividedDateTimeField57.getMinimumValue();
//        long long60 = dividedDateTimeField57.roundFloor(33L);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 22 + "'", int17 == 22);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateMidnight47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-2019L) + "'", long60 == (-2019L));
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfDay();
        org.joda.time.DurationField durationField9 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) '4');
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField12.getAsShortText(963, locale14);
        long long17 = offsetDateTimeField12.remainder((long) (short) -1);
        long long20 = offsetDateTimeField12.add(101L, (long) '#');
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight22 = dateTime21.toDateMidnight();
        org.joda.time.DateTime dateTime24 = dateTime21.minusDays((int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfDay();
        int int26 = property25.getMinimumValue();
        org.joda.time.DateTime dateTime27 = property25.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType28, 20, (int) (short) -1, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType28, 39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendMonthOfYear(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder34.appendLiteral("T222020+0000");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "963" + "'", str15.equals("963"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2018L + "'", long17 == 2018L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1104537600101L + "'", long20 == 1104537600101L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) 'a');
//        java.util.Date date9 = dateTime5.toDate();
//        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime5);
//        int int11 = dateTime2.getYear();
//        org.joda.time.DateTime dateTime13 = dateTime2.withYearOfEra(3);
//        int int14 = dateTime13.getYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime2.dayOfYear();
        org.joda.time.DateTime.Property property6 = dateTime2.weekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        java.util.Locale locale5 = null;
//        int int6 = property4.getMaximumTextLength(locale5);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property4.getAsText(locale7);
//        org.joda.time.DateTime dateTime10 = property4.addToCopy(0L);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1340" + "'", str8.equals("1340"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) 'a');
        java.util.Date date9 = dateTime5.toDate();
        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime5);
        int int11 = dateTime2.getYear();
        org.joda.time.DateTime.Property property12 = dateTime2.dayOfWeek();
        java.lang.String str13 = property12.toString();
        org.joda.time.DateTime dateTime14 = property12.roundFloorCopy();
        java.util.Locale locale15 = null;
        int int16 = property12.getMaximumShortTextLength(locale15);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[dayOfWeek]" + "'", str13.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfWeek(51594);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "T151934-0700", "19");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "1969-W39-4T16:00:00-07:00", "ISOChronology[America/Los_Angeles]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis(100);
        org.joda.time.DateTime dateTime8 = dateTime6.plus((-1L));
        org.joda.time.DateTime dateTime10 = dateTime6.minusYears(0);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withDayOfMonth(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0", 10);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("2019-W10-7T22:20:17+00:00:02.019", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number2, (java.lang.Number) 100.0f);
        java.lang.Number number7 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) 0, number7, (java.lang.Number) 100.0f);
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException9.getDurationFieldType();
        java.lang.Number number11 = illegalFieldValueException9.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException9.getIllegalStringValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = illegalFieldValueException9.getDateTimeFieldType();
        java.lang.String str15 = illegalFieldValueException9.toString();
        java.lang.Throwable[] throwableArray16 = illegalFieldValueException9.getSuppressed();
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 0 + "'", number11.equals((byte) 0));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0" + "'", str15.equals("org.joda.time.IllegalFieldValueException: Value 0 for  must not be larger than 100.0"));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime4 = property2.roundFloorCopy();
        org.joda.time.DurationField durationField5 = property2.getDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) fixedDateTimeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology13 = iSOChronology12.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter11.withChronology(chronology13);
        org.joda.time.Chronology chronology15 = dateTimeFormatter14.getChronology();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone10, chronology15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        long long7 = gregorianChronology0.add((long) 9, (long) 351, (-56));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-19647L) + "'", long7 == (-19647L));
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName(100L, locale2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getName(0L, locale5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfYear();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusMillis(100);
//        boolean boolean15 = cachedDateTimeZone7.equals((java.lang.Object) dateTime14);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight18 = dateTime17.toDateMidnight();
//        org.joda.time.DateTime dateTime19 = dateTime17.toDateTimeISO();
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime(chronology20);
//        java.lang.String str22 = dateTimeFormatter16.print((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withPivotYear((-1));
//        java.util.Locale locale25 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter16.withLocale(locale25);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter16.withPivotYear((java.lang.Integer) 39);
//        boolean boolean29 = cachedDateTimeZone7.equals((java.lang.Object) dateTimeFormatter28);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter28.withPivotYear((java.lang.Integer) 289);
//        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter28.getPrinter();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "T222048+0000" + "'", str22.equals("T222048+0000"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimePrinter32);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime.Property property7 = dateTime5.minuteOfHour();
//        org.joda.time.DateTime dateTime8 = property7.withMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T222048+0000" + "'", str6.equals("T222048+0000"));
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (long) 91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
//        int int17 = dateTime7.get(dateTimeField12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
//        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
//        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
//        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
//        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
//        int int51 = property50.getMinimumValue();
//        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
//        int int58 = dividedDateTimeField57.getMinimumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField57);
//        long long61 = remainderDateTimeField59.roundFloor((-8380742019L));
//        long long63 = remainderDateTimeField59.roundHalfCeiling((long) 264);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 22 + "'", int17 == 22);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateMidnight47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-8380802019L) + "'", long61 == (-8380802019L));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-2019L) + "'", long63 == (-2019L));
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime0.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumShortTextLength(locale7);
        org.joda.time.Interval interval9 = property4.toInterval();
        org.joda.time.Interval interval10 = property4.toInterval();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(interval10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(292279045);
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter2.parseDateTime("963");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"963\" is malformed at \"3\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField16.getDurationField();
        java.lang.String str19 = unsupportedDateTimeField16.getName();
        try {
            int int21 = unsupportedDateTimeField16.get((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "minuteOfDay" + "'", str19.equals("minuteOfDay"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        java.util.Date date4 = dateTime0.toDate();
        org.joda.time.DateTime.Property property5 = dateTime0.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendFractionOfSecond(35, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType9, (int) '4', 53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
        int int19 = offsetDateTimeField6.getOffset();
        long long22 = offsetDateTimeField6.add((long) 36, (int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 36L + "'", long22 == 36L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long13 = offsetDateTimeField6.set((long) 264, (-1));
        org.joda.time.DurationField durationField14 = offsetDateTimeField6.getLeapDurationField();
        long long16 = offsetDateTimeField6.roundHalfEven(101L);
        org.joda.time.DurationField durationField17 = offsetDateTimeField6.getRangeDurationField();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight19 = dateTime18.toDateMidnight();
        org.joda.time.DateTime dateTime21 = dateTime18.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime23.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime dateTime27 = property26.roundFloorCopy();
        org.joda.time.DateTime dateTime29 = dateTime27.plusMinutes(573);
        org.joda.time.DateTime dateTime31 = dateTime29.plusDays(0);
        org.joda.time.TimeOfDay timeOfDay32 = dateTime31.toTimeOfDay();
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) timeOfDay32, 13008960, locale34);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-63839750399736L) + "'", long13 == (-63839750399736L));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2019L) + "'", long16 == (-2019L));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateMidnight19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(timeOfDay32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13008960" + "'", str35.equals("13008960"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.minutes();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
//        long long9 = offsetDateTimeField6.add((long) 25, (-139740L));
//        long long11 = offsetDateTimeField6.roundHalfCeiling((long) 963);
//        long long13 = offsetDateTimeField6.remainder((long) 29);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
//        boolean boolean17 = dateTime14.isAfter(100L);
//        org.joda.time.YearMonthDay yearMonthDay18 = dateTime14.toYearMonthDay();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology21 = iSOChronology20.withUTC();
//        org.joda.time.Chronology chronology22 = iSOChronology20.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis(28);
//        org.joda.time.Chronology chronology25 = iSOChronology20.withZone(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology20.centuryOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.dayOfWeek();
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight32 = dateTime31.toDateMidnight();
//        org.joda.time.DateTime dateTime34 = dateTime31.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.toDateTime(dateTimeZone35);
//        org.joda.time.DateTime dateTime38 = dateTime36.minusYears((int) (byte) 1);
//        org.joda.time.DateTime.Property property39 = dateTime36.minuteOfHour();
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight41 = dateTime40.toDateMidnight();
//        org.joda.time.DateTime dateTime43 = dateTime40.minusDays((int) 'a');
//        java.util.Date date44 = dateTime40.toDate();
//        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime36, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.DateTime dateTime51 = dateTime49.toDateTime(dateTimeZone50);
//        org.joda.time.DateTime dateTime53 = dateTime51.minusYears((int) (byte) 1);
//        boolean boolean54 = dateTime36.isAfter((org.joda.time.ReadableInstant) dateTime53);
//        org.joda.time.DateTime dateTime56 = dateTime53.plusMonths(28);
//        org.joda.time.TimeOfDay timeOfDay57 = dateTime56.toTimeOfDay();
//        int[] intArray59 = iSOChronology30.get((org.joda.time.ReadablePartial) timeOfDay57, (long) ' ');
//        long long61 = gregorianChronology27.set((org.joda.time.ReadablePartial) timeOfDay57, (-139680L));
//        int[] intArray63 = iSOChronology20.get((org.joda.time.ReadablePartial) timeOfDay57, (long) 33);
//        try {
//            int[] intArray65 = offsetDateTimeField6.addWrapPartial((org.joda.time.ReadablePartial) yearMonthDay18, (-292275002), intArray63, 2000);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -292275002");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4409768476799975L) + "'", long9 == (-4409768476799975L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2019L) + "'", long11 == (-2019L));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2048L + "'", long13 == 2048L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(yearMonthDay18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateMidnight32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateMidnight41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateMidnight47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(timeOfDay57);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-5952892L) + "'", long61 == (-5952892L));
//        org.junit.Assert.assertNotNull(intArray63);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("-0003-W10-7T14:20:00-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-0003-W10-7T14:20:00-07:52:58\" is malformed at \"-W10-7T14:20:00-07:52:58\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = unsupportedDateTimeField16.getType();
        try {
            long long20 = unsupportedDateTimeField16.add((long) 292279045, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(28);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-3), dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis(100);
        org.joda.time.DateTime dateTime8 = dateTime6.plus((-1L));
        org.joda.time.DateTime dateTime10 = dateTime6.withDayOfYear(6);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 12, 846);
        org.joda.time.DateTime dateTime15 = dateTime13.withDayOfWeek((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField16.getAsText(5044L, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfHour(2019, 289);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 399);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer4, 1560637164357L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 1104537600101L, "��");
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField12 = gregorianChronology11.weeks();
        org.joda.time.DurationField durationField13 = gregorianChronology11.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField13);
        try {
            java.lang.String str16 = unsupportedDateTimeField14.getAsText((long) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField14);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(846);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "1969-09-25T16:00:00.019-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek(660);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        boolean boolean6 = dateTime5.isEqualNow();
        boolean boolean7 = dateTime5.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime10 = dateTime8.plusDays(52);
        org.joda.time.DateTime dateTime12 = dateTime10.withCenturyOfEra(1340);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
//        int int17 = dateTime7.get(dateTimeField12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
//        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
//        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
//        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
//        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
//        int int51 = property50.getMinimumValue();
//        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
//        int int58 = dividedDateTimeField57.getMinimumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField57);
//        int int61 = remainderDateTimeField59.get(2177452799999L);
//        int int62 = remainderDateTimeField59.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 22 + "'", int17 == 22);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateMidnight47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfDay();
        int int6 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField16.getAsText(28, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology8.getZone();
        java.lang.String str11 = zonedChronology8.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeFormatter12);
        try {
            long long19 = zonedChronology8.getDateTimeMillis((-63839750399736L), 2091, (int) ' ', 729, 852);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2091 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]" + "'", str11.equals("ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
//        int int17 = dateTime7.get(dateTimeField12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
//        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
//        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
//        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
//        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
//        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
//        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
//        int int51 = property50.getMinimumValue();
//        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
//        int int60 = dividedDateTimeField57.getDifference((long) (short) -1, (long) 292278993);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateMidnight1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 22 + "'", int17 == 22);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateMidnight47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName(100L, locale2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getName(0L, locale5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone7.getUncachedZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = cachedDateTimeZone7.getShortName((-26438399054L), locale11);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long9 = fixedDateTimeZone4.nextTransition(0L);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) ' ');
        int int13 = fixedDateTimeZone4.getOffsetFromLocal((long) (-100));
        int int15 = fixedDateTimeZone4.getOffsetFromLocal((long) 946);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(28);
        org.joda.time.Chronology chronology5 = iSOChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.centuryOfEra();
        org.joda.time.DurationField durationField7 = iSOChronology0.weekyears();
        java.lang.String str8 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[Coordinated Universal Time]" + "'", str8.equals("ISOChronology[Coordinated Universal Time]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-63902822401755L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        long long6 = gregorianChronology0.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField7 = gregorianChronology0.years();
        try {
            long long15 = gregorianChronology0.getDateTimeMillis(0, 946, 1969, 2000, (-292275002), 292279045, 2021);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField16.getDurationField();
        java.lang.String str19 = unsupportedDateTimeField16.getName();
        java.util.Locale locale22 = null;
        try {
            long long23 = unsupportedDateTimeField16.set((-5960595L), "1968-05-26T00:01:00.000+00:00:02.019", locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "minuteOfDay" + "'", str19.equals("minuteOfDay"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getLeapDurationField();
        try {
            long long19 = unsupportedDateTimeField16.roundHalfCeiling((-6373201898163599975L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(573);
        org.joda.time.DateTime dateTime13 = dateTime11.plusDays(0);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime15.getZone();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        java.io.Writer writer4 = null;
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property13 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
        org.joda.time.DateTime dateTime17 = dateTime14.minusDays((int) 'a');
        java.util.Date date18 = dateTime14.toDate();
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight21 = dateTime20.toDateMidnight();
        org.joda.time.DateTime dateTime23 = dateTime20.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.minusYears((int) (byte) 1);
        boolean boolean28 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime30 = dateTime27.plusMonths(28);
        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadablePartial) timeOfDay31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateMidnight21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(timeOfDay31);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((int) 'a');
        long long9 = property6.remainder();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 23241600264L + "'", long9 == 23241600264L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        java.lang.Object obj7 = null;
        boolean boolean8 = property4.equals(obj7);
        org.joda.time.DateTime dateTime10 = property4.addToCopy(19L);
        org.joda.time.DateTime dateTime11 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
        org.joda.time.DateTime dateTime15 = dateTime12.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.toDateTime(dateTimeZone16);
        boolean boolean18 = dateTime17.isEqualNow();
        boolean boolean19 = dateTime17.isEqualNow();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.String str21 = dateTime17.toString(dateTimeFormatter20);
        org.joda.time.DateTime dateTime23 = dateTime17.withMillisOfSecond((int) '4');
        org.joda.time.DateTime dateTime24 = dateTime17.withTimeAtStartOfDay();
        int int25 = property4.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-0056-W39-2T00:00:00+00:00:02.019" + "'", str21.equals("-0056-W39-2T00:00:00+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology(chronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = gregorianChronology4.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        boolean boolean6 = dateTime5.isEqualNow();
        boolean boolean7 = dateTime5.isEqualNow();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.String str9 = dateTime5.toString(dateTimeFormatter8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.DurationField durationField13 = gregorianChronology10.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology10.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) '4');
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField16.getMaximumTextLength(locale17);
        boolean boolean20 = offsetDateTimeField16.isLeap((long) ' ');
        long long23 = offsetDateTimeField16.set((long) 264, (-1));
        org.joda.time.DurationField durationField24 = offsetDateTimeField16.getLeapDurationField();
        boolean boolean25 = dateTime5.equals((java.lang.Object) offsetDateTimeField16);
        int int27 = offsetDateTimeField16.get((long) (byte) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.hourOfDay();
        org.joda.time.DurationField durationField31 = gregorianChronology28.seconds();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology28.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) '4');
        java.util.Locale locale35 = null;
        int int36 = offsetDateTimeField34.getMaximumTextLength(locale35);
        boolean boolean38 = offsetDateTimeField34.isLeap((long) ' ');
        long long41 = offsetDateTimeField34.set((long) 264, (-1));
        org.joda.time.DurationField durationField42 = offsetDateTimeField34.getLeapDurationField();
        long long44 = offsetDateTimeField34.roundHalfEven(101L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
        org.joda.time.DateTime dateTime48 = dateTime46.toDateTimeISO();
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.DateTime dateTime50 = dateTime48.toDateTime(chronology49);
        java.lang.String str51 = dateTimeFormatter45.print((org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter45.withPivotYear((-1));
        java.util.Locale locale54 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = dateTimeFormatter45.withLocale(locale54);
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(0L, chronology57);
        org.joda.time.ReadableDuration readableDuration59 = null;
        org.joda.time.DateTime dateTime60 = dateTime58.plus(readableDuration59);
        org.joda.time.DateTime dateTime62 = dateTime60.withYearOfCentury((int) 'a');
        org.joda.time.YearMonthDay yearMonthDay63 = dateTime62.toYearMonthDay();
        java.lang.String str64 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) yearMonthDay63);
        int int65 = offsetDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay63);
        int[] intArray67 = null;
        try {
            int[] intArray69 = offsetDateTimeField16.addWrapPartial((org.joda.time.ReadablePartial) yearMonthDay63, 14, intArray67, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0056-W39-2T00:00:00+00:00:02.019" + "'", str9.equals("-0056-W39-2T00:00:00+00:00:02.019"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-63839750399736L) + "'", long23 == (-63839750399736L));
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2022 + "'", int27 == 2022);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 9 + "'", int36 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-63839750399736L) + "'", long41 == (-63839750399736L));
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-2019L) + "'", long44 == (-2019L));
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateMidnight47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T000000+0000" + "'", str51.equals("T000000+0000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(yearMonthDay63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "T������" + "'", str64.equals("T������"));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 292279045 + "'", int65 == 292279045);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField16.getDurationField();
        java.lang.String str19 = unsupportedDateTimeField16.getName();
        try {
            boolean boolean21 = unsupportedDateTimeField16.isLeap(1104537600101L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "minuteOfDay" + "'", str19.equals("minuteOfDay"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property16 = dateTime13.minuteOfHour();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight18 = dateTime17.toDateMidnight();
        org.joda.time.DateTime dateTime20 = dateTime17.minusDays((int) 'a');
        java.util.Date date21 = dateTime17.toDate();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight24 = dateTime23.toDateMidnight();
        org.joda.time.DateTime dateTime26 = dateTime23.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.toDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime28.minusYears((int) (byte) 1);
        boolean boolean31 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime33 = dateTime30.plusMonths(28);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        int[] intArray36 = iSOChronology7.get((org.joda.time.ReadablePartial) timeOfDay34, (long) ' ');
        int[] intArray38 = gregorianChronology0.get((org.joda.time.ReadablePartial) timeOfDay34, (-5997482L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateMidnight24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.yearOfEra();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(0, (int) 'a', 80445, (int) (byte) 100, 80440, 57600, 264);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(dateTimeZone11);
        boolean boolean13 = dateTime12.isEqualNow();
        boolean boolean14 = dateTime12.isEqualNow();
        int int15 = property6.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.Interval interval16 = property6.toInterval();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(interval16);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
        int int17 = dateTime7.get(dateTimeField12);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
        java.util.Locale locale25 = null;
        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
        int int51 = property50.getMinimumValue();
        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
        long long60 = dividedDateTimeField57.add((long) 25, (-6057L));
        int int63 = dividedDateTimeField57.getDifference(0L, (long) 0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateMidnight47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-6373201898163599975L) + "'", long60 == (-6373201898163599975L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) 100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfYear(22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019069");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime0.dayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime0.withDurationAdded((-10560L), 289);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(963, '#', 39, 0, (int) (short) 100, false, (int) (byte) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(0, 'a', 57600, 573, (int) (byte) -1, true, 946);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfDay();
        org.joda.time.DurationField durationField9 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) '4');
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField12.getAsShortText(963, locale14);
        long long17 = offsetDateTimeField12.remainder((long) (short) -1);
        long long20 = offsetDateTimeField12.add(101L, (long) '#');
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight22 = dateTime21.toDateMidnight();
        org.joda.time.DateTime dateTime24 = dateTime21.minusDays((int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfDay();
        int int26 = property25.getMinimumValue();
        org.joda.time.DateTime dateTime27 = property25.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType28, 20, (int) (short) -1, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType28, 39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendYearOfEra(0, 729);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendClockhourOfDay(264);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "963" + "'", str15.equals("963"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2018L + "'", long17 == 2018L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1104537600101L + "'", long20 == 1104537600101L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendFractionOfHour(660, 846);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendTimeZoneOffset("T222017+0000", true, 80444, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField6.getAsShortText(963, locale8);
        long long11 = offsetDateTimeField6.remainder((long) (short) -1);
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.hourOfDay();
        org.joda.time.DurationField durationField16 = gregorianChronology13.seconds();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) '4');
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField19.getMaximumTextLength(locale20);
        boolean boolean23 = offsetDateTimeField19.isLeap((long) ' ');
        long long25 = offsetDateTimeField19.roundHalfEven((long) 846);
        int int28 = offsetDateTimeField19.getDifference((long) 25, 101L);
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField19.getAsText(2019, locale30);
        org.joda.time.ReadablePartial readablePartial32 = null;
        int[] intArray39 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int40 = offsetDateTimeField19.getMaximumValue(readablePartial32, intArray39);
        int int41 = offsetDateTimeField6.getMinimumValue(readablePartial12, intArray39);
        int int42 = offsetDateTimeField6.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "963" + "'", str9.equals("963"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2018L + "'", long11 == 2018L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2019L) + "'", long25 == (-2019L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 292279045 + "'", int40 == 292279045);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-292275002) + "'", int41 == (-292275002));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 292279045 + "'", int42 == 292279045);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneShortName(strMap12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfHour(0);
        boolean boolean16 = zonedChronology8.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long7 = cachedDateTimeZone5.nextTransition(0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property4.getDifferenceAsLong(readableInstant6);
        try {
            org.joda.time.DateTime dateTime9 = property4.setCopy("T������");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T������\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(59, 39);
        long long9 = dateTimeZone7.convertUTCToLocal(292276974L);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, 80445, 1970, 0, 13008960, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 13008960 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 507016974L + "'", long9 == 507016974L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DurationField durationField9 = property8.getRangeDurationField();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTimeISO();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.toDateTime(chronology13);
        int int15 = dateTime12.getSecondOfMinute();
        org.joda.time.DateTime.Property property16 = dateTime12.dayOfWeek();
        int int17 = property8.compareTo((org.joda.time.ReadableInstant) dateTime12);
        int int18 = dateTime12.getMillisOfSecond();
        org.joda.time.DateTime dateTime20 = dateTime12.withMillisOfDay(13008959);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 264 + "'", int18 == 264);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int7 = fixedDateTimeZone5.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTimeISO();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(chronology11);
        int int13 = dateTime10.getSecondOfMinute();
        org.joda.time.DateTime dateTime15 = dateTime10.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay(57600);
        boolean boolean18 = fixedDateTimeZone5.equals((java.lang.Object) dateTime17);
        int int20 = fixedDateTimeZone5.getOffset((long) (byte) 0);
        long long22 = fixedDateTimeZone5.convertUTCToLocal(0L);
        boolean boolean23 = fixedDateTimeZone5.isFixed();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 264, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField6.getAsShortText(963, locale8);
        long long11 = offsetDateTimeField6.remainder((long) (short) -1);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        int int14 = offsetDateTimeField6.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "963" + "'", str9.equals("963"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2018L + "'", long11 == 2018L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275002) + "'", int14 == (-292275002));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfDay();
        org.joda.time.DurationField durationField9 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) '4');
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField12.getAsShortText(963, locale14);
        long long17 = offsetDateTimeField12.remainder((long) (short) -1);
        long long20 = offsetDateTimeField12.add(101L, (long) '#');
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight22 = dateTime21.toDateMidnight();
        org.joda.time.DateTime dateTime24 = dateTime21.minusDays((int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfDay();
        int int26 = property25.getMinimumValue();
        org.joda.time.DateTime dateTime27 = property25.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType28, 20, (int) (short) -1, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType28, 39);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray35 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType28 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList36 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList36, dateTimeFieldTypeArray35);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList36, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No valid format for fields: [minuteOfDay]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "963" + "'", str15.equals("963"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2018L + "'", long17 == 2018L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1104537600101L + "'", long20 == 1104537600101L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long13 = offsetDateTimeField6.set(1552256374735L, "960");
        long long15 = offsetDateTimeField6.roundHalfEven((long) '#');
        long long17 = offsetDateTimeField6.roundHalfEven((long) (byte) -1);
        int int19 = offsetDateTimeField6.getMinimumValue((long) (-100));
        try {
            long long22 = offsetDateTimeField6.set((long) 17, "minuteOfDay");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"minuteOfDay\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-33507481225265L) + "'", long13 == (-33507481225265L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2019L) + "'", long15 == (-2019L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2019L) + "'", long17 == (-2019L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-292275002) + "'", int19 == (-292275002));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = unsupportedDateTimeField16.getType();
        try {
            int int19 = unsupportedDateTimeField16.get((-63839750399736L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DurationField durationField9 = property8.getRangeDurationField();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTimeISO();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.toDateTime(chronology13);
        int int15 = dateTime12.getSecondOfMinute();
        org.joda.time.DateTime.Property property16 = dateTime12.dayOfWeek();
        int int17 = property8.compareTo((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime18 = property8.getDateTime();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight20 = dateTime19.toDateMidnight();
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTimeISO();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTime(chronology22);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight25 = dateTime24.toDateMidnight();
        org.joda.time.DateTime dateTime27 = dateTime24.minusDays((int) 'a');
        java.util.Date date28 = dateTime24.toDate();
        int int29 = dateTime21.compareTo((org.joda.time.ReadableInstant) dateTime24);
        int int30 = dateTime21.getYear();
        org.joda.time.DateTime.Property property31 = dateTime21.dayOfWeek();
        int int32 = dateTime21.getMonthOfYear();
        boolean boolean33 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property34 = dateTime18.era();
        org.joda.time.DateTime.Property property35 = dateTime18.secondOfDay();
        org.joda.time.DateTime dateTime37 = property35.addWrapFieldToCopy(2091);
        org.joda.time.DateTime dateTime38 = property35.roundCeilingCopy();
        org.joda.time.DateTime.Property property39 = dateTime38.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateMidnight25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-55) + "'", int30 == (-55));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitYear(0, false);
        dateTimeFormatterBuilder4.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral('a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        int int5 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime dateTime7 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTime.Property property8 = dateTime2.monthOfYear();
        int int9 = property8.get();
        org.joda.time.DateTime dateTime10 = property8.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readableDuration3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusDays((int) (byte) 0);
        org.joda.time.DateTime dateTime7 = dateTime6.withEarlierOffsetAtOverlap();
        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
        int int17 = dateTime7.get(dateTimeField12);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
        java.util.Locale locale25 = null;
        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
        int int51 = property50.getMinimumValue();
        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
        int int58 = dividedDateTimeField57.getMinimumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder60.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap62 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder60.appendTimeZoneShortName(strMap62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder60.appendClockhourOfHalfday((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology66.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology66.hourOfDay();
        org.joda.time.DurationField durationField69 = gregorianChronology66.seconds();
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology66.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField(dateTimeField70, (int) '4');
        java.util.Locale locale74 = null;
        java.lang.String str75 = offsetDateTimeField72.getAsShortText(963, locale74);
        long long77 = offsetDateTimeField72.remainder((long) (short) -1);
        long long80 = offsetDateTimeField72.add(101L, (long) '#');
        org.joda.time.DateTime dateTime81 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight82 = dateTime81.toDateMidnight();
        org.joda.time.DateTime dateTime84 = dateTime81.minusDays((int) 'a');
        org.joda.time.DateTime.Property property85 = dateTime84.minuteOfDay();
        int int86 = property85.getMinimumValue();
        org.joda.time.DateTime dateTime87 = property85.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType88 = property85.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField92 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField72, dateTimeFieldType88, 20, (int) (short) -1, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder94 = dateTimeFormatterBuilder60.appendFixedSignedDecimal(dateTimeFieldType88, 39);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField95 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField59, dateTimeFieldType88);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateMidnight47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(gregorianChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "963" + "'", str75.equals("963"));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 2018L + "'", long77 == 2018L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1104537600101L + "'", long80 == 1104537600101L);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(dateMidnight82);
        org.junit.Assert.assertNotNull(dateTime84);
        org.junit.Assert.assertNotNull(property85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(dateTimeFieldType88);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder94);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("2019-W10-7T22:20:19+00:00:02.019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W10-7T22:20:19+00:00:02.019\" is malformed at \"-W10-7T22:20:19+00:00:02.019\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        int int5 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime.Property property6 = dateTime2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        int int8 = property6.getLeapAmount();
        org.joda.time.DateTime dateTime9 = property6.roundFloorCopy();
        org.joda.time.DateTime dateTime10 = property6.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime0.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumShortTextLength(locale7);
        org.joda.time.Interval interval9 = property4.toInterval();
        org.joda.time.DurationField durationField10 = property4.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendTimeZoneName(strMap3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.minuteOfDay();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
        org.joda.time.DateTime.Property property13 = dateTime12.minuteOfDay();
        int int14 = property13.getMinimumValue();
        org.joda.time.DateTime dateTime15 = property13.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 1104537600101L, "��");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType16, (-3));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder1.appendFixedDecimal(dateTimeFieldType16, 20);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019", number1, (java.lang.Number) (-33507478047265L), (java.lang.Number) (-1L));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean6 = cachedDateTimeZone5.isFixed();
        java.util.Locale locale8 = null;
        java.lang.String str9 = cachedDateTimeZone5.getShortName((long) 57600, locale8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:02.019" + "'", str9.equals("+00:00:02.019"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(2091, 292279045, (int) (byte) 1, 2, (-55), 10, (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -55 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("UTC");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("UTC");
        java.lang.String str7 = jodaTimePermission6.toString();
        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("UTC");
        boolean boolean12 = jodaTimePermission9.implies((java.security.Permission) jodaTimePermission11);
        org.joda.time.JodaTimePermission jodaTimePermission14 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean15 = jodaTimePermission9.implies((java.security.Permission) jodaTimePermission14);
        org.joda.time.JodaTimePermission jodaTimePermission17 = new org.joda.time.JodaTimePermission("2019-03-10T15:19:30.351-07:00");
        boolean boolean18 = jodaTimePermission14.implies((java.security.Permission) jodaTimePermission17);
        boolean boolean19 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission14);
        boolean boolean20 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission14);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"UTC\")" + "'", str7.equals("(\"org.joda.time.JodaTimePermission\" \"UTC\")"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYearOfEra((int) (short) 10, 24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
        java.util.Date date13 = dateTime9.toDate();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime16 = dateTime5.withEra(1);
        org.joda.time.DateTime dateTime18 = dateTime16.plusSeconds((-100));
        org.joda.time.DateTime dateTime20 = dateTime16.withYearOfCentury(29);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight22 = dateTime21.toDateMidnight();
        org.joda.time.DateTime dateTime24 = dateTime21.minusDays((int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfDay();
        org.joda.time.DateTime dateTime26 = property25.roundCeilingCopy();
        org.joda.time.DateTime.Property property27 = dateTime26.millisOfSecond();
        java.lang.Class<?> wildcardClass28 = dateTime26.getClass();
        boolean boolean29 = dateTime20.isEqual((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime dateTime31 = dateTime20.plus((long) 52);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology9 = gregorianChronology7.withZone(dateTimeZone8);
        long long13 = gregorianChronology7.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology7.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology7.yearOfEra();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) -1, 264, 1969, 52, 22, 1340, 0, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        long long4 = dateTimeZone0.convertLocalToUTC((-63839750399736L), true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-63839750401755L) + "'", long4 == (-63839750401755L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField16.getDurationField();
        org.joda.time.DurationField durationField19 = unsupportedDateTimeField16.getRangeDurationField();
        java.util.Locale locale20 = null;
        try {
            int int21 = unsupportedDateTimeField16.getMaximumTextLength(locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight4 = dateTime3.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        int int8 = property7.getMinimumValue();
        org.joda.time.DateTime dateTime9 = property7.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology13 = gregorianChronology11.withZone(dateTimeZone12);
        long long17 = gregorianChronology11.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField18 = gregorianChronology11.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField19 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMinuteOfHour(52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
        int int17 = dateTime7.get(dateTimeField12);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
        java.util.Locale locale25 = null;
        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
        int int51 = property50.getMinimumValue();
        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField57);
        int int59 = remainderDateTimeField58.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateMidnight47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight14 = dateTime13.toDateMidnight();
        org.joda.time.DateTime dateTime16 = dateTime13.minusDays((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfDay();
        int int18 = property17.getMinimumValue();
        org.joda.time.DateTime dateTime19 = property17.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType20, 846);
        java.lang.String str24 = remainderDateTimeField22.getAsText((long) 18);
        int int25 = remainderDateTimeField22.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "330" + "'", str24.equals("330"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology8.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField9 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology7 = gregorianChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone6);
        int int9 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.String str11 = dateTime8.toString(dateTimeFormatter10);
        org.joda.time.LocalTime localTime12 = dateTime8.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-0056366T235958Z" + "'", str11.equals("-0056366T235958Z"));
        org.junit.Assert.assertNotNull(localTime12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readableDuration3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusDays((int) (byte) 0);
        org.joda.time.DateTime dateTime7 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime6.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(timeOfDay8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        java.util.Locale locale6 = null;
        org.joda.time.DateTime dateTime7 = property4.setCopy("963", locale6);
        org.joda.time.DateTime dateTime8 = property4.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds((int) 'a');
        org.joda.time.DateTime dateTime4 = dateTime0.plusWeeks(2000);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime5.minusDays((int) 'a');
        java.util.Date date9 = dateTime5.toDate();
        int int10 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime5);
        int int11 = dateTime2.getYearOfEra();
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime2.plusHours(12);
        org.joda.time.DateTime dateTime15 = dateTime2.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
        int int17 = property16.get();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 56 + "'", int11 == 56);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-55) + "'", int17 == (-55));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[Coordinated Universal Time]" + "'", str9.equals("GregorianChronology[Coordinated Universal Time]"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970");
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.toDateTime(dateTimeZone11);
        boolean boolean13 = dateTime12.isEqualNow();
        boolean boolean14 = dateTime12.isEqualNow();
        int int15 = property6.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = property6.getDateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime.Property property2 = dateTime0.centuryOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        org.joda.time.DateTime dateTime5 = property2.roundFloorCopy();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.DateTime dateTime8 = property2.setCopy("��", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"��\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long9 = fixedDateTimeZone4.nextTransition(0L);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getName((long) 19, locale11);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:02.019" + "'", str12.equals("+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
        int int17 = dateTime7.get(dateTimeField12);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
        java.util.Locale locale25 = null;
        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
        int int51 = property50.getMinimumValue();
        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
        int int59 = dividedDateTimeField57.get((long) 2000);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateMidnight47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "-0003-W10-7T14:19:59-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        java.lang.Object obj7 = null;
        boolean boolean8 = property4.equals(obj7);
        org.joda.time.DateTime dateTime10 = property4.addToCopy(19L);
        org.joda.time.DateTime dateTime11 = property4.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime13 = property4.addToCopy((-6373201898163599975L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: -6373201898163599975 * 60000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.String str2 = dateTimeFormatter0.print((long) 3);
        org.joda.time.ReadableInstant readableInstant3 = null;
        java.lang.String str4 = dateTimeFormatter0.print(readableInstant3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-01T00:00:02.022" + "'", str2.equals("1970-01-01T00:00:02.022"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-0055-01-01T00:00:00.264" + "'", str4.equals("-0055-01-01T00:00:00.264"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("UTC");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"UTC\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"UTC\")"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis(100);
        org.joda.time.DateTime dateTime8 = dateTime6.plus((-1L));
        org.joda.time.DateTime dateTime10 = dateTime6.withDayOfYear(6);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded((long) 12, 846);
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(10);
        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight2 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(chronology4);
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
        int int7 = dateTime5.getEra();
        org.joda.time.DateTime dateTime9 = dateTime5.minusMinutes((int) (short) 1);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        long long11 = property10.remainder();
        boolean boolean12 = property10.isLeap();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T000000+0000" + "'", str6.equals("T000000+0000"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 264L + "'", long11 == 264L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName(100L, locale2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getName(0L, locale5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfYear();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusMillis(100);
//        boolean boolean15 = cachedDateTimeZone7.equals((java.lang.Object) dateTime14);
//        long long17 = cachedDateTimeZone7.previousTransition((long) 33);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 33L + "'", long17 == 33L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime11.year();
        org.joda.time.DateTime dateTime16 = dateTime11.withWeekOfWeekyear((int) ' ');
        boolean boolean17 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime2.plusWeeks(13008960);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.hourOfDay();
        org.joda.time.DurationField durationField23 = gregorianChronology20.seconds();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology20.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumTextLength(locale27);
        boolean boolean30 = offsetDateTimeField26.isLeap((long) ' ');
        long long32 = offsetDateTimeField26.roundHalfEven((long) 846);
        int int35 = offsetDateTimeField26.getDifference((long) 25, 101L);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField26.getAsText(2019, locale37);
        org.joda.time.ReadablePartial readablePartial39 = null;
        int[] intArray46 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int47 = offsetDateTimeField26.getMaximumValue(readablePartial39, intArray46);
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight49 = dateTime48.toDateMidnight();
        org.joda.time.DateTime dateTime51 = dateTime48.minusDays((int) 'a');
        org.joda.time.DateTime.Property property52 = dateTime51.minuteOfDay();
        int int53 = property52.getMinimumValue();
        org.joda.time.DateTime dateTime54 = property52.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property52.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26, dateTimeFieldType55, 2091);
        int int58 = dateTime19.get(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2019L) + "'", long32 == (-2019L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292279045 + "'", int47 == 292279045);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateMidnight49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField6.getWrappedField();
        org.joda.time.DurationField durationField10 = offsetDateTimeField6.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField6.getMaximumValue(readablePartial7);
        java.lang.String str9 = offsetDateTimeField6.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292279045 + "'", int8 == 292279045);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "year" + "'", str9.equals("year"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readableDuration3);
        org.joda.time.DateTime dateTime6 = dateTime2.minusDays((int) (byte) 0);
        int int7 = dateTime6.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField6.getAsText(2019, locale17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray26 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int27 = offsetDateTimeField6.getMaximumValue(readablePartial19, intArray26);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight29 = dateTime28.toDateMidnight();
        org.joda.time.DateTime dateTime31 = dateTime28.minusDays((int) 'a');
        org.joda.time.DateTime.Property property32 = dateTime31.minuteOfDay();
        int int33 = property32.getMinimumValue();
        org.joda.time.DateTime dateTime34 = property32.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property32.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType35, 2091);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) (-31536000000L), "-0003-03-09T14:19:55.852-07:52:58");
        java.lang.Number number41 = illegalFieldValueException40.getLowerBound();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 292279045 + "'", int27 == 292279045);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateMidnight29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.DurationField durationField4 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.DurationField durationField4 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone7.getName(1560637164357L, locale9);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (short) 0, 0, 5044, (-292275054), 18, 3, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:02.019" + "'", str10.equals("+00:00:02.019"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        int int8 = dateTime5.getMillisOfSecond();
        java.lang.String str9 = dateTime5.toString();
        org.joda.time.DateTime dateTime11 = dateTime5.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
        org.joda.time.DateTime dateTime15 = dateTime12.minusDays((int) 'a');
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
        boolean boolean18 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime17);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 264 + "'", int8 == 264);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0056-09-26T00:00:00.264+00:00:02.019" + "'", str9.equals("-0056-09-26T00:00:00.264+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(chronology10);
        int int12 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime9.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfDay(57600);
        boolean boolean17 = fixedDateTimeZone4.equals((java.lang.Object) dateTime16);
        org.joda.time.Instant instant18 = dateTime16.toInstant();
        org.joda.time.Instant instant19 = dateTime16.toInstant();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant19);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime0.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumShortTextLength(locale7);
        org.joda.time.Interval interval9 = property4.toInterval();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval9);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long12 = offsetDateTimeField6.roundHalfEven((long) 846);
        int int15 = offsetDateTimeField6.getDifference((long) 25, 101L);
        org.joda.time.DurationField durationField16 = offsetDateTimeField6.getLeapDurationField();
        long long19 = durationField16.subtract((-62255958427387L), (-1));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2019L) + "'", long12 == (-2019L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62255872027387L) + "'", long19 == (-62255872027387L));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        java.lang.String str6 = property4.getAsShortText();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.DateTime dateTime11 = dateTime8.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property16 = dateTime13.minuteOfHour();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight18 = dateTime17.toDateMidnight();
        org.joda.time.DateTime dateTime20 = dateTime17.minusDays((int) 'a');
        java.util.Date date21 = dateTime17.toDate();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime24 = dateTime17.minusYears(25);
        boolean boolean26 = dateTime24.isEqual(1L);
        java.util.GregorianCalendar gregorianCalendar27 = dateTime24.toGregorianCalendar();
        int int28 = property4.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField30 = gregorianChronology29.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, (org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DateTime dateTime38 = dateTime24.withChronology((org.joda.time.Chronology) gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13010400 + "'", int28 == 13010400);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertNotNull(zonedChronology37);
        org.junit.Assert.assertNotNull(dateTime38);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(chronology10);
        int int12 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime9.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfDay(57600);
        boolean boolean17 = fixedDateTimeZone4.equals((java.lang.Object) dateTime16);
        int int19 = fixedDateTimeZone4.getOffset((long) (byte) 0);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField22 = iSOChronology21.years();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 19L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField6.getAsShortText(963, locale8);
        boolean boolean11 = offsetDateTimeField6.isLeap((long) 4);
        boolean boolean12 = offsetDateTimeField6.isSupported();
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField6.getMaximumShortTextLength(locale13);
        java.lang.String str15 = offsetDateTimeField6.toString();
        java.lang.String str17 = offsetDateTimeField6.getAsShortText(0L);
        long long19 = offsetDateTimeField6.roundHalfEven((long) 39);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "963" + "'", str9.equals("963"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[year]" + "'", str15.equals("DateTimeField[year]"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2022" + "'", str17.equals("2022"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2019L) + "'", long19 == (-2019L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        int int8 = dateTime5.getMillisOfSecond();
        java.lang.String str9 = dateTime5.toString();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime5.plus(readablePeriod10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
        org.joda.time.DateTime dateTime15 = dateTime12.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.toDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property20 = dateTime17.minuteOfHour();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight22 = dateTime21.toDateMidnight();
        org.joda.time.DateTime dateTime24 = dateTime21.minusDays((int) 'a');
        java.util.Date date25 = dateTime21.toDate();
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime17, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight28 = dateTime27.toDateMidnight();
        org.joda.time.DateTime dateTime30 = dateTime27.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.toDateTime(dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime32.minusYears((int) (byte) 1);
        boolean boolean35 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight38 = dateTime37.toDateMidnight();
        org.joda.time.DateTime dateTime40 = dateTime37.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.toDateTime(dateTimeZone41);
        org.joda.time.DateTime dateTime44 = dateTime42.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property45 = dateTime42.minuteOfHour();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
        java.util.Date date50 = dateTime46.toDate();
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime42, (org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.ReadableDuration readableDuration52 = null;
        org.joda.time.DateTime dateTime54 = dateTime46.withDurationAdded(readableDuration52, 12);
        boolean boolean55 = dateTime34.isAfter((org.joda.time.ReadableInstant) dateTime54);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 264 + "'", int8 == 264);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0056-09-26T00:00:00.264+00:00:02.019" + "'", str9.equals("-0056-09-26T00:00:00.264+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateMidnight38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateMidnight47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DurationField durationField9 = property8.getLeapDurationField();
        org.joda.time.DateTime dateTime10 = property8.withMaximumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight13 = dateTime12.toDateMidnight();
        org.joda.time.DateTime dateTime14 = dateTime12.toDateTimeISO();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.toDateTime(chronology15);
        java.lang.String str17 = dateTimeFormatter11.print((org.joda.time.ReadableInstant) dateTime16);
        int int18 = dateTime16.getEra();
        org.joda.time.DateTime dateTime20 = dateTime16.plusMillis(292278993);
        long long21 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime20.withMillis(23241600264L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "T000000+0000" + "'", str17.equals("T000000+0000"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-144551L) + "'", long21 == (-144551L));
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        try {
            int int19 = unsupportedDateTimeField16.getDifference(100L, 56569L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTimeISO();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime(chronology10);
        int int12 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime9.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfDay(57600);
        boolean boolean17 = fixedDateTimeZone4.equals((java.lang.Object) dateTime16);
        java.lang.String str19 = fixedDateTimeZone4.getNameKey((long) 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "T151935-0700" + "'", str19.equals("T151935-0700"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField16.getDurationField();
        org.joda.time.DurationField durationField19 = unsupportedDateTimeField16.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = unsupportedDateTimeField16.getType();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight23 = dateTime22.toDateMidnight();
        org.joda.time.DateTime dateTime24 = dateTime22.toDateTimeISO();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.toDateTime(chronology25);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight28 = dateTime27.toDateMidnight();
        org.joda.time.DateTime dateTime30 = dateTime27.minusDays((int) 'a');
        java.util.Date date31 = dateTime27.toDate();
        int int32 = dateTime24.compareTo((org.joda.time.ReadableInstant) dateTime27);
        int int33 = dateTime24.getYearOfEra();
        org.joda.time.YearMonthDay yearMonthDay34 = dateTime24.toYearMonthDay();
        java.lang.String str35 = dateTimeFormatter21.print((org.joda.time.ReadablePartial) yearMonthDay34);
        java.util.Locale locale37 = null;
        try {
            java.lang.String str38 = unsupportedDateTimeField16.getAsText((org.joda.time.ReadablePartial) yearMonthDay34, 292278993, locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateMidnight23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 56 + "'", int33 == 56);
        org.junit.Assert.assertNotNull(yearMonthDay34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "��" + "'", str35.equals("��"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(chronology3);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime(dateTimeZone6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField12, (int) (byte) 10, 4, (int) (byte) 10);
        int int17 = dateTime7.get(dateTimeField12);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
        org.joda.time.DurationField durationField21 = gregorianChronology18.seconds();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
        java.util.Locale locale25 = null;
        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
        boolean boolean28 = offsetDateTimeField24.isLeap((long) ' ');
        long long30 = offsetDateTimeField24.roundHalfEven((long) 846);
        int int33 = offsetDateTimeField24.getDifference((long) 25, 101L);
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField24.getAsText(2019, locale35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int[] intArray44 = new int[] { 4, 1969, '#', 292278993, 0, 33 };
        int int45 = offsetDateTimeField24.getMaximumValue(readablePartial37, intArray44);
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight47 = dateTime46.toDateMidnight();
        org.joda.time.DateTime dateTime49 = dateTime46.minusDays((int) 'a');
        org.joda.time.DateTime.Property property50 = dateTime49.minuteOfDay();
        int int51 = property50.getMinimumValue();
        org.joda.time.DateTime dateTime52 = property50.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType53, 2091);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType53, 292278993);
        long long60 = dividedDateTimeField57.add((long) 25, (-6057L));
        int int61 = dividedDateTimeField57.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2019L) + "'", long30 == (-2019L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 292279045 + "'", int45 == 292279045);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateMidnight47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-6373201898163599975L) + "'", long60 == (-6373201898163599975L));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays((int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfDay();
        int int9 = property8.getMinimumValue();
        org.joda.time.DateTime dateTime10 = property8.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType11, 14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField6.getMaximumTextLength(locale7);
        boolean boolean10 = offsetDateTimeField6.isLeap((long) ' ');
        long long13 = offsetDateTimeField6.set((long) 264, (-1));
        org.joda.time.DurationField durationField14 = offsetDateTimeField6.getLeapDurationField();
        long long16 = offsetDateTimeField6.roundHalfEven(101L);
        try {
            long long19 = offsetDateTimeField6.set((-144551L), "ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-63839750399736L) + "'", long13 == (-63839750399736L));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2019L) + "'", long16 == (-2019L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = fixedDateTimeZone4.getOffsetFromLocal((-63808214821736L));
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = unsupportedDateTimeField16.getType();
        boolean boolean18 = unsupportedDateTimeField16.isLenient();
        try {
            int int19 = unsupportedDateTimeField16.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        long long9 = offsetDateTimeField6.add((long) 25, (-139740L));
        long long11 = offsetDateTimeField6.roundHalfCeiling((long) 963);
        int int13 = offsetDateTimeField6.getMaximumValue(0L);
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField6.getMaximumTextLength(locale14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4409768476799975L) + "'", long9 == (-4409768476799975L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2019L) + "'", long11 == (-2019L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292279045 + "'", int13 == 292279045);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTimeISO();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.toDateTime(chronology7);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
        java.util.Date date13 = dateTime9.toDate();
        int int14 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int15 = dateTime6.getYearOfEra();
        org.joda.time.YearMonthDay yearMonthDay16 = dateTime6.toYearMonthDay();
        java.lang.String str17 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) yearMonthDay16);
        int[] intArray19 = gregorianChronology2.get((org.joda.time.ReadablePartial) yearMonthDay16, (long) (byte) -1);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology2.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 56 + "'", int15 == 56);
        org.junit.Assert.assertNotNull(yearMonthDay16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "��" + "'", str17.equals("��"));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis(100);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMinutes((int) (byte) 1);
        java.util.Date date9 = dateTime8.toDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName(100L, locale2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone0.getName(0L, locale5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone7.getUncachedZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.DateMidnight dateMidnight12 = dateTime11.toDateMidnight();
//        org.joda.time.DateTime dateTime13 = dateTime11.toDateTimeISO();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.toDateTime(chronology14);
//        java.lang.String str16 = dateTimeFormatter10.print((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter10.withPivotYear((-1));
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter10.withLocale(locale19);
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(0L, chronology22);
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.plus(readableDuration24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withYearOfCentury((int) 'a');
//        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
//        java.lang.String str29 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) yearMonthDay28);
//        long long31 = gregorianChronology9.set((org.joda.time.ReadablePartial) yearMonthDay28, (long) (-55));
//        boolean boolean33 = gregorianChronology9.equals((java.lang.Object) "PST");
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateMidnight12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "T000000+0000" + "'", str16.equals("T000000+0000"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(yearMonthDay28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "T������" + "'", str29.equals("T������"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 852163199945L + "'", long31 == 852163199945L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology8.getZone();
        java.lang.String str11 = zonedChronology8.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean13 = zonedChronology8.equals((java.lang.Object) dateTimeFormatter12);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int20 = fixedDateTimeZone18.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        int int23 = fixedDateTimeZone18.getOffsetFromLocal((-63808214821736L));
        long long25 = fixedDateTimeZone18.previousTransition((long) 5044);
        org.joda.time.Chronology chronology26 = zonedChronology8.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]" + "'", str11.equals("ZonedChronology[GregorianChronology[UTC], Coordinated Universal Time]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 5044L + "'", long25 == 5044L);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths(16);
        int int8 = dateTime5.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-56), 59, 2000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1886 + "'", int3 == 1886);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime0.dayOfMonth();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
        boolean boolean7 = dateTime6.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Coordinated Universal Time", "T151935-0700", 2019, 33);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 351);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) 57600);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (-55), 28, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -55 for  must be in the range [28,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-292275002), 80417, (-1), 52, 0, 57600000, 292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
        java.util.Date date13 = dateTime9.toDate();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime16 = dateTime5.withEra(1);
        boolean boolean17 = dateTime5.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        int int5 = property4.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = gregorianChronology8.withZone(dateTimeZone9);
        long long14 = gregorianChronology8.add((long) 1, (long) (short) 0, (int) (byte) 0);
        org.joda.time.DurationField durationField15 = gregorianChronology8.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField16.getDurationField();
        java.lang.String str19 = unsupportedDateTimeField16.getName();
        try {
            long long22 = unsupportedDateTimeField16.set((long) 22, "T151928-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: minuteOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "minuteOfDay" + "'", str19.equals("minuteOfDay"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        int int8 = dateTime5.getMillisOfSecond();
        boolean boolean10 = dateTime5.isAfter(1104537600101L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 264 + "'", int8 == 264);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        int int8 = dateTime5.getMillisOfSecond();
        java.lang.String str9 = dateTime5.toString();
        org.joda.time.DateTime dateTime11 = dateTime5.plusSeconds((int) '4');
        int int12 = dateTime11.getWeekOfWeekyear();
        int int13 = dateTime11.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 264 + "'", int8 == 264);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0056-09-26T00:00:00.264+00:00:02.019" + "'", str9.equals("-0056-09-26T00:00:00.264+00:00:02.019"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 39 + "'", int12 == 39);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 39 + "'", int13 == 39);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        java.lang.String str6 = property4.getAsShortText();
        boolean boolean7 = property4.isLeap();
        int int8 = property4.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight1 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime9.minusDays((int) 'a');
        java.util.Date date13 = dateTime9.toDate();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateMidnight dateMidnight16 = dateTime15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = dateTime15.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.minusYears((int) (byte) 1);
        boolean boolean23 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime25 = dateTime22.plusMonths(28);
        org.joda.time.DateTime.Property property26 = dateTime22.weekyear();
        org.joda.time.DateTime.Property property27 = dateTime22.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime22.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateMidnight1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
    }
}

