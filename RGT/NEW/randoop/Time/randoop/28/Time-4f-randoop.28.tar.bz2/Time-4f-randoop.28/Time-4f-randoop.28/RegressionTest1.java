import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        boolean boolean3 = dateTime0.isAfter((long) 100);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(9);
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays(58697);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-2697703589222000L), 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = copticChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology6.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        long long11 = delegatedDateTimeField9.roundHalfCeiling((long) 84);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = delegatedDateTimeField9.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType12);
        org.joda.time.DurationField durationField14 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalTime localTime4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime7.toYearMonthDay();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withFieldAdded(durationFieldType9, 58696);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(yearMonthDay8);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendTimeZoneOffset("1970-01-01", "19691231T������", true, 57599, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalTime localTime4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime11.withTimeAtStartOfDay();
        boolean boolean13 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime7.plusHours(0);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime7.withZoneRetainFields(dateTimeZone16);
        boolean boolean19 = dateTime7.isEqual((long) 58697);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.minus(readablePeriod7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.minus(readableDuration9);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        long long6 = copticChronology0.getDateTimeMillis((int) (byte) 1, 9, (int) (byte) 10, 58696);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = zonedChronology10.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-53162697541304L) + "'", long6 == (-53162697541304L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.centuryOfEra();
        org.joda.time.LocalDate localDate7 = property6.withMinimumValue();
        try {
            int int9 = localDate7.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 35");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DurationField durationField2 = copticChronology0.weekyears();
        try {
            long long10 = copticChronology0.getDateTimeMillis(1969, 58696, 100, (-292275054), (int) (byte) 10, 2922789, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(31478400000L, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62956800000L + "'", long2 == 62956800000L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(10L, dateTimeZone7);
        org.joda.time.Partial partial9 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate8);
        int int10 = localDate2.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.LocalDate localDate12 = localDate8.minusDays((-81595));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = gJChronology1.hours();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58698, '#', 365, (int) (short) -1, (int) (byte) 10, false, (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("America/Los_Angeles", 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder8.setFixedSavings("0", 58696);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalTime localTime7 = null;
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = localDate5.toDateTime(localTime7, dateTimeZone9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withZone(dateTimeZone4);
        boolean boolean6 = buddhistChronology2.equals((java.lang.Object) dateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        int int15 = cachedDateTimeZone13.getOffset((long) 70);
        org.joda.time.Chronology chronology16 = buddhistChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        try {
            long long21 = buddhistChronology2.getDateTimeMillis(0, 3939, 57601, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3939 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(chronology16);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(47);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.plus(readablePeriod5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond(9);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime();
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58698, '#', 365, (int) (short) -1, (int) (byte) 10, false, (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("America/Los_Angeles", 10);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder8.writeTo("1970-01-01", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        int int13 = delegatedDateTimeField7.getDifference((long) 100, (long) 480);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 960, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        java.lang.String str4 = partial3.toStringList();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        int int9 = localDate7.indexOf(dateTimeFieldType8);
        org.joda.time.DateMidnight dateMidnight10 = localDate7.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        int int15 = localDate7.compareTo((org.joda.time.ReadablePartial) localDate13);
        boolean boolean16 = partial3.isMatch((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Interval interval18 = localDate13.toInterval(dateTimeZone17);
        try {
            org.joda.time.LocalDate localDate20 = localDate13.withDayOfMonth(292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str4.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(interval18);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "19691231T������");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        org.joda.time.LocalDate localDate14 = property6.roundHalfEvenCopy();
        java.lang.String str15 = property6.getAsText();
        org.joda.time.LocalDate localDate16 = property6.roundFloorCopy();
        int int17 = localDate16.getYearOfEra();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        int int15 = offsetDateTimeField9.get((long) (byte) 100);
        int int16 = offsetDateTimeField9.getMinimumValue();
        long long18 = offsetDateTimeField9.roundHalfEven((long) 1);
        long long20 = offsetDateTimeField9.roundCeiling(62956800000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3939 + "'", int15 == 3939);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-292273085) + "'", int16 == (-292273085));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 63072000000L + "'", long20 == 63072000000L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        long long5 = delegatedDateTimeField3.roundHalfCeiling((long) 84);
        int int7 = delegatedDateTimeField3.get((long) '4');
        int int9 = delegatedDateTimeField3.getLeapAmount((long) 57601);
        java.lang.String str11 = delegatedDateTimeField3.getAsShortText((long) 58695);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readableDuration14);
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str11, (java.lang.Object) dateTime12);
        org.joda.time.DateTime dateTime17 = dateTime12.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfDay(23);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        int int7 = dateTime6.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime8 = dateTime6.toLocalDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.DateTime dateTime12 = property9.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime14 = property9.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.minus(readableDuration15);
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = copticChronology17.halfdays();
//        org.joda.time.DateTimeField dateTimeField19 = copticChronology17.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
//        long long22 = delegatedDateTimeField20.roundHalfCeiling((long) 84);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField20.getType();
//        int int24 = dateTime14.get(dateTimeFieldType23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType23, 12, 960);
//        boolean boolean28 = dateTimeFormatterBuilder27.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendLiteral("December");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder27.appendEraText();
//        boolean boolean32 = dateTimeFormatterBuilder27.canBuildPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57601 + "'", int7 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 960 + "'", int24 == 960);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.dayOfWeek();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
//        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
//        int int7 = dateTime0.getMinuteOfHour();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime((org.joda.time.Chronology) copticChronology8);
//        try {
//            long long15 = copticChronology8.getDateTimeMillis((long) 12, 2, 57599, 1, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 23);
//        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
//        java.io.Writer writer4 = null;
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        int int6 = dateTime5.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime7 = dateTime5.toLocalDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime5.monthOfYear();
//        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
//        org.joda.time.DateTime dateTime11 = property8.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) 9);
//        try {
//            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadableInstant) dateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W01-3" + "'", str2.equals("1970-W01-3"));
//        org.junit.Assert.assertNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57601 + "'", int6 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        boolean boolean3 = dateTime0.isAfter((long) 100);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(9);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.DateTime.Property property12 = dateTime10.minuteOfHour();
        boolean boolean13 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime15 = dateTime10.plusSeconds(57600);
        org.joda.time.Instant instant16 = dateTime10.toInstant();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(instant16);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969-12-31T16:00:01.439-08:00", "1969-12-31", 84, 57600);
        long long6 = fixedDateTimeZone4.nextTransition((long) 1438);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1438L + "'", long6 == 1438L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 16);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalTime localTime4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
        java.lang.String str8 = dateTimeZone6.getID();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology9.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.Partial partial37 = property34.withMinimumValue();
        org.joda.time.Partial partial39 = property34.addWrapFieldToCopy((int) (short) 10);
        int int40 = property34.getMinimumValue();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNotNull(partial37);
        org.junit.Assert.assertNotNull(partial39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-292275054) + "'", int40 == (-292275054));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.LocalDate.Property property5 = localDate2.dayOfMonth();
        org.joda.time.LocalDate localDate7 = property5.addWrapFieldToCopy(10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeField dateTimeField4 = delegatedDateTimeField3.getWrappedField();
        long long6 = delegatedDateTimeField3.roundCeiling(0L);
        long long9 = delegatedDateTimeField3.add((long) 84, 4);
        java.lang.String str11 = delegatedDateTimeField3.getAsText((-292320000L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240084L + "'", long9 == 240084L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "888" + "'", str11.equals("888"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.dayOfWeek();
        long long7 = julianChronology0.getDateTimeMillis(16, 3, (int) (short) 1, 3);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61657286399997L) + "'", long7 == (-61657286399997L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(dateTimeFieldType2);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) '#');
        org.joda.time.LocalDate localDate7 = localDate1.minusDays(2922789);
        org.joda.time.LocalDate localDate9 = localDate1.withCenturyOfEra(0);
        org.joda.time.Interval interval10 = localDate1.toInterval();
        try {
            org.joda.time.LocalDate localDate12 = localDate1.withDayOfMonth(57601439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57601439 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(interval10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(47);
        try {
            org.joda.time.LocalDate localDate5 = dateTimeFormatter3.parseLocalDate("JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        boolean boolean10 = fixedDateTimeZone6.equals((java.lang.Object) dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = dateTime4.plus((long) 58695);
        boolean boolean8 = dateTime6.equals((java.lang.Object) 1811496960000000L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy((int) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        org.joda.time.DateTime dateTime11 = property9.setCopy(31);
//        org.joda.time.DurationField durationField12 = property9.getRangeDurationField();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57601 + "'", int1 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        java.lang.String str4 = partial3.toStringList();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        int int9 = localDate7.indexOf(dateTimeFieldType8);
        org.joda.time.DateMidnight dateMidnight10 = localDate7.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        int int15 = localDate7.compareTo((org.joda.time.ReadablePartial) localDate13);
        boolean boolean16 = partial3.isMatch((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Interval interval18 = localDate13.toInterval(dateTimeZone17);
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str4.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(interval18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate5 = dateTime0.toLocalDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime9 = dateTime0.plusYears(57601);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = copticChronology1.years();
        org.joda.time.DurationField durationField3 = copticChronology1.millis();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology1.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = copticChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) copticChronology1);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime3 = dateTime1.toLocalDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime1.monthOfYear();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.DateTime dateTime7 = property4.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime9 = property4.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField13 = copticChronology12.halfdays();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
//        long long17 = delegatedDateTimeField15.roundHalfCeiling((long) 84);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField15.getType();
//        int int19 = dateTime9.get(dateTimeFieldType18);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField20 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57601 + "'", int2 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 960 + "'", int19 == 960);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfDay(1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField13.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        java.lang.Object obj3 = null;
        boolean boolean4 = property2.equals(obj3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate10 = dateTime5.toLocalDate();
        org.joda.time.LocalDate localDate12 = localDate10.withDayOfMonth((int) (byte) 1);
        int int13 = property2.compareTo((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate localDate14 = property2.getLocalDate();
        org.joda.time.LocalDate localDate15 = property2.roundHalfEvenCopy();
        try {
            org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((java.lang.Object) property2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.LocalDate$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(3, (int) ' ', 4, (int) '4', 58696, 365, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 960 + "'", int2 == 960);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalTime localTime4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        java.lang.String str11 = delegatedDateTimeField7.toString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[minuteOfDay]" + "'", str11.equals("DateTimeField[minuteOfDay]"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalDate localDate5 = localDate2.plusYears((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(10L, dateTimeZone7);
        int int9 = localDate8.getCenturyOfEra();
        org.joda.time.LocalDate.Property property10 = localDate8.dayOfWeek();
        boolean boolean11 = localDate2.isEqual((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.DateMidnight dateMidnight12 = localDate8.toDateMidnight();
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateMidnight12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate2.plus(readablePeriod6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight12 = localDate2.toDateMidnight(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime13 = dateMidnight12.toMutableDateTime();
        int int14 = mutableDateTime13.getHourOfDay();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy((int) (short) 10);
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime8.withDayOfWeek((int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57601 + "'", int1 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.millisOfDay();
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
//        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
//        org.joda.time.LocalTime localTime4 = null;
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone6);
//        java.lang.String str10 = dateTimeZone6.getShortName((long) 0);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone6.getName(0L, locale12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        try {
//            long long19 = gregorianChronology14.getDateTimeMillis(9, 4, (int) ' ', 58696);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(47);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        java.lang.String str8 = dateTime4.toString(dateTimeFormatter7);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology10);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.secondOfDay();
//        org.joda.time.DurationField durationField13 = gJChronology10.halfdays();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology10);
//        try {
//            long long19 = gJChronology10.getDateTimeMillis(2, (-1), 47, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1682-W38" + "'", str8.equals("1682-W38"));
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate2.plus(readablePeriod6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight12 = localDate2.toDateMidnight(dateTimeZone9);
        int int14 = localDate2.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate16 = localDate2.minusMonths(57600);
        org.joda.time.LocalDate.Property property17 = localDate16.year();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        int int4 = localDate2.indexOf(dateTimeFieldType3);
//        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
//        org.joda.time.LocalDate.Property property6 = localDate2.year();
//        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
//        java.util.Locale locale11 = null;
//        int int12 = offsetDateTimeField9.getMaximumShortTextLength(locale11);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(10L, dateTimeZone14);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
//        int int17 = localDate15.indexOf(dateTimeFieldType16);
//        org.joda.time.DateMidnight dateMidnight18 = localDate15.toDateMidnight();
//        org.joda.time.LocalDate.Property property19 = localDate15.year();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(10L, dateTimeZone21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        int int24 = localDate22.indexOf(dateTimeFieldType23);
//        org.joda.time.DateMidnight dateMidnight25 = localDate22.toDateMidnight();
//        long long26 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight25);
//        java.lang.String str27 = property19.getName();
//        org.joda.time.LocalDate localDate28 = property19.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate30 = localDate28.withDayOfYear((int) (short) 10);
//        int int31 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDate30);
//        java.lang.String str32 = offsetDateTimeField9.toString();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(dateTimeZone33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
//        boolean boolean36 = localDate34.isSupported(dateTimeFieldType35);
//        org.joda.time.LocalDate localDate38 = localDate34.withWeekyear((int) '#');
//        org.joda.time.LocalDate localDate40 = localDate34.minusDays(2922789);
//        org.joda.time.LocalDate localDate42 = localDate34.withCenturyOfEra(0);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate42, locale43);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = offsetDateTimeField9.getAsShortText((long) 480, locale46);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(dateMidnight18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(dateMidnight25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "year" + "'", str27.equals("year"));
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-292273085) + "'", int31 == (-292273085));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "DateTimeField[year]" + "'", str32.equals("DateTimeField[year]"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "69" + "'", str44.equals("69"));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "3939" + "'", str47.equals("3939"));
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendWeekOfWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(31, 57601, 7, 480);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 278 + "'", int4 == 278);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = gJChronology1.hours();
        java.lang.Class<?> wildcardClass5 = gJChronology1.getClass();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime0.minusMillis(60662);
        org.joda.time.Chronology chronology9 = dateTime0.getChronology();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime0.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
        org.joda.time.Instant instant10 = dateTime8.toInstant();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate5 = dateTime0.toLocalDate();
        org.joda.time.LocalDate localDate7 = localDate5.withDayOfMonth((int) (byte) 1);
        org.joda.time.LocalDate.Property property8 = localDate7.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58698, '#', 365, (int) (short) -1, (int) (byte) 10, false, (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("America/Los_Angeles", 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder8.setFixedSavings("year", 7);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.setStandardOffset(58698);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder16.setFixedSavings("America/Los_Angeles", 60662);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        java.lang.String str14 = property6.getName();
        org.joda.time.LocalDate localDate15 = property6.roundFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate18 = localDate15.withPeriodAdded(readablePeriod16, (int) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.yearOfEra();
        org.joda.time.LocalDate localDate21 = property19.addToCopy(7);
        org.joda.time.LocalDate localDate22 = property19.roundHalfFloorCopy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate22);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMillis(57601);
        org.joda.time.DateTime dateTime6 = dateTime2.plusSeconds(57601439);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime.Property property4 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        boolean boolean12 = dateTime8.isSupported(dateTimeFieldType11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) 100);
//        int int17 = dateTime8.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        int int18 = dateTime16.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57601 + "'", int1 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        int int15 = offsetDateTimeField9.get((long) (byte) 100);
        long long18 = offsetDateTimeField9.add(2758760L, (long) 'a');
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime20 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.minus(readableDuration21);
        org.joda.time.DateTime dateTime23 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate24 = dateTime19.toLocalDate();
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime19.toYearMonthDay();
        int int26 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay25);
        long long28 = offsetDateTimeField9.roundHalfFloor((long) 70);
        long long30 = offsetDateTimeField9.roundHalfEven((long) 1969);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(10L, dateTimeZone32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
        int int35 = localDate33.indexOf(dateTimeFieldType34);
        org.joda.time.DateMidnight dateMidnight36 = localDate33.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.LocalDate localDate38 = localDate33.plus(readablePeriod37);
        java.util.TimeZone timeZone39 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
        int int42 = dateTimeZone40.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight43 = localDate33.toDateMidnight(dateTimeZone40);
        int int45 = localDate33.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate47 = localDate33.minusMonths(57600);
        org.joda.time.Partial partial48 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate33);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.Partial partial50 = partial48.plus(readablePeriod49);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray51 = partial48.getFieldTypes();
        int[] intArray53 = null;
        try {
            int[] intArray55 = offsetDateTimeField9.set((org.joda.time.ReadablePartial) partial48, (-1), intArray53, (-292273085));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3939 + "'", int15 == 3939);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3061068358760L + "'", long18 == 3061068358760L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-292273085) + "'", int26 == (-292273085));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-28800000) + "'", int42 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertNotNull(partial50);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray51);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        java.lang.String str14 = property6.toString();
        org.joda.time.LocalDate localDate15 = property6.getLocalDate();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[year]" + "'", str14.equals("Property[year]"));
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
//        java.lang.StringBuffer stringBuffer3 = null;
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
//        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
//        java.lang.String str11 = delegatedDateTimeField7.getAsText((long) 16);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        boolean boolean15 = localDate13.isSupported(dateTimeFieldType14);
//        int int16 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) localDate13);
//        int int17 = localDate13.getCenturyOfEra();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) localDate13);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNull(chronology2);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1439 + "'", int16 == 1439);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusSeconds(0);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, 2922789);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57601 + "'", int1 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        boolean boolean12 = dateTime8.isSupported(dateTimeFieldType11);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) 100);
//        int int17 = dateTime8.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57601 + "'", int1 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(chronology18);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1970-01-01");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeZone6);
        java.lang.String str9 = dateTimeZone6.getID();
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+01:00" + "'", str9.equals("+01:00"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate5 = dateTime0.toLocalDate();
        org.joda.time.LocalDate localDate7 = localDate5.withDayOfMonth((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.lang.String str9 = localDate7.toString(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T������.000" + "'", str9.equals("T������.000"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
        org.joda.time.DateTime dateTime5 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.plus((long) 58695);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = copticChronology8.years();
        org.joda.time.DurationField durationField10 = copticChronology8.millis();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology8.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology8.getZone();
        org.joda.time.DateTime dateTime13 = dateTime5.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 7, dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime0.withYear((int) (short) 100);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withEra(58698);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58698 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter3.getZone();
        boolean boolean5 = dateTimeFormatter3.isParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.append(dateTimeFormatter3);
        java.lang.Appendable appendable7 = null;
        try {
            dateTimeFormatter3.printTo(appendable7, 1922209L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfHour(58693, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendTimeZoneOffset("960", "minuteOfDay", false, 58695, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime4 = property3.roundFloorCopy();
//        boolean boolean5 = dateTime4.isBeforeNow();
//        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded(2209L, 0);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57601 + "'", int1 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = dateTime4.plus((long) 58695);
        org.joda.time.Chronology chronology7 = dateTime6.getChronology();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate2.plus(readablePeriod6);
        org.joda.time.LocalDate localDate9 = localDate2.plusYears(58693);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate9.plus(readablePeriod10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (byte) 0);
        org.joda.time.DateTime.Property property37 = dateTime36.secondOfMinute();
        org.joda.time.DateTime dateTime38 = property37.getDateTime();
        int int39 = property34.compareTo((org.joda.time.ReadableInstant) dateTime38);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        int int15 = offsetDateTimeField9.get((long) (byte) 100);
        int int16 = offsetDateTimeField9.getMinimumValue();
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsShortText(16, locale18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3939 + "'", int15 == 3939);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-292273085) + "'", int16 == (-292273085));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "16" + "'", str19.equals("16"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalTime localTime4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = dateTime8.withDayOfMonth(10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime14 = dateTime10.minusMillis(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = dateTime10.isSupported(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMillis(57601);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays(12);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        org.joda.time.LocalDate localDate14 = property6.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate15 = property6.roundFloorCopy();
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            org.joda.time.LocalDate localDate18 = localDate15.withFieldAdded(durationFieldType16, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = copticChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology6.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        long long11 = delegatedDateTimeField9.roundHalfCeiling((long) 84);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = delegatedDateTimeField9.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType12);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType12, 58696, 1439, 47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58696 for minuteOfDay must be in the range [1439,47]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfDay(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfDay(58696);
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) 58696);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(copticChronology3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField9.getMaximumShortTextLength(locale11);
        long long14 = offsetDateTimeField9.roundHalfEven(0L);
        int int16 = offsetDateTimeField9.get((-2699186731622000L));
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsShortText((long) (short) 100, locale18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-81595) + "'", int16 == (-81595));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3939" + "'", str19.equals("3939"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("DateTimeField[minuteOfDay]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[minuteOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readableDuration14);
        org.joda.time.DateTime dateTime16 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
        java.util.Date date18 = dateTime16.toDate();
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance(chronology3, readableDateTime11, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, 240084L, 7);
        org.joda.time.Chronology chronology26 = limitChronology19.withZone(dateTimeZone22);
        try {
            long long34 = limitChronology19.getDateTimeMillis((-292275054), 52, 0, 57601439, 58697, 69, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57601439 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(chronology26);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime8 = dateTime6.withMillis((long) 9);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusYears((-28800000));
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
//        java.util.TimeZone timeZone16 = fixedDateTimeZone15.toTimeZone();
//        org.joda.time.DateTime dateTime17 = dateTime8.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57601 + "'", int1 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(dateTimeFieldType2);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) '#');
        org.joda.time.LocalTime localTime6 = null;
        org.joda.time.DateTime dateTime7 = localDate5.toDateTime(localTime6);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime.Property property9 = dateTime7.weekOfWeekyear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 10, 960, (int) '#', 69, 2, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfDay();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) 365, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        java.lang.String str12 = property10.getAsString();
        boolean boolean13 = iSOChronology1.equals((java.lang.Object) str12);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, 240084L, 7);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(10L, dateTimeZone7);
        org.joda.time.Partial partial9 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate8);
        java.lang.String str10 = partial9.toStringList();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(10L, dateTimeZone18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate19);
        int int21 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate19);
        boolean boolean22 = partial9.isMatch((org.joda.time.ReadablePartial) localDate19);
        java.lang.String str23 = partial9.toStringList();
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(dateTimeZone25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        boolean boolean28 = localDate26.isSupported(dateTimeFieldType27);
        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) '#');
        org.joda.time.LocalDate localDate32 = localDate26.minusDays(2922789);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField34 = copticChronology33.halfdays();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology33.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime38 = dateTime37.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate39 = dateTime38.toLocalDate();
        int[] intArray45 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray47 = delegatedDateTimeField36.set((org.joda.time.ReadablePartial) localDate39, 0, intArray45, (int) (byte) 10);
        copticChronology24.validate((org.joda.time.ReadablePartial) localDate26, intArray47);
        gJChronology5.validate((org.joda.time.ReadablePartial) partial9, intArray47);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str10.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str23.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(2922789);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        int int12 = dateTime11.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime11.toLocalDateTime();
//        org.joda.time.DateTime.Property property14 = dateTime11.monthOfYear();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.DateTime dateTime17 = property14.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime19 = property14.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = copticChronology22.halfdays();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
//        long long27 = delegatedDateTimeField25.roundHalfCeiling((long) 84);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField25.getType();
//        int int29 = dateTime19.get(dateTimeFieldType28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder8.appendDayOfMonth(1970);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57601 + "'", int12 == 57601);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 960 + "'", int29 == 960);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        int int15 = offsetDateTimeField9.get((long) (byte) 100);
        int int16 = offsetDateTimeField9.getMinimumValue();
        try {
            long long19 = offsetDateTimeField9.set((-28799968L), "2019-06-15T16:18:17.594-07:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T16:18:17.594-07:00\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3939 + "'", int15 == 3939);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-292273085) + "'", int16 == (-292273085));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(10L, dateTimeZone3);
        org.joda.time.Partial partial5 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate4);
        org.joda.time.LocalTime localTime6 = null;
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.DateTime dateTime9 = localDate4.toDateTime(localTime6, dateTimeZone8);
        java.lang.String str10 = dateTimeZone8.getID();
        long long12 = dateTimeZone8.convertUTCToLocal((long) ' ');
        long long15 = dateTimeZone8.convertLocalToUTC((-2699186760000000L), true);
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28799968L) + "'", long12 == (-28799968L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2699186731622000L) + "'", long15 == (-2699186731622000L));
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeField dateTimeField4 = delegatedDateTimeField3.getWrappedField();
        long long6 = delegatedDateTimeField3.roundCeiling(0L);
        long long9 = delegatedDateTimeField3.add((long) 84, 4);
        boolean boolean11 = delegatedDateTimeField3.isLeap((long) 3939);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240084L + "'", long9 == 240084L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = gJChronology1.halfdays();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfYear();
        boolean boolean10 = gJChronology1.equals((java.lang.Object) dateTime5);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime12 = dateTime5.withChronology((org.joda.time.Chronology) iSOChronology11);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.Partial partial37 = property34.withMinimumValue();
        org.joda.time.Partial partial39 = property34.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.DateTimeField dateTimeField40 = property34.getField();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNotNull(partial37);
        org.junit.Assert.assertNotNull(partial39);
        org.junit.Assert.assertNotNull(dateTimeField40);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        long long5 = delegatedDateTimeField3.roundHalfCeiling((long) 84);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField3.getType();
        int int7 = delegatedDateTimeField3.getMinimumValue();
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField3.getAsText((long) 1439, locale9);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(10L, dateTimeZone13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = localDate14.indexOf(dateTimeFieldType15);
        org.joda.time.DateMidnight dateMidnight17 = localDate14.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate19 = localDate14.plus(readablePeriod18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        int int23 = dateTimeZone21.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight24 = localDate14.toDateMidnight(dateTimeZone21);
        int int26 = localDate14.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate28 = localDate14.minusMonths(57600);
        int int29 = localDate14.getYearOfEra();
        org.joda.time.LocalDate localDate31 = localDate14.minusMonths(58693);
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate31, (int) (short) 0, locale33);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-292273085));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969-12-31T16:00:01.439-08:00", "19691231T������");
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.DurationField durationField2 = copticChronology0.millis();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = copticChronology0.add(readablePeriod3, (long) (byte) 1, (int) (short) 10);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 31536000000L, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.Chronology chronology8 = localDate7.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = copticChronology9.halfdays();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology9.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        long long14 = delegatedDateTimeField12.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, (org.joda.time.DateTimeField) delegatedDateTimeField12);
        boolean boolean16 = delegatedDateTimeField12.isLenient();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(10L, dateTimeZone18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = localDate19.indexOf(dateTimeFieldType20);
        org.joda.time.DateMidnight dateMidnight22 = localDate19.toDateMidnight();
        org.joda.time.LocalDate.Property property23 = localDate19.year();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 1969);
        boolean boolean27 = offsetDateTimeField26.isLenient();
        long long30 = offsetDateTimeField26.addWrapField(31449600000L, 0);
        int int32 = offsetDateTimeField26.get((long) (byte) 100);
        long long35 = offsetDateTimeField26.add(2758760L, (long) 'a');
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime37 = dateTime36.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime36.minus(readableDuration38);
        org.joda.time.DateTime dateTime40 = dateTime36.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate41 = dateTime36.toLocalDate();
        org.joda.time.YearMonthDay yearMonthDay42 = dateTime36.toYearMonthDay();
        int int43 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay42);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate(10L, dateTimeZone45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
        int int48 = localDate46.indexOf(dateTimeFieldType47);
        org.joda.time.DateMidnight dateMidnight49 = localDate46.toDateMidnight();
        org.joda.time.LocalDate.Property property50 = localDate46.year();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(10L, dateTimeZone52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        int int55 = localDate53.indexOf(dateTimeFieldType54);
        org.joda.time.DateMidnight dateMidnight56 = localDate53.toDateMidnight();
        long long57 = property50.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight56);
        java.lang.String str58 = property50.getName();
        org.joda.time.LocalDate localDate59 = property50.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate61 = localDate59.withDayOfYear((int) (short) 10);
        int int62 = localDate61.getEra();
        java.util.Locale locale64 = null;
        java.lang.String str65 = offsetDateTimeField26.getAsText((org.joda.time.ReadablePartial) localDate61, 0, locale64);
        org.joda.time.chrono.CopticChronology copticChronology67 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField68 = copticChronology67.halfdays();
        org.joda.time.DateTimeField dateTimeField69 = copticChronology67.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField69);
        org.joda.time.DateTime dateTime71 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime72 = dateTime71.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate73 = dateTime72.toLocalDate();
        int[] intArray79 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray81 = delegatedDateTimeField70.set((org.joda.time.ReadablePartial) localDate73, 0, intArray79, (int) (byte) 10);
        int[] intArray83 = delegatedDateTimeField12.set((org.joda.time.ReadablePartial) localDate61, (int) (byte) 0, intArray81, 10);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField85 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) delegatedDateTimeField12, (-1));
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31449600000L + "'", long30 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3939 + "'", int32 == 3939);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3061068358760L + "'", long35 == 3061068358760L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(yearMonthDay42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-292273085) + "'", int43 == (-292273085));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "year" + "'", str58.equals("year"));
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "0" + "'", str65.equals("0"));
        org.junit.Assert.assertNotNull(copticChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray83);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime5 = property3.withMinimumValue();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.DateTime dateTime8 = property3.setCopy("1969", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24526 + "'", int1 == 24526);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        int int15 = offsetDateTimeField9.get((long) (byte) 100);
        long long17 = offsetDateTimeField9.roundHalfCeiling((long) 31);
        java.lang.String str19 = offsetDateTimeField9.getAsText((-53162697541304L));
        int int20 = offsetDateTimeField9.getMinimumValue();
        org.joda.time.DurationField durationField21 = offsetDateTimeField9.getDurationField();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3939 + "'", int15 == 3939);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2254" + "'", str19.equals("2254"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292273085) + "'", int20 == (-292273085));
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology6);
        long long12 = copticChronology6.getDateTimeMillis((int) (byte) 1, 9, (int) (byte) 10, 58696);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology6, dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = copticChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(0, 57601439, 16, 1439, (int) (short) 1, 292280962, dateTimeZone17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-53162697541304L) + "'", long12 == (-53162697541304L));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField9.getType();
        long long13 = offsetDateTimeField9.roundCeiling(0L);
        long long16 = offsetDateTimeField9.set((long) 58698, 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-124176585541302L) + "'", long16 == (-124176585541302L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology0.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        int int11 = delegatedDateTimeField7.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1439 + "'", int11 == 1439);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("hi!", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        long long5 = copticChronology0.add(1L, (long) 47, 58697);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(dateTimeZone6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = localDate7.isSupported(dateTimeFieldType8);
        org.joda.time.LocalDate localDate11 = localDate7.withWeekyear((int) '#');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(10L, dateTimeZone13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = localDate14.indexOf(dateTimeFieldType15);
        org.joda.time.DateMidnight dateMidnight17 = localDate14.toDateMidnight();
        org.joda.time.LocalDate.Property property18 = localDate14.year();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        int int23 = localDate21.indexOf(dateTimeFieldType22);
        org.joda.time.DateMidnight dateMidnight24 = localDate21.toDateMidnight();
        long long25 = property18.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight24);
        java.lang.String str26 = property18.getName();
        org.joda.time.LocalDate localDate27 = property18.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate29 = localDate27.withDayOfYear((int) (short) 10);
        boolean boolean30 = localDate11.isAfter((org.joda.time.ReadablePartial) localDate29);
        long long32 = copticChronology0.set((org.joda.time.ReadablePartial) localDate11, 240084L);
        org.joda.time.DateMidnight dateMidnight33 = localDate11.toDateMidnight();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2758760L + "'", long5 == 2758760L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "year" + "'", str26.equals("year"));
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-52080278159916L) + "'", long32 == (-52080278159916L));
        org.junit.Assert.assertNotNull(dateMidnight33);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readableDuration8);
        org.joda.time.DateTime dateTime10 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate11 = dateTime6.toLocalDate();
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime6.toYearMonthDay();
        boolean boolean13 = fixedDateTimeZone4.equals((java.lang.Object) yearMonthDay12);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        int int3 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(3939);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone5);
        java.util.Locale locale7 = dateTimeFormatter6.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(locale7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeField dateTimeField4 = delegatedDateTimeField3.getWrappedField();
        long long6 = delegatedDateTimeField3.roundCeiling(0L);
        long long8 = delegatedDateTimeField3.roundHalfEven(7L);
        java.lang.String str10 = delegatedDateTimeField3.getAsText((long) 1969);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DurationField durationField7 = property5.getDurationField();
        org.joda.time.DateTime dateTime8 = property5.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(480);
        int int37 = property34.getMaximumValueOverall();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 292278993 + "'", int37 == 292278993);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(2, 58696, 480, 58693, 7, 60662, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58693 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        try {
            long long7 = gJChronology1.getDateTimeMillis((-81595), (-1), (-292273085), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = dateTimeZone1.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("888");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"888\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("Pacific Standard Time", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField9.getType();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = copticChronology12.years();
        org.joda.time.DurationField durationField14 = copticChronology12.millis();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = copticChronology15.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField17 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType11, durationField14, durationField16);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "minuteOfDay");
        java.lang.String str20 = illegalFieldValueException19.getFieldName();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "year" + "'", str20.equals("year"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.secondOfDay();
        org.joda.time.DurationField durationField10 = gJChronology7.hours();
        boolean boolean11 = fixedDateTimeZone4.equals((java.lang.Object) gJChronology7);
        long long13 = fixedDateTimeZone4.previousTransition(272L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 272L + "'", long13 == 272L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(47);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.String str8 = dateTime4.toString(dateTimeFormatter7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.secondOfDay();
        org.joda.time.DurationField durationField13 = gJChronology10.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology10.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology10.weekOfWeekyear();
        org.joda.time.DurationField durationField17 = gJChronology10.weeks();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1682-W37" + "'", str8.equals("1682-W37"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (-28800000), (int) (byte) 100, 3939);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3840 + "'", int4 == 3840);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfDay();
        try {
            org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((-81595), (int) (byte) -1, 0, (org.joda.time.Chronology) iSOChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(2440588L, 1845871372800000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1845871370359412L) + "'", long2 == (-1845871370359412L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtMidnight();
        int int5 = localDate1.getMonthOfYear();
        try {
            int int7 = localDate1.getValue(58695);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 58695");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = dateTime4.plus((long) 58695);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.withDurationAdded(readableDuration7, 3939);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendClockhourOfDay(12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.append(dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfMinute((int) '#', 1438);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = localDate2.isSupported(dateTimeFieldType3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekyear((int) '#');
        org.joda.time.LocalDate localDate8 = localDate2.minusDays(2922789);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = copticChronology9.halfdays();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology9.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        int[] intArray21 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray23 = delegatedDateTimeField12.set((org.joda.time.ReadablePartial) localDate15, 0, intArray21, (int) (byte) 10);
        copticChronology0.validate((org.joda.time.ReadablePartial) localDate2, intArray23);
        org.joda.time.LocalDate localDate26 = localDate2.plusDays(365);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.LocalDate localDate29 = localDate26.withPeriodAdded(readablePeriod27, 70);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(localDate29);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        java.lang.String str14 = property6.getName();
        org.joda.time.LocalDate localDate15 = property6.roundFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate18 = localDate15.withPeriodAdded(readablePeriod16, (int) (short) 0);
        org.joda.time.LocalDate.Property property19 = localDate18.yearOfEra();
        try {
            org.joda.time.LocalDate localDate21 = property19.setCopy(292280962);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292280962 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(31);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(0);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("1732-W06", true);
        java.lang.String str8 = dateTimeZone7.toString();
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1732-W06" + "'", str8.equals("1732-W06"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(1, false);
        boolean boolean14 = dateTimeFormatterBuilder10.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
        org.joda.time.DateTime dateTime8 = property3.addToCopy((int) (short) 10);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTime dateTime10 = property9.roundFloorCopy();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property9.getAsShortText(locale11);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24526 + "'", int1 == 24526);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "24526" + "'", str12.equals("24526"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime.Property property4 = dateTime0.dayOfYear();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.LocalDate.Property property2 = localDate1.centuryOfEra();
        java.lang.Object obj3 = null;
        boolean boolean4 = property2.equals(obj3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate10 = dateTime5.toLocalDate();
        org.joda.time.LocalDate localDate12 = localDate10.withDayOfMonth((int) (byte) 1);
        int int13 = property2.compareTo((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate localDate14 = property2.getLocalDate();
        org.joda.time.ReadablePartial readablePartial15 = null;
        try {
            boolean boolean16 = localDate14.isBefore(readablePartial15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField37 = property34.getRangeDurationField();
        org.joda.time.Partial partial38 = property34.getPartial();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
        try {
            org.joda.time.Partial partial41 = partial38.withField(dateTimeFieldType39, 58693);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertNotNull(partial38);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        java.io.Writer writer4 = null;
        try {
            dateTimeFormatter2.printTo(writer4, (long) 960);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        java.lang.String str14 = property6.toString();
        org.joda.time.LocalDate localDate16 = property6.setCopy(19);
        org.joda.time.LocalDate localDate18 = localDate16.plusDays(69);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.Interval interval20 = localDate16.toInterval(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[year]" + "'", str14.equals("Property[year]"));
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(interval20);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        java.lang.String str14 = property6.getName();
        org.joda.time.LocalDate localDate15 = property6.roundFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate18 = localDate15.withPeriodAdded(readablePeriod16, (int) (short) 0);
        org.joda.time.LocalDate localDate20 = localDate15.withWeekyear((-81595));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        java.lang.String str14 = property6.getName();
        org.joda.time.LocalDate localDate15 = property6.roundFloorCopy();
        org.joda.time.LocalDate localDate16 = property6.getLocalDate();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        long long15 = offsetDateTimeField9.roundHalfCeiling((long) (-1));
        int int16 = offsetDateTimeField9.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(10L, dateTimeZone18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = localDate19.indexOf(dateTimeFieldType20);
        org.joda.time.DateMidnight dateMidnight22 = localDate19.toDateMidnight();
        org.joda.time.LocalDate.Property property23 = localDate19.year();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(10L, dateTimeZone25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        int int28 = localDate26.indexOf(dateTimeFieldType27);
        org.joda.time.DateMidnight dateMidnight29 = localDate26.toDateMidnight();
        long long30 = property23.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight29);
        org.joda.time.LocalDate localDate31 = property23.roundHalfEvenCopy();
        java.lang.String str32 = localDate31.toString();
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = copticChronology34.years();
        org.joda.time.DurationField durationField36 = copticChronology34.millis();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(10L, dateTimeZone38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        int int41 = localDate39.indexOf(dateTimeFieldType40);
        int[] intArray43 = copticChronology34.get((org.joda.time.ReadablePartial) localDate39, 0L);
        try {
            int[] intArray45 = offsetDateTimeField9.addWrapPartial((org.joda.time.ReadablePartial) localDate31, (int) '#', intArray43, 58);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 292280962 + "'", int16 == 292280962);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1970-01-01" + "'", str32.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.years();
        org.joda.time.DurationField durationField2 = copticChronology0.millis();
        org.joda.time.DurationField durationField3 = copticChronology0.millis();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 58698, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
        org.joda.time.DateTime dateTime8 = property3.addToCopy(1L);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime8.isSupported(dateTimeFieldType11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.secondOfDay();
        org.joda.time.DurationField durationField17 = gJChronology14.halfdays();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime19 = dateTime18.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.minus(readableDuration20);
        org.joda.time.DateTime.Property property22 = dateTime18.dayOfYear();
        boolean boolean23 = gJChronology14.equals((java.lang.Object) dateTime18);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime8.toMutableDateTime((org.joda.time.Chronology) gJChronology14);
        try {
            long long29 = gJChronology14.getDateTimeMillis((int) (short) -1, 278, 1438, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 278 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24526 + "'", int1 == 24526);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(mutableDateTime24);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("[year=1969, monthOfYear=12, dayOfMonth=31]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"[year=1969, monthOfYear=12, dayOfMonth=31]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("DateTimeField[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'DateTimeField[year]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate2.plus(readablePeriod6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight12 = localDate2.toDateMidnight(dateTimeZone9);
        int int14 = localDate2.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate16 = localDate2.minusMonths(57600);
        int int17 = localDate2.getYearOfEra();
        org.joda.time.LocalDate localDate19 = localDate2.withCenturyOfEra(9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(localDate19);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate2.plus(readablePeriod6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight12 = localDate2.toDateMidnight(dateTimeZone9);
        java.util.Locale locale13 = null;
        java.util.Calendar calendar14 = dateMidnight12.toCalendar(locale13);
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.fromCalendarFields(calendar14);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(10L, dateTimeZone17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        int int20 = localDate18.indexOf(dateTimeFieldType19);
        org.joda.time.DateMidnight dateMidnight21 = localDate18.toDateMidnight();
        org.joda.time.LocalDate.Property property22 = localDate18.year();
        org.joda.time.DateTimeField dateTimeField23 = property22.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField25.getType();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(10L, dateTimeZone28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate29);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(10L, dateTimeZone32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
        int int35 = localDate33.indexOf(dateTimeFieldType34);
        org.joda.time.DateMidnight dateMidnight36 = localDate33.toDateMidnight();
        org.joda.time.LocalDate.Property property37 = localDate33.year();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(10L, dateTimeZone39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
        int int42 = localDate40.indexOf(dateTimeFieldType41);
        org.joda.time.DateMidnight dateMidnight43 = localDate40.toDateMidnight();
        long long44 = property37.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight43);
        java.lang.String str45 = property37.getName();
        org.joda.time.LocalDate localDate46 = property37.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate48 = localDate46.withDayOfYear(100);
        boolean boolean49 = partial30.isMatch((org.joda.time.ReadablePartial) localDate46);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate(10L, dateTimeZone51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
        int int54 = localDate52.indexOf(dateTimeFieldType53);
        org.joda.time.DateMidnight dateMidnight55 = localDate52.toDateMidnight();
        org.joda.time.LocalDate.Property property56 = localDate52.year();
        org.joda.time.DateTimeField dateTimeField57 = property56.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = offsetDateTimeField59.getType();
        org.joda.time.Partial.Property property61 = partial30.property(dateTimeFieldType60);
        org.joda.time.Partial partial63 = property61.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField64 = property61.getRangeDurationField();
        java.lang.String str65 = property61.getAsString();
        org.joda.time.DurationField durationField66 = property61.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.LocalDate localDate69 = new org.joda.time.LocalDate(10L, dateTimeZone68);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = null;
        int int71 = localDate69.indexOf(dateTimeFieldType70);
        org.joda.time.DateMidnight dateMidnight72 = localDate69.toDateMidnight();
        org.joda.time.LocalDate.Property property73 = localDate69.year();
        org.joda.time.DateTimeField dateTimeField74 = property73.getField();
        java.lang.String str75 = property73.getAsString();
        java.lang.String str76 = property73.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = property73.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField79 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField25, durationField66, dateTimeFieldType77, 100);
        int int80 = localDate15.get(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(calendar14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "year" + "'", str45.equals("year"));
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(partial63);
        org.junit.Assert.assertNull(durationField64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1969" + "'", str65.equals("1969"));
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight72);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1969" + "'", str75.equals("1969"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "year" + "'", str76.equals("year"));
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1969 + "'", int80 == 1969);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = copticChronology1.years();
        org.joda.time.DurationField durationField3 = copticChronology1.millis();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = copticChronology1.add(readablePeriod4, (long) (byte) 1, (int) (short) 10);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((-28799993L), (org.joda.time.Chronology) copticChronology1);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readableDuration14);
        org.joda.time.DateTime dateTime16 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
        java.util.Date date18 = dateTime16.toDate();
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance(chronology3, readableDateTime11, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, 240084L, 7);
        org.joda.time.Chronology chronology26 = limitChronology19.withZone(dateTimeZone22);
        org.joda.time.DurationField durationField27 = limitChronology19.seconds();
        org.joda.time.DateTime dateTime28 = limitChronology19.getLowerLimit();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNull(dateTime28);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        long long5 = iSOChronology0.add(3600100L, (long) 1439, 69);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3699391L + "'", long5 == 3699391L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap13);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap13);
        dateTimeFormatterBuilder16.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(strMap13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter7.withDefaultYear(57601);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter7.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder16.append(dateTimeParser21);
        org.joda.time.format.DateTimePrinter dateTimePrinter23 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeParser dateTimeParser28 = dateTimeFormatterBuilder24.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter23, dateTimeParser28);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray30 = new org.joda.time.format.DateTimeParser[] { dateTimeParser13, dateTimeParser15, dateTimeParser21, dateTimeParser28 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder6.append(dateTimePrinter11, dateTimeParserArray30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder6.appendWeekOfWeekyear(31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(strMap5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeParser28);
        org.junit.Assert.assertNotNull(dateTimeParserArray30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        boolean boolean11 = delegatedDateTimeField7.isLenient();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(10L, dateTimeZone13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = localDate14.indexOf(dateTimeFieldType15);
        org.joda.time.DateMidnight dateMidnight17 = localDate14.toDateMidnight();
        org.joda.time.LocalDate.Property property18 = localDate14.year();
        org.joda.time.DateTimeField dateTimeField19 = property18.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 1969);
        boolean boolean22 = offsetDateTimeField21.isLenient();
        long long25 = offsetDateTimeField21.addWrapField(31449600000L, 0);
        int int27 = offsetDateTimeField21.get((long) (byte) 100);
        long long30 = offsetDateTimeField21.add(2758760L, (long) 'a');
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime32 = dateTime31.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.minus(readableDuration33);
        org.joda.time.DateTime dateTime35 = dateTime31.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate36 = dateTime31.toLocalDate();
        org.joda.time.YearMonthDay yearMonthDay37 = dateTime31.toYearMonthDay();
        int int38 = offsetDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay37);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate(10L, dateTimeZone40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
        int int43 = localDate41.indexOf(dateTimeFieldType42);
        org.joda.time.DateMidnight dateMidnight44 = localDate41.toDateMidnight();
        org.joda.time.LocalDate.Property property45 = localDate41.year();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(10L, dateTimeZone47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        int int50 = localDate48.indexOf(dateTimeFieldType49);
        org.joda.time.DateMidnight dateMidnight51 = localDate48.toDateMidnight();
        long long52 = property45.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight51);
        java.lang.String str53 = property45.getName();
        org.joda.time.LocalDate localDate54 = property45.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate56 = localDate54.withDayOfYear((int) (short) 10);
        int int57 = localDate56.getEra();
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDate56, 0, locale59);
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField63 = copticChronology62.halfdays();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology62.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField64);
        org.joda.time.DateTime dateTime66 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime67 = dateTime66.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate68 = dateTime67.toLocalDate();
        int[] intArray74 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray76 = delegatedDateTimeField65.set((org.joda.time.ReadablePartial) localDate68, 0, intArray74, (int) (byte) 10);
        int[] intArray78 = delegatedDateTimeField7.set((org.joda.time.ReadablePartial) localDate56, (int) (byte) 0, intArray76, 10);
        int int80 = delegatedDateTimeField7.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3939 + "'", int27 == 3939);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3061068358760L + "'", long30 == 3061068358760L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(yearMonthDay37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-292273085) + "'", int38 == (-292273085));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "year" + "'", str53.equals("year"));
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "0" + "'", str60.equals("0"));
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1439 + "'", int80 == 1439);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        java.lang.String str14 = property6.getName();
        org.joda.time.LocalDate localDate15 = property6.roundFloorCopy();
        org.joda.time.LocalDate localDate16 = property6.roundHalfEvenCopy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        java.lang.String str4 = partial3.toStringList();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        int int9 = localDate7.indexOf(dateTimeFieldType8);
        org.joda.time.DateMidnight dateMidnight10 = localDate7.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        int int15 = localDate7.compareTo((org.joda.time.ReadablePartial) localDate13);
        boolean boolean16 = partial3.isMatch((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.Chronology chronology17 = partial3.getChronology();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(10L, dateTimeZone19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        int int22 = localDate20.indexOf(dateTimeFieldType21);
        org.joda.time.DateMidnight dateMidnight23 = localDate20.toDateMidnight();
        org.joda.time.LocalDate.Property property24 = localDate20.year();
        org.joda.time.DateTimeField dateTimeField25 = property24.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 1969);
        boolean boolean28 = offsetDateTimeField27.isLenient();
        long long31 = offsetDateTimeField27.addWrapField(31449600000L, 0);
        int int33 = offsetDateTimeField27.get((long) (byte) 100);
        long long35 = offsetDateTimeField27.roundHalfCeiling((long) 31);
        java.lang.String str37 = offsetDateTimeField27.getAsText((-53162697541304L));
        int int38 = offsetDateTimeField27.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, (org.joda.time.DateTimeField) offsetDateTimeField27);
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getChronology(chronology17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str4.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31449600000L + "'", long31 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3939 + "'", int33 == 3939);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2254" + "'", str37.equals("2254"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-292273085) + "'", int38 == (-292273085));
        org.junit.Assert.assertNotNull(chronology40);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readableDuration14);
        org.joda.time.DateTime dateTime16 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
        java.util.Date date18 = dateTime16.toDate();
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance(chronology3, readableDateTime11, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.DateTime dateTime20 = limitChronology19.getUpperLimit();
        org.joda.time.DateTime dateTime21 = limitChronology19.getLowerLimit();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNull(dateTime21);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = localDate2.isSupported(dateTimeFieldType3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekyear((int) '#');
        org.joda.time.LocalDate localDate8 = localDate2.minusDays(2922789);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate2);
        java.io.Writer writer10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(dateTimeZone11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = localDate12.isSupported(dateTimeFieldType13);
        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) '#');
        org.joda.time.LocalTime localTime17 = null;
        org.joda.time.DateTime dateTime18 = localDate16.toDateTime(localTime17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) '4');
        try {
            dateTimeFormatter0.printTo(writer10, (org.joda.time.ReadableInstant) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19691228T������" + "'", str9.equals("19691228T������"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfHour(58693, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendYear(292278993, 1439);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        int int5 = localDate3.indexOf(dateTimeFieldType4);
        org.joda.time.DateMidnight dateMidnight6 = localDate3.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate3.year();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField10.getType();
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = copticChronology13.years();
        org.joda.time.DurationField durationField15 = copticChronology13.millis();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField17 = copticChronology16.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField18 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType12, durationField15, durationField17);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        long long15 = offsetDateTimeField9.roundHalfFloor(31449600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31536000000L + "'", long15 == 31536000000L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfHour(58693, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime0.withYear((int) (short) 100);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.minus(readableDuration6);
        org.joda.time.DateTime dateTime8 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.minus(readablePeriod9);
        int int11 = dateTime0.compareTo((org.joda.time.ReadableInstant) dateTime10);
        try {
            org.joda.time.DateTime dateTime15 = dateTime10.withDate(47, (int) (byte) 100, 58698);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = localDate3.isSupported(dateTimeFieldType4);
        org.joda.time.LocalDate localDate7 = localDate3.withWeekyear((int) '#');
        org.joda.time.LocalDate localDate9 = localDate3.minusDays(2922789);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = copticChronology10.halfdays();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime14.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
        int[] intArray22 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray24 = delegatedDateTimeField13.set((org.joda.time.ReadablePartial) localDate16, 0, intArray22, (int) (byte) 10);
        copticChronology1.validate((org.joda.time.ReadablePartial) localDate3, intArray24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (byte) 100, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTime.Property property27 = dateTime26.dayOfWeek();
        org.joda.time.DateTime dateTime29 = dateTime26.plusYears(19);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField37 = property34.getRangeDurationField();
        java.lang.String str38 = property34.getAsText();
        org.joda.time.Partial partial40 = property34.addWrapFieldToCopy(16);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969" + "'", str38.equals("1969"));
        org.junit.Assert.assertNotNull(partial40);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.LocalDate localDate6 = localDate2.withPeriodAdded(readablePeriod4, 16);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate8 = localDate6.plus(readablePeriod7);
        java.util.Date date9 = localDate8.toDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField37 = property34.getRangeDurationField();
        java.lang.String str38 = property34.getAsString();
        java.util.Locale locale40 = null;
        try {
            org.joda.time.Partial partial41 = property34.setCopy("1969-12-31", locale40);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969" + "'", str38.equals("1969"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = localDate2.isSupported(dateTimeFieldType3);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekyear((int) '#');
        org.joda.time.LocalDate localDate8 = localDate2.minusDays(2922789);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = copticChronology9.halfdays();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology9.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        int[] intArray21 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray23 = delegatedDateTimeField12.set((org.joda.time.ReadablePartial) localDate15, 0, intArray21, (int) (byte) 10);
        copticChronology0.validate((org.joda.time.ReadablePartial) localDate2, intArray23);
        org.joda.time.LocalDate localDate26 = localDate2.plusDays(365);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(10L, dateTimeZone28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate29);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(10L, dateTimeZone32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
        int int35 = localDate33.indexOf(dateTimeFieldType34);
        org.joda.time.DateMidnight dateMidnight36 = localDate33.toDateMidnight();
        org.joda.time.LocalDate.Property property37 = localDate33.year();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(10L, dateTimeZone39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
        int int42 = localDate40.indexOf(dateTimeFieldType41);
        org.joda.time.DateMidnight dateMidnight43 = localDate40.toDateMidnight();
        long long44 = property37.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight43);
        java.lang.String str45 = property37.getName();
        org.joda.time.LocalDate localDate46 = property37.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate48 = localDate46.withDayOfYear(100);
        boolean boolean49 = partial30.isMatch((org.joda.time.ReadablePartial) localDate46);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = null;
        org.joda.time.Partial partial51 = partial30.without(dateTimeFieldType50);
        boolean boolean52 = localDate2.isAfter((org.joda.time.ReadablePartial) partial30);
        java.lang.String str53 = partial30.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "year" + "'", str45.equals("year"));
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(partial51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1969-12-31" + "'", str53.equals("1969-12-31"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        int int37 = partial36.size();
        java.lang.String str38 = partial36.toString();
        org.joda.time.DurationFieldType durationFieldType39 = null;
        try {
            org.joda.time.Partial partial41 = partial36.withFieldAddWrapped(durationFieldType39, 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1988-12-31" + "'", str38.equals("1988-12-31"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        long long5 = delegatedDateTimeField3.roundHalfCeiling((long) 84);
        java.lang.String str7 = delegatedDateTimeField3.getAsShortText((long) 58693);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(10L, dateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = localDate10.indexOf(dateTimeFieldType11);
        org.joda.time.DateMidnight dateMidnight13 = localDate10.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate16);
        int int18 = localDate10.compareTo((org.joda.time.ReadablePartial) localDate16);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) localDate16, 1969, locale20);
        java.lang.String str22 = delegatedDateTimeField3.getName();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969" + "'", str21.equals("1969"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "minuteOfDay" + "'", str22.equals("minuteOfDay"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, (int) 'a');
        org.joda.time.Instant instant5 = instant0.withMillis((long) 69);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        int[] intArray12 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray14 = delegatedDateTimeField3.set((org.joda.time.ReadablePartial) localDate6, 0, intArray12, (int) (byte) 10);
        int int15 = localDate6.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) ' ');
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(dateTimeFieldType2);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) '#');
        org.joda.time.LocalTime localTime6 = null;
        org.joda.time.DateTime dateTime7 = localDate5.toDateTime(localTime6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.joda.time.DateTime dateTime13 = property11.addToCopy((int) (short) 1);
        org.joda.time.DateTime dateTime14 = dateTime13.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        org.joda.time.LocalDate localDate14 = property6.roundHalfEvenCopy();
        int int15 = property6.getMinimumValueOverall();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-292275054) + "'", int15 == (-292275054));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        java.lang.String str14 = property6.getName();
        long long15 = property6.remainder();
        org.joda.time.LocalDate localDate16 = property6.roundHalfCeilingCopy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31449600000L + "'", long15 == 31449600000L);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.TimeOfDay timeOfDay2 = dateTime1.toTimeOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(timeOfDay2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str8 = cachedDateTimeZone6.getNameKey((long) (short) 100);
        int int10 = cachedDateTimeZone6.getStandardOffset((-2699186731622000L));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[year]" + "'", str8.equals("Property[year]"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        int int5 = localDate3.indexOf(dateTimeFieldType4);
        org.joda.time.DateMidnight dateMidnight6 = localDate3.toDateMidnight();
        org.joda.time.LocalDate.Property property7 = localDate3.year();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField10.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfDay(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(58697);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(0, 2922789);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatterBuilder5.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendHourOfDay(960);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = gJChronology1.minutes();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        int int7 = localDate5.indexOf(dateTimeFieldType6);
        org.joda.time.DateMidnight dateMidnight8 = localDate5.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate5.year();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(10L, dateTimeZone11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        int int14 = localDate12.indexOf(dateTimeFieldType13);
        org.joda.time.DateMidnight dateMidnight15 = localDate12.toDateMidnight();
        long long16 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight15);
        java.lang.String str17 = property9.getName();
        long long18 = property9.remainder();
        org.joda.time.DurationField durationField19 = property9.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(10L, dateTimeZone21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(10L, dateTimeZone25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        int int28 = localDate26.indexOf(dateTimeFieldType27);
        org.joda.time.DateMidnight dateMidnight29 = localDate26.toDateMidnight();
        org.joda.time.LocalDate.Property property30 = localDate26.year();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(10L, dateTimeZone32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
        int int35 = localDate33.indexOf(dateTimeFieldType34);
        org.joda.time.DateMidnight dateMidnight36 = localDate33.toDateMidnight();
        long long37 = property30.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight36);
        java.lang.String str38 = property30.getName();
        org.joda.time.LocalDate localDate39 = property30.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate41 = localDate39.withDayOfYear(100);
        boolean boolean42 = partial23.isMatch((org.joda.time.ReadablePartial) localDate39);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(10L, dateTimeZone44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
        int int47 = localDate45.indexOf(dateTimeFieldType46);
        org.joda.time.DateMidnight dateMidnight48 = localDate45.toDateMidnight();
        org.joda.time.LocalDate.Property property49 = localDate45.year();
        org.joda.time.DateTimeField dateTimeField50 = property49.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = offsetDateTimeField52.getType();
        org.joda.time.Partial.Property property54 = partial23.property(dateTimeFieldType53);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, durationField19, dateTimeFieldType53);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "year" + "'", str17.equals("year"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 31449600000L + "'", long18 == 31449600000L);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "year" + "'", str38.equals("year"));
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(property54);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter3.getZone();
        boolean boolean5 = dateTimeFormatter3.isParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.append(dateTimeFormatter3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendFractionOfMinute(0, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(dateTimeZone2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = localDate3.isSupported(dateTimeFieldType4);
        org.joda.time.LocalDate localDate7 = localDate3.withWeekyear((int) '#');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(10L, dateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = localDate10.indexOf(dateTimeFieldType11);
        org.joda.time.DateMidnight dateMidnight13 = localDate10.toDateMidnight();
        org.joda.time.LocalDate.Property property14 = localDate10.year();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        org.joda.time.DateMidnight dateMidnight20 = localDate17.toDateMidnight();
        long long21 = property14.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight20);
        java.lang.String str22 = property14.getName();
        org.joda.time.LocalDate localDate23 = property14.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate25 = localDate23.withDayOfYear((int) (short) 10);
        boolean boolean26 = localDate7.isAfter((org.joda.time.ReadablePartial) localDate25);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 1);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone33);
        boolean boolean35 = fixedDateTimeZone31.equals((java.lang.Object) dateTimeZone33);
        org.joda.time.DateTime dateTime36 = localDate7.toDateTimeAtMidnight(dateTimeZone33);
        org.joda.time.DateTime dateTime38 = dateTime36.plus(0L);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "year" + "'", str22.equals("year"));
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        boolean boolean5 = dateTime1.isBefore((long) 4);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, (int) 'a');
        org.joda.time.Instant instant10 = instant6.toInstant();
        org.joda.time.Chronology chronology11 = instant10.getChronology();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0, 0, 70, 0, 0, 0, chronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField2 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        long long6 = copticChronology0.getDateTimeMillis((int) (byte) 1, 9, (int) (byte) 10, 58696);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((org.joda.time.Chronology) copticChronology0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-53162697541304L) + "'", long6 == (-53162697541304L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(zonedChronology10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField37 = property34.getRangeDurationField();
        org.joda.time.Partial partial38 = property34.getPartial();
        org.joda.time.Partial partial39 = property34.getPartial();
        int int40 = property34.getMinimumValueOverall();
        java.lang.Object obj41 = null;
        boolean boolean42 = property34.equals(obj41);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertNotNull(partial38);
        org.junit.Assert.assertNotNull(partial39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-292275054) + "'", int40 == (-292275054));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        long long5 = dateTimeZone1.convertLocalToUTC(31449600000L, true);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 84);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31478400000L + "'", long5 == 31478400000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = gJChronology1.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalTime localTime9 = null;
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.DateTime dateTime12 = localDate7.toDateTime(localTime9, dateTimeZone11);
        java.lang.String str13 = dateTimeZone11.getID();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.Chronology chronology15 = gJChronology1.withZone(dateTimeZone11);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology1);
        try {
            long long22 = gJChronology1.getDateTimeMillis(0L, 480, (int) (byte) 1, (-28800000), 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 480 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("1682-W38");
        java.lang.String str2 = illegalInstantException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.joda.time.IllegalInstantException: 1682-W38" + "'", str2.equals("org.joda.time.IllegalInstantException: 1682-W38"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology5);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(47);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond(9);
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime11.toMutableDateTime();
        long long15 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime14);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField9.getType();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = copticChronology12.years();
        org.joda.time.DurationField durationField14 = copticChronology12.millis();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = copticChronology15.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField17 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType11, durationField14, durationField16);
        org.joda.time.DurationField durationField18 = preciseDateTimeField17.getDurationField();
        long long21 = preciseDateTimeField17.addWrapField((long) 57601439, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 57601438L + "'", long21 == 57601438L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalInstantException: ", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalInstantException: /ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getSecondOfDay();
        int int2 = dateTime0.getEra();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime();
        org.joda.time.Instant instant4 = dateTime0.toInstant();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24526 + "'", int1 == 24526);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readableDuration8);
        org.joda.time.DateTime dateTime10 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate11 = dateTime6.toLocalDate();
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime6.toYearMonthDay();
        boolean boolean13 = fixedDateTimeZone4.equals((java.lang.Object) yearMonthDay12);
        long long15 = fixedDateTimeZone4.nextTransition(2209L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 57601439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57601439");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2209L + "'", long15 == 2209L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendWeekyear(60662, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        int int11 = localDate9.indexOf(dateTimeFieldType10);
        org.joda.time.DateMidnight dateMidnight12 = localDate9.toDateMidnight();
        long long13 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight12);
        java.lang.String str14 = property6.getName();
        org.joda.time.LocalDate localDate15 = property6.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate17 = localDate15.withDayOfYear((int) (short) 10);
        int int18 = localDate17.getEra();
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20);
        org.joda.time.DateMidnight dateMidnight22 = localDate17.toDateMidnight(dateTimeZone20);
        int int23 = dateMidnight22.getMillisOfSecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "19691231T������");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T������" + "'", str5.equals("19691231T������"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        int int15 = offsetDateTimeField9.get((long) (byte) 100);
        int int16 = offsetDateTimeField9.getMinimumValue();
        long long18 = offsetDateTimeField9.roundHalfEven((long) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        org.joda.time.Partial partial22 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate21);
        java.lang.String str23 = partial22.toStringList();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(10L, dateTimeZone25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        int int28 = localDate26.indexOf(dateTimeFieldType27);
        org.joda.time.DateMidnight dateMidnight29 = localDate26.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(10L, dateTimeZone31);
        org.joda.time.Partial partial33 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate32);
        int int34 = localDate26.compareTo((org.joda.time.ReadablePartial) localDate32);
        boolean boolean35 = partial22.isMatch((org.joda.time.ReadablePartial) localDate32);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.Interval interval37 = localDate32.toInterval(dateTimeZone36);
        int[] intArray43 = new int[] { 100, 31, 58695, 'a', 10 };
        int int44 = offsetDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) localDate32, intArray43);
        org.joda.time.DurationField durationField45 = offsetDateTimeField9.getLeapDurationField();
        int int47 = offsetDateTimeField9.getMaximumValue(240084L);
        int int48 = offsetDateTimeField9.getOffset();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate(10L, dateTimeZone50);
        org.joda.time.Partial partial52 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate51);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(10L, dateTimeZone54);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
        int int57 = localDate55.indexOf(dateTimeFieldType56);
        org.joda.time.DateMidnight dateMidnight58 = localDate55.toDateMidnight();
        org.joda.time.LocalDate.Property property59 = localDate55.year();
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate(10L, dateTimeZone61);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = null;
        int int64 = localDate62.indexOf(dateTimeFieldType63);
        org.joda.time.DateMidnight dateMidnight65 = localDate62.toDateMidnight();
        long long66 = property59.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight65);
        java.lang.String str67 = property59.getName();
        org.joda.time.LocalDate localDate68 = property59.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate70 = localDate68.withDayOfYear(100);
        boolean boolean71 = partial52.isMatch((org.joda.time.ReadablePartial) localDate68);
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate(10L, dateTimeZone73);
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = null;
        int int76 = localDate74.indexOf(dateTimeFieldType75);
        org.joda.time.DateMidnight dateMidnight77 = localDate74.toDateMidnight();
        org.joda.time.LocalDate.Property property78 = localDate74.year();
        org.joda.time.DateTimeField dateTimeField79 = property78.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField81 = new org.joda.time.field.OffsetDateTimeField(dateTimeField79, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = offsetDateTimeField81.getType();
        org.joda.time.Partial.Property property83 = partial52.property(dateTimeFieldType82);
        org.joda.time.Partial partial85 = property83.addWrapFieldToCopy(19);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray86 = partial85.getFieldTypes();
        int int87 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) partial85);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3939 + "'", int15 == 3939);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-292273085) + "'", int16 == (-292273085));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str23.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(interval37);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 292280962 + "'", int44 == 292280962);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 292280962 + "'", int47 == 292280962);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1969 + "'", int48 == 1969);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "year" + "'", str67.equals("year"));
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertNotNull(localDate70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight77);
        org.junit.Assert.assertNotNull(property78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertNotNull(property83);
        org.junit.Assert.assertNotNull(partial85);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-292273085) + "'", int87 == (-292273085));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
        org.joda.time.DateTime dateTime8 = property3.addToCopy(1L);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = copticChronology11.halfdays();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        long long16 = delegatedDateTimeField14.roundHalfCeiling((long) 84);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField14.getType();
        int int18 = dateTime8.get(dateTimeFieldType17);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, "1732-W06");
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24526 + "'", int1 == 24526);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 408 + "'", int18 == 408);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.LocalTime localTime1 = dateTime0.toLocalTime();
        org.junit.Assert.assertNotNull(localTime1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        java.util.Locale locale4 = null;
        int int5 = delegatedDateTimeField3.getMaximumShortTextLength(locale4);
        java.util.Locale locale6 = null;
        int int7 = delegatedDateTimeField3.getMaximumShortTextLength(locale6);
        int int8 = delegatedDateTimeField3.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1439 + "'", int8 == 1439);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfDay(23);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        int int7 = dateTime6.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime8 = dateTime6.toLocalDateTime();
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.DateTime dateTime12 = property9.addToCopy((long) 58696);
        org.joda.time.DateTime dateTime14 = property9.addToCopy(1L);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.minus(readableDuration15);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = copticChronology17.halfdays();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology17.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        long long22 = delegatedDateTimeField20.roundHalfCeiling((long) 84);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField20.getType();
        int int24 = dateTime14.get(dateTimeFieldType23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType23, 12, 960);
        boolean boolean28 = dateTimeFormatterBuilder27.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendLiteral("December");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendTwoDigitYear((-81595), false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24526 + "'", int7 == 24526);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 408 + "'", int24 == 408);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfDay(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfHour(58697);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(0, 2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendWeekOfWeekyear(57600);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4) + "'", int1 == (-4));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendWeekyear((int) (short) 1, 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate16);
        java.lang.String str18 = partial17.toStringList();
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = copticChronology19.halfdays();
        org.joda.time.DateTimeField dateTimeField21 = copticChronology19.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        long long24 = delegatedDateTimeField22.roundHalfCeiling((long) 84);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(10L, dateTimeZone26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        int int29 = localDate27.indexOf(dateTimeFieldType28);
        org.joda.time.DateMidnight dateMidnight30 = localDate27.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.LocalDate localDate32 = localDate27.plus(readablePeriod31);
        java.util.TimeZone timeZone33 = null;
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forTimeZone(timeZone33);
        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight37 = localDate27.toDateMidnight(dateTimeZone34);
        int int39 = localDate27.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate41 = localDate27.minusMonths(57600);
        org.joda.time.Partial partial42 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate27);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.Partial partial44 = partial42.plus(readablePeriod43);
        int int45 = delegatedDateTimeField22.getMaximumValue((org.joda.time.ReadablePartial) partial44);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(10L, dateTimeZone47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        int int50 = localDate48.indexOf(dateTimeFieldType49);
        org.joda.time.DateMidnight dateMidnight51 = localDate48.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        org.joda.time.LocalDate localDate53 = localDate48.plus(readablePeriod52);
        org.joda.time.chrono.CopticChronology copticChronology54 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField55 = copticChronology54.years();
        org.joda.time.DurationField durationField56 = copticChronology54.millis();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate(10L, dateTimeZone58);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = null;
        int int61 = localDate59.indexOf(dateTimeFieldType60);
        int[] intArray63 = copticChronology54.get((org.joda.time.ReadablePartial) localDate59, 0L);
        int int64 = delegatedDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) localDate48, intArray63);
        int int65 = offsetDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) partial17, intArray63);
        java.util.Locale locale67 = null;
        java.lang.String str68 = offsetDateTimeField9.getAsText((long) 1438, locale67);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str18.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(partial44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1439 + "'", int45 == 1439);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight51);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(copticChronology54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 292280962 + "'", int65 == 292280962);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "3939" + "'", str68.equals("3939"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate2.plus(readablePeriod6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight12 = localDate2.toDateMidnight(dateTimeZone9);
        boolean boolean13 = dateMidnight12.isBeforeNow();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalTime localTime4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime11.withTimeAtStartOfDay();
        boolean boolean13 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime7.plusHours(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(0);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime15.getZone();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalTime localTime4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime11.withTimeAtStartOfDay();
        boolean boolean13 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime7.plusHours(0);
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(100L, 19);
        org.joda.time.DateTime dateTime19 = dateTime18.toDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField9.getType();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = copticChronology12.years();
        org.joda.time.DurationField durationField14 = copticChronology12.millis();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = copticChronology15.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField17 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType11, durationField14, durationField16);
        long long18 = preciseDateTimeField17.getUnitMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime0.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        int int15 = offsetDateTimeField9.get((long) (byte) 100);
        org.joda.time.DurationField durationField16 = offsetDateTimeField9.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(10L, dateTimeZone18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = localDate19.indexOf(dateTimeFieldType20);
        org.joda.time.DateMidnight dateMidnight22 = localDate19.toDateMidnight();
        org.joda.time.LocalDate.Property property23 = localDate19.year();
        org.joda.time.DateTimeField dateTimeField24 = property23.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 1969);
        boolean boolean27 = offsetDateTimeField26.isLenient();
        long long30 = offsetDateTimeField26.addWrapField(31449600000L, 0);
        int int32 = offsetDateTimeField26.get((long) (byte) 100);
        long long35 = offsetDateTimeField26.add(2758760L, (long) 'a');
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime37 = dateTime36.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime36.minus(readableDuration38);
        org.joda.time.DateTime dateTime40 = dateTime36.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate41 = dateTime36.toLocalDate();
        org.joda.time.YearMonthDay yearMonthDay42 = dateTime36.toYearMonthDay();
        int int43 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay42);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate(10L, dateTimeZone45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
        int int48 = localDate46.indexOf(dateTimeFieldType47);
        org.joda.time.DateMidnight dateMidnight49 = localDate46.toDateMidnight();
        org.joda.time.LocalDate.Property property50 = localDate46.year();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(10L, dateTimeZone52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        int int55 = localDate53.indexOf(dateTimeFieldType54);
        org.joda.time.DateMidnight dateMidnight56 = localDate53.toDateMidnight();
        long long57 = property50.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight56);
        java.lang.String str58 = property50.getName();
        org.joda.time.LocalDate localDate59 = property50.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate61 = localDate59.withDayOfYear((int) (short) 10);
        int int62 = localDate61.getEra();
        java.util.Locale locale64 = null;
        java.lang.String str65 = offsetDateTimeField26.getAsText((org.joda.time.ReadablePartial) localDate61, 0, locale64);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate61, locale66);
        org.joda.time.ReadablePartial readablePartial68 = null;
        org.joda.time.LocalDate localDate69 = localDate61.withFields(readablePartial68);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3939 + "'", int15 == 3939);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31449600000L + "'", long30 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3939 + "'", int32 == 3939);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3061068358760L + "'", long35 == 3061068358760L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(yearMonthDay42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-292273085) + "'", int43 == (-292273085));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "year" + "'", str58.equals("year"));
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "0" + "'", str65.equals("0"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "1970" + "'", str67.equals("1970"));
        org.junit.Assert.assertNotNull(localDate69);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = property5.addToCopy(0);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.toDateTime(chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        try {
            long long6 = julianChronology0.getDateTimeMillis((-28800000), 84, (int) (byte) -1, 58);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        int int15 = offsetDateTimeField9.get((long) (byte) 100);
        int int16 = offsetDateTimeField9.getMinimumValue();
        long long18 = offsetDateTimeField9.roundHalfEven((long) 1);
        boolean boolean20 = offsetDateTimeField9.isLeap((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType21, 19, (int) (short) 10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3939 + "'", int15 == 3939);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-292273085) + "'", int16 == (-292273085));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        boolean boolean11 = dateTime8.isAfter((long) 100);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        boolean boolean14 = dateTime8.isAfter((org.joda.time.ReadableInstant) dateTime13);
        int int15 = property5.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime17 = dateTime8.withWeekOfWeekyear(9);
        org.joda.time.DateTime dateTime19 = dateTime8.minusWeeks(19);
        org.joda.time.DateTime dateTime20 = dateTime8.toDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 58697);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.centuryOfEra();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray8 = localDate7.getFieldTypes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int8 = cachedDateTimeZone6.getOffset((long) 70);
        java.lang.String str10 = cachedDateTimeZone6.getNameKey((long) ' ');
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[year]" + "'", str10.equals("Property[year]"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
        org.joda.time.DateTime dateTime8 = property3.addToCopy((int) (short) 10);
        org.joda.time.Interval interval9 = property3.toInterval();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval9);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24526 + "'", int1 == 24526);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 292280962, 2758760L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 806333026727120");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField37 = property34.getRangeDurationField();
        java.lang.String str38 = property34.getAsString();
        int int39 = property34.getMinimumValueOverall();
        java.lang.String str40 = property34.getAsString();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969" + "'", str38.equals("1969"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-292275054) + "'", int39 == (-292275054));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1969" + "'", str40.equals("1969"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.Partial partial37 = property34.withMinimumValue();
        boolean boolean38 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) partial37);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray39 = partial37.getFieldTypes();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNotNull(partial37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray39);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.LocalDate localDate8 = property6.withMinimumValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        java.util.Date date6 = dateTime4.toDate();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime8 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.joda.time.Chronology chronology10 = localDate9.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = copticChronology11.halfdays();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        long long16 = delegatedDateTimeField14.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, (org.joda.time.DateTimeField) delegatedDateTimeField14);
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime20 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.minus(readableDuration21);
        org.joda.time.DateTime dateTime23 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property24 = dateTime23.dayOfWeek();
        java.util.Date date25 = dateTime23.toDate();
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance(chronology10, readableDateTime18, (org.joda.time.ReadableDateTime) dateTime23);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, 240084L, 7);
        org.joda.time.Chronology chronology33 = limitChronology26.withZone(dateTimeZone29);
        org.joda.time.DateTime dateTime34 = limitChronology26.getLowerLimit();
        org.joda.time.DateTime dateTime35 = dateTime4.withChronology((org.joda.time.Chronology) limitChronology26);
        try {
            long long43 = limitChronology26.getDateTimeMillis(0, 23, 69, 480, 0, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 480 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DurationField durationField3 = copticChronology0.centuries();
        try {
            long long8 = copticChronology0.getDateTimeMillis(0, (-292275054), 292280962, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = gJChronology1.halfdays();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfYear();
        boolean boolean10 = gJChronology1.equals((java.lang.Object) dateTime5);
        org.joda.time.Chronology chronology11 = gJChronology1.withUTC();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendFractionOfHour(58, 60662);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendWeekOfWeekyear(480);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(58698, '#', 365, (int) (short) -1, (int) (byte) 10, false, (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("America/Los_Angeles", 10);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(10L, dateTimeZone13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = localDate14.indexOf(dateTimeFieldType15);
        org.joda.time.DateMidnight dateMidnight17 = localDate14.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.LocalDate localDate19 = localDate14.plus(readablePeriod18);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        int int23 = dateTimeZone21.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight24 = localDate14.toDateMidnight(dateTimeZone21);
        int int26 = localDate14.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate28 = localDate14.minusMonths(57600);
        org.joda.time.Partial partial29 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.Partial partial31 = partial29.plus(readablePeriod30);
        boolean boolean32 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZoneBuilder11, (java.lang.Object) partial31);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime34 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate35 = dateTime34.toLocalDate();
        int int36 = localDate35.getEra();
        boolean boolean37 = partial31.isMatch((org.joda.time.ReadablePartial) localDate35);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(partial31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 35);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeField dateTimeField4 = delegatedDateTimeField3.getWrappedField();
        long long6 = delegatedDateTimeField3.roundCeiling(0L);
        long long9 = delegatedDateTimeField3.add(2209L, (int) ' ');
        java.lang.String str11 = delegatedDateTimeField3.getAsShortText(292280962L);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = delegatedDateTimeField3.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 0.0f, "+01:00");
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1922209L + "'", long9 == 1922209L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "551" + "'", str11.equals("551"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.minus(readableDuration14);
        org.joda.time.DateTime dateTime16 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
        java.util.Date date18 = dateTime16.toDate();
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance(chronology3, readableDateTime11, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, 240084L, 7);
        org.joda.time.Chronology chronology26 = limitChronology19.withZone(dateTimeZone22);
        org.joda.time.DurationField durationField27 = limitChronology19.seconds();
        try {
            long long33 = limitChronology19.getDateTimeMillis(31478400000L, 52, 23, (-292273085), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is above the supported maximum of 1970-01-01T00:00:00.035Z (ISOChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate16);
        java.lang.String str18 = partial17.toStringList();
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = copticChronology19.halfdays();
        org.joda.time.DateTimeField dateTimeField21 = copticChronology19.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        long long24 = delegatedDateTimeField22.roundHalfCeiling((long) 84);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(10L, dateTimeZone26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        int int29 = localDate27.indexOf(dateTimeFieldType28);
        org.joda.time.DateMidnight dateMidnight30 = localDate27.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.LocalDate localDate32 = localDate27.plus(readablePeriod31);
        java.util.TimeZone timeZone33 = null;
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forTimeZone(timeZone33);
        int int36 = dateTimeZone34.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight37 = localDate27.toDateMidnight(dateTimeZone34);
        int int39 = localDate27.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate41 = localDate27.minusMonths(57600);
        org.joda.time.Partial partial42 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate27);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.Partial partial44 = partial42.plus(readablePeriod43);
        int int45 = delegatedDateTimeField22.getMaximumValue((org.joda.time.ReadablePartial) partial44);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(10L, dateTimeZone47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        int int50 = localDate48.indexOf(dateTimeFieldType49);
        org.joda.time.DateMidnight dateMidnight51 = localDate48.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        org.joda.time.LocalDate localDate53 = localDate48.plus(readablePeriod52);
        org.joda.time.chrono.CopticChronology copticChronology54 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField55 = copticChronology54.years();
        org.joda.time.DurationField durationField56 = copticChronology54.millis();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate(10L, dateTimeZone58);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = null;
        int int61 = localDate59.indexOf(dateTimeFieldType60);
        int[] intArray63 = copticChronology54.get((org.joda.time.ReadablePartial) localDate59, 0L);
        int int64 = delegatedDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) localDate48, intArray63);
        int int65 = offsetDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) partial17, intArray63);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray66 = partial17.getFieldTypes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str18.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(partial44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1439 + "'", int45 == 1439);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight51);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(copticChronology54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 292280962 + "'", int65 == 292280962);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray66);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        long long7 = fixedDateTimeZone5.previousTransition((long) 1439);
        long long10 = fixedDateTimeZone5.convertLocalToUTC(0L, false);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str13 = fixedDateTimeZone5.getShortName(504921600019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1439L + "'", long7 == 1439L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.001" + "'", str13.equals("+00:00:00.001"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime0.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
        org.joda.time.DateTime dateTime11 = dateTime8.minusMonths(24526);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        java.lang.String str35 = property34.getAsText();
        int int36 = property34.get();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime38 = dateTime37.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime40 = dateTime37.minus(readableDuration39);
        org.joda.time.DateTime dateTime41 = dateTime37.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property42 = dateTime41.dayOfWeek();
        org.joda.time.DateTime dateTime43 = property42.withMaximumValue();
        org.joda.time.DateTime dateTime45 = property42.addToCopy(0);
        org.joda.time.DateTime dateTime46 = property42.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property47 = dateTime46.weekOfWeekyear();
        org.joda.time.DateTime dateTime49 = dateTime46.plusDays(1969);
        int int50 = property34.compareTo((org.joda.time.ReadableInstant) dateTime46);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1969" + "'", str35.equals("1969"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        org.joda.time.Chronology chronology8 = copticChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate2.plus(readablePeriod6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight12 = localDate2.toDateMidnight(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate2.plus(readablePeriod13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        org.joda.time.DateMidnight dateMidnight20 = localDate17.toDateMidnight();
        org.joda.time.LocalDate.Property property21 = localDate17.year();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(10L, dateTimeZone23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        int int26 = localDate24.indexOf(dateTimeFieldType25);
        org.joda.time.DateMidnight dateMidnight27 = localDate24.toDateMidnight();
        long long28 = property21.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight27);
        org.joda.time.LocalDate localDate29 = property21.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate30 = property21.roundHalfEvenCopy();
        int int31 = localDate14.compareTo((org.joda.time.ReadablePartial) localDate30);
        boolean boolean32 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime0.withYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime0.plusWeeks((int) '4');
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = copticChronology6.years();
        org.joda.time.DurationField durationField8 = copticChronology6.millis();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology6.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = copticChronology6.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime0.toMutableDateTime(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.weekOfWeekyear();
        try {
            long long11 = gJChronology1.getDateTimeMillis(2, 58, 0, 47, 365, (int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.minus(readableDuration13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusWeeks(10);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((java.lang.Object) dateTime14);
        int int18 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDate17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(dateTimeZone19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        boolean boolean22 = localDate20.isSupported(dateTimeFieldType21);
        org.joda.time.LocalDate localDate24 = localDate20.withWeekyear((int) '#');
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate24, 0, locale26);
        org.joda.time.DurationField durationField28 = offsetDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-292273085) + "'", int18 == (-292273085));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        org.joda.time.DateMidnight dateMidnight20 = localDate17.toDateMidnight();
        org.joda.time.LocalDate.Property property21 = localDate17.year();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(10L, dateTimeZone23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        int int26 = localDate24.indexOf(dateTimeFieldType25);
        org.joda.time.DateMidnight dateMidnight27 = localDate24.toDateMidnight();
        long long28 = property21.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight27);
        java.lang.String str29 = property21.getName();
        org.joda.time.LocalDate localDate30 = property21.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate32 = localDate30.withDayOfYear(100);
        boolean boolean33 = partial14.isMatch((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(10L, dateTimeZone35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        int int38 = localDate36.indexOf(dateTimeFieldType37);
        org.joda.time.DateMidnight dateMidnight39 = localDate36.toDateMidnight();
        org.joda.time.LocalDate.Property property40 = localDate36.year();
        org.joda.time.DateTimeField dateTimeField41 = property40.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.Partial.Property property45 = partial14.property(dateTimeFieldType44);
        org.joda.time.Partial partial47 = property45.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField48 = property45.getRangeDurationField();
        java.lang.String str49 = property45.getAsString();
        org.joda.time.DurationField durationField50 = property45.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(10L, dateTimeZone52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        int int55 = localDate53.indexOf(dateTimeFieldType54);
        org.joda.time.DateMidnight dateMidnight56 = localDate53.toDateMidnight();
        org.joda.time.LocalDate.Property property57 = localDate53.year();
        org.joda.time.DateTimeField dateTimeField58 = property57.getField();
        java.lang.String str59 = property57.getAsString();
        java.lang.String str60 = property57.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property57.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, durationField50, dateTimeFieldType61, 100);
        int int64 = remainderDateTimeField63.getDivisor();
        java.lang.String str66 = remainderDateTimeField63.getAsShortText((long) 58698);
        java.util.Locale locale68 = null;
        java.lang.String str69 = remainderDateTimeField63.getAsShortText((long) 960, locale68);
        int int71 = remainderDateTimeField63.get((-2699192332800000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "year" + "'", str29.equals("year"));
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(partial47);
        org.junit.Assert.assertNull(durationField48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1969" + "'", str59.equals("1969"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "year" + "'", str60.equals("year"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "39" + "'", str66.equals("39"));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "39" + "'", str69.equals("39"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 5 + "'", int71 == 5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.Partial partial37 = property34.withMinimumValue();
        org.joda.time.Partial partial39 = property34.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.Chronology chronology40 = partial39.getChronology();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNotNull(partial37);
        org.junit.Assert.assertNotNull(partial39);
        org.junit.Assert.assertNotNull(chronology40);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.LocalDate.Property property5 = localDate2.dayOfMonth();
        org.joda.time.LocalDate localDate7 = localDate2.minusDays(480);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMillis(57601);
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekOfWeekyear(23);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(47);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        int int7 = dateTime6.getSecondOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(dateTimeFieldType2);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) '#');
        org.joda.time.LocalDate localDate7 = localDate1.minusDays(2922789);
        org.joda.time.LocalDate localDate9 = localDate1.withCenturyOfEra(0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = localDate1.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate13.plus(readablePeriod17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        int int22 = dateTimeZone20.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight23 = localDate13.toDateMidnight(dateTimeZone20);
        int int25 = localDate13.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate27 = localDate13.minusMonths(57600);
        org.joda.time.Partial partial28 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        int[] intArray29 = localDate13.getValues();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(10L, dateTimeZone31);
        org.joda.time.Partial partial33 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate32);
        org.joda.time.LocalTime localTime34 = null;
        java.util.TimeZone timeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
        org.joda.time.DateTime dateTime37 = localDate32.toDateTime(localTime34, dateTimeZone36);
        java.lang.String str38 = dateTimeZone36.getID();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        org.joda.time.Partial partial41 = new org.joda.time.Partial(dateTimeFieldTypeArray10, intArray29, (org.joda.time.Chronology) gregorianChronology40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField43 = copticChronology42.halfdays();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime47 = dateTime46.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate48 = dateTime47.toLocalDate();
        int[] intArray54 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray56 = delegatedDateTimeField45.set((org.joda.time.ReadablePartial) localDate48, 0, intArray54, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57);
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology58);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology58.secondOfDay();
        org.joda.time.DurationField durationField61 = gJChronology58.halfdays();
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime63 = dateTime62.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration64 = null;
        org.joda.time.DateTime dateTime65 = dateTime62.minus(readableDuration64);
        org.joda.time.DateTime.Property property66 = dateTime62.dayOfYear();
        boolean boolean67 = gJChronology58.equals((java.lang.Object) dateTime62);
        try {
            org.joda.time.Partial partial68 = new org.joda.time.Partial(dateTimeFieldTypeArray10, intArray56, (org.joda.time.Chronology) gJChronology58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "America/Los_Angeles" + "'", str38.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = property5.addToCopy(0);
        int int9 = property5.getMaximumValueOverall();
        org.joda.time.DurationField durationField10 = property5.getDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        long long6 = copticChronology0.getDateTimeMillis((int) (byte) 1, 9, (int) (byte) 10, 58696);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone8);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology10.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-53162697541304L) + "'", long6 == (-53162697541304L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.Partial partial38 = property34.addToCopy(3840);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNotNull(partial38);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField9.getMaximumShortTextLength(locale11);
        long long14 = offsetDateTimeField9.roundHalfEven(0L);
        long long16 = offsetDateTimeField9.roundCeiling((long) (-1));
        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getLeapDurationField();
        long long19 = offsetDateTimeField9.roundCeiling(2209L);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(10L, dateTimeZone21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        int int24 = localDate22.indexOf(dateTimeFieldType23);
        org.joda.time.DateMidnight dateMidnight25 = localDate22.toDateMidnight();
        org.joda.time.LocalDate.Property property26 = localDate22.year();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(10L, dateTimeZone28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
        int int31 = localDate29.indexOf(dateTimeFieldType30);
        org.joda.time.DateMidnight dateMidnight32 = localDate29.toDateMidnight();
        long long33 = property26.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight32);
        java.lang.String str34 = property26.getName();
        org.joda.time.LocalDate localDate35 = property26.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate37 = localDate35.withDayOfYear(100);
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) localDate37, locale38);
        org.joda.time.DurationFieldType durationFieldType40 = null;
        try {
            org.joda.time.LocalDate localDate42 = localDate37.withFieldAdded(durationFieldType40, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 31536000000L + "'", long19 == 31536000000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "year" + "'", str34.equals("year"));
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970" + "'", str39.equals("1970"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) 365, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = gJChronology1.halfdays();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfYear();
        boolean boolean10 = gJChronology1.equals((java.lang.Object) dateTime5);
        org.joda.time.DurationField durationField11 = gJChronology1.millis();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        long long6 = fixedDateTimeZone4.previousTransition((long) 1439);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1439L + "'", long6 == 1439L);
        org.junit.Assert.assertNotNull(julianChronology7);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.Partial partial6 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalTime localTime7 = null;
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = localDate5.toDateTime(localTime7, dateTimeZone9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        boolean boolean3 = dateTime0.isAfter((long) 100);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(9);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.DateTime.Property property12 = dateTime10.minuteOfHour();
        boolean boolean13 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime15 = dateTime10.plusSeconds(57600);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(yearMonthDay17);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfCentury((int) '#', 16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfMonth(3840);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = gJChronology1.halfdays();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfYear();
        boolean boolean10 = gJChronology1.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.minus(readableDuration15);
        org.joda.time.DateTime dateTime17 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate18 = dateTime13.toLocalDate();
        org.joda.time.LocalDate localDate20 = localDate18.withDayOfMonth((int) (byte) 1);
        org.joda.time.DateTime dateTime21 = dateTime12.withFields((org.joda.time.ReadablePartial) localDate20);
        int int22 = dateTime12.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(1, false);
        boolean boolean14 = dateTimeFormatterBuilder10.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter8.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter8.withDefaultYear(57601);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.append(dateTimePrinter12, dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendYearOfCentury((int) (byte) 0, (int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatterBuilder16.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter22.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.append(dateTimeParser23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder4.append(dateTimePrinter17, dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str8 = cachedDateTimeZone6.getNameKey((long) (short) 100);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        int int10 = dateTime9.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime11 = dateTime9.toLocalDateTime();
        org.joda.time.DateTime.Property property12 = dateTime9.monthOfYear();
        org.joda.time.DateTime dateTime13 = property12.roundFloorCopy();
        boolean boolean15 = dateTime13.isEqual(1L);
        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        boolean boolean18 = cachedDateTimeZone6.isLocalDateTimeGap(localDateTime17);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[year]" + "'", str8.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600 + "'", int10 == 57600);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        boolean boolean10 = offsetDateTimeField9.isLenient();
        long long13 = offsetDateTimeField9.addWrapField(31449600000L, 0);
        long long15 = offsetDateTimeField9.remainder((long) 292280962);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField9.getType();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31449600000L + "'", long13 == 31449600000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 292280962L + "'", long15 == 292280962L);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        boolean boolean11 = dateTime8.isAfter((long) 100);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        boolean boolean14 = dateTime8.isAfter((org.joda.time.ReadableInstant) dateTime13);
        int int15 = property5.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime17 = dateTime8.withWeekOfWeekyear(9);
        org.joda.time.DateTime dateTime19 = dateTime8.minusMillis(1439);
        int int20 = dateTime19.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 596 + "'", int20 == 596);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        java.lang.String str35 = property34.getAsText();
        org.joda.time.DateTimeField dateTimeField36 = property34.getField();
        int int37 = property34.getMaximumValueOverall();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1969" + "'", str35.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 292278993 + "'", int37 == 292278993);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
        org.joda.time.DateTime dateTime8 = property3.addToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime9 = property3.roundFloorCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(35);
        org.joda.time.DateTime.Property property12 = dateTime11.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600 + "'", int1 == 57600);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        org.joda.time.DateMidnight dateMidnight20 = localDate17.toDateMidnight();
        org.joda.time.LocalDate.Property property21 = localDate17.year();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(10L, dateTimeZone23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        int int26 = localDate24.indexOf(dateTimeFieldType25);
        org.joda.time.DateMidnight dateMidnight27 = localDate24.toDateMidnight();
        long long28 = property21.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight27);
        java.lang.String str29 = property21.getName();
        org.joda.time.LocalDate localDate30 = property21.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate32 = localDate30.withDayOfYear(100);
        boolean boolean33 = partial14.isMatch((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(10L, dateTimeZone35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        int int38 = localDate36.indexOf(dateTimeFieldType37);
        org.joda.time.DateMidnight dateMidnight39 = localDate36.toDateMidnight();
        org.joda.time.LocalDate.Property property40 = localDate36.year();
        org.joda.time.DateTimeField dateTimeField41 = property40.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.Partial.Property property45 = partial14.property(dateTimeFieldType44);
        org.joda.time.Partial partial47 = property45.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField48 = property45.getRangeDurationField();
        java.lang.String str49 = property45.getAsString();
        org.joda.time.DurationField durationField50 = property45.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(10L, dateTimeZone52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        int int55 = localDate53.indexOf(dateTimeFieldType54);
        org.joda.time.DateMidnight dateMidnight56 = localDate53.toDateMidnight();
        org.joda.time.LocalDate.Property property57 = localDate53.year();
        org.joda.time.DateTimeField dateTimeField58 = property57.getField();
        java.lang.String str59 = property57.getAsString();
        java.lang.String str60 = property57.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property57.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, durationField50, dateTimeFieldType61, 100);
        int int64 = remainderDateTimeField63.getDivisor();
        java.lang.String str66 = remainderDateTimeField63.getAsShortText((long) 58698);
        java.util.Locale locale68 = null;
        java.lang.String str69 = remainderDateTimeField63.getAsShortText((long) 960, locale68);
        long long71 = remainderDateTimeField63.roundFloor((long) (short) -1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "year" + "'", str29.equals("year"));
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(partial47);
        org.junit.Assert.assertNull(durationField48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1969" + "'", str59.equals("1969"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "year" + "'", str60.equals("year"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "39" + "'", str66.equals("39"));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "39" + "'", str69.equals("39"));
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-31536000000L) + "'", long71 == (-31536000000L));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.secondOfDay();
        int int3 = gJChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = property5.addToCopy(0);
        org.joda.time.DateTime dateTime9 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.joda.time.DateTime dateTime12 = dateTime9.plusDays(1969);
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        int int5 = dateTime4.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime.Property property7 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime10 = property7.addToCopy((long) 58696);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((long) 9);
        org.joda.time.DateTime dateTime14 = dateTime12.withYearOfEra((int) (short) 10);
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600 + "'", int5 == 57600);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight();
        boolean boolean6 = dateMidnight4.isEqual((long) 57601);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.LocalDate localDate7 = localDate2.plus(readablePeriod6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        int int11 = dateTimeZone9.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight12 = localDate2.toDateMidnight(dateTimeZone9);
        int int14 = localDate2.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate16 = localDate2.minusMonths(57600);
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial17.plus(readablePeriod18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        boolean boolean24 = localDate22.isSupported(dateTimeFieldType23);
        org.joda.time.LocalDate localDate26 = localDate22.withWeekyear((int) '#');
        org.joda.time.LocalDate localDate28 = localDate22.minusDays(2922789);
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField30 = copticChronology29.halfdays();
        org.joda.time.DateTimeField dateTimeField31 = copticChronology29.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime34 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate35 = dateTime34.toLocalDate();
        int[] intArray41 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray43 = delegatedDateTimeField32.set((org.joda.time.ReadablePartial) localDate35, 0, intArray41, (int) (byte) 10);
        copticChronology20.validate((org.joda.time.ReadablePartial) localDate22, intArray43);
        org.joda.time.LocalDate localDate46 = localDate22.plusDays(365);
        boolean boolean47 = partial19.isBefore((org.joda.time.ReadablePartial) localDate46);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getSecondOfDay();
        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
        org.joda.time.DateTime dateTime8 = property3.addToCopy((int) (short) 10);
        org.joda.time.DateTime dateTime9 = property3.roundFloorCopy();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology10);
        long long16 = copticChronology10.getDateTimeMillis((int) (byte) 1, 9, (int) (byte) 10, 58696);
        org.joda.time.DateTime dateTime17 = dateTime9.toDateTime((org.joda.time.Chronology) copticChronology10);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) 69);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57600 + "'", int1 == 57600);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-53162697541304L) + "'", long16 == (-53162697541304L));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) dateTime0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        java.lang.String str8 = property6.getAsString();
        java.lang.String str9 = property6.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property6.getFieldType();
        org.joda.time.LocalDate localDate11 = property6.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = localDate13.isSupported(dateTimeFieldType14);
        org.joda.time.LocalDate localDate17 = localDate13.withWeekyear(19);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField19 = copticChronology18.halfdays();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        long long23 = delegatedDateTimeField21.roundHalfCeiling((long) 84);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField21.getType();
        boolean boolean25 = localDate17.isSupported(dateTimeFieldType24);
        try {
            org.joda.time.LocalDate.Property property26 = localDate11.property(dateTimeFieldType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "year" + "'", str9.equals("year"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: ");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.joda.time.IllegalInstantException: " + "'", str2.equals("org.joda.time.IllegalInstantException: "));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        boolean boolean3 = dateTime0.isAfter((long) 100);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(9);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        org.joda.time.DateTime.Property property12 = dateTime10.minuteOfHour();
        boolean boolean13 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime10);
        java.util.GregorianCalendar gregorianCalendar14 = dateTime10.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendClockhourOfDay(58697);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatterBuilder0.toPrinter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        int int3 = localDate2.getCenturyOfEra();
        org.joda.time.LocalDate.Property property4 = localDate2.dayOfWeek();
        org.joda.time.LocalDate localDate6 = localDate2.minusWeeks(58693);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime0.withYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime0.plusWeeks((int) '4');
        try {
            org.joda.time.DateTime dateTime7 = dateTime0.withEra(3840);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3840 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        long long6 = copticChronology0.getDateTimeMillis((int) (byte) 1, 9, (int) (byte) 10, 58696);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone8);
        org.joda.time.Chronology chronology11 = zonedChronology10.withUTC();
        org.joda.time.Chronology chronology12 = zonedChronology10.withUTC();
        org.joda.time.Chronology chronology13 = zonedChronology10.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-53162697541304L) + "'", long6 == (-53162697541304L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(58695, 57600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 116295 + "'", int2 == 116295);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        long long6 = copticChronology0.getDateTimeMillis((int) (byte) 1, 9, (int) (byte) 10, 58696);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone8);
        java.lang.Object obj11 = null;
        boolean boolean12 = zonedChronology10.equals(obj11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours(16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withZone(dateTimeZone17);
        boolean boolean19 = buddhistChronology15.equals((java.lang.Object) dateTimeZone17);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        java.util.TimeZone timeZone25 = fixedDateTimeZone24.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone26 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        int int28 = cachedDateTimeZone26.getOffset((long) 70);
        org.joda.time.Chronology chronology29 = buddhistChronology15.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone26);
        org.joda.time.Chronology chronology30 = zonedChronology10.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone26);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-53162697541304L) + "'", long6 == (-53162697541304L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(cachedDateTimeZone26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(chronology30);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(47);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.String str8 = dateTime4.toString(dateTimeFormatter7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.secondOfDay();
        org.joda.time.DurationField durationField13 = gJChronology10.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.Partial partial18 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate17);
        java.lang.String str19 = partial18.toStringList();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(10L, dateTimeZone21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        int int24 = localDate22.indexOf(dateTimeFieldType23);
        org.joda.time.DateMidnight dateMidnight25 = localDate22.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(10L, dateTimeZone27);
        org.joda.time.Partial partial29 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate28);
        int int30 = localDate22.compareTo((org.joda.time.ReadablePartial) localDate28);
        boolean boolean31 = partial18.isMatch((org.joda.time.ReadablePartial) localDate28);
        long long33 = gJChronology10.set((org.joda.time.ReadablePartial) localDate28, (long) (short) -1);
        org.joda.time.DateTimeField dateTimeField34 = gJChronology10.weekOfWeekyear();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1682-W38" + "'", str8.equals("1682-W38"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[year=1969, monthOfYear=12, dayOfMonth=31]" + "'", str19.equals("[year=1969, monthOfYear=12, dayOfMonth=31]"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Property[year]", 1, (int) (short) 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long8 = cachedDateTimeZone6.nextTransition((-86400000L));
        long long10 = cachedDateTimeZone6.convertUTCToLocal(1922209L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-86400000L) + "'", long8 == (-86400000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1922210L + "'", long10 == 1922210L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("69");
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        java.lang.String str8 = property6.getAsString();
        java.lang.String str9 = property6.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property6.getFieldType();
        org.joda.time.LocalDate localDate11 = property6.roundFloorCopy();
        int int12 = localDate11.getYearOfCentury();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "year" + "'", str9.equals("year"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: ");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalInstantException: \")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalInstantException: \")"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendMillisOfDay(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        int int9 = localDate7.indexOf(dateTimeFieldType8);
        org.joda.time.DateMidnight dateMidnight10 = localDate7.toDateMidnight();
        org.joda.time.LocalDate.Property property11 = localDate7.year();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = copticChronology17.years();
        org.joda.time.DurationField durationField19 = copticChronology17.millis();
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = copticChronology20.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField22 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType16, durationField19, durationField21);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "minuteOfDay");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtMidnight();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate1.plus(readablePeriod5);
        org.joda.time.LocalDate.Property property7 = localDate1.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(10L, dateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = localDate10.indexOf(dateTimeFieldType11);
        org.joda.time.DateMidnight dateMidnight13 = localDate10.toDateMidnight();
        org.joda.time.LocalDate.Property property14 = localDate10.year();
        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField17.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField17.getType();
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = copticChronology20.years();
        org.joda.time.DurationField durationField22 = copticChronology20.millis();
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField24 = copticChronology23.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField25 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType19, durationField22, durationField24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "minuteOfDay");
        boolean boolean28 = localDate1.isSupported(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 408);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeField dateTimeField4 = delegatedDateTimeField3.getWrappedField();
        long long6 = delegatedDateTimeField3.roundCeiling(0L);
        int int8 = delegatedDateTimeField3.getLeapAmount((long) 70);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = gJChronology1.halfdays();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfYear();
        boolean boolean10 = gJChronology1.equals((java.lang.Object) dateTime5);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        boolean boolean14 = gJChronology1.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtStartOfDay();
        int int5 = dateTime4.getMinuteOfDay();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
//        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime6 = dateTime0.minus((long) 31);
//        org.joda.time.DateTime dateTime8 = dateTime0.withYearOfEra(69);
//        int int9 = dateTime8.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("+01:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendSecondOfMinute(47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury((int) (byte) 0, (int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendMillisOfSecond(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 57599);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime0.monthOfYear();
//        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
//        org.joda.time.DateTime.Property property11 = dateTime10.weekyear();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusSeconds(0);
//        org.joda.time.DateTime dateTime15 = dateTime13.withCenturyOfEra(1439);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 58786 + "'", int1 == 58786);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone10);
        org.joda.time.LocalDate localDate13 = localDate11.withWeekyear(58696);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDate11, locale14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = localDate1.isSupported(dateTimeFieldType2);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) '#');
        org.joda.time.LocalDate localDate7 = localDate1.minusDays(2922789);
        org.joda.time.LocalDate localDate9 = localDate1.withCenturyOfEra(0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = localDate1.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.LocalDate localDate18 = localDate13.plus(readablePeriod17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        int int22 = dateTimeZone20.getOffsetFromLocal((long) (short) 1);
        org.joda.time.DateMidnight dateMidnight23 = localDate13.toDateMidnight(dateTimeZone20);
        int int25 = localDate13.getValue((int) (short) 0);
        org.joda.time.LocalDate localDate27 = localDate13.minusMonths(57600);
        org.joda.time.Partial partial28 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        int[] intArray29 = localDate13.getValues();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(10L, dateTimeZone31);
        org.joda.time.Partial partial33 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate32);
        org.joda.time.LocalTime localTime34 = null;
        java.util.TimeZone timeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
        org.joda.time.DateTime dateTime37 = localDate32.toDateTime(localTime34, dateTimeZone36);
        java.lang.String str38 = dateTimeZone36.getID();
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        org.joda.time.Partial partial41 = new org.joda.time.Partial(dateTimeFieldTypeArray10, intArray29, (org.joda.time.Chronology) gregorianChronology40);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType43 = partial41.getFieldType((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
        org.junit.Assert.assertNotNull(dateMidnight23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "America/Los_Angeles" + "'", str38.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.MutableDateTime mutableDateTime3 = instant0.toMutableDateTime();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime0.withYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime0.plusWeeks((int) '4');
        boolean boolean7 = dateTime0.isAfter(0L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField37 = property34.getRangeDurationField();
        org.joda.time.DurationField durationField38 = property34.getDurationField();
        org.joda.time.Instant instant39 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.Instant instant42 = instant39.withDurationAdded(readableDuration40, (int) 'a');
        int int43 = property34.compareTo((org.joda.time.ReadableInstant) instant39);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(instant42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateMidnight dateMidnight4 = localDate2.toDateMidnight();
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = dateMidnight4.toCalendar(locale5);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(calendar6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test352");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(2922789);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        int int12 = dateTime11.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime11.toLocalDateTime();
//        org.joda.time.DateTime.Property property14 = dateTime11.monthOfYear();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.DateTime dateTime17 = property14.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime19 = property14.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = copticChronology22.halfdays();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
//        long long27 = delegatedDateTimeField25.roundHalfCeiling((long) 84);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField25.getType();
//        int int29 = dateTime19.get(dateTimeFieldType28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendClockhourOfHalfday((int) (byte) 10);
//        boolean boolean33 = dateTimeFormatterBuilder32.canBuildPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58787 + "'", int12 == 58787);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 979 + "'", int29 == 979);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        long long5 = delegatedDateTimeField3.roundHalfCeiling((long) 84);
        int int7 = delegatedDateTimeField3.get((long) '4');
        int int9 = delegatedDateTimeField3.getLeapAmount((long) 57601);
        long long11 = delegatedDateTimeField3.roundHalfFloor((long) (short) 1);
        int int13 = delegatedDateTimeField3.get((long) '#');
        int int15 = delegatedDateTimeField3.get((-28799993L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 960 + "'", int15 == 960);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeField dateTimeField4 = delegatedDateTimeField3.getWrappedField();
        long long6 = delegatedDateTimeField3.roundCeiling(0L);
        long long8 = delegatedDateTimeField3.roundHalfEven(7L);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField3.getLeapDurationField();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology10);
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = delegatedDateTimeField3.getAsText((org.joda.time.ReadablePartial) partial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNull(durationField9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury((int) (byte) 0, (int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder6.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendLiteral("America/Los_Angeles");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(10L, dateTimeZone11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        int int14 = localDate12.indexOf(dateTimeFieldType13);
        org.joda.time.DateMidnight dateMidnight15 = localDate12.toDateMidnight();
        org.joda.time.LocalDate.Property property16 = localDate12.year();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(10L, dateTimeZone18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = localDate19.indexOf(dateTimeFieldType20);
        org.joda.time.DateMidnight dateMidnight22 = localDate19.toDateMidnight();
        long long23 = property16.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight22);
        java.lang.String str24 = property16.getName();
        org.joda.time.LocalDate localDate25 = property16.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate27 = localDate25.withDayOfYear(100);
        int int28 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localDate25);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "year" + "'", str24.equals("year"));
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-292273085) + "'", int28 == (-292273085));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimePrinter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendFractionOfHour(58, 60662);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(10L, dateTimeZone14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        int int17 = localDate15.indexOf(dateTimeFieldType16);
        org.joda.time.DateMidnight dateMidnight18 = localDate15.toDateMidnight();
        org.joda.time.LocalDate.Property property19 = localDate15.year();
        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField22.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField22.getType();
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField26 = copticChronology25.years();
        org.joda.time.DurationField durationField27 = copticChronology25.millis();
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField29 = copticChronology28.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField30 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType24, durationField27, durationField29);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "minuteOfDay");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder12.appendSignedDecimal(dateTimeFieldType24, 58696, 1438);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        org.joda.time.DateMidnight dateMidnight20 = localDate17.toDateMidnight();
        org.joda.time.LocalDate.Property property21 = localDate17.year();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(10L, dateTimeZone23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        int int26 = localDate24.indexOf(dateTimeFieldType25);
        org.joda.time.DateMidnight dateMidnight27 = localDate24.toDateMidnight();
        long long28 = property21.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight27);
        java.lang.String str29 = property21.getName();
        org.joda.time.LocalDate localDate30 = property21.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate32 = localDate30.withDayOfYear(100);
        boolean boolean33 = partial14.isMatch((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(10L, dateTimeZone35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        int int38 = localDate36.indexOf(dateTimeFieldType37);
        org.joda.time.DateMidnight dateMidnight39 = localDate36.toDateMidnight();
        org.joda.time.LocalDate.Property property40 = localDate36.year();
        org.joda.time.DateTimeField dateTimeField41 = property40.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.Partial.Property property45 = partial14.property(dateTimeFieldType44);
        org.joda.time.Partial partial47 = property45.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField48 = property45.getRangeDurationField();
        java.lang.String str49 = property45.getAsString();
        org.joda.time.DurationField durationField50 = property45.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(10L, dateTimeZone52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        int int55 = localDate53.indexOf(dateTimeFieldType54);
        org.joda.time.DateMidnight dateMidnight56 = localDate53.toDateMidnight();
        org.joda.time.LocalDate.Property property57 = localDate53.year();
        org.joda.time.DateTimeField dateTimeField58 = property57.getField();
        java.lang.String str59 = property57.getAsString();
        java.lang.String str60 = property57.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property57.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, durationField50, dateTimeFieldType61, 100);
        int int64 = remainderDateTimeField63.getMinimumValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "year" + "'", str29.equals("year"));
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(partial47);
        org.junit.Assert.assertNull(durationField48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1969" + "'", str59.equals("1969"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "year" + "'", str60.equals("year"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime0.withYear((int) (short) 100);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.withYear(9);
        int int7 = dateTime3.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField9.getType();
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = copticChronology12.years();
        org.joda.time.DurationField durationField14 = copticChronology12.millis();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = copticChronology15.halfdays();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField17 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType11, durationField14, durationField16);
        org.joda.time.DurationField durationField18 = preciseDateTimeField17.getDurationField();
        long long20 = preciseDateTimeField17.roundFloor((long) 1);
        long long22 = preciseDateTimeField17.remainder((-9221463978537600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "19691231T������");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "19691231T������");
        java.lang.Number number7 = illegalFieldValueException6.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException6.getDurationFieldType();
        org.joda.time.IllegalInstantException illegalInstantException11 = new org.joda.time.IllegalInstantException((-9221463978537600000L), "+00:00:00.001");
        illegalFieldValueException6.addSuppressed((java.lang.Throwable) illegalInstantException11);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        java.lang.Number number14 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Throwable[] throwableArray15 = illegalFieldValueException2.getSuppressed();
        boolean boolean16 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(durationFieldType8);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime0.minus(readableDuration7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.secondOfDay();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((java.lang.Object) dateTime8, (org.joda.time.Chronology) gJChronology10);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = property3.getDateTime();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeField dateTimeField4 = delegatedDateTimeField3.getWrappedField();
        long long6 = delegatedDateTimeField3.roundCeiling(0L);
        long long8 = delegatedDateTimeField3.roundHalfEven(7L);
        java.util.Locale locale9 = null;
        int int10 = delegatedDateTimeField3.getMaximumTextLength(locale9);
        org.joda.time.DateTimeField dateTimeField11 = delegatedDateTimeField3.getWrappedField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DurationField durationField7 = property5.getDurationField();
        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy(1439);
        int int10 = property5.getMinimumValue();
        org.joda.time.Interval interval11 = property5.toInterval();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(interval11);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        java.lang.String str35 = property34.getAsText();
        int int36 = property34.get();
        org.joda.time.Partial partial38 = property34.addWrapFieldToCopy(292278993);
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField40 = copticChronology39.halfdays();
        org.joda.time.DateTimeField dateTimeField41 = copticChronology39.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField41);
        long long44 = delegatedDateTimeField42.roundHalfCeiling((long) 84);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = delegatedDateTimeField42.getType();
        org.joda.time.Partial partial46 = partial38.without(dateTimeFieldType45);
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.Partial partial48 = partial38.plus(readablePeriod47);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1969" + "'", str35.equals("1969"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertNotNull(partial38);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(partial46);
        org.junit.Assert.assertNotNull(partial48);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1969);
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) localDate0, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        int int8 = localDate6.indexOf(dateTimeFieldType7);
        org.joda.time.DateMidnight dateMidnight9 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property10 = localDate6.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        int int15 = localDate13.indexOf(dateTimeFieldType14);
        org.joda.time.DateMidnight dateMidnight16 = localDate13.toDateMidnight();
        long long17 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight16);
        java.lang.String str18 = property10.getName();
        org.joda.time.LocalDate localDate19 = property10.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate21 = localDate19.withDayOfYear(100);
        boolean boolean22 = partial3.isMatch((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        int int27 = localDate25.indexOf(dateTimeFieldType26);
        org.joda.time.DateMidnight dateMidnight28 = localDate25.toDateMidnight();
        org.joda.time.LocalDate.Property property29 = localDate25.year();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField32.getType();
        org.joda.time.Partial.Property property34 = partial3.property(dateTimeFieldType33);
        org.joda.time.Partial partial36 = property34.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField37 = property34.getRangeDurationField();
        org.joda.time.Partial partial38 = property34.getPartial();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(dateTimeZone39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
        boolean boolean42 = localDate40.isSupported(dateTimeFieldType41);
        org.joda.time.LocalDate localDate44 = localDate40.withWeekyear((int) '#');
        org.joda.time.LocalTime localTime45 = null;
        org.joda.time.DateTime dateTime46 = localDate44.toDateTime(localTime45);
        org.joda.time.LocalDate.Property property47 = localDate44.yearOfCentury();
        org.joda.time.LocalDate localDate48 = property47.withMinimumValue();
        int int49 = property34.compareTo((org.joda.time.ReadablePartial) localDate48);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertNotNull(partial38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMonths(47);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond(9);
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfMonth();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: ");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra((int) (short) 0, 19);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder3.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFractionOfHour(58693, 0);
        boolean boolean12 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1732-W06");
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalTime localTime4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
        java.lang.String str8 = dateTimeZone6.getID();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        boolean boolean14 = gregorianChronology10.equals((java.lang.Object) 2922789);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatterBuilder0.toParser();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 979);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate2);
        org.joda.time.LocalTime localTime4 = null;
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = localDate2.toDateTime(localTime4, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = dateTime8.withDayOfMonth(10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfCentury((int) (short) 0);
        org.joda.time.DateTime dateTime14 = dateTime10.minusMillis(0);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime10.minus(readableDuration15);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        org.joda.time.Chronology chronology4 = localDate3.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = copticChronology5.halfdays();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        long long10 = delegatedDateTimeField8.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) delegatedDateTimeField8);
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.minus(readableDuration15);
        org.joda.time.DateTime dateTime17 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property18 = dateTime17.dayOfWeek();
        java.util.Date date19 = dateTime17.toDate();
        org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance(chronology4, readableDateTime12, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.DateTime dateTime21 = limitChronology20.getUpperLimit();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0, (org.joda.time.Chronology) limitChronology20);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(limitChronology20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1732-W06");
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.joda.time.DateTime dateTime4 = property2.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = copticChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
        long long9 = delegatedDateTimeField7.roundHalfCeiling((long) 84);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField7);
        boolean boolean11 = delegatedDateTimeField7.isLenient();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(10L, dateTimeZone13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = localDate14.indexOf(dateTimeFieldType15);
        org.joda.time.DateMidnight dateMidnight17 = localDate14.toDateMidnight();
        org.joda.time.LocalDate.Property property18 = localDate14.year();
        org.joda.time.DateTimeField dateTimeField19 = property18.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 1969);
        boolean boolean22 = offsetDateTimeField21.isLenient();
        long long25 = offsetDateTimeField21.addWrapField(31449600000L, 0);
        int int27 = offsetDateTimeField21.get((long) (byte) 100);
        long long30 = offsetDateTimeField21.add(2758760L, (long) 'a');
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime32 = dateTime31.withLaterOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.minus(readableDuration33);
        org.joda.time.DateTime dateTime35 = dateTime31.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate36 = dateTime31.toLocalDate();
        org.joda.time.YearMonthDay yearMonthDay37 = dateTime31.toYearMonthDay();
        int int38 = offsetDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay37);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate(10L, dateTimeZone40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
        int int43 = localDate41.indexOf(dateTimeFieldType42);
        org.joda.time.DateMidnight dateMidnight44 = localDate41.toDateMidnight();
        org.joda.time.LocalDate.Property property45 = localDate41.year();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(10L, dateTimeZone47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        int int50 = localDate48.indexOf(dateTimeFieldType49);
        org.joda.time.DateMidnight dateMidnight51 = localDate48.toDateMidnight();
        long long52 = property45.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight51);
        java.lang.String str53 = property45.getName();
        org.joda.time.LocalDate localDate54 = property45.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate56 = localDate54.withDayOfYear((int) (short) 10);
        int int57 = localDate56.getEra();
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDate56, 0, locale59);
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField63 = copticChronology62.halfdays();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology62.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField64);
        org.joda.time.DateTime dateTime66 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime67 = dateTime66.withLaterOffsetAtOverlap();
        org.joda.time.LocalDate localDate68 = dateTime67.toLocalDate();
        int[] intArray74 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
        int[] intArray76 = delegatedDateTimeField65.set((org.joda.time.ReadablePartial) localDate68, 0, intArray74, (int) (byte) 10);
        int[] intArray78 = delegatedDateTimeField7.set((org.joda.time.ReadablePartial) localDate56, (int) (byte) 0, intArray76, 10);
        long long80 = delegatedDateTimeField7.roundFloor(0L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31449600000L + "'", long25 == 31449600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3939 + "'", int27 == 3939);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3061068358760L + "'", long30 == 3061068358760L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(yearMonthDay37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-292273085) + "'", int38 == (-292273085));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "year" + "'", str53.equals("year"));
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "0" + "'", str60.equals("0"));
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
//        boolean boolean3 = dateTime0.isAfter((long) 100);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
//        boolean boolean6 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(9);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime10 = dateTime9.withLaterOffsetAtOverlap();
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        org.joda.time.DateTime.Property property12 = dateTime10.minuteOfHour();
//        boolean boolean13 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime15 = dateTime10.plusSeconds(57600);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime18 = dateTime17.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) 100);
//        boolean boolean21 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime23 = dateTime22.withLaterOffsetAtOverlap();
//        boolean boolean25 = dateTime22.isAfter((long) 100);
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime27 = dateTime26.withLaterOffsetAtOverlap();
//        boolean boolean28 = dateTime22.isAfter((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTime dateTime30 = dateTime27.minusSeconds(9);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime32 = dateTime31.withLaterOffsetAtOverlap();
//        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
//        org.joda.time.DateTime.Property property34 = dateTime32.minuteOfHour();
//        boolean boolean35 = dateTime30.isEqual((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime dateTime37 = dateTime32.plusSeconds(57600);
//        int int38 = dateTime37.getDayOfYear();
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime40 = dateTime39.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime42 = dateTime39.withYear((int) (short) 100);
//        boolean boolean43 = dateTime37.isAfter((org.joda.time.ReadableInstant) dateTime42);
//        org.joda.time.Chronology chronology44 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime42);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 167 + "'", int16 == 167);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 167 + "'", int38 == 167);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(chronology44);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(31);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder2.addRecurringSavings("39", 23, (int) '#', (int) (byte) 100, '#', (int) (short) 100, 57601, (-292275054), true, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test386");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((int) (short) 10, (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(2922789);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        int int12 = dateTime11.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime11.toLocalDateTime();
//        org.joda.time.DateTime.Property property14 = dateTime11.monthOfYear();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.DateTime dateTime17 = property14.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime19 = property14.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = copticChronology22.halfdays();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
//        long long27 = delegatedDateTimeField25.roundHalfCeiling((long) 84);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField25.getType();
//        int int29 = dateTime19.get(dateTimeFieldType28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendMonthOfYear(12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 58791 + "'", int12 == 58791);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 979 + "'", int29 == 979);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(35, 365, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test388");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = copticChronology0.halfdays();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
//        org.joda.time.DateTimeField dateTimeField4 = delegatedDateTimeField3.getWrappedField();
//        long long6 = delegatedDateTimeField3.roundCeiling(0L);
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(dateTimeZone8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = localDate9.isSupported(dateTimeFieldType10);
//        org.joda.time.LocalDate localDate13 = localDate9.withWeekyear((int) '#');
//        org.joda.time.LocalDate localDate15 = localDate9.minusDays(2922789);
//        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField17 = copticChronology16.halfdays();
//        org.joda.time.DateTimeField dateTimeField18 = copticChronology16.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
//        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
//        int[] intArray28 = new int[] { 1969, 'a', (byte) 0, (short) 100 };
//        int[] intArray30 = delegatedDateTimeField19.set((org.joda.time.ReadablePartial) localDate22, 0, intArray28, (int) (byte) 10);
//        copticChronology7.validate((org.joda.time.ReadablePartial) localDate9, intArray30);
//        org.joda.time.LocalDate localDate33 = localDate9.plusDays(365);
//        int int34 = localDate9.getWeekOfWeekyear();
//        int int35 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) localDate9);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(copticChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 24 + "'", int34 == 24);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test389");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (short) 0, 19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfDay(23);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        int int7 = dateTime6.getSecondOfDay();
//        org.joda.time.LocalDateTime localDateTime8 = dateTime6.toLocalDateTime();
//        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.DateTime dateTime12 = property9.addToCopy((long) 58696);
//        org.joda.time.DateTime dateTime14 = property9.addToCopy(1L);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime14.minus(readableDuration15);
//        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField18 = copticChronology17.halfdays();
//        org.joda.time.DateTimeField dateTimeField19 = copticChronology17.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
//        long long22 = delegatedDateTimeField20.roundHalfCeiling((long) 84);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField20.getType();
//        int int24 = dateTime14.get(dateTimeFieldType23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType23, 12, 960);
//        boolean boolean28 = dateTimeFormatterBuilder27.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendLiteral("December");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder27.appendEraText();
//        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatterBuilder31.toParser();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 58791 + "'", int7 == 58791);
//        org.junit.Assert.assertNotNull(localDateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(copticChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 979 + "'", int24 == 979);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeParser32);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(10L, dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateMidnight dateMidnight5 = localDate2.toDateMidnight();
        org.joda.time.LocalDate.Property property6 = localDate2.year();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField9.getType();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        org.joda.time.DateMidnight dateMidnight20 = localDate17.toDateMidnight();
        org.joda.time.LocalDate.Property property21 = localDate17.year();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(10L, dateTimeZone23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        int int26 = localDate24.indexOf(dateTimeFieldType25);
        org.joda.time.DateMidnight dateMidnight27 = localDate24.toDateMidnight();
        long long28 = property21.getDifferenceAsLong((org.joda.time.ReadableInstant) dateMidnight27);
        java.lang.String str29 = property21.getName();
        org.joda.time.LocalDate localDate30 = property21.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate32 = localDate30.withDayOfYear(100);
        boolean boolean33 = partial14.isMatch((org.joda.time.ReadablePartial) localDate30);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(10L, dateTimeZone35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        int int38 = localDate36.indexOf(dateTimeFieldType37);
        org.joda.time.DateMidnight dateMidnight39 = localDate36.toDateMidnight();
        org.joda.time.LocalDate.Property property40 = localDate36.year();
        org.joda.time.DateTimeField dateTimeField41 = property40.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 1969);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.Partial.Property property45 = partial14.property(dateTimeFieldType44);
        org.joda.time.Partial partial47 = property45.addWrapFieldToCopy(19);
        org.joda.time.DurationField durationField48 = property45.getRangeDurationField();
        java.lang.String str49 = property45.getAsString();
        org.joda.time.DurationField durationField50 = property45.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate(10L, dateTimeZone52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = null;
        int int55 = localDate53.indexOf(dateTimeFieldType54);
        org.joda.time.DateMidnight dateMidnight56 = localDate53.toDateMidnight();
        org.joda.time.LocalDate.Property property57 = localDate53.year();
        org.joda.time.DateTimeField dateTimeField58 = property57.getField();
        java.lang.String str59 = property57.getAsString();
        java.lang.String str60 = property57.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property57.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, durationField50, dateTimeFieldType61, 100);
        long long65 = remainderDateTimeField63.roundHalfCeiling((long) (short) 0);
        long long68 = remainderDateTimeField63.addWrapField((-2699192332800000L), 58693);
        int int69 = remainderDateTimeField63.getDivisor();
        int int71 = remainderDateTimeField63.get((long) 16);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "year" + "'", str29.equals("year"));
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(partial47);
        org.junit.Assert.assertNull(durationField48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1969" + "'", str59.equals("1969"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "year" + "'", str60.equals("year"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2696257497600000L) + "'", long68 == (-2696257497600000L));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 100 + "'", int69 == 100);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 39 + "'", int71 == 39);
    }
}

