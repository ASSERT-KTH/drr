import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2067-11-23T01:59:43.216Z", "GregorianChronology[America/Los_Angeles]", 21581, 13);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test002");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale5 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology4, locale5, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.weekOfWeekyear();
//        boolean boolean11 = gregorianChronology4.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str14 = dateTimeZone12.getName((long) 1);
//        org.joda.time.Chronology chronology15 = gregorianChronology4.withZone(dateTimeZone12);
//        org.joda.time.Chronology chronology16 = iSOChronology2.withZone(dateTimeZone12);
//        java.util.TimeZone timeZone17 = dateTimeZone12.toTimeZone();
//        java.lang.String str18 = dateTimeZone12.toString();
//        int int20 = dateTimeZone12.getOffsetFromLocal((long) 1541);
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((long) 57621, dateTimeZone12);
//        mutableDateTime21.setMinuteOfDay(68);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter24.withOffsetParsed();
//        java.lang.String str26 = mutableDateTime21.toString(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T01:08:57" + "'", str26.equals("1970-01-01T01:08:57"));
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        try {
            long long7 = julianChronology2.getDateTimeMillis(1000, (int) (byte) 1, 781, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 781 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
        boolean boolean18 = delegatedDateTimeField14.isSupported();
        int int19 = delegatedDateTimeField14.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
        int int24 = dividedDateTimeField23.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        long long27 = remainderDateTimeField25.roundCeiling((long) 1541);
        org.joda.time.DurationField durationField28 = remainderDateTimeField25.getRangeDurationField();
        long long31 = remainderDateTimeField25.addWrapField((long) 20, 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3542379L + "'", long27 == 3542379L);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 20L + "'", long31 == 20L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, 10L, (int) '4');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gregorianChronology0.add(readablePeriod6, (long) 739, 0);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime11 = dateTime10.withTimeAtStartOfDay();
        org.joda.time.Instant instant13 = new org.joda.time.Instant((long) (-25200000));
        boolean boolean14 = dateTime10.isEqual((org.joda.time.ReadableInstant) instant13);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 739L + "'", long9 == 739L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.add(4022000L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.yearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundCeiling();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfFloor();
//        int int8 = mutableDateTime7.getMillisOfDay();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime7.secondOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText((long) 4, locale18);
        boolean boolean20 = delegatedDateTimeField16.isSupported();
        int int21 = delegatedDateTimeField16.getMaximumValue();
        java.lang.String str22 = delegatedDateTimeField16.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
        org.joda.time.DateTime.Property property24 = dateTime6.property(dateTimeFieldType23);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType23, (int) '4');
        int int28 = dividedDateTimeField26.get((long) (-28800000));
        org.joda.time.DurationField durationField29 = dividedDateTimeField26.getLeapDurationField();
        long long32 = dividedDateTimeField26.add((long) (byte) 1, (long) 'a');
        org.joda.time.tz.DefaultNameProvider defaultNameProvider33 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale36 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology35, locale36, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket39.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket39.setOffset((java.lang.Integer) 359);
        java.util.Locale locale44 = dateTimeParserBucket39.getLocale();
        java.lang.String str47 = defaultNameProvider33.getShortName(locale44, "2018-06-13T12:59:21.232Z", "1970-W01-3");
        int int48 = dividedDateTimeField26.getMaximumTextLength(locale44);
        long long51 = dividedDateTimeField26.add(93L, (long) 4);
        long long53 = dividedDateTimeField26.remainder((long) 57621);
        org.joda.time.DurationField durationField54 = dividedDateTimeField26.getRangeDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField55 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26);
        try {
            long long58 = dividedDateTimeField26.addWrapField((long) 17, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[21561]" + "'", str9.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hourOfHalfday" + "'", str22.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 18158400001L + "'", long32 == 18158400001L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(locale44);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 748800093L + "'", long51 == 748800093L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 57621L + "'", long53 == 57621L);
        org.junit.Assert.assertNotNull(durationField54);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy((int) 'a');
        org.joda.time.DateTimeField dateTimeField6 = property3.getField();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((java.lang.Object) property3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "0", 3, (int) '#');
        long long6 = fixedDateTimeZone4.previousTransition((long) 21561);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 1560340800000L, 7);
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((java.lang.Object) fixedDateTimeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 21561L + "'", long6 == 21561L);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", number1, (java.lang.Number) 10.0d, (java.lang.Number) 100L);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        illegalFieldValueException4.prependMessage("GregorianChronology[America/Los_Angeles]");
        java.lang.String str10 = illegalFieldValueException4.toString();
        java.lang.Number number11 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number13 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException("", number13, (java.lang.Number) 10.0d, (java.lang.Number) 100L);
        java.lang.Number number17 = illegalFieldValueException16.getUpperBound();
        java.lang.Number number18 = illegalFieldValueException16.getIllegalNumberValue();
        java.lang.String str19 = illegalFieldValueException16.getFieldName();
        illegalFieldValueException16.prependMessage("GregorianChronology[America/Los_Angeles]");
        java.lang.Throwable[] throwableArray22 = illegalFieldValueException16.getSuppressed();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException16);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.joda.time.IllegalFieldValueException: GregorianChronology[America/Los_Angeles]: Value null for  must be in the range [10.0,100]" + "'", str10.equals("org.joda.time.IllegalFieldValueException: GregorianChronology[America/Los_Angeles]: Value null for  must be in the range [10.0,100]"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10.0d + "'", number11.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100L + "'", number17.equals(100L));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withWeekOfWeekyear(7198652);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7198652 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("4", "Coordinated Universal Time", 0, 739);
        int int6 = fixedDateTimeZone4.getOffset(21558999L);
        int int8 = fixedDateTimeZone4.getOffset((-31449601L));
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        long long12 = fixedDateTimeZone4.previousTransition((long) 21577513);
        long long14 = fixedDateTimeZone4.previousTransition((-57527L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 21577513L + "'", long12 == 21577513L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-57527L) + "'", long14 == (-57527L));
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime4.centuryOfEra();
//        mutableDateTime4.addHours(4);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime4.centuryOfEra();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.hourOfDay();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1);
        int int8 = dateTimeParserBucket5.getOffset();
        java.lang.Integer int9 = dateTimeParserBucket5.getOffsetInteger();
        long long12 = dateTimeParserBucket5.computeMillis(true, "12:01 AM");
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9.equals(1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9L + "'", long12 == 9L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyear();
        org.joda.time.DurationField durationField5 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.yearOfCentury();
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime8 = instant7.toDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime8.getZone();
        boolean boolean12 = gregorianChronology0.equals((java.lang.Object) dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[21561]" + "'", str3.equals("GregorianChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        java.lang.String str5 = cachedDateTimeZone3.getNameKey((long) 5);
//        java.util.TimeZone timeZone6 = cachedDateTimeZone3.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone3.getUncachedZone();
//        long long9 = cachedDateTimeZone3.convertUTCToLocal((long) 5);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5L + "'", long9 == 5L);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        boolean boolean6 = dateTimeZone4.isStandardOffset((long) (byte) 1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(3600000L, dateTimeZone4);
        int int8 = dateTime7.getDayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        int int8 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
        int int12 = offsetDateTimeField10.getLeapAmount(0L);
        long long14 = offsetDateTimeField10.remainder(1560344383477L);
        int int16 = offsetDateTimeField10.get((long) 10);
        long long19 = offsetDateTimeField10.set((long) (-360), 4);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 41098L + "'", long14 == 41098L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10799640L + "'", long19 == 10799640L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("21561", "2018-06-13T12:59:21.232Z", 57621, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffset((long) (-25200000));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) (short) 10);
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57621 + "'", int6 == 57621);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2018-06-13T12:59:21.232Z" + "'", str9.equals("2018-06-13T12:59:21.232Z"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime5 = dateTime1.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField18.getAsText((long) 4, locale20);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        int int23 = delegatedDateTimeField18.getMaximumValue();
        java.lang.String str24 = delegatedDateTimeField18.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField18.getType();
        org.joda.time.DateTime.Property property26 = dateTime8.property(dateTimeFieldType25);
        int int27 = dateTime7.get(dateTimeFieldType25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        java.lang.String str30 = iSOChronology29.toString();
        org.joda.time.DateTimeZone dateTimeZone31 = iSOChronology29.getZone();
        org.joda.time.DurationField durationField32 = iSOChronology29.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter33.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = dateTimeFormatter34.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology29, dateTimeZone35);
        org.joda.time.DurationField durationField37 = zonedChronology36.months();
        org.joda.time.DurationField durationField38 = zonedChronology36.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField38);
        try {
            int int41 = unsupportedDateTimeField39.getLeapAmount(21558999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hourOfHalfday" + "'", str24.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[21561]" + "'", str30.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withEarlierOffsetAtOverlap();
        int int4 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property5 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime7 = property5.addToCopy(0);
        org.joda.time.DateTime dateTime9 = dateTime7.plusDays((-3));
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        long long7 = iSOChronology1.add((long) (byte) -1, (long) 1000, 21559);
        org.joda.time.DurationField durationField8 = iSOChronology1.minutes();
        try {
            long long14 = iSOChronology1.getDateTimeMillis((long) '4', 4, 21577513, 1, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21577513 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 21558999L + "'", long7 == 21558999L);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test025");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.addWeekyears((int) (byte) -1);
//        int int6 = mutableDateTime3.getRoundingMode();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        java.lang.String str10 = iSOChronology9.toString();
//        org.joda.time.DateTimeZone dateTimeZone11 = iSOChronology9.getZone();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField16);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = delegatedDateTimeField22.getAsText((long) 4, locale24);
//        boolean boolean26 = delegatedDateTimeField22.isSupported();
//        int int27 = delegatedDateTimeField22.getMaximumValue();
//        java.lang.String str28 = delegatedDateTimeField22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField22.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, dateTimeFieldType29, 21562);
//        int int32 = dividedDateTimeField31.getMaximumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField31);
//        long long35 = remainderDateTimeField33.roundCeiling((long) 1541);
//        long long37 = remainderDateTimeField33.remainder((long) 57621);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime40 = dateTime39.toDateTime();
//        org.joda.time.DateTime dateTime41 = dateTime39.toDateTimeISO();
//        org.joda.time.DateTime dateTime43 = dateTime39.withMinuteOfHour(0);
//        org.joda.time.DateTime dateTime45 = dateTime43.withYear((int) (byte) 100);
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
//        java.lang.String str49 = iSOChronology48.toString();
//        org.joda.time.DateTimeZone dateTimeZone50 = iSOChronology48.getZone();
//        org.joda.time.DateTime dateTime51 = dateTime46.withZoneRetainFields(dateTimeZone50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology53.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField55 = iSOChronology53.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = delegatedDateTimeField56.getAsText((long) 4, locale58);
//        boolean boolean60 = delegatedDateTimeField56.isSupported();
//        int int61 = delegatedDateTimeField56.getMaximumValue();
//        java.lang.String str62 = delegatedDateTimeField56.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = delegatedDateTimeField56.getType();
//        org.joda.time.DateTime.Property property64 = dateTime46.property(dateTimeFieldType63);
//        int int65 = dateTime45.get(dateTimeFieldType63);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType63, (java.lang.Number) 21561, (java.lang.Number) 0, (java.lang.Number) 739L);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField70 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField33, dateTimeFieldType63);
//        try {
//            mutableDateTime3.set(dateTimeFieldType63, 16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[21561]" + "'", str10.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hourOfHalfday" + "'", str28.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3542379L + "'", long35 == 3542379L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 115242L + "'", long37 == 115242L);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "ISOChronology[21561]" + "'", str49.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(iSOChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hourOfHalfday" + "'", str62.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime3.add(readableDuration4);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.plus(readableDuration4);
        java.util.Date date6 = instant5.toDate();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        long long6 = buddhistChronology2.add((long) (short) 1, 10L, 0);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.Chronology chronology8 = buddhistChronology2.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology(chronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.weekyearOfCentury();
        org.joda.time.DurationField durationField11 = zonedChronology8.seconds();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField11.getAsText((long) 4, locale13);
        boolean boolean15 = delegatedDateTimeField11.isSupported();
        mutableDateTime5.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.MutableDateTime mutableDateTime17 = mutableDateTime5.copy();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.centuryOfEra();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 43200 + "'", int19 == 43200);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
//        boolean boolean8 = gregorianChronology1.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str11 = dateTimeZone9.getName((long) 1);
//        org.joda.time.Chronology chronology12 = gregorianChronology1.withZone(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = delegatedDateTimeField17.getAsText((long) 4, locale19);
//        boolean boolean21 = delegatedDateTimeField17.isSupported();
//        int int22 = delegatedDateTimeField17.getMaximumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField17, 4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.DateTimeFormat.shortTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter25.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField31.getAsText((long) 4, locale33);
//        boolean boolean35 = delegatedDateTimeField31.isSupported();
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale40 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology39, locale40, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket43.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket43.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale48 = dateTimeParserBucket43.getLocale();
//        java.lang.String str49 = delegatedDateTimeField31.getAsShortText(readablePartial36, (int) (short) 100, locale48);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime52 = dateTime51.toDateTime();
//        org.joda.time.LocalDateTime localDateTime53 = dateTime51.toLocalDateTime();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider54 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology56.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology56.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = delegatedDateTimeField59.getAsText((long) 4, locale61);
//        boolean boolean63 = delegatedDateTimeField59.isSupported();
//        org.joda.time.ReadablePartial readablePartial64 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale68 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology67, locale68, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket71.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket71.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale76 = dateTimeParserBucket71.getLocale();
//        java.lang.String str77 = delegatedDateTimeField59.getAsShortText(readablePartial64, (int) (short) 100, locale76);
//        java.lang.String str80 = defaultNameProvider54.getShortName(locale76, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
//        java.lang.String str81 = delegatedDateTimeField31.getAsShortText((org.joda.time.ReadablePartial) localDateTime53, locale76);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = dateTimeFormatter25.withLocale(locale76);
//        java.text.DateFormatSymbols dateFormatSymbols83 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale76);
//        int int84 = skipDateTimeField24.getMaximumShortTextLength(locale76);
//        int int85 = skipDateTimeField24.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(locale48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "100" + "'", str49.equals("100"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "0" + "'", str62.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology67);
//        org.junit.Assert.assertNotNull(locale76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "100" + "'", str77.equals("100"));
//        org.junit.Assert.assertNull(str80);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "0" + "'", str81.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter82);
//        org.junit.Assert.assertNotNull(dateFormatSymbols83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 2 + "'", int84 == 2);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) 100, 'a', (int) (short) 0, 100, 2000, false, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("Coordinated Universal Time", 21559);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("BuddhistChronology[America/Los_Angeles]", 5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField4.getAsShortText((long) '4', locale9);
        long long12 = delegatedDateTimeField4.roundHalfEven((-210862267200000L));
        long long14 = delegatedDateTimeField4.roundCeiling((long) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField20.getAsText((long) 4, locale22);
        boolean boolean24 = delegatedDateTimeField20.isSupported();
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology28, locale29, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket32.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket32.setOffset((java.lang.Integer) 359);
        java.util.Locale locale37 = dateTimeParserBucket32.getLocale();
        java.lang.String str38 = delegatedDateTimeField20.getAsShortText(readablePartial25, (int) (short) 100, locale37);
        java.lang.String str39 = delegatedDateTimeField4.getAsText((long) 21559, locale37);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology41.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField43);
        java.util.Locale locale46 = null;
        java.lang.String str47 = delegatedDateTimeField44.getAsText((long) 4, locale46);
        boolean boolean48 = delegatedDateTimeField44.isSupported();
        org.joda.time.ReadablePartial readablePartial49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale53 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology52, locale53, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket56.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket56.setOffset((java.lang.Integer) 359);
        java.util.Locale locale61 = dateTimeParserBucket56.getLocale();
        java.lang.String str62 = delegatedDateTimeField44.getAsShortText(readablePartial49, (int) (short) 100, locale61);
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime65 = dateTime64.toDateTime();
        org.joda.time.LocalDateTime localDateTime66 = dateTime64.toLocalDateTime();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider67 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone68);
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField71 = iSOChronology69.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField71);
        java.util.Locale locale74 = null;
        java.lang.String str75 = delegatedDateTimeField72.getAsText((long) 4, locale74);
        boolean boolean76 = delegatedDateTimeField72.isSupported();
        org.joda.time.ReadablePartial readablePartial77 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology80 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale81 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket84 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology80, locale81, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket84.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket84.setOffset((java.lang.Integer) 359);
        java.util.Locale locale89 = dateTimeParserBucket84.getLocale();
        java.lang.String str90 = delegatedDateTimeField72.getAsShortText(readablePartial77, (int) (short) 100, locale89);
        java.lang.String str93 = defaultNameProvider67.getShortName(locale89, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        java.lang.String str94 = delegatedDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localDateTime66, locale89);
        int[] intArray98 = new int[] { (-49), '#', 11 };
        int int99 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDateTime66, intArray98);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210862267257621L) + "'", long12 == (-210862267257621L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3542379L + "'", long14 == 3542379L);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(locale37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertNotNull(locale61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "100" + "'", str62.equals("100"));
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "0" + "'", str75.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(gregorianChronology80);
        org.junit.Assert.assertNotNull(locale89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "100" + "'", str90.equals("100"));
        org.junit.Assert.assertNull(str93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "0" + "'", str94.equals("0"));
        org.junit.Assert.assertNotNull(intArray98);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 11 + "'", int99 == 11);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "0", 3, (int) '#');
        java.lang.String str6 = fixedDateTimeZone4.getShortName(5L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.003" + "'", str6.equals("+00:00:00.003"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("21561", "2018-06-13T12:59:21.232Z", 57621, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffset((long) (-25200000));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime17 = dateTime14.withMinuteOfHour(10);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57621 + "'", int6 == 57621);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gJChronology18);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test037");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime1 = dateTime0.toDateTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.lang.String str4 = iSOChronology3.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = delegatedDateTimeField16.getAsText((long) 4, locale18);
//        boolean boolean20 = delegatedDateTimeField16.isSupported();
//        int int21 = delegatedDateTimeField16.getMaximumValue();
//        java.lang.String str22 = delegatedDateTimeField16.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType23, 21562);
//        int int26 = dividedDateTimeField25.getMaximumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25);
//        int int28 = dateTime1.get((org.joda.time.DateTimeField) remainderDateTimeField27);
//        org.joda.time.DateTime dateTime30 = dateTime1.withMillisOfDay(0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[21561]" + "'", str4.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hourOfHalfday" + "'", str22.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("21561", "2018-06-13T12:59:21.232Z", 57621, (int) (byte) 10);
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedDateTimeZone4.equals(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        mutableDateTime5.setMillisOfDay(0);
        try {
            mutableDateTime5.setDate(0, 59, 7198652);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test041");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str7 = dateTimeZone0.getShortName((long) 7198652);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test042");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int6 = mutableDateTime5.getWeekOfWeekyear();
//        mutableDateTime5.setMillisOfSecond(0);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) mutableDateTime5);
//        mutableDateTime5.addDays(7);
//        try {
//            mutableDateTime5.setMinuteOfHour((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(chronology9);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
        boolean boolean8 = delegatedDateTimeField4.isSupported();
        int int9 = delegatedDateTimeField4.getMaximumValue();
        java.lang.String str10 = delegatedDateTimeField4.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 10, (java.lang.Number) 17942379L, (java.lang.Number) 21541480);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hourOfHalfday" + "'", str10.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime7 = property6.getMutableDateTime();
        java.lang.String str8 = property6.getAsText();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.millisOfDay();
        java.lang.String str9 = iSOChronology6.toString();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(21562, (-1), 2068, (int) (short) -1, 720, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[21561]" + "'", str9.equals("ISOChronology[21561]"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText((long) 4, locale18);
        boolean boolean20 = delegatedDateTimeField16.isSupported();
        int int21 = delegatedDateTimeField16.getMaximumValue();
        java.lang.String str22 = delegatedDateTimeField16.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
        org.joda.time.DateTime.Property property24 = dateTime6.property(dateTimeFieldType23);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType23, (int) '4');
        int int28 = dividedDateTimeField26.get((long) (-28800000));
        org.joda.time.DurationField durationField29 = dividedDateTimeField26.getLeapDurationField();
        long long32 = dividedDateTimeField26.add((long) (byte) 1, (long) 'a');
        org.joda.time.tz.DefaultNameProvider defaultNameProvider33 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale36 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology35, locale36, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket39.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket39.setOffset((java.lang.Integer) 359);
        java.util.Locale locale44 = dateTimeParserBucket39.getLocale();
        java.lang.String str47 = defaultNameProvider33.getShortName(locale44, "2018-06-13T12:59:21.232Z", "1970-W01-3");
        int int48 = dividedDateTimeField26.getMaximumTextLength(locale44);
        long long51 = dividedDateTimeField26.add(93L, (long) 4);
        long long53 = dividedDateTimeField26.remainder((long) 57621);
        org.joda.time.DurationField durationField54 = dividedDateTimeField26.getRangeDurationField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField26);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[21561]" + "'", str9.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hourOfHalfday" + "'", str22.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 18158400001L + "'", long32 == 18158400001L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(locale44);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 748800093L + "'", long51 == 748800093L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 57621L + "'", long53 == 57621L);
        org.junit.Assert.assertNotNull(durationField54);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.Instant instant5 = instant2.withMillis((long) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = instant2.toMutableDateTime();
        mutableDateTime6.setDate(100L);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField23.getAsText((long) 4, locale25);
        boolean boolean27 = delegatedDateTimeField23.isSupported();
        int int28 = delegatedDateTimeField23.getMaximumValue();
        java.lang.String str29 = delegatedDateTimeField23.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField23.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType30, 21562);
        int int33 = dividedDateTimeField32.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField32);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DateTimeZone dateTimeZone39 = iSOChronology37.getZone();
        org.joda.time.DateTime dateTime40 = dateTime35.withZoneRetainFields(dateTimeZone39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = delegatedDateTimeField45.getAsText((long) 4, locale47);
        boolean boolean49 = delegatedDateTimeField45.isSupported();
        int int50 = delegatedDateTimeField45.getMaximumValue();
        java.lang.String str51 = delegatedDateTimeField45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField45.getType();
        org.joda.time.DateTime.Property property53 = dateTime35.property(dateTimeFieldType52);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType52);
        boolean boolean55 = mutableDateTime6.isSupported(dateTimeFieldType52);
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology56);
        java.lang.String str59 = gregorianChronology56.toString();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology56.weekyear();
        org.joda.time.DurationField durationField61 = gregorianChronology56.days();
        org.joda.time.DurationField durationField62 = gregorianChronology56.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField62);
        try {
            int int65 = unsupportedDateTimeField63.getMaximumValue((-210866846400000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hourOfHalfday" + "'", str29.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[21561]" + "'", str38.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 11 + "'", int50 == 11);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hourOfHalfday" + "'", str51.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "GregorianChronology[21561]" + "'", str59.equals("GregorianChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
        boolean boolean18 = delegatedDateTimeField14.isSupported();
        int int19 = delegatedDateTimeField14.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
        boolean boolean24 = dividedDateTimeField23.isLenient();
        int int26 = dividedDateTimeField23.get(93L);
        long long29 = dividedDateTimeField23.getDifferenceAsLong(0L, (long) 960);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime5 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime6 = property3.getDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        long long14 = gregorianChronology9.add((long) 1000, (long) ' ', 4);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology9.weekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        java.lang.String str18 = iSOChronology17.toString();
        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology17.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology17, dateTimeField24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField30.getAsText((long) 4, locale32);
        boolean boolean34 = delegatedDateTimeField30.isSupported();
        int int35 = delegatedDateTimeField30.getMaximumValue();
        java.lang.String str36 = delegatedDateTimeField30.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = delegatedDateTimeField30.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField25, dateTimeFieldType37, 21562);
        boolean boolean40 = dividedDateTimeField39.isLenient();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        java.lang.String str43 = iSOChronology42.toString();
        org.joda.time.DateTimeZone dateTimeZone44 = iSOChronology42.getZone();
        org.joda.time.DurationField durationField45 = iSOChronology42.halfdays();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = iSOChronology47.toString();
        org.joda.time.DateTimeZone dateTimeZone49 = iSOChronology47.getZone();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology51.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology47, dateTimeField54);
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime58 = dateTime57.toDateTime();
        org.joda.time.LocalDateTime localDateTime59 = dateTime57.toLocalDateTime();
        int[] intArray61 = iSOChronology47.get((org.joda.time.ReadablePartial) localDateTime59, 1560344362544L);
        int[] intArray63 = iSOChronology42.get((org.joda.time.ReadablePartial) localDateTime59, 0L);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider64 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
        org.joda.time.DateTimeField dateTimeField67 = iSOChronology66.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology66.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField69 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68);
        java.util.Locale locale71 = null;
        java.lang.String str72 = delegatedDateTimeField69.getAsText((long) 4, locale71);
        boolean boolean73 = delegatedDateTimeField69.isSupported();
        org.joda.time.ReadablePartial readablePartial74 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology77 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale78 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket81 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology77, locale78, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket81.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket81.setOffset((java.lang.Integer) 359);
        java.util.Locale locale86 = dateTimeParserBucket81.getLocale();
        java.lang.String str87 = delegatedDateTimeField69.getAsShortText(readablePartial74, (int) (short) 100, locale86);
        java.lang.String str90 = defaultNameProvider64.getShortName(locale86, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        java.lang.String str91 = dividedDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDateTime59, locale86);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket93 = new org.joda.time.format.DateTimeParserBucket((-57600000L), (org.joda.time.Chronology) gregorianChronology9, locale86, (java.lang.Integer) (-28800000));
        java.text.DateFormatSymbols dateFormatSymbols94 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale86);
        try {
            org.joda.time.DateTime dateTime95 = property3.setCopy("2018-06-13T12:59:38.810Z", locale86);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2018-06-13T12:59:38.810Z\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1128L + "'", long14 == 1128L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[21561]" + "'", str18.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "0" + "'", str33.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 11 + "'", int35 == 11);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hourOfHalfday" + "'", str36.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ISOChronology[21561]" + "'", str43.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[21561]" + "'", str48.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(localDateTime59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "0" + "'", str72.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(gregorianChronology77);
        org.junit.Assert.assertNotNull(locale86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "100" + "'", str87.equals("100"));
        org.junit.Assert.assertNull(str90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "0" + "'", str91.equals("0"));
        org.junit.Assert.assertNotNull(dateFormatSymbols94);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        int int8 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
        int int12 = offsetDateTimeField10.getLeapAmount(0L);
        boolean boolean14 = offsetDateTimeField10.isLeap(2L);
        long long16 = offsetDateTimeField10.remainder(3120688773696L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31317L + "'", long16 == 31317L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology3, locale4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        java.util.Locale locale15 = null;
        int int16 = skipUndoDateTimeField14.getMaximumTextLength(locale15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        java.lang.String str19 = iSOChronology18.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = iSOChronology18.getZone();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField25);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
        org.joda.time.LocalDateTime localDateTime30 = dateTime28.toLocalDateTime();
        int[] intArray32 = iSOChronology18.get((org.joda.time.ReadablePartial) localDateTime30, 1560344362544L);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        java.lang.String str35 = iSOChronology34.toString();
        org.joda.time.DateTimeZone dateTimeZone36 = iSOChronology34.getZone();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology38.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField41);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime45 = dateTime44.toDateTime();
        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
        int[] intArray48 = iSOChronology34.get((org.joda.time.ReadablePartial) localDateTime46, 1560344362544L);
        int int49 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDateTime30, intArray48);
        java.lang.String str51 = skipUndoDateTimeField14.getAsText((long) 16);
        int int53 = skipUndoDateTimeField14.get(43200010L);
        int int54 = skipUndoDateTimeField14.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[21561]" + "'", str19.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDateTime30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[21561]" + "'", str35.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(localDateTime46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "0" + "'", str51.equals("0"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 11 + "'", int54 == 11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DurationField durationField5 = iSOChronology2.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter6.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone8);
        java.lang.String str10 = zonedChronology9.toString();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology9.minuteOfHour();
        java.lang.String str12 = zonedChronology9.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean14 = dateTimeFormatter13.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = iSOChronology16.getZone();
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter13.withZone(dateTimeZone18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter13.withPivotYear(16);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        java.lang.String str28 = iSOChronology27.toString();
        org.joda.time.DateTimeZone dateTimeZone29 = iSOChronology27.getZone();
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 5, dateTimeZone29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter34.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology37.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        java.util.Locale locale42 = null;
        java.lang.String str43 = delegatedDateTimeField40.getAsText((long) 4, locale42);
        boolean boolean44 = delegatedDateTimeField40.isSupported();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale49 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology48, locale49, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket52.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket52.setOffset((java.lang.Integer) 359);
        java.util.Locale locale57 = dateTimeParserBucket52.getLocale();
        java.lang.String str58 = delegatedDateTimeField40.getAsShortText(readablePartial45, (int) (short) 100, locale57);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime61 = dateTime60.toDateTime();
        org.joda.time.LocalDateTime localDateTime62 = dateTime60.toLocalDateTime();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider63 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone64);
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology65.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField67 = iSOChronology65.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField68 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField67);
        java.util.Locale locale70 = null;
        java.lang.String str71 = delegatedDateTimeField68.getAsText((long) 4, locale70);
        boolean boolean72 = delegatedDateTimeField68.isSupported();
        org.joda.time.ReadablePartial readablePartial73 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale77 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology76, locale77, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket80.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket80.setOffset((java.lang.Integer) 359);
        java.util.Locale locale85 = dateTimeParserBucket80.getLocale();
        java.lang.String str86 = delegatedDateTimeField68.getAsShortText(readablePartial73, (int) (short) 100, locale85);
        java.lang.String str89 = defaultNameProvider63.getShortName(locale85, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        java.lang.String str90 = delegatedDateTimeField40.getAsShortText((org.joda.time.ReadablePartial) localDateTime62, locale85);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter91 = dateTimeFormatter34.withLocale(locale85);
        java.text.DateFormatSymbols dateFormatSymbols92 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale85);
        java.lang.String str93 = dateTimeZone29.getName((long) 2066, locale85);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter94 = dateTimeFormatter23.withLocale(locale85);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket97 = new org.joda.time.format.DateTimeParserBucket((long) 0, (org.joda.time.Chronology) zonedChronology9, locale85, (java.lang.Integer) 19, 20);
        org.joda.time.DateTimeField dateTimeField98 = zonedChronology9.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str10.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str12.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[21561]" + "'", str17.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[21561]" + "'", str28.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(locale57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "100" + "'", str58.equals("100"));
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDateTime62);
        org.junit.Assert.assertNotNull(iSOChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(gregorianChronology76);
        org.junit.Assert.assertNotNull(locale85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "100" + "'", str86.equals("100"));
        org.junit.Assert.assertNull(str89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "0" + "'", str90.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter91);
        org.junit.Assert.assertNotNull(dateFormatSymbols92);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "+00:00:57.621" + "'", str93.equals("+00:00:57.621"));
        org.junit.Assert.assertNotNull(dateTimeFormatter94);
        org.junit.Assert.assertNotNull(dateTimeField98);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property4 = dateTime1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
        org.joda.time.DurationField durationField9 = iSOChronology6.halfdays();
        org.joda.time.Chronology chronology10 = iSOChronology6.withUTC();
        org.joda.time.DateTime dateTime11 = dateTime1.withChronology(chronology10);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[21561]" + "'", str7.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
        boolean boolean18 = delegatedDateTimeField14.isSupported();
        int int19 = delegatedDateTimeField14.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
        boolean boolean24 = dividedDateTimeField23.isLenient();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        java.lang.String str27 = iSOChronology26.toString();
        org.joda.time.DateTimeZone dateTimeZone28 = iSOChronology26.getZone();
        org.joda.time.DurationField durationField29 = iSOChronology26.halfdays();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        java.lang.String str32 = iSOChronology31.toString();
        org.joda.time.DateTimeZone dateTimeZone33 = iSOChronology31.getZone();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology31, dateTimeField38);
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime42 = dateTime41.toDateTime();
        org.joda.time.LocalDateTime localDateTime43 = dateTime41.toLocalDateTime();
        int[] intArray45 = iSOChronology31.get((org.joda.time.ReadablePartial) localDateTime43, 1560344362544L);
        int[] intArray47 = iSOChronology26.get((org.joda.time.ReadablePartial) localDateTime43, 0L);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider48 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology50.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
        java.util.Locale locale55 = null;
        java.lang.String str56 = delegatedDateTimeField53.getAsText((long) 4, locale55);
        boolean boolean57 = delegatedDateTimeField53.isSupported();
        org.joda.time.ReadablePartial readablePartial58 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale62 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology61, locale62, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket65.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket65.setOffset((java.lang.Integer) 359);
        java.util.Locale locale70 = dateTimeParserBucket65.getLocale();
        java.lang.String str71 = delegatedDateTimeField53.getAsShortText(readablePartial58, (int) (short) 100, locale70);
        java.lang.String str74 = defaultNameProvider48.getShortName(locale70, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        java.lang.String str75 = dividedDateTimeField23.getAsText((org.joda.time.ReadablePartial) localDateTime43, locale70);
        int int76 = dividedDateTimeField23.getMinimumValue();
        try {
            long long79 = dividedDateTimeField23.addWrapField(3120688773696L, 21559);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[21561]" + "'", str27.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ISOChronology[21561]" + "'", str32.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localDateTime43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(gregorianChronology61);
        org.junit.Assert.assertNotNull(locale70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "100" + "'", str71.equals("100"));
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "0" + "'", str75.equals("0"));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test057");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        long long12 = skipUndoDateTimeField9.add(1560344381373L, (-641));
//        int int13 = skipUndoDateTimeField9.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        java.lang.String str18 = iSOChronology17.toString();
//        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology17.getZone();
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = dateTime20.withLaterOffsetAtOverlap();
//        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
//        java.lang.String str23 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) localTime22);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
//        org.joda.time.DateTimeField dateTimeField29 = delegatedDateTimeField28.getWrappedField();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        java.lang.String str33 = iSOChronology32.toString();
//        org.joda.time.DateTimeZone dateTimeZone34 = iSOChronology32.getZone();
//        org.joda.time.DateTime dateTime35 = dateTime30.withZoneRetainFields(dateTimeZone34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology37.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = delegatedDateTimeField40.getAsText((long) 4, locale42);
//        boolean boolean44 = delegatedDateTimeField40.isSupported();
//        int int45 = delegatedDateTimeField40.getMaximumValue();
//        java.lang.String str46 = delegatedDateTimeField40.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = delegatedDateTimeField40.getType();
//        org.joda.time.DateTime.Property property48 = dateTime30.property(dateTimeFieldType47);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField29, dateTimeFieldType47, (int) '4');
//        int int52 = dividedDateTimeField50.get((long) (-28800000));
//        org.joda.time.DurationField durationField53 = dividedDateTimeField50.getLeapDurationField();
//        long long56 = dividedDateTimeField50.add((long) (byte) 1, (long) 'a');
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider57 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale60 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology59, locale60, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket63.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket63.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale68 = dateTimeParserBucket63.getLocale();
//        java.lang.String str71 = defaultNameProvider57.getShortName(locale68, "2018-06-13T12:59:21.232Z", "1970-W01-3");
//        int int72 = dividedDateTimeField50.getMaximumTextLength(locale68);
//        java.lang.String str73 = skipUndoDateTimeField9.getAsText((org.joda.time.ReadablePartial) localTime22, locale68);
//        boolean boolean74 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime22);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1558036781373L + "'", long12 == 1558036781373L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[21561]" + "'", str18.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localTime22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "T130142" + "'", str23.equals("T130142"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ISOChronology[21561]" + "'", str33.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 11 + "'", int45 == 11);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hourOfHalfday" + "'", str46.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNull(durationField53);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 18158400001L + "'", long56 == 18158400001L);
//        org.junit.Assert.assertNotNull(gregorianChronology59);
//        org.junit.Assert.assertNotNull(locale68);
//        org.junit.Assert.assertNull(str71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "13" + "'", str73.equals("13"));
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        mutableDateTime1.add(readablePeriod2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.secondOfMinute();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.centuryOfEra();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        int int8 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
        long long12 = offsetDateTimeField10.roundHalfFloor((long) 5);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-57621L) + "'", long12 == (-57621L));
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test061");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        long long8 = dateTimeZone4.adjustOffset(1560344362544L, false);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str12 = dateTimeZone10.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0L, dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime16.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology18.getZone();
//        org.joda.time.Chronology chronology20 = gJChronology18.withUTC();
//        try {
//            long long28 = gJChronology18.getDateTimeMillis((-98), (-3), 0, 4, 16, 46881, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 46881 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560344362544L + "'", long8 == 1560344362544L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime5 = dateTime1.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField18.getAsText((long) 4, locale20);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        int int23 = delegatedDateTimeField18.getMaximumValue();
        java.lang.String str24 = delegatedDateTimeField18.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField18.getType();
        org.joda.time.DateTime.Property property26 = dateTime8.property(dateTimeFieldType25);
        int int27 = dateTime7.get(dateTimeFieldType25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        java.lang.String str30 = iSOChronology29.toString();
        org.joda.time.DateTimeZone dateTimeZone31 = iSOChronology29.getZone();
        org.joda.time.DurationField durationField32 = iSOChronology29.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter33.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = dateTimeFormatter34.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology29, dateTimeZone35);
        org.joda.time.DurationField durationField37 = zonedChronology36.months();
        org.joda.time.DurationField durationField38 = zonedChronology36.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField38);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        org.joda.time.DateTimeField dateTimeField46 = delegatedDateTimeField45.getWrappedField();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        java.lang.String str50 = iSOChronology49.toString();
        org.joda.time.DateTimeZone dateTimeZone51 = iSOChronology49.getZone();
        org.joda.time.DateTime dateTime52 = dateTime47.withZoneRetainFields(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.DateTimeField dateTimeField55 = iSOChronology54.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology54.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56);
        java.util.Locale locale59 = null;
        java.lang.String str60 = delegatedDateTimeField57.getAsText((long) 4, locale59);
        boolean boolean61 = delegatedDateTimeField57.isSupported();
        int int62 = delegatedDateTimeField57.getMaximumValue();
        java.lang.String str63 = delegatedDateTimeField57.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = delegatedDateTimeField57.getType();
        org.joda.time.DateTime.Property property65 = dateTime47.property(dateTimeFieldType64);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField(dateTimeField46, dateTimeFieldType64, (int) '4');
        int int69 = dividedDateTimeField67.get((long) (-28800000));
        org.joda.time.DurationField durationField70 = dividedDateTimeField67.getLeapDurationField();
        long long73 = dividedDateTimeField67.add((long) (byte) 1, (long) 'a');
        org.joda.time.tz.DefaultNameProvider defaultNameProvider74 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale77 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology76, locale77, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket80.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket80.setOffset((java.lang.Integer) 359);
        java.util.Locale locale85 = dateTimeParserBucket80.getLocale();
        java.lang.String str88 = defaultNameProvider74.getShortName(locale85, "2018-06-13T12:59:21.232Z", "1970-W01-3");
        int int89 = dividedDateTimeField67.getMaximumTextLength(locale85);
        try {
            java.lang.String str90 = unsupportedDateTimeField39.getAsText(47, locale85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hourOfHalfday" + "'", str24.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[21561]" + "'", str30.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "ISOChronology[21561]" + "'", str50.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "0" + "'", str60.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hourOfHalfday" + "'", str63.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNull(durationField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 18158400001L + "'", long73 == 18158400001L);
        org.junit.Assert.assertNotNull(gregorianChronology76);
        org.junit.Assert.assertNotNull(locale85);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((long) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder5.addCutover((-1), '#', 57621, (int) (byte) 10, 1541, true, 21561);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder13.addRecurringSavings("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")", 3, 960, 59, '4', 10, (int) (short) 10, 0, false, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder24.setFixedSavings("21562", 21577513);
        org.joda.time.DateTimeZone dateTimeZone30 = dateTimeZoneBuilder24.toDateTimeZone("hi!", true);
        org.joda.time.DateTime dateTime31 = mutableDateTime4.toDateTime(dateTimeZone30);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder24);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder27);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test064");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekOfWeekyear();
//        org.joda.time.DurationFieldType durationFieldType4 = null;
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime1.withFieldAdded(durationFieldType4, 16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 567 + "'", int2 == 567);
//        org.junit.Assert.assertNotNull(property3);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
        java.lang.Number number6 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", number6, (java.lang.Number) 10.0d, (java.lang.Number) 100L);
        java.lang.Number number10 = illegalFieldValueException9.getUpperBound();
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.String str12 = illegalFieldValueException9.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100L + "'", number10.equals(100L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "null" + "'", str12.equals("null"));
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear(64);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46903 + "'", int2 == 46903);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.Instant instant5 = instant2.withMillis((long) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = instant2.toMutableDateTime();
        mutableDateTime6.setDate(100L);
        int int9 = mutableDateTime6.getWeekyear();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((int) (short) 1, 57600, 47, 59, 2000, (-98), 47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology3, locale4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        java.util.Locale locale15 = null;
        int int16 = skipUndoDateTimeField14.getMaximumTextLength(locale15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        java.lang.String str19 = iSOChronology18.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = iSOChronology18.getZone();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField25);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
        org.joda.time.LocalDateTime localDateTime30 = dateTime28.toLocalDateTime();
        int[] intArray32 = iSOChronology18.get((org.joda.time.ReadablePartial) localDateTime30, 1560344362544L);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        java.lang.String str35 = iSOChronology34.toString();
        org.joda.time.DateTimeZone dateTimeZone36 = iSOChronology34.getZone();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology38.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField41);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime45 = dateTime44.toDateTime();
        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
        int[] intArray48 = iSOChronology34.get((org.joda.time.ReadablePartial) localDateTime46, 1560344362544L);
        int int49 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDateTime30, intArray48);
        java.lang.String str51 = skipUndoDateTimeField14.getAsText((long) 16);
        int int53 = skipUndoDateTimeField14.get(43200010L);
        int int55 = skipUndoDateTimeField14.getLeapAmount((-210866846400005L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[21561]" + "'", str19.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDateTime30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[21561]" + "'", str35.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(localDateTime46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "0" + "'", str51.equals("0"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        mutableDateTime12.add(readablePeriod13);
//        mutableDateTime12.setSecondOfMinute(10);
//        org.joda.time.DateTimeField dateTimeField17 = mutableDateTime12.getRoundingField();
//        int int18 = mutableDateTime12.getEra();
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime12.hourOfDay();
//        mutableDateTime12.addYears(16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(property19);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
        boolean boolean18 = delegatedDateTimeField14.isSupported();
        int int19 = delegatedDateTimeField14.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
        int int24 = dividedDateTimeField23.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        int int26 = dividedDateTimeField23.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
        boolean boolean18 = delegatedDateTimeField14.isSupported();
        int int19 = delegatedDateTimeField14.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
        int int24 = dividedDateTimeField23.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        long long27 = remainderDateTimeField25.roundCeiling((long) 1541);
        int int29 = remainderDateTimeField25.getMaximumValue(3120688773696L);
        long long31 = remainderDateTimeField25.roundHalfCeiling(28800010L);
        try {
            long long34 = remainderDateTimeField25.set((-57622L), 58);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58 for clockhourOfDay must be in the range [0,24]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3542379L + "'", long27 == 3542379L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 21561 + "'", int29 == 21561);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28742379L + "'", long31 == 28742379L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        int int8 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
        int int12 = offsetDateTimeField10.getLeapAmount(0L);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider13 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField18.getAsText((long) 4, locale20);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology26, locale27, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket30.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket30.setOffset((java.lang.Integer) 359);
        java.util.Locale locale35 = dateTimeParserBucket30.getLocale();
        java.lang.String str36 = delegatedDateTimeField18.getAsShortText(readablePartial23, (int) (short) 100, locale35);
        java.lang.String str39 = defaultNameProvider13.getShortName(locale35, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        int int40 = offsetDateTimeField10.getMaximumShortTextLength(locale35);
        long long42 = offsetDateTimeField10.roundCeiling(14400031L);
        int int43 = offsetDateTimeField10.getMinimumValue();
        long long45 = offsetDateTimeField10.roundFloor((long) 64771);
        long long48 = offsetDateTimeField10.add(17942379L, 3600000L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(locale35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 17942379L + "'", long42 == 17942379L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-57621L) + "'", long45 == (-57621L));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 12960017942379L + "'", long48 == 12960017942379L);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test075");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTimeISO();
//        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime7 = instant6.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay(100);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        java.lang.Class<?> wildcardClass11 = dateTime7.getClass();
//        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime2, (org.joda.time.ReadableDateTime) dateTime7);
//        try {
//            long long18 = limitChronology12.getDateTimeMillis(1209542379L, 0, 2068, (-1), (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2068 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560344445988L + "'", long10 == 1560344445988L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(limitChronology12);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek((-360));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test078");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.year();
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        boolean boolean15 = instant14.isBeforeNow();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.Instant instant19 = instant16.withMillis((long) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime20 = instant16.toMutableDateTime();
//        mutableDateTime20.setDate(100L);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        java.lang.String str25 = iSOChronology24.toString();
//        org.joda.time.DateTimeZone dateTimeZone26 = iSOChronology24.getZone();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology24, dateTimeField31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = delegatedDateTimeField37.getAsText((long) 4, locale39);
//        boolean boolean41 = delegatedDateTimeField37.isSupported();
//        int int42 = delegatedDateTimeField37.getMaximumValue();
//        java.lang.String str43 = delegatedDateTimeField37.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = delegatedDateTimeField37.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField32, dateTimeFieldType44, 21562);
//        int int47 = dividedDateTimeField46.getMaximumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField48 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField46);
//        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
//        java.lang.String str52 = iSOChronology51.toString();
//        org.joda.time.DateTimeZone dateTimeZone53 = iSOChronology51.getZone();
//        org.joda.time.DateTime dateTime54 = dateTime49.withZoneRetainFields(dateTimeZone53);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology56.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology56.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = delegatedDateTimeField59.getAsText((long) 4, locale61);
//        boolean boolean63 = delegatedDateTimeField59.isSupported();
//        int int64 = delegatedDateTimeField59.getMaximumValue();
//        java.lang.String str65 = delegatedDateTimeField59.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = delegatedDateTimeField59.getType();
//        org.joda.time.DateTime.Property property67 = dateTime49.property(dateTimeFieldType66);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField48, dateTimeFieldType66);
//        boolean boolean69 = mutableDateTime20.isSupported(dateTimeFieldType66);
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone71 = gregorianChronology70.getZone();
//        org.joda.time.Chronology chronology72 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology70);
//        java.lang.String str73 = gregorianChronology70.toString();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology70.weekyear();
//        org.joda.time.DurationField durationField75 = gregorianChronology70.days();
//        org.joda.time.DurationField durationField76 = gregorianChronology70.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField77 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType66, durationField76);
//        mutableDateTime12.set(dateTimeFieldType66, 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ISOChronology[21561]" + "'", str25.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 11 + "'", int42 == 11);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hourOfHalfday" + "'", str43.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "ISOChronology[21561]" + "'", str52.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "0" + "'", str62.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "hourOfHalfday" + "'", str65.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//        org.junit.Assert.assertNotNull(chronology72);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "GregorianChronology[21561]" + "'", str73.equals("GregorianChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(durationField75);
//        org.junit.Assert.assertNotNull(durationField76);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField77);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        int int8 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
        int int12 = offsetDateTimeField10.getLeapAmount(0L);
        long long14 = offsetDateTimeField10.remainder(1560344383477L);
        long long16 = offsetDateTimeField10.remainder((long) 21560);
        long long18 = offsetDateTimeField10.roundHalfCeiling((long) 31);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 41098L + "'", long14 == 41098L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 79181L + "'", long16 == 79181L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-57621L) + "'", long18 == (-57621L));
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
//        boolean boolean8 = gregorianChronology1.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str11 = dateTimeZone9.getName((long) 1);
//        org.joda.time.Chronology chronology12 = gregorianChronology1.withZone(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = delegatedDateTimeField17.getAsText((long) 4, locale19);
//        boolean boolean21 = delegatedDateTimeField17.isSupported();
//        int int22 = delegatedDateTimeField17.getMaximumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField17, 4);
//        long long27 = skipDateTimeField24.set(422000L, 0);
//        int int28 = skipDateTimeField24.getMinimumValue();
//        try {
//            long long31 = skipDateTimeField24.set((-57527L), 2019);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfHalfday must be in the range [-1,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 4022000L + "'", long27 == 4022000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test081");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(100);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        java.lang.Class<?> wildcardClass5 = dateTime1.getClass();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale10 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology9, locale10, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.weekOfWeekyear();
//        boolean boolean16 = gregorianChronology9.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str19 = dateTimeZone17.getName((long) 1);
//        org.joda.time.Chronology chronology20 = gregorianChronology9.withZone(dateTimeZone17);
//        org.joda.time.Chronology chronology21 = iSOChronology7.withZone(dateTimeZone17);
//        java.util.TimeZone timeZone22 = dateTimeZone17.toTimeZone();
//        java.lang.String str23 = dateTimeZone17.toString();
//        org.joda.time.DateTime dateTime24 = dateTime1.withZoneRetainFields(dateTimeZone17);
//        try {
//            org.joda.time.DateTime dateTime26 = dateTime1.withEra(64773051);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 64773051 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560344446873L + "'", long4 == 1560344446873L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordinated Universal Time" + "'", str19.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test082");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str9 = dateTimeZone7.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone7);
//        mutableDateTime10.addWeekyears((int) (byte) -1);
//        int int15 = dateTimeFormatter6.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime10.toMutableDateTime((org.joda.time.Chronology) gregorianChronology16);
//        java.lang.String str19 = mutableDateTime10.toString();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime10.monthOfYear();
//        mutableDateTime10.setMillisOfDay(0);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-98) + "'", int15 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2018-06-13T13:00:46.894Z" + "'", str19.equals("2018-06-13T13:00:46.894Z"));
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(property21);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfFloor();
        mutableDateTime3.addMonths(359);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology8, dateTimeField15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField21.getAsText((long) 4, locale23);
        boolean boolean25 = delegatedDateTimeField21.isSupported();
        int int26 = delegatedDateTimeField21.getMaximumValue();
        java.lang.String str27 = delegatedDateTimeField21.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField21.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType28, 21562);
        int int31 = dividedDateTimeField30.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField32 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField30);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        java.lang.String str36 = iSOChronology35.toString();
        org.joda.time.DateTimeZone dateTimeZone37 = iSOChronology35.getZone();
        org.joda.time.DateTime dateTime38 = dateTime33.withZoneRetainFields(dateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42);
        java.util.Locale locale45 = null;
        java.lang.String str46 = delegatedDateTimeField43.getAsText((long) 4, locale45);
        boolean boolean47 = delegatedDateTimeField43.isSupported();
        int int48 = delegatedDateTimeField43.getMaximumValue();
        java.lang.String str49 = delegatedDateTimeField43.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = delegatedDateTimeField43.getType();
        org.joda.time.DateTime.Property property51 = dateTime33.property(dateTimeFieldType50);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField52 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField32, dateTimeFieldType50);
        int int53 = mutableDateTime3.get(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[21561]" + "'", str9.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 11 + "'", int26 == 11);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hourOfHalfday" + "'", str27.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[21561]" + "'", str36.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "0" + "'", str46.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 11 + "'", int48 == 11);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hourOfHalfday" + "'", str49.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
        boolean boolean14 = delegatedDateTimeField10.isSupported();
        int int15 = delegatedDateTimeField10.getMaximumValue();
        java.lang.String str16 = delegatedDateTimeField10.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField10.getType();
        org.joda.time.DateTime.Property property18 = dateTime0.property(dateTimeFieldType17);
        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
        org.joda.time.DateTime dateTime20 = property18.getDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 11 + "'", int15 == 11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hourOfHalfday" + "'", str16.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime8 = dateTime1.withDate(59, (int) (byte) 1, 1);
        org.joda.time.DateTime.Property property9 = dateTime1.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = iSOChronology11.getZone();
        boolean boolean15 = dateTimeZone13.isStandardOffset((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology17 = buddhistChronology16.withUTC();
        org.joda.time.DateTime dateTime18 = dateTime1.toDateTime(chronology17);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[21561]" + "'", str12.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = julianChronology2.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology2.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
        long long8 = iSOChronology2.add((long) (byte) -1, (long) 1000, 21559);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 1541, (org.joda.time.Chronology) iSOChronology2, locale9, (java.lang.Integer) 21561, 1);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        java.lang.String str16 = iSOChronology15.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = iSOChronology15.getZone();
        org.joda.time.DateTime dateTime18 = dateTime13.withZoneRetainFields(dateTimeZone17);
        org.joda.time.Chronology chronology19 = iSOChronology2.withZone(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21558999L + "'", long8 == 21558999L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[21561]" + "'", str16.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(4, 79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test089");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        int int5 = mutableDateTime4.getRoundingMode();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
//        try {
//            mutableDateTime4.setMinuteOfDay(46875);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 46875 for minuteOfDay must be in the range [0,1439]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology3, locale4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology17);
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology19, locale20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = delegatedDateTimeField26.getAsText((long) 4, locale28);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        java.util.Locale locale31 = null;
        int int32 = skipUndoDateTimeField30.getMaximumTextLength(locale31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter34.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology37.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        java.util.Locale locale42 = null;
        java.lang.String str43 = delegatedDateTimeField40.getAsText((long) 4, locale42);
        boolean boolean44 = delegatedDateTimeField40.isSupported();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale49 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology48, locale49, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket52.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket52.setOffset((java.lang.Integer) 359);
        java.util.Locale locale57 = dateTimeParserBucket52.getLocale();
        java.lang.String str58 = delegatedDateTimeField40.getAsShortText(readablePartial45, (int) (short) 100, locale57);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime61 = dateTime60.toDateTime();
        org.joda.time.LocalDateTime localDateTime62 = dateTime60.toLocalDateTime();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider63 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone64);
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology65.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField67 = iSOChronology65.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField68 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField67);
        java.util.Locale locale70 = null;
        java.lang.String str71 = delegatedDateTimeField68.getAsText((long) 4, locale70);
        boolean boolean72 = delegatedDateTimeField68.isSupported();
        org.joda.time.ReadablePartial readablePartial73 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale77 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket80 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology76, locale77, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket80.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket80.setOffset((java.lang.Integer) 359);
        java.util.Locale locale85 = dateTimeParserBucket80.getLocale();
        java.lang.String str86 = delegatedDateTimeField68.getAsShortText(readablePartial73, (int) (short) 100, locale85);
        java.lang.String str89 = defaultNameProvider63.getShortName(locale85, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        java.lang.String str90 = delegatedDateTimeField40.getAsShortText((org.joda.time.ReadablePartial) localDateTime62, locale85);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter91 = dateTimeFormatter34.withLocale(locale85);
        java.text.DateFormatSymbols dateFormatSymbols92 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale85);
        java.lang.String str93 = skipUndoDateTimeField30.getAsText(21562, locale85);
        java.lang.String str94 = skipUndoDateTimeField14.getAsText(57621, locale85);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(locale57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "100" + "'", str58.equals("100"));
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDateTime62);
        org.junit.Assert.assertNotNull(iSOChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(gregorianChronology76);
        org.junit.Assert.assertNotNull(locale85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "100" + "'", str86.equals("100"));
        org.junit.Assert.assertNull(str89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "0" + "'", str90.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter91);
        org.junit.Assert.assertNotNull(dateFormatSymbols92);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "21562" + "'", str93.equals("21562"));
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "57621" + "'", str94.equals("57621"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.years();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(12, 46786439);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46786451 + "'", int2 == 46786451);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.Instant instant5 = instant2.withMillis((long) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = instant2.toMutableDateTime();
        mutableDateTime6.setDate(100L);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField23.getAsText((long) 4, locale25);
        boolean boolean27 = delegatedDateTimeField23.isSupported();
        int int28 = delegatedDateTimeField23.getMaximumValue();
        java.lang.String str29 = delegatedDateTimeField23.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField23.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType30, 21562);
        int int33 = dividedDateTimeField32.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField32);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DateTimeZone dateTimeZone39 = iSOChronology37.getZone();
        org.joda.time.DateTime dateTime40 = dateTime35.withZoneRetainFields(dateTimeZone39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = delegatedDateTimeField45.getAsText((long) 4, locale47);
        boolean boolean49 = delegatedDateTimeField45.isSupported();
        int int50 = delegatedDateTimeField45.getMaximumValue();
        java.lang.String str51 = delegatedDateTimeField45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField45.getType();
        org.joda.time.DateTime.Property property53 = dateTime35.property(dateTimeFieldType52);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType52);
        boolean boolean55 = mutableDateTime6.isSupported(dateTimeFieldType52);
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology56);
        java.lang.String str59 = gregorianChronology56.toString();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology56.weekyear();
        org.joda.time.DurationField durationField61 = gregorianChronology56.days();
        org.joda.time.DurationField durationField62 = gregorianChronology56.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField62);
        long long66 = unsupportedDateTimeField63.getDifferenceAsLong(0L, (long) 46903);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hourOfHalfday" + "'", str29.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[21561]" + "'", str38.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 11 + "'", int50 == 11);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hourOfHalfday" + "'", str51.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "GregorianChronology[21561]" + "'", str59.equals("GregorianChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DurationField durationField5 = iSOChronology2.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter6.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone8);
        java.lang.String str10 = dateTimeZone8.toString();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, 0L, 2);
        org.joda.time.Chronology chronology14 = gJChronology13.withUTC();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((long) 10, (org.joda.time.Chronology) gJChronology13);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.dayOfWeek();
        int int17 = property16.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test096");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isPrinter();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.lang.String str4 = iSOChronology3.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withPivotYear(16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale13 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology12, locale13, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology12.weekOfWeekyear();
//        boolean boolean19 = gregorianChronology12.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str22 = dateTimeZone20.getName((long) 1);
//        org.joda.time.Chronology chronology23 = gregorianChronology12.withZone(dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = delegatedDateTimeField28.getAsText((long) 4, locale30);
//        boolean boolean32 = delegatedDateTimeField28.isSupported();
//        int int33 = delegatedDateTimeField28.getMaximumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology12, (org.joda.time.DateTimeField) delegatedDateTimeField28, 4);
//        int int37 = skipDateTimeField35.getLeapAmount(2440588L);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime40 = dateTime39.toDateTime();
//        org.joda.time.LocalDateTime localDateTime41 = dateTime39.toLocalDateTime();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider43 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale46 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket49 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology45, locale46, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket49.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket49.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale54 = dateTimeParserBucket49.getLocale();
//        java.lang.String str57 = defaultNameProvider43.getShortName(locale54, "2018-06-13T12:59:21.232Z", "1970-W01-3");
//        java.lang.String str58 = skipDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, (int) (byte) 100, locale54);
//        java.lang.String str59 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime41);
//        java.lang.Appendable appendable60 = null;
//        try {
//            dateTimeFormatter0.printTo(appendable60, (long) 163);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[21561]" + "'", str4.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordinated Universal Time" + "'", str22.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDateTime41);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(locale54);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "100" + "'", str58.equals("100"));
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "T00:01:19" + "'", str59.equals("T00:01:19"));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(717139000, 1000, 46786451, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.year();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = iSOChronology1.get(readablePeriod5, (long) 100, (long) 64771);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[monthOfYear]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusMinutes((int) (short) 100);
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withWeekOfWeekyear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime1.minusHours((-1));
        org.joda.time.DateTime.Property property6 = dateTime1.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
        org.joda.time.LocalDateTime localDateTime18 = dateTime16.toLocalDateTime();
        int[] intArray20 = iSOChronology6.get((org.joda.time.ReadablePartial) localDateTime18, 1560344362544L);
        int[] intArray22 = iSOChronology1.get((org.joda.time.ReadablePartial) localDateTime18, 0L);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        mutableDateTime23.add(readablePeriod24);
        try {
            mutableDateTime23.setHourOfDay(7198652);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7198652 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[21561]" + "'", str7.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
        boolean boolean18 = delegatedDateTimeField14.isSupported();
        int int19 = delegatedDateTimeField14.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
        int int24 = dividedDateTimeField23.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        long long27 = remainderDateTimeField25.roundCeiling((long) 1541);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime30 = dateTime29.toDateTime();
        org.joda.time.DateTime dateTime31 = dateTime29.toDateTimeISO();
        org.joda.time.DateTime dateTime33 = dateTime29.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime35 = dateTime33.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        java.lang.String str39 = iSOChronology38.toString();
        org.joda.time.DateTimeZone dateTimeZone40 = iSOChronology38.getZone();
        org.joda.time.DateTime dateTime41 = dateTime36.withZoneRetainFields(dateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = delegatedDateTimeField46.getAsText((long) 4, locale48);
        boolean boolean50 = delegatedDateTimeField46.isSupported();
        int int51 = delegatedDateTimeField46.getMaximumValue();
        java.lang.String str52 = delegatedDateTimeField46.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = delegatedDateTimeField46.getType();
        org.joda.time.DateTime.Property property54 = dateTime36.property(dateTimeFieldType53);
        int int55 = dateTime35.get(dateTimeFieldType53);
        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 21561, (java.lang.Number) 0, (java.lang.Number) 739L);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType53);
        long long62 = remainderDateTimeField25.roundHalfEven(8741L);
        int int64 = remainderDateTimeField25.get(79183L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3542379L + "'", long27 == 3542379L);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ISOChronology[21561]" + "'", str39.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hourOfHalfday" + "'", str52.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-57621L) + "'", long62 == (-57621L));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 24 + "'", int64 == 24);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
        boolean boolean14 = delegatedDateTimeField10.isSupported();
        int int15 = delegatedDateTimeField10.getMaximumValue();
        java.lang.String str16 = delegatedDateTimeField10.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField10.getType();
        org.joda.time.DateTime.Property property18 = dateTime0.property(dateTimeFieldType17);
        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTimeISO();
        org.joda.time.DateTime dateTime25 = dateTime21.withMinuteOfHour(0);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime27 = dateTime25.minus(readableDuration26);
        org.joda.time.DateTime.Property property28 = dateTime25.centuryOfEra();
        int int29 = dateTime19.compareTo((org.joda.time.ReadableInstant) dateTime25);
        boolean boolean31 = dateTime25.isBefore((-140577639384728L));
        org.joda.time.DateTime dateTime33 = dateTime25.minusMonths(380);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 11 + "'", int15 == 11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hourOfHalfday" + "'", str16.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "0", 3, (int) '#');
        long long6 = fixedDateTimeZone4.previousTransition((long) 21561);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 1560340800000L, 7);
        try {
            long long14 = gJChronology9.getDateTimeMillis(46881, 0, 76, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 21561L + "'", long6 == 21561L);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gJChronology7.add(readablePeriod8, (long) (byte) 10, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology7.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test108");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getDurationField();
//        org.joda.time.DurationField durationField9 = delegatedDateTimeField4.getRangeDurationField();
//        boolean boolean10 = delegatedDateTimeField4.isLenient();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        boolean boolean12 = dateTimeFormatter11.isPrinter();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        java.lang.String str15 = iSOChronology14.toString();
//        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology14.getZone();
//        boolean boolean18 = dateTimeZone16.isStandardOffset((long) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter11.withZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
//        org.joda.time.DateTime dateTime24 = property23.withMaximumValue();
//        int int25 = dateTimeZone16.getOffset((org.joda.time.ReadableInstant) dateTime24);
//        java.lang.String str26 = dateTimeZone16.getID();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        java.lang.String str30 = iSOChronology29.toString();
//        org.joda.time.DateTimeZone dateTimeZone31 = iSOChronology29.getZone();
//        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone31);
//        org.joda.time.MutableDateTime.Property property33 = mutableDateTime32.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime34 = property33.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime36 = property33.set((int) (short) 10);
//        java.lang.String str37 = property33.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale40 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology39, locale40, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology39.weekOfWeekyear();
//        boolean boolean46 = gregorianChronology39.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str49 = dateTimeZone47.getName((long) 1);
//        org.joda.time.Chronology chronology50 = gregorianChronology39.withZone(dateTimeZone47);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField54);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = delegatedDateTimeField55.getAsText((long) 4, locale57);
//        boolean boolean59 = delegatedDateTimeField55.isSupported();
//        int int60 = delegatedDateTimeField55.getMaximumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField62 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology39, (org.joda.time.DateTimeField) delegatedDateTimeField55, 4);
//        int int64 = skipDateTimeField62.getLeapAmount(2440588L);
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime67 = dateTime66.toDateTime();
//        org.joda.time.LocalDateTime localDateTime68 = dateTime66.toLocalDateTime();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider70 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale73 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket76 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology72, locale73, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket76.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket76.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale81 = dateTimeParserBucket76.getLocale();
//        java.lang.String str84 = defaultNameProvider70.getShortName(locale81, "2018-06-13T12:59:21.232Z", "1970-W01-3");
//        java.lang.String str85 = skipDateTimeField62.getAsShortText((org.joda.time.ReadablePartial) localDateTime68, (int) (byte) 100, locale81);
//        int int86 = property33.compareTo((org.joda.time.ReadablePartial) localDateTime68);
//        boolean boolean87 = dateTimeZone16.isLocalDateTimeGap(localDateTime68);
//        int int88 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDateTime68);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[21561]" + "'", str15.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 57621 + "'", int25 == 57621);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "21561" + "'", str26.equals("21561"));
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[21561]" + "'", str30.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(mutableDateTime36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Property[dayOfMonth]" + "'", str37.equals("Property[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordinated Universal Time" + "'", str49.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0" + "'", str58.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 11 + "'", int60 == 11);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(localDateTime68);
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertNotNull(locale81);
//        org.junit.Assert.assertNull(str84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "100" + "'", str85.equals("100"));
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 11 + "'", int88 == 11);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(100);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText((long) 4, locale7);
        boolean boolean9 = delegatedDateTimeField5.isSupported();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology13, locale14, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket17.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket17.setOffset((java.lang.Integer) 359);
        java.util.Locale locale22 = dateTimeParserBucket17.getLocale();
        java.lang.String str23 = delegatedDateTimeField5.getAsShortText(readablePartial10, (int) (short) 100, locale22);
        java.lang.String str26 = defaultNameProvider0.getShortName(locale22, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(locale22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
        org.joda.time.Chronology chronology6 = dateTime5.getChronology();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.DurationField durationField11 = iSOChronology8.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter12.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeFormatter13.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, dateTimeZone14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("21561", "2018-06-13T12:59:21.232Z", 57621, (int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime5.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        long long24 = fixedDateTimeZone20.nextTransition((long) 79706);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[21561]" + "'", str9.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 79706L + "'", long24 == 79706L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        long long7 = iSOChronology1.add((long) (byte) -1, (long) 1000, 21559);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyear();
        boolean boolean9 = iSOChronology1.equals((java.lang.Object) dateTimeFormatter8);
        org.joda.time.DurationField durationField10 = iSOChronology1.halfdays();
        org.joda.time.DurationField durationField11 = iSOChronology1.halfdays();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
        long long20 = iSOChronology14.add((long) (byte) -1, (long) 1000, 21559);
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) iSOChronology14, locale21);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DurationField durationField24 = iSOChronology14.minutes();
        boolean boolean25 = iSOChronology1.equals((java.lang.Object) iSOChronology14);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 21558999L + "'", long7 == 21558999L);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 21558999L + "'", long20 == 21558999L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        int int8 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
        int int12 = offsetDateTimeField10.getLeapAmount(0L);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider13 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField18.getAsText((long) 4, locale20);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology26, locale27, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket30.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket30.setOffset((java.lang.Integer) 359);
        java.util.Locale locale35 = dateTimeParserBucket30.getLocale();
        java.lang.String str36 = delegatedDateTimeField18.getAsShortText(readablePartial23, (int) (short) 100, locale35);
        java.lang.String str39 = defaultNameProvider13.getShortName(locale35, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        int int40 = offsetDateTimeField10.getMaximumShortTextLength(locale35);
        java.lang.String str42 = offsetDateTimeField10.getAsShortText((long) (byte) -1);
        long long44 = offsetDateTimeField10.roundFloor((long) 21559);
        int int45 = offsetDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(locale35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-57621L) + "'", long44 == (-57621L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime7 = property6.roundFloor();
        int int8 = property6.get();
        org.joda.time.DurationField durationField9 = property6.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(durationField9);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test115");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime4.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (short) 0);
//        int int13 = property10.compareTo((org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        boolean boolean15 = instant14.isBeforeNow();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.Instant instant19 = instant14.plus((long) 10);
//        org.joda.time.Instant instant22 = instant14.withDurationAdded((long) (byte) 1, 1000);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str25 = dateTimeZone23.getName((long) 1);
//        boolean boolean26 = instant22.equals((java.lang.Object) 1);
//        long long27 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) instant22);
//        org.joda.time.MutableDateTime mutableDateTime28 = property10.roundFloor();
//        try {
//            mutableDateTime28.setTime(0, (int) (byte) 100, 0, 21559);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordinated Universal Time" + "'", str25.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31449601L) + "'", long27 == (-31449601L));
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test116");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.addWeekyears((int) (byte) -1);
//        int int6 = mutableDateTime3.getRoundingMode();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.weekyear();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime3.millisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime0.yearOfEra();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((int) (short) 0);
        org.joda.time.DateTime dateTime10 = property6.setCopy(739);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMillis(13);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        int int7 = delegatedDateTimeField4.getLeapAmount(739L);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField4.getType();
        java.lang.String str9 = delegatedDateTimeField4.getName();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hourOfHalfday" + "'", str9.equals("hourOfHalfday"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(64771);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(2066);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1);
        int int8 = dateTimeParserBucket5.getOffset();
        dateTimeParserBucket5.setOffset((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeParserBucket5.getZone();
        long long14 = dateTimeParserBucket5.computeMillis(false, "21562");
        boolean boolean16 = dateTimeParserBucket5.restoreState((java.lang.Object) (-28799999L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-22L) + "'", long14 == (-22L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test122");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone6.getName((long) 1);
//        org.joda.time.DateTime dateTime9 = dateTime1.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime.Property property10 = dateTime1.era();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime1.withDurationAdded(readableDuration11, 1970);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsShortText((int) (short) 0, locale7);
        long long11 = delegatedDateTimeField4.getDifferenceAsLong(21558999L, (-31449599261L));
        int int13 = delegatedDateTimeField4.getMinimumValue(14400031L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 8741L + "'", long11 == 8741L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
        boolean boolean14 = delegatedDateTimeField10.isSupported();
        int int15 = delegatedDateTimeField10.getMaximumValue();
        java.lang.String str16 = delegatedDateTimeField10.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField10.getType();
        org.joda.time.DateTime.Property property18 = dateTime0.property(dateTimeFieldType17);
        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
        org.joda.time.DateTime dateTime23 = dateTime21.toDateTimeISO();
        org.joda.time.DateTime dateTime25 = dateTime21.withMinuteOfHour(0);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime27 = dateTime25.minus(readableDuration26);
        org.joda.time.DateTime.Property property28 = dateTime25.centuryOfEra();
        int int29 = dateTime19.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.LocalTime localTime30 = dateTime25.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 11 + "'", int15 == 11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hourOfHalfday" + "'", str16.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(localTime30);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(7198652, 46903);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 2000, (-349L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-698000) + "'", int2 == (-698000));
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test127");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getYearOfEra();
//        org.joda.time.DateTime dateTime4 = dateTime1.plusDays(1541);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
        boolean boolean18 = delegatedDateTimeField14.isSupported();
        int int19 = delegatedDateTimeField14.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
        int int24 = dividedDateTimeField23.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        long long27 = remainderDateTimeField25.roundCeiling((long) 1541);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) long27);
        java.lang.Object obj29 = mutableDateTime28.clone();
        try {
            mutableDateTime28.setMinuteOfHour(2066);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2066 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3542379L + "'", long27 == 3542379L);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = iSOChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone5);
        boolean boolean11 = mutableDateTime9.isAfter((long) 21561);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[21561]" + "'", str4.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.addWeekyears((int) (byte) -1);
//        mutableDateTime3.setWeekyear((int) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((long) 100);
        org.joda.time.MutableDateTime mutableDateTime5 = property2.roundCeiling();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("2018-06-13T13:00:20.512Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2018-06-13T13:00:20.512Z");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        int int5 = mutableDateTime4.getWeekOfWeekyear();
//        mutableDateTime4.setMillisOfDay(0);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.millisOfDay();
//        try {
//            mutableDateTime4.setDateTime((int) (short) 100, 46786439, 7171390, 20, 3, 64, 717139000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 64 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(40, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1400 + "'", int2 == 1400);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        int int8 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
        long long12 = offsetDateTimeField10.roundHalfEven(0L);
        int int13 = offsetDateTimeField10.getMinimumValue();
        int int15 = offsetDateTimeField10.get(17L);
        int int16 = offsetDateTimeField10.getMaximumValue();
        int int17 = offsetDateTimeField10.getMinimumValue();
        int int19 = offsetDateTimeField10.getMinimumValue((-360L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-57621L) + "'", long12 == (-57621L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
        java.lang.String str9 = zonedChronology8.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("21561", "2018-06-13T12:59:21.232Z", 57621, (int) (byte) 10);
        int int16 = fixedDateTimeZone14.getOffset((long) (-25200000));
        long long19 = fixedDateTimeZone14.convertLocalToUTC(1560344383477L, false);
        long long21 = fixedDateTimeZone14.nextTransition(1560344377285L);
        org.joda.time.Chronology chronology22 = zonedChronology8.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57621 + "'", int16 == 57621);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560344325856L + "'", long19 == 1560344325856L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560344377285L + "'", long21 == 1560344377285L);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(gJChronology23);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
        boolean boolean18 = delegatedDateTimeField14.isSupported();
        int int19 = delegatedDateTimeField14.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
        boolean boolean24 = dividedDateTimeField23.isLenient();
        int int26 = dividedDateTimeField23.getMinimumValue((long) 2019);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test138");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        mutableDateTime12.add(readablePeriod13);
//        mutableDateTime12.setSecondOfMinute(10);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime12.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime12.copy();
//        int int19 = mutableDateTime12.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.yearOfEra();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
//        int int7 = property6.get();
//        org.joda.time.DateTimeField dateTimeField8 = property6.getField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology10, locale11, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology10.weekOfWeekyear();
//        boolean boolean17 = gregorianChronology10.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str20 = dateTimeZone18.getName((long) 1);
//        org.joda.time.Chronology chronology21 = gregorianChronology10.withZone(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = delegatedDateTimeField26.getAsText((long) 4, locale28);
//        boolean boolean30 = delegatedDateTimeField26.isSupported();
//        int int31 = delegatedDateTimeField26.getMaximumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField26, 4);
//        int int35 = skipDateTimeField33.getLeapAmount(2440588L);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        java.lang.String str38 = iSOChronology37.toString();
//        org.joda.time.DateTimeZone dateTimeZone39 = iSOChronology37.getZone();
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology41.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology41.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology37, dateTimeField44);
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology47.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField49);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = delegatedDateTimeField50.getAsText((long) 4, locale52);
//        boolean boolean54 = delegatedDateTimeField50.isSupported();
//        int int55 = delegatedDateTimeField50.getMaximumValue();
//        java.lang.String str56 = delegatedDateTimeField50.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = delegatedDateTimeField50.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField45, dateTimeFieldType57, 21562);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField33, dateTimeFieldType57, 1541, (int) '#', 1000);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType57, (int) (byte) 10, 7171390, (-28800000));
//        int int68 = offsetDateTimeField67.getMinimumValue();
//        long long70 = offsetDateTimeField67.roundHalfEven(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[21561]" + "'", str38.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "0" + "'", str53.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 11 + "'", int55 == 11);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hourOfHalfday" + "'", str56.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 7171390 + "'", int68 == 7171390);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 946684800000L + "'", long70 == 946684800000L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = iSOChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.yearOfEra();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        int int14 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[21561]" + "'", str4.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 57621 + "'", int14 == 57621);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test141");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
//        boolean boolean18 = delegatedDateTimeField14.isSupported();
//        int int19 = delegatedDateTimeField14.getMaximumValue();
//        java.lang.String str20 = delegatedDateTimeField14.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
//        boolean boolean24 = dividedDateTimeField23.isLenient();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str29 = dateTimeZone27.getName((long) 1);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone27);
//        long long32 = cachedDateTimeZone30.previousTransition(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale36 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology35, locale36, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket39.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket39.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale44 = dateTimeParserBucket39.getLocale();
//        java.lang.String str45 = cachedDateTimeZone30.getShortName(0L, locale44);
//        try {
//            long long46 = dividedDateTimeField23.set((-210862267200000L), "T020046", locale44);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T020046\" for hourOfHalfday is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Coordinated Universal Time" + "'", str29.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(locale44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UTC" + "'", str45.equals("UTC"));
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
        boolean boolean10 = dateTimeZone8.isStandardOffset((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology12 = buddhistChronology11.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        java.lang.String str15 = iSOChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology14.getZone();
        org.joda.time.DurationField durationField17 = iSOChronology14.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter18.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = dateTimeFormatter19.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, dateTimeZone20);
        org.joda.time.Chronology chronology22 = buddhistChronology11.withZone(dateTimeZone20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter0.withZone(dateTimeZone20);
        boolean boolean24 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[21561]" + "'", str7.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[21561]" + "'", str15.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        long long5 = buddhistChronology1.add((long) (short) 1, 10L, 0);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology7 = buddhistChronology1.withUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((java.lang.Object) 411870, (org.joda.time.Chronology) buddhistChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.weekyearOfCentury();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology8.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        java.lang.String str15 = iSOChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology14.getZone();
        org.joda.time.DurationField durationField17 = iSOChronology14.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter18.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = dateTimeFormatter19.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, dateTimeZone20);
        java.lang.String str22 = dateTimeZone20.toString();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, 0L, 2);
        boolean boolean26 = zonedChronology8.equals((java.lang.Object) 2);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[21561]" + "'", str15.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        mutableDateTime0.addHours((-1));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test146");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        long long8 = dateTimeZone4.adjustOffset(1560344362544L, false);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str12 = dateTimeZone10.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0L, dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime16.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology18.getZone();
//        try {
//            long long24 = gJChronology18.getDateTimeMillis(3, 46786439, 64, 13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 46786439 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560344362544L + "'", long8 == 1560344362544L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
        long long8 = iSOChronology2.add((long) (byte) -1, (long) 1000, 21559);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) iSOChronology2, locale9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField12 = iSOChronology2.minutes();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray15 = iSOChronology2.get(readablePeriod13, 20L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21558999L + "'", long8 == 21558999L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        int int8 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
        long long12 = offsetDateTimeField10.roundHalfEven(0L);
        int int13 = offsetDateTimeField10.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        java.lang.String str16 = iSOChronology15.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = iSOChronology15.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology15, dateTimeField22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = delegatedDateTimeField28.getAsText((long) 4, locale30);
        boolean boolean32 = delegatedDateTimeField28.isSupported();
        int int33 = delegatedDateTimeField28.getMaximumValue();
        java.lang.String str34 = delegatedDateTimeField28.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = delegatedDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType35, 21562);
        boolean boolean38 = dividedDateTimeField37.isLenient();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        java.lang.String str41 = iSOChronology40.toString();
        org.joda.time.DateTimeZone dateTimeZone42 = iSOChronology40.getZone();
        org.joda.time.DurationField durationField43 = iSOChronology40.halfdays();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        java.lang.String str46 = iSOChronology45.toString();
        org.joda.time.DateTimeZone dateTimeZone47 = iSOChronology45.getZone();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology49.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology45, dateTimeField52);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime56 = dateTime55.toDateTime();
        org.joda.time.LocalDateTime localDateTime57 = dateTime55.toLocalDateTime();
        int[] intArray59 = iSOChronology45.get((org.joda.time.ReadablePartial) localDateTime57, 1560344362544L);
        int[] intArray61 = iSOChronology40.get((org.joda.time.ReadablePartial) localDateTime57, 0L);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider62 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone63);
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology64.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology64.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField67 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField66);
        java.util.Locale locale69 = null;
        java.lang.String str70 = delegatedDateTimeField67.getAsText((long) 4, locale69);
        boolean boolean71 = delegatedDateTimeField67.isSupported();
        org.joda.time.ReadablePartial readablePartial72 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale76 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket79 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology75, locale76, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket79.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket79.setOffset((java.lang.Integer) 359);
        java.util.Locale locale84 = dateTimeParserBucket79.getLocale();
        java.lang.String str85 = delegatedDateTimeField67.getAsShortText(readablePartial72, (int) (short) 100, locale84);
        java.lang.String str88 = defaultNameProvider62.getShortName(locale84, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        java.lang.String str89 = dividedDateTimeField37.getAsText((org.joda.time.ReadablePartial) localDateTime57, locale84);
        int int90 = offsetDateTimeField10.getMaximumTextLength(locale84);
        long long92 = offsetDateTimeField10.roundHalfFloor((long) (byte) 1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-57621L) + "'", long12 == (-57621L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[21561]" + "'", str16.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hourOfHalfday" + "'", str34.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ISOChronology[21561]" + "'", str41.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ISOChronology[21561]" + "'", str46.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(localDateTime57);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "0" + "'", str70.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(gregorianChronology75);
        org.junit.Assert.assertNotNull(locale84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "100" + "'", str85.equals("100"));
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "0" + "'", str89.equals("0"));
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 2 + "'", int90 == 2);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + (-57621L) + "'", long92 == (-57621L));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
        long long10 = delegatedDateTimeField4.add(1L, 0);
        int int13 = delegatedDateTimeField4.getDifference((long) (byte) 0, (long) 5);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        java.lang.String str16 = iSOChronology15.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = iSOChronology15.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology15, dateTimeField22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = delegatedDateTimeField28.getAsText((long) 4, locale30);
        boolean boolean32 = delegatedDateTimeField28.isSupported();
        int int33 = delegatedDateTimeField28.getMaximumValue();
        java.lang.String str34 = delegatedDateTimeField28.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = delegatedDateTimeField28.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, dateTimeFieldType35, 21562);
        int int38 = dividedDateTimeField37.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField37);
        long long41 = remainderDateTimeField39.roundCeiling((long) 1541);
        long long43 = remainderDateTimeField39.remainder((long) 57621);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime46 = dateTime45.toDateTime();
        org.joda.time.DateTime dateTime47 = dateTime45.toDateTimeISO();
        org.joda.time.DateTime dateTime49 = dateTime45.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime51 = dateTime49.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        java.lang.String str55 = iSOChronology54.toString();
        org.joda.time.DateTimeZone dateTimeZone56 = iSOChronology54.getZone();
        org.joda.time.DateTime dateTime57 = dateTime52.withZoneRetainFields(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField61);
        java.util.Locale locale64 = null;
        java.lang.String str65 = delegatedDateTimeField62.getAsText((long) 4, locale64);
        boolean boolean66 = delegatedDateTimeField62.isSupported();
        int int67 = delegatedDateTimeField62.getMaximumValue();
        java.lang.String str68 = delegatedDateTimeField62.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = delegatedDateTimeField62.getType();
        org.joda.time.DateTime.Property property70 = dateTime52.property(dateTimeFieldType69);
        int int71 = dateTime51.get(dateTimeFieldType69);
        org.joda.time.IllegalFieldValueException illegalFieldValueException75 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType69, (java.lang.Number) 21561, (java.lang.Number) 0, (java.lang.Number) 739L);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField76 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField39, dateTimeFieldType69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType69, 79, 1, 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[21561]" + "'", str16.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hourOfHalfday" + "'", str34.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 3542379L + "'", long41 == 3542379L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 115242L + "'", long43 == 115242L);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "ISOChronology[21561]" + "'", str55.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "0" + "'", str65.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 11 + "'", int67 == 11);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "hourOfHalfday" + "'", str68.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test150");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, 10L, (int) '4');
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        long long9 = gregorianChronology0.add(readablePeriod6, (long) 739, 0);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime13 = instant12.toDateTime();
//        int int14 = dateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = delegatedDateTimeField19.getAsText((long) 4, locale21);
//        boolean boolean23 = delegatedDateTimeField19.isSupported();
//        int int24 = delegatedDateTimeField19.getMaximumValue();
//        java.lang.String str25 = delegatedDateTimeField19.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = delegatedDateTimeField19.getType();
//        org.joda.time.DateTime dateTime28 = dateTime13.withField(dateTimeFieldType26, 4);
//        try {
//            org.joda.time.DateTime dateTime30 = dateTime10.withField(dateTimeFieldType26, 35);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 739L + "'", long9 == 739L);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 46908 + "'", int14 == 46908);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 11 + "'", int24 == 11);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hourOfHalfday" + "'", str25.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime5 = dateTime1.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField18.getAsText((long) 4, locale20);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        int int23 = delegatedDateTimeField18.getMaximumValue();
        java.lang.String str24 = delegatedDateTimeField18.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField18.getType();
        org.joda.time.DateTime.Property property26 = dateTime8.property(dateTimeFieldType25);
        int int27 = dateTime7.get(dateTimeFieldType25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        java.lang.String str30 = iSOChronology29.toString();
        org.joda.time.DateTimeZone dateTimeZone31 = iSOChronology29.getZone();
        org.joda.time.DurationField durationField32 = iSOChronology29.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter33.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = dateTimeFormatter34.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology29, dateTimeZone35);
        org.joda.time.DurationField durationField37 = zonedChronology36.months();
        org.joda.time.DurationField durationField38 = zonedChronology36.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField38);
        try {
            int int41 = unsupportedDateTimeField39.getMinimumValue((long) 64771);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hourOfHalfday" + "'", str24.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[21561]" + "'", str30.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
        org.joda.time.DurationField durationField9 = iSOChronology6.halfdays();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = iSOChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology11, dateTimeField18);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
        org.joda.time.LocalDateTime localDateTime23 = dateTime21.toLocalDateTime();
        int[] intArray25 = iSOChronology11.get((org.joda.time.ReadablePartial) localDateTime23, 1560344362544L);
        int[] intArray27 = iSOChronology6.get((org.joda.time.ReadablePartial) localDateTime23, 0L);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology6.millisOfDay();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTime();
        org.joda.time.DateTime dateTime32 = dateTime30.toDateTimeISO();
        org.joda.time.DateTime dateTime34 = dateTime30.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime36 = dateTime34.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        java.lang.String str40 = iSOChronology39.toString();
        org.joda.time.DateTimeZone dateTimeZone41 = iSOChronology39.getZone();
        org.joda.time.DateTime dateTime42 = dateTime37.withZoneRetainFields(dateTimeZone41);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology44.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        java.util.Locale locale49 = null;
        java.lang.String str50 = delegatedDateTimeField47.getAsText((long) 4, locale49);
        boolean boolean51 = delegatedDateTimeField47.isSupported();
        int int52 = delegatedDateTimeField47.getMaximumValue();
        java.lang.String str53 = delegatedDateTimeField47.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = delegatedDateTimeField47.getType();
        org.joda.time.DateTime.Property property55 = dateTime37.property(dateTimeFieldType54);
        int int56 = dateTime36.get(dateTimeFieldType54);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType54, 5);
        org.joda.time.field.SkipDateTimeField skipDateTimeField59 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, (org.joda.time.DateTimeField) offsetDateTimeField58);
        boolean boolean60 = offsetDateTimeField58.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[21561]" + "'", str7.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[21561]" + "'", str12.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDateTime23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ISOChronology[21561]" + "'", str40.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hourOfHalfday" + "'", str53.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        java.lang.String str8 = delegatedDateTimeField4.toString();
        int int9 = delegatedDateTimeField4.getMaximumValue();
        long long11 = delegatedDateTimeField4.roundCeiling((-360L));
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str8.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3542379L + "'", long11 == 3542379L);
        org.junit.Assert.assertNull(durationField12);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
//        boolean boolean8 = gregorianChronology1.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str11 = dateTimeZone9.getName((long) 1);
//        org.joda.time.Chronology chronology12 = gregorianChronology1.withZone(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology1.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology1.minuteOfDay();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
        boolean boolean18 = delegatedDateTimeField14.isSupported();
        int int19 = delegatedDateTimeField14.getMaximumValue();
        java.lang.String str20 = delegatedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
        int int24 = dividedDateTimeField23.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
        try {
            long long28 = dividedDateTimeField23.set((long) 21577513, 1541);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1541 for hourOfHalfday must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime0.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime0.minusHours(2018);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime0.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test157");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        boolean boolean1 = instant0.isBeforeNow();
//        org.joda.time.Instant instant2 = new org.joda.time.Instant();
//        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
//        org.joda.time.Instant instant5 = instant0.plus((long) 10);
//        org.joda.time.Instant instant8 = instant0.withDurationAdded((long) (byte) 1, 1000);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str11 = dateTimeZone9.getName((long) 1);
//        boolean boolean12 = instant8.equals((java.lang.Object) 1);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.Instant instant14 = instant8.minus(readableDuration13);
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (short) 0);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.dayOfMonth();
//        mutableDateTime16.setMillisOfDay((int) '#');
//        mutableDateTime16.addMillis(59);
//        long long22 = mutableDateTime16.getMillis();
//        boolean boolean23 = instant14.isEqual((org.joda.time.ReadableInstant) mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-57527L) + "'", long22 == (-57527L));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test158");
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str7 = dateTimeZone5.getName((long) 1);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        long long10 = cachedDateTimeZone8.previousTransition(0L);
//        try {
//            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(47, 19, (int) (byte) 100, (-98), 359, (org.joda.time.DateTimeZone) cachedDateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        int int6 = dateTimeParserBucket5.getOffset();
        dateTimeParserBucket5.setPivotYear((java.lang.Integer) 0);
        int int9 = dateTimeParserBucket5.getOffset();
        java.util.Locale locale10 = dateTimeParserBucket5.getLocale();
        org.joda.time.Chronology chronology11 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        int int7 = delegatedDateTimeField4.getLeapAmount(739L);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology9);
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology11, locale12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField18.getAsText((long) 4, locale20);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
        java.lang.String str33 = delegatedDateTimeField32.toString();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime36 = dateTime35.toDateTime();
        org.joda.time.LocalDateTime localDateTime37 = dateTime35.toLocalDateTime();
        int[] intArray45 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
        int[] intArray47 = delegatedDateTimeField32.addWrapPartial((org.joda.time.ReadablePartial) localDateTime37, 57600, intArray45, 0);
        int[] intArray49 = skipUndoDateTimeField22.addWrapPartial((org.joda.time.ReadablePartial) localDateTime26, 0, intArray47, 57600);
        boolean boolean50 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime26);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField54);
        java.lang.String str56 = delegatedDateTimeField55.toString();
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime59 = dateTime58.toDateTime();
        org.joda.time.LocalDateTime localDateTime60 = dateTime58.toLocalDateTime();
        int[] intArray68 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
        int[] intArray70 = delegatedDateTimeField55.addWrapPartial((org.joda.time.ReadablePartial) localDateTime60, 57600, intArray68, 0);
        int int71 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDateTime26, intArray68);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str33.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDateTime37);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str56.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localDateTime60);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test161");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        boolean boolean1 = instant0.isBeforeNow();
//        org.joda.time.Instant instant2 = new org.joda.time.Instant();
//        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
//        org.joda.time.Instant instant5 = instant2.withMillis((long) (byte) 100);
//        org.joda.time.MutableDateTime mutableDateTime6 = instant2.toMutableDateTime();
//        mutableDateTime6.setDate(100L);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        java.lang.String str11 = iSOChronology10.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = delegatedDateTimeField23.getAsText((long) 4, locale25);
//        boolean boolean27 = delegatedDateTimeField23.isSupported();
//        int int28 = delegatedDateTimeField23.getMaximumValue();
//        java.lang.String str29 = delegatedDateTimeField23.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField23.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType30, 21562);
//        int int33 = dividedDateTimeField32.getMaximumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField32);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        java.lang.String str38 = iSOChronology37.toString();
//        org.joda.time.DateTimeZone dateTimeZone39 = iSOChronology37.getZone();
//        org.joda.time.DateTime dateTime40 = dateTime35.withZoneRetainFields(dateTimeZone39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = delegatedDateTimeField45.getAsText((long) 4, locale47);
//        boolean boolean49 = delegatedDateTimeField45.isSupported();
//        int int50 = delegatedDateTimeField45.getMaximumValue();
//        java.lang.String str51 = delegatedDateTimeField45.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField45.getType();
//        org.joda.time.DateTime.Property property53 = dateTime35.property(dateTimeFieldType52);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType52);
//        boolean boolean55 = mutableDateTime6.isSupported(dateTimeFieldType52);
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
//        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology56);
//        java.lang.String str59 = gregorianChronology56.toString();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology56.weekyear();
//        org.joda.time.DurationField durationField61 = gregorianChronology56.days();
//        org.joda.time.DurationField durationField62 = gregorianChronology56.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField62);
//        try {
//            long long66 = unsupportedDateTimeField63.addWrapField((long) (-1), (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hourOfHalfday" + "'", str29.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[21561]" + "'", str38.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 11 + "'", int50 == 11);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hourOfHalfday" + "'", str51.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "GregorianChronology[21561]" + "'", str59.equals("GregorianChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
        java.lang.Number number6 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", number6, (java.lang.Number) 10.0d, (java.lang.Number) 100L);
        java.lang.Number number10 = illegalFieldValueException9.getUpperBound();
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.DurationFieldType durationFieldType12 = illegalFieldValueException9.getDurationFieldType();
        java.lang.String str13 = illegalFieldValueException9.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100L + "'", number10.equals(100L));
        org.junit.Assert.assertNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "null" + "'", str13.equals("null"));
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test163");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.yearOfEra();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.weekyear();
//        mutableDateTime4.addMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        java.lang.String str12 = iSOChronology11.toString();
//        org.joda.time.DateTimeZone dateTimeZone13 = iSOChronology11.getZone();
//        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusYears(7);
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime4, (org.joda.time.ReadableInstant) dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[21561]" + "'", str12.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(chronology17);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test164");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime0.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        org.joda.time.DateTime dateTime10 = dateTime7.minusDays(2018);
//        int int11 = dateTime7.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test165");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        mutableDateTime12.add(readablePeriod13);
//        mutableDateTime12.setSecondOfMinute(10);
//        mutableDateTime12.setWeekyear(21559);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField6.getAsText((long) 4, locale8);
        boolean boolean10 = delegatedDateTimeField6.isSupported();
        int int11 = delegatedDateTimeField6.getMaximumValue();
        java.lang.String str12 = delegatedDateTimeField6.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField6.getType();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6, 0);
        org.joda.time.DurationField durationField16 = delegatedDateTimeField6.getRangeDurationField();
        java.lang.String str18 = delegatedDateTimeField6.getAsShortText(10799640L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hourOfHalfday" + "'", str12.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "3" + "'", str18.equals("3"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime0.plusWeeks((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime0.minus(readablePeriod8);
        org.joda.time.DateTime.Property property10 = dateTime0.yearOfEra();
        org.joda.time.DateTime dateTime12 = property10.setCopy((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withFieldAdded(durationFieldType13, 21562);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test168");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
//        int int7 = dateTime5.getMillisOfSecond();
//        org.joda.time.LocalTime localTime8 = dateTime5.toLocalTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 21 + "'", int7 == 21);
//        org.junit.Assert.assertNotNull(localTime8);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("21561", "2018-06-13T12:59:21.232Z", 57621, (int) (byte) 10);
        int int7 = fixedDateTimeZone5.getOffset((long) (-25200000));
        long long10 = fixedDateTimeZone5.convertLocalToUTC(1560344383477L, false);
        int int12 = fixedDateTimeZone5.getOffsetFromLocal(1560344387276L);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(3120688773696L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int16 = fixedDateTimeZone5.getOffset(1560340787276L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57621 + "'", int7 == 57621);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560344325856L + "'", long10 == 1560344325856L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57621 + "'", int12 == 57621);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57621 + "'", int16 == 57621);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(64771);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendLiteral("JulianChronology[21561]");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-1), '#', 57621, (int) (byte) 10, 1541, true, 21561);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder8.addRecurringSavings("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")", 3, 960, 59, '4', 10, (int) (short) 10, 0, false, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder19.setFixedSavings("21562", 21577513);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeZoneBuilder19.toDateTimeZone("hi!", true);
        java.io.DataOutput dataOutput27 = null;
        try {
            dateTimeZoneBuilder19.writeTo("GJChronology[America/Los_Angeles]", dataOutput27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText((long) 4, locale18);
        boolean boolean20 = delegatedDateTimeField16.isSupported();
        int int21 = delegatedDateTimeField16.getMaximumValue();
        java.lang.String str22 = delegatedDateTimeField16.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
        org.joda.time.DateTime.Property property24 = dateTime6.property(dateTimeFieldType23);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType23, (int) '4');
        long long29 = dividedDateTimeField26.add((long) 24, (long) (byte) 10);
        java.lang.String str31 = dividedDateTimeField26.getAsShortText((long) 21559);
        boolean boolean32 = dividedDateTimeField26.isSupported();
        int int33 = dividedDateTimeField26.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[21561]" + "'", str9.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hourOfHalfday" + "'", str22.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1872000024L + "'", long29 == 1872000024L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test174");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.lang.String str4 = iSOChronology3.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.LocalTime localTime8 = dateTime7.toLocalTime();
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localTime8);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[21561]" + "'", str4.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T130150" + "'", str9.equals("T130150"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText((long) 4, locale18);
        boolean boolean20 = delegatedDateTimeField16.isSupported();
        int int21 = delegatedDateTimeField16.getMaximumValue();
        java.lang.String str22 = delegatedDateTimeField16.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
        org.joda.time.DateTime.Property property24 = dateTime6.property(dateTimeFieldType23);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType23, (int) '4');
        int int28 = dividedDateTimeField26.get((long) (-28800000));
        org.joda.time.DurationField durationField29 = dividedDateTimeField26.getLeapDurationField();
        long long32 = dividedDateTimeField26.add((long) (byte) 1, (long) 'a');
        org.joda.time.tz.DefaultNameProvider defaultNameProvider33 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale36 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology35, locale36, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket39.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket39.setOffset((java.lang.Integer) 359);
        java.util.Locale locale44 = dateTimeParserBucket39.getLocale();
        java.lang.String str47 = defaultNameProvider33.getShortName(locale44, "2018-06-13T12:59:21.232Z", "1970-W01-3");
        int int48 = dividedDateTimeField26.getMaximumTextLength(locale44);
        long long51 = dividedDateTimeField26.add(93L, (long) 4);
        org.joda.time.DurationField durationField52 = dividedDateTimeField26.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[21561]" + "'", str9.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hourOfHalfday" + "'", str22.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 18158400001L + "'", long32 == 18158400001L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(locale44);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 748800093L + "'", long51 == 748800093L);
        org.junit.Assert.assertNotNull(durationField52);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test176");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str4 = dateTimeZone2.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
//        org.joda.time.LocalDateTime localDateTime10 = dateTime8.toLocalDateTime();
//        boolean boolean11 = dateTimeZone2.isLocalDateTimeGap(localDateTime10);
//        org.joda.time.DateTime dateTime12 = dateTime1.withZoneRetainFields(dateTimeZone2);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
        long long8 = iSOChronology2.add((long) (byte) -1, (long) 1000, 21559);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) iSOChronology2, locale9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField12 = iSOChronology2.minutes();
        long long15 = durationField12.subtract(0L, (int) '#');
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21558999L + "'", long8 == 21558999L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2100000L) + "'", long15 == (-2100000L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatterBuilder0.toPrinter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = iSOChronology11.getZone();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 5, dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter18.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField24.getAsText((long) 4, locale26);
        boolean boolean28 = delegatedDateTimeField24.isSupported();
        org.joda.time.ReadablePartial readablePartial29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale33 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket36 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology32, locale33, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket36.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket36.setOffset((java.lang.Integer) 359);
        java.util.Locale locale41 = dateTimeParserBucket36.getLocale();
        java.lang.String str42 = delegatedDateTimeField24.getAsShortText(readablePartial29, (int) (short) 100, locale41);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime45 = dateTime44.toDateTime();
        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider47 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField51);
        java.util.Locale locale54 = null;
        java.lang.String str55 = delegatedDateTimeField52.getAsText((long) 4, locale54);
        boolean boolean56 = delegatedDateTimeField52.isSupported();
        org.joda.time.ReadablePartial readablePartial57 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale61 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology60, locale61, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket64.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket64.setOffset((java.lang.Integer) 359);
        java.util.Locale locale69 = dateTimeParserBucket64.getLocale();
        java.lang.String str70 = delegatedDateTimeField52.getAsShortText(readablePartial57, (int) (short) 100, locale69);
        java.lang.String str73 = defaultNameProvider47.getShortName(locale69, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
        java.lang.String str74 = delegatedDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) localDateTime46, locale69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter75 = dateTimeFormatter18.withLocale(locale69);
        java.text.DateFormatSymbols dateFormatSymbols76 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale69);
        java.lang.String str77 = dateTimeZone13.getName((long) 2066, locale69);
        int int78 = property7.getMaximumTextLength(locale69);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[21561]" + "'", str12.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(locale41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "100" + "'", str42.equals("100"));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(localDateTime46);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(locale69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "100" + "'", str70.equals("100"));
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "0" + "'", str74.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter75);
        org.junit.Assert.assertNotNull(dateFormatSymbols76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "+00:00:57.621" + "'", str77.equals("+00:00:57.621"));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test180");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        boolean boolean1 = instant0.isBeforeNow();
//        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) -1);
//        long long4 = instant0.getMillis();
//        org.joda.time.MutableDateTime mutableDateTime5 = instant0.toMutableDateTimeISO();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560344453116L + "'", long4 == 1560344453116L);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(64771);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYear(19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfEra(11, (-1));
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        java.lang.String str11 = iSOChronology10.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
//        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = dateTime8.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.toDateTimeISO();
//        org.joda.time.DateTime dateTime21 = dateTime17.withMinuteOfHour(0);
//        org.joda.time.DateTime dateTime23 = dateTime21.withYear((int) (byte) 100);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
//        java.lang.String str27 = iSOChronology26.toString();
//        org.joda.time.DateTimeZone dateTimeZone28 = iSOChronology26.getZone();
//        org.joda.time.DateTime dateTime29 = dateTime24.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = delegatedDateTimeField34.getAsText((long) 4, locale36);
//        boolean boolean38 = delegatedDateTimeField34.isSupported();
//        int int39 = delegatedDateTimeField34.getMaximumValue();
//        java.lang.String str40 = delegatedDateTimeField34.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField34.getType();
//        org.joda.time.DateTime.Property property42 = dateTime24.property(dateTimeFieldType41);
//        int int43 = dateTime23.get(dateTimeFieldType41);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, (java.lang.Number) 21561, (java.lang.Number) 0, (java.lang.Number) 739L);
//        boolean boolean48 = dateTime15.isSupported(dateTimeFieldType41);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder7.appendFraction(dateTimeFieldType41, 46903, 7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str55 = dateTimeZone53.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime56 = org.joda.time.MutableDateTime.now(dateTimeZone53);
//        mutableDateTime56.addWeekyears((int) (byte) -1);
//        int int61 = dateTimeFormatter52.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime56, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.format.DateTimePrinter dateTimePrinter62 = dateTimeFormatter52.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder7.append(dateTimePrinter62);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str67 = dateTimeZone65.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime68 = org.joda.time.MutableDateTime.now(dateTimeZone65);
//        mutableDateTime68.addWeekyears((int) (byte) -1);
//        int int73 = dateTimeFormatter64.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime68, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.format.DateTimePrinter dateTimePrinter74 = dateTimeFormatter64.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter75 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeParser dateTimeParser76 = dateTimeFormatter75.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder7.append(dateTimePrinter74, dateTimeParser76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[21561]" + "'", str27.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 11 + "'", int39 == 11);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hourOfHalfday" + "'", str40.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Coordinated Universal Time" + "'", str55.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-98) + "'", int61 == (-98));
//        org.junit.Assert.assertNotNull(dateTimePrinter62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(dateTimeFormatter64);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Coordinated Universal Time" + "'", str67.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime68);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-98) + "'", int73 == (-98));
//        org.junit.Assert.assertNotNull(dateTimePrinter74);
//        org.junit.Assert.assertNotNull(dateTimeFormatter75);
//        org.junit.Assert.assertNotNull(dateTimeParser76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.lang.String str4 = jodaTimePermission1.toString();
        java.lang.Object obj5 = null;
        boolean boolean6 = jodaTimePermission1.equals(obj5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(43200, 2068, 79, (-49));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test184");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        java.lang.String str5 = cachedDateTimeZone3.getNameKey((long) 5);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = cachedDateTimeZone3.getShortName((long) 46786439, locale7);
//        long long10 = cachedDateTimeZone3.previousTransition((long) 2);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
        int int8 = delegatedDateTimeField4.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
        long long12 = offsetDateTimeField10.roundHalfEven(0L);
        int int13 = offsetDateTimeField10.getMinimumValue();
        int int15 = offsetDateTimeField10.get(17L);
        long long17 = offsetDateTimeField10.remainder(1558036800000L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-57621L) + "'", long12 == (-57621L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 57621L + "'", long17 == 57621L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime5 = dateTime1.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField18.getAsText((long) 4, locale20);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        int int23 = delegatedDateTimeField18.getMaximumValue();
        java.lang.String str24 = delegatedDateTimeField18.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField18.getType();
        org.joda.time.DateTime.Property property26 = dateTime8.property(dateTimeFieldType25);
        int int27 = dateTime7.get(dateTimeFieldType25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        java.lang.String str30 = iSOChronology29.toString();
        org.joda.time.DateTimeZone dateTimeZone31 = iSOChronology29.getZone();
        org.joda.time.DurationField durationField32 = iSOChronology29.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter33.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = dateTimeFormatter34.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology29, dateTimeZone35);
        org.joda.time.DurationField durationField37 = zonedChronology36.months();
        org.joda.time.DurationField durationField38 = zonedChronology36.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField38);
        boolean boolean40 = unsupportedDateTimeField39.isSupported();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hourOfHalfday" + "'", str24.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[21561]" + "'", str30.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test187");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        mutableDateTime12.add(readablePeriod13);
//        mutableDateTime12.setSecondOfMinute(10);
//        mutableDateTime12.setMinuteOfDay(0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test188");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTimeISO();
//        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime7 = instant6.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay(100);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        java.lang.Class<?> wildcardClass11 = dateTime7.getClass();
//        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime2, (org.joda.time.ReadableDateTime) dateTime7);
//        try {
//            long long17 = limitChronology12.getDateTimeMillis(7198652, 46881, 0, 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 46881 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560344454155L + "'", long10 == 1560344454155L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(limitChronology12);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test189");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
//        long long8 = iSOChronology2.add((long) (byte) -1, (long) 1000, 21559);
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) iSOChronology2, locale9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
//        int int12 = dateTime11.getYearOfCentury();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds(0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21558999L + "'", long8 == 21558999L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime5 = dateTime1.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField18.getAsText((long) 4, locale20);
        boolean boolean22 = delegatedDateTimeField18.isSupported();
        int int23 = delegatedDateTimeField18.getMaximumValue();
        java.lang.String str24 = delegatedDateTimeField18.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField18.getType();
        org.joda.time.DateTime.Property property26 = dateTime8.property(dateTimeFieldType25);
        int int27 = dateTime7.get(dateTimeFieldType25);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        java.lang.String str30 = iSOChronology29.toString();
        org.joda.time.DateTimeZone dateTimeZone31 = iSOChronology29.getZone();
        org.joda.time.DurationField durationField32 = iSOChronology29.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter33.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = dateTimeFormatter34.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology29, dateTimeZone35);
        org.joda.time.DurationField durationField37 = zonedChronology36.months();
        org.joda.time.DurationField durationField38 = zonedChronology36.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField38);
        try {
            int int41 = unsupportedDateTimeField39.getMaximumValue((-28800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hourOfHalfday" + "'", str24.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[21561]" + "'", str30.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.Instant instant5 = instant2.withMillis((long) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = instant2.toMutableDateTime();
        mutableDateTime6.setDate(100L);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField23.getAsText((long) 4, locale25);
        boolean boolean27 = delegatedDateTimeField23.isSupported();
        int int28 = delegatedDateTimeField23.getMaximumValue();
        java.lang.String str29 = delegatedDateTimeField23.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField23.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType30, 21562);
        int int33 = dividedDateTimeField32.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField32);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DateTimeZone dateTimeZone39 = iSOChronology37.getZone();
        org.joda.time.DateTime dateTime40 = dateTime35.withZoneRetainFields(dateTimeZone39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = delegatedDateTimeField45.getAsText((long) 4, locale47);
        boolean boolean49 = delegatedDateTimeField45.isSupported();
        int int50 = delegatedDateTimeField45.getMaximumValue();
        java.lang.String str51 = delegatedDateTimeField45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField45.getType();
        org.joda.time.DateTime.Property property53 = dateTime35.property(dateTimeFieldType52);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType52);
        boolean boolean55 = mutableDateTime6.isSupported(dateTimeFieldType52);
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology56);
        java.lang.String str59 = gregorianChronology56.toString();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology56.weekyear();
        org.joda.time.DurationField durationField61 = gregorianChronology56.days();
        org.joda.time.DurationField durationField62 = gregorianChronology56.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField62);
        try {
            boolean boolean65 = unsupportedDateTimeField63.isLeap(1128L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfHalfday field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hourOfHalfday" + "'", str29.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[21561]" + "'", str38.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 11 + "'", int50 == 11);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hourOfHalfday" + "'", str51.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "GregorianChronology[21561]" + "'", str59.equals("GregorianChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
        boolean boolean8 = delegatedDateTimeField4.isSupported();
        int int9 = delegatedDateTimeField4.getMaximumValue();
        java.lang.String str10 = delegatedDateTimeField4.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        java.lang.String str15 = iSOChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology14.getZone();
        org.joda.time.DurationField durationField17 = iSOChronology14.halfdays();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        java.lang.String str20 = iSOChronology19.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology19.getZone();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology19, dateTimeField26);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime30 = dateTime29.toDateTime();
        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
        int[] intArray33 = iSOChronology19.get((org.joda.time.ReadablePartial) localDateTime31, 1560344362544L);
        int[] intArray35 = iSOChronology14.get((org.joda.time.ReadablePartial) localDateTime31, 0L);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology14.millisOfDay();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime39 = dateTime38.toDateTime();
        org.joda.time.DateTime dateTime40 = dateTime38.toDateTimeISO();
        org.joda.time.DateTime dateTime42 = dateTime38.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime44 = dateTime42.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = iSOChronology47.toString();
        org.joda.time.DateTimeZone dateTimeZone49 = iSOChronology47.getZone();
        org.joda.time.DateTime dateTime50 = dateTime45.withZoneRetainFields(dateTimeZone49);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField54);
        java.util.Locale locale57 = null;
        java.lang.String str58 = delegatedDateTimeField55.getAsText((long) 4, locale57);
        boolean boolean59 = delegatedDateTimeField55.isSupported();
        int int60 = delegatedDateTimeField55.getMaximumValue();
        java.lang.String str61 = delegatedDateTimeField55.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = delegatedDateTimeField55.getType();
        org.joda.time.DateTime.Property property63 = dateTime45.property(dateTimeFieldType62);
        int int64 = dateTime44.get(dateTimeFieldType62);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, dateTimeFieldType62, 5);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField67 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType62);
        long long69 = zeroIsMaxDateTimeField67.roundHalfFloor((long) (byte) 1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hourOfHalfday" + "'", str10.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[21561]" + "'", str15.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ISOChronology[21561]" + "'", str20.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[21561]" + "'", str48.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0" + "'", str58.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 11 + "'", int60 == 11);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hourOfHalfday" + "'", str61.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-57621L) + "'", long69 == (-57621L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) 100, 'a', (int) (short) 0, 100, 2000, false, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2018-06-13T13:00:15.655Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
        org.joda.time.Chronology chronology6 = dateTime5.getChronology();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.DurationField durationField11 = iSOChronology8.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter12.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeFormatter13.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, dateTimeZone14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("21561", "2018-06-13T12:59:21.232Z", 57621, (int) (byte) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime5.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime24 = dateTime22.withCenturyOfEra(46874);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[21561]" + "'", str9.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test197");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0L, dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
//        boolean boolean10 = dateTime8.isAfter((-28856661L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.hourOfDay();
        int int8 = mutableDateTime5.getMinuteOfDay();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.era();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 720 + "'", int8 == 720);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test199");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        boolean boolean1 = instant0.isBeforeNow();
//        org.joda.time.Instant instant2 = new org.joda.time.Instant();
//        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
//        boolean boolean5 = instant2.isAfter(0L);
//        org.joda.time.MutableDateTime mutableDateTime6 = instant2.toMutableDateTime();
//        long long7 = instant2.getMillis();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560344454635L + "'", long7 == 1560344454635L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
        long long10 = delegatedDateTimeField4.add(1L, 0);
        int int12 = delegatedDateTimeField4.getLeapAmount(21560L);
        long long15 = delegatedDateTimeField4.getDifferenceAsLong((long) 1000, (-1L));
        long long17 = delegatedDateTimeField4.remainder(1560344362544L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 20165L + "'", long17 == 20165L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone6, readableInstant8);
        try {
            long long14 = gJChronology9.getDateTimeMillis(5, (-28800000), 3, 64771395);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[21561]" + "'", str3.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(64771);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYear(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfEra(11, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.Chronology chronology3 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.Instant instant5 = instant2.withMillis((long) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = instant2.toMutableDateTime();
        mutableDateTime6.setDate(100L);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField23.getAsText((long) 4, locale25);
        boolean boolean27 = delegatedDateTimeField23.isSupported();
        int int28 = delegatedDateTimeField23.getMaximumValue();
        java.lang.String str29 = delegatedDateTimeField23.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField23.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType30, 21562);
        int int33 = dividedDateTimeField32.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField32);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DateTimeZone dateTimeZone39 = iSOChronology37.getZone();
        org.joda.time.DateTime dateTime40 = dateTime35.withZoneRetainFields(dateTimeZone39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = delegatedDateTimeField45.getAsText((long) 4, locale47);
        boolean boolean49 = delegatedDateTimeField45.isSupported();
        int int50 = delegatedDateTimeField45.getMaximumValue();
        java.lang.String str51 = delegatedDateTimeField45.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField45.getType();
        org.joda.time.DateTime.Property property53 = dateTime35.property(dateTimeFieldType52);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType52);
        boolean boolean55 = mutableDateTime6.isSupported(dateTimeFieldType52);
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology56);
        java.lang.String str59 = gregorianChronology56.toString();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology56.weekyear();
        org.joda.time.DurationField durationField61 = gregorianChronology56.days();
        org.joda.time.DurationField durationField62 = gregorianChronology56.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField62);
        long long66 = unsupportedDateTimeField63.add((long) 21, 0L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[21561]" + "'", str11.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hourOfHalfday" + "'", str29.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[21561]" + "'", str38.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 11 + "'", int50 == 11);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hourOfHalfday" + "'", str51.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "GregorianChronology[21561]" + "'", str59.equals("GregorianChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 21L + "'", long66 == 21L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = iSOChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
        java.lang.String str9 = zonedChronology8.toString();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.minuteOfHour();
        try {
            long long18 = zonedChronology8.getDateTimeMillis(46891, 68, (-25200000), (int) (byte) 1, (-25200000), (int) (short) -1, 641);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[21561]" + "'", str2.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test206");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.addWeekyears((int) (byte) -1);
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        boolean boolean7 = instant6.isBeforeNow();
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        boolean boolean9 = instant6.isBefore((org.joda.time.ReadableInstant) instant8);
//        mutableDateTime3.setTime((org.joda.time.ReadableInstant) instant8);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        boolean boolean12 = instant11.isBeforeNow();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant11.isBefore((org.joda.time.ReadableInstant) instant13);
//        boolean boolean16 = instant13.isAfter(0L);
//        org.joda.time.MutableDateTime mutableDateTime17 = instant13.toMutableDateTime();
//        int int18 = mutableDateTime17.getMinuteOfHour();
//        org.joda.time.DateTimeField dateTimeField19 = mutableDateTime17.getRoundingField();
//        mutableDateTime3.setTime((org.joda.time.ReadableInstant) mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNull(dateTimeField19);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test207");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.lang.String str7 = iSOChronology6.toString();
//        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField13);
//        long long17 = skipUndoDateTimeField14.add(1560344381373L, (-641));
//        int int18 = skipUndoDateTimeField14.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
//        java.lang.String str23 = iSOChronology22.toString();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology22.getZone();
//        org.joda.time.DateTime dateTime25 = dateTime20.withZoneRetainFields(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime25.withLaterOffsetAtOverlap();
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        java.lang.String str28 = dateTimeFormatter19.print((org.joda.time.ReadablePartial) localTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
//        org.joda.time.DateTimeField dateTimeField34 = delegatedDateTimeField33.getWrappedField();
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        java.lang.String str38 = iSOChronology37.toString();
//        org.joda.time.DateTimeZone dateTimeZone39 = iSOChronology37.getZone();
//        org.joda.time.DateTime dateTime40 = dateTime35.withZoneRetainFields(dateTimeZone39);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = delegatedDateTimeField45.getAsText((long) 4, locale47);
//        boolean boolean49 = delegatedDateTimeField45.isSupported();
//        int int50 = delegatedDateTimeField45.getMaximumValue();
//        java.lang.String str51 = delegatedDateTimeField45.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField45.getType();
//        org.joda.time.DateTime.Property property53 = dateTime35.property(dateTimeFieldType52);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField(dateTimeField34, dateTimeFieldType52, (int) '4');
//        int int57 = dividedDateTimeField55.get((long) (-28800000));
//        org.joda.time.DurationField durationField58 = dividedDateTimeField55.getLeapDurationField();
//        long long61 = dividedDateTimeField55.add((long) (byte) 1, (long) 'a');
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider62 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale65 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket68 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology64, locale65, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket68.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket68.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale73 = dateTimeParserBucket68.getLocale();
//        java.lang.String str76 = defaultNameProvider62.getShortName(locale73, "2018-06-13T12:59:21.232Z", "1970-W01-3");
//        int int77 = dividedDateTimeField55.getMaximumTextLength(locale73);
//        java.lang.String str78 = skipUndoDateTimeField14.getAsText((org.joda.time.ReadablePartial) localTime27, locale73);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket81 = new org.joda.time.format.DateTimeParserBucket((long) 58, (org.joda.time.Chronology) iSOChronology2, locale73, (java.lang.Integer) 79706, (int) (short) 10);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[21561]" + "'", str7.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1558036781373L + "'", long17 == 1558036781373L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[21561]" + "'", str23.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "T130152" + "'", str28.equals("T130152"));
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[21561]" + "'", str38.equals("ISOChronology[21561]"));
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 11 + "'", int50 == 11);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hourOfHalfday" + "'", str51.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNull(durationField58);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 18158400001L + "'", long61 == 18158400001L);
//        org.junit.Assert.assertNotNull(gregorianChronology64);
//        org.junit.Assert.assertNotNull(locale73);
//        org.junit.Assert.assertNull(str76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "13" + "'", str78.equals("13"));
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2067-11-22T17:59:10.529-08:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2067-11-22T17:59:10.529-08:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
        boolean boolean8 = delegatedDateTimeField4.isSupported();
        int int9 = delegatedDateTimeField4.getMaximumValue();
        java.lang.String str10 = delegatedDateTimeField4.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        java.lang.String str15 = iSOChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology14.getZone();
        org.joda.time.DurationField durationField17 = iSOChronology14.halfdays();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        java.lang.String str20 = iSOChronology19.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology19.getZone();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.clockhourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology19, dateTimeField26);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime30 = dateTime29.toDateTime();
        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
        int[] intArray33 = iSOChronology19.get((org.joda.time.ReadablePartial) localDateTime31, 1560344362544L);
        int[] intArray35 = iSOChronology14.get((org.joda.time.ReadablePartial) localDateTime31, 0L);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology14.millisOfDay();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime39 = dateTime38.toDateTime();
        org.joda.time.DateTime dateTime40 = dateTime38.toDateTimeISO();
        org.joda.time.DateTime dateTime42 = dateTime38.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime44 = dateTime42.withYear((int) (byte) 100);
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = iSOChronology47.toString();
        org.joda.time.DateTimeZone dateTimeZone49 = iSOChronology47.getZone();
        org.joda.time.DateTime dateTime50 = dateTime45.withZoneRetainFields(dateTimeZone49);
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField54);
        java.util.Locale locale57 = null;
        java.lang.String str58 = delegatedDateTimeField55.getAsText((long) 4, locale57);
        boolean boolean59 = delegatedDateTimeField55.isSupported();
        int int60 = delegatedDateTimeField55.getMaximumValue();
        java.lang.String str61 = delegatedDateTimeField55.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = delegatedDateTimeField55.getType();
        org.joda.time.DateTime.Property property63 = dateTime45.property(dateTimeFieldType62);
        int int64 = dateTime44.get(dateTimeFieldType62);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, dateTimeFieldType62, 5);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField67 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType62);
        long long69 = zeroIsMaxDateTimeField67.roundFloor((long) ' ');
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hourOfHalfday" + "'", str10.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[21561]" + "'", str15.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ISOChronology[21561]" + "'", str20.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ISOChronology[21561]" + "'", str48.equals("ISOChronology[21561]"));
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0" + "'", str58.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 11 + "'", int60 == 11);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hourOfHalfday" + "'", str61.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-57621L) + "'", long69 == (-57621L));
    }
}

