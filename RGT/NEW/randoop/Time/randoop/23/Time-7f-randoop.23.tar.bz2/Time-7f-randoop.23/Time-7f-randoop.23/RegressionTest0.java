import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(10, (int) 'a', 10, (int) (short) -1, (int) (byte) 100, 1, (int) (byte) 10, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology8, locale9, (java.lang.Integer) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((int) '#', 4, (int) (byte) 1, (int) (byte) 10, 0, (int) 'a', (int) (short) -1, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        try {
            org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test013");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        java.lang.String str9 = iSOChronology8.toString();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 10, 100, (int) (short) 10, (int) (short) 100, 1, (org.joda.time.Chronology) iSOChronology8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str9.equals("ISOChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
        boolean boolean8 = gregorianChronology1.equals((java.lang.Object) (byte) 100);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray11 = gregorianChronology1.get(readablePeriod9, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant2.isBeforeNow();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant2.isBefore((org.joda.time.ReadableInstant) instant4);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) instant4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField3 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = dateTime1.toString("", locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.DurationFieldType durationFieldType4 = null;
//        try {
//            mutableDateTime3.add(durationFieldType4, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 2440587.5d, (org.joda.time.Chronology) gregorianChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField7 = gregorianChronology1.halfdays();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField7 = gregorianChronology1.halfdays();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType8, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        java.util.Locale locale6 = null;
        try {
            org.joda.time.DateTime dateTime7 = property4.setCopy("ISOChronology[America/Los_Angeles]", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[America/Los_Angeles]\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology2, locale3, (java.lang.Integer) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DurationField durationField8 = gregorianChronology2.halfdays();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField9 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, (int) (short) 10, 1000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.addWeekyears((int) (byte) -1);
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        boolean boolean7 = instant6.isBeforeNow();
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        boolean boolean9 = instant6.isBefore((org.joda.time.ReadableInstant) instant8);
//        mutableDateTime3.setTime((org.joda.time.ReadableInstant) instant8);
//        try {
//            mutableDateTime3.setMillisOfSecond(57600);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.addWeekyears((int) (byte) -1);
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        boolean boolean7 = instant6.isBeforeNow();
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        boolean boolean9 = instant6.isBefore((org.joda.time.ReadableInstant) instant8);
//        mutableDateTime3.setTime((org.joda.time.ReadableInstant) instant8);
//        try {
//            mutableDateTime3.setDate((int) (byte) 10, (int) '#', (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 4);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (-98), 2000);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.addWeekyears((int) (byte) -1);
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        boolean boolean7 = instant6.isBeforeNow();
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        boolean boolean9 = instant6.isBefore((org.joda.time.ReadableInstant) instant8);
//        mutableDateTime3.setTime((org.joda.time.ReadableInstant) instant8);
//        try {
//            mutableDateTime3.setDateTime(57600, 0, 100, (int) (short) 0, (int) ' ', 59, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.addWeekyears((int) (byte) -1);
//        try {
//            mutableDateTime3.setTime(0, 2000, 57600, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(100);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withMonthOfYear(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 10, 10, (-98), (int) (short) 10, (int) (short) 1, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Coordinated Universal Time' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.Chronology chronology4 = iSOChronology1.withUTC();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) 100, 'a', (int) (short) 0, 100, 2000, false, (int) ' ');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("ISOChronology[America/Los_Angeles]", 57600, (-1), 1, ' ', (-98), 4, 100, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
        java.lang.Number number6 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", number6, (java.lang.Number) 10.0d, (java.lang.Number) 100L);
        java.lang.Number number10 = illegalFieldValueException9.getUpperBound();
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = illegalFieldValueException9.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100L + "'", number10.equals(100L));
        org.junit.Assert.assertNull(dateTimeFieldType12);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
        org.joda.time.DurationField durationField4 = iSOChronology2.centuries();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology6, locale7, (java.lang.Integer) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology6.weekOfWeekyear();
        org.joda.time.DurationField durationField12 = gregorianChronology6.halfdays();
        long long15 = durationField12.subtract((long) (short) 10, (-1));
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField16 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField4, durationField12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43200010L + "'", long15 == 43200010L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        int int2 = dateTimeFormatter1.getDefaultYear();
        org.joda.time.Chronology chronology3 = dateTimeFormatter1.getChronology();
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((int) '#', (int) (short) 100, 59, 0, 21559, 2000, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21559 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(21561, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21561 + "'", int2 == 21561);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int[] intArray10 = new int[] { 57600, ' ', 2000 };
        java.util.Locale locale12 = null;
        try {
            int[] intArray13 = delegatedDateTimeField4.set(readablePartial5, 1, intArray10, "ISOChronology[America/Los_Angeles]", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[America/Los_Angeles]\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 100, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(2000, 57600, 100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) -1, 4, 21561);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.joda.time.Instant instant7 = new org.joda.time.Instant();
//        boolean boolean8 = instant7.isBeforeNow();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        boolean boolean10 = instant7.isBefore((org.joda.time.ReadableInstant) instant9);
//        org.joda.time.Instant instant12 = instant9.withMillis((long) (byte) 100);
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant13.isBeforeNow();
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant9, (org.joda.time.ReadableInstant) instant13);
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((int) 'a', (int) '4', 0, (int) (short) 100, (-1), 59, 100, chronology15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale7 = null;
        try {
            long long8 = delegatedDateTimeField4.set((long) 100, "", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        int int6 = dateTimeParserBucket5.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            dateTimeParserBucket5.saveField(dateTimeFieldType7, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210862267200000L) + "'", long1 == (-210862267200000L));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(21561);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 21561");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        java.lang.String str3 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType5, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        mutableDateTime12.add(readablePeriod13);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        try {
//            int int16 = mutableDateTime12.get(dateTimeFieldType15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray14 = new int[] { (byte) 10, (short) 100, 2000, (short) -1 };
//        try {
//            int[] intArray16 = delegatedDateTimeField4.set(readablePartial8, 3, intArray14, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertNotNull(intArray14);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime1.yearOfEra();
        try {
            org.joda.time.DateTime dateTime5 = property3.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        try {
            long long9 = buddhistChronology1.getDateTimeMillis(100, 10, (int) (byte) -1, 0, (int) (byte) 0, 0, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 739);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getMinuteOfHour();
//        org.joda.time.DateTime.Property property4 = dateTime1.monthOfYear();
//        java.util.Locale locale6 = null;
//        try {
//            org.joda.time.DateTime dateTime7 = property4.setCopy("DateTimeField[hourOfHalfday]", locale6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[hourOfHalfday]\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(property4);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '0' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 739L + "'", long0 == 739L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        mutableDateTime4.addSeconds((-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology7);
//        java.lang.String str10 = gregorianChronology7.toString();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.monthOfYear();
//        try {
//            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) '#', (int) 'a', 21559, 21560, (-98), (int) (short) -1, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21560 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str10.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 10, "DateTimeField[hourOfHalfday]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.adjustOffset((long) 10, false);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(21561, (int) (short) -1, 2000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1541 + "'", int3 == 1541);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, 100, (int) 'a', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) readableInterval1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.Interval");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        java.lang.String str4 = iSOChronology1.toString();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(739L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000085533d + "'", double1 == 2440587.5000085533d);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
//        int int5 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        try {
//            org.joda.time.DateTime.Property property7 = dateTime1.property(dateTimeFieldType6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 960 + "'", int5 == 960);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone6.getName((long) 1);
//        org.joda.time.DateTime dateTime9 = dateTime1.toDateTime(dateTimeZone6);
//        org.joda.time.Instant instant10 = new org.joda.time.Instant();
//        boolean boolean11 = instant10.isBeforeNow();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        boolean boolean13 = instant10.isBefore((org.joda.time.ReadableInstant) instant12);
//        org.joda.time.Instant instant15 = instant12.withMillis((long) (byte) 100);
//        org.joda.time.Instant instant18 = instant12.withDurationAdded((long) 100, (int) 'a');
//        boolean boolean19 = dateTime1.isBefore((org.joda.time.ReadableInstant) instant18);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertNotNull(instant18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 641);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 641");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(21559, 0, 0, (int) '4', 21560, 1541);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology3, locale4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField14, dateTimeFieldType15, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4" + "'", str13.equals("4"));
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.DurationField durationField5 = iSOChronology1.years();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("DateTimeField[hourOfHalfday]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: DateTimeField[hourOfHalfday]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((int) '4', 57621, (int) (byte) -1, 57600, 21562, 3, (int) '4', (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        java.lang.String str8 = iSOChronology7.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = iSOChronology7.getZone();
//        org.joda.time.DateTime dateTime10 = dateTime5.withZoneRetainFields(dateTimeZone9);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str14 = dateTimeZone12.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now(dateTimeZone12);
//        mutableDateTime15.addWeekyears((int) (byte) -1);
//        int int20 = dateTimeFormatter11.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime15, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime15.toMutableDateTime((org.joda.time.Chronology) gregorianChronology21);
//        java.lang.String str24 = mutableDateTime15.toString();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime15);
//        try {
//            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(10, 21561, (int) (short) 0, (int) ' ', (int) (byte) 0, dateTimeZone9);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str8.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-98) + "'", int20 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969-01-02T00:00:00.739Z" + "'", str24.equals("1969-01-02T00:00:00.739Z"));
//        org.junit.Assert.assertNotNull(gJChronology25);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0, 57600, 3, (int) (byte) 1, (int) '4', 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1);
        int int8 = dateTimeParserBucket5.getOffset();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        java.util.Locale locale11 = null;
        try {
            dateTimeParserBucket5.saveField(dateTimeFieldType9, "hi!", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((long) 4, locale7);
//        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
//        org.joda.time.DurationField durationField18 = delegatedDateTimeField14.getDurationField();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField19 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField9, durationField18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4" + "'", str8.equals("4"));
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
//        org.junit.Assert.assertNotNull(durationField18);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0f, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        java.lang.Class<?> wildcardClass4 = dateTime1.getClass();
//        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime1.withDate(1, (int) (byte) 10, 21561);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21561 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str9 = dateTimeZone7.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone7);
//        mutableDateTime10.addWeekyears((int) (byte) -1);
//        int int15 = dateTimeFormatter6.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime10.toMutableDateTime((org.joda.time.Chronology) gregorianChronology16);
//        java.lang.String str19 = mutableDateTime10.toString();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime10);
//        try {
//            long long28 = gJChronology20.getDateTimeMillis((int) (short) 100, 57600, (int) (short) 0, 59, 0, 641, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-98) + "'", int15 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1969-01-02T00:00:00.739Z" + "'", str19.equals("1969-01-02T00:00:00.739Z"));
//        org.junit.Assert.assertNotNull(gJChronology20);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        try {
            long long10 = julianChronology2.getDateTimeMillis((int) (short) 100, 0, (int) (short) 100, 641, 641, (int) (byte) 10, 21561);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 641 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'ISOChronology[America/Los_Angeles]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        try {
            mutableDateTime1.setDate((int) 'a', 641, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 641 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        java.lang.String str7 = delegatedDateTimeField6.toString();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.LocalDateTime localDateTime11 = dateTime9.toLocalDateTime();
        int[] intArray19 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
        int[] intArray21 = delegatedDateTimeField6.addWrapPartial((org.joda.time.ReadablePartial) localDateTime11, 57600, intArray19, 0);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str7.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("4", (-1), 59, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for 4 must be in the range [59,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime1.yearOfEra();
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withYearOfEra((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(43200010L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43200010L + "'", long2 == 43200010L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime3 = instant2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readablePeriod6);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 43200010L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology7);
//        java.util.Locale locale10 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology9, locale10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = delegatedDateTimeField16.getAsText((long) 4, locale18);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, (org.joda.time.DateTimeField) delegatedDateTimeField16);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime23 = dateTime22.toDateTime();
//        org.joda.time.LocalDateTime localDateTime24 = dateTime22.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
//        java.lang.String str31 = delegatedDateTimeField30.toString();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime34 = dateTime33.toDateTime();
//        org.joda.time.LocalDateTime localDateTime35 = dateTime33.toLocalDateTime();
//        int[] intArray43 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
//        int[] intArray45 = delegatedDateTimeField30.addWrapPartial((org.joda.time.ReadablePartial) localDateTime35, 57600, intArray43, 0);
//        int[] intArray47 = skipUndoDateTimeField20.addWrapPartial((org.joda.time.ReadablePartial) localDateTime24, 0, intArray45, 57600);
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone51 = gregorianChronology50.getZone();
//        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology50);
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology52, locale53);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology56.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology56.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = delegatedDateTimeField59.getAsText((long) 4, locale61);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField63 = new org.joda.time.field.SkipUndoDateTimeField(chronology52, (org.joda.time.DateTimeField) delegatedDateTimeField59);
//        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime66 = dateTime65.toDateTime();
//        org.joda.time.LocalDateTime localDateTime67 = dateTime65.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology70 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone69);
//        org.joda.time.DateTimeField dateTimeField71 = iSOChronology70.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField72 = iSOChronology70.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField73 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField72);
//        java.lang.String str74 = delegatedDateTimeField73.toString();
//        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime77 = dateTime76.toDateTime();
//        org.joda.time.LocalDateTime localDateTime78 = dateTime76.toLocalDateTime();
//        int[] intArray86 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
//        int[] intArray88 = delegatedDateTimeField73.addWrapPartial((org.joda.time.ReadablePartial) localDateTime78, 57600, intArray86, 0);
//        int[] intArray90 = skipUndoDateTimeField63.addWrapPartial((org.joda.time.ReadablePartial) localDateTime67, 0, intArray88, 57600);
//        try {
//            int[] intArray92 = delegatedDateTimeField4.add((org.joda.time.ReadablePartial) localDateTime24, 100, intArray90, (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4" + "'", str19.equals("4"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localDateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str31.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDateTime35);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(iSOChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "4" + "'", str62.equals("4"));
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(localDateTime67);
//        org.junit.Assert.assertNotNull(iSOChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str74.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(localDateTime78);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertNotNull(intArray88);
//        org.junit.Assert.assertNotNull(intArray90);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        mutableDateTime12.setMillisOfDay((int) (byte) 10);
//        mutableDateTime12.addDays((int) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        try {
//            int int18 = mutableDateTime12.get(dateTimeFieldType17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = delegatedDateTimeField4.getAsShortText((long) '4', locale9);
//        boolean boolean11 = delegatedDateTimeField4.isLenient();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4" + "'", str10.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.Instant instant5 = instant0.plus((long) 10);
        org.joda.time.MutableDateTime mutableDateTime6 = instant0.toMutableDateTimeISO();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime6 = instant5.toDateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis((long) 0);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfDay();
        org.joda.time.Chronology chronology10 = dateTime6.getChronology();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(739, 1541, 2, (int) 'a', 100, chronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-1), (long) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str9 = dateTimeZone7.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone7);
//        mutableDateTime10.addWeekyears((int) (byte) -1);
//        int int15 = dateTimeFormatter6.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime10.toMutableDateTime((org.joda.time.Chronology) gregorianChronology16);
//        java.lang.String str19 = mutableDateTime10.toString();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime10);
//        try {
//            long long28 = gJChronology20.getDateTimeMillis((int) '#', 21559, (int) ' ', 2000, (int) (byte) 1, (-98), (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-98) + "'", int15 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1969-01-02T00:00:00.739Z" + "'", str19.equals("1969-01-02T00:00:00.739Z"));
//        org.junit.Assert.assertNotNull(gJChronology20);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime1.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withField(dateTimeFieldType4, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str5 = dateTimeZone3.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone3);
//        mutableDateTime6.addWeekyears((int) (byte) -1);
//        int int11 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime6, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
//        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime6.toMutableDateTime((org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        mutableDateTime14.add(readablePeriod15);
//        mutableDateTime14.setSecondOfMinute(10);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) mutableDateTime14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-98) + "'", int11 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        int int9 = delegatedDateTimeField4.get((long) 1);
//        java.util.Locale locale10 = null;
//        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
//        long long14 = delegatedDateTimeField4.set((long) 21560, 0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-14378440L) + "'", long14 == (-14378440L));
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = julianChronology2.toString();
//        try {
//            long long8 = julianChronology2.getDateTimeMillis(3, (int) (short) 0, 57621, 1000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-98), "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(641, (int) (byte) 1, 0, 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withYearOfEra((-98));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(739L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 21559, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21560L + "'", long2 == 21560L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, 21561);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100L, (java.lang.Number) (short) 1, (java.lang.Number) (-98));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 100, "1969-01-02T00:00:00.739Z");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) ' ', 21562, 739);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        java.lang.String str6 = delegatedDateTimeField4.getName();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hourOfHalfday" + "'", str6.equals("hourOfHalfday"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, 4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: Coordinated Universal Time");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology2, locale3, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.weekOfWeekyear();
//        boolean boolean9 = gregorianChronology2.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str12 = dateTimeZone10.getName((long) 1);
//        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone10);
//        java.util.Locale locale14 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 641, chronology13, locale14, (java.lang.Integer) 11);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        java.lang.String str20 = iSOChronology19.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = iSOChronology19.getZone();
//        org.joda.time.DateTime dateTime22 = dateTime17.withZoneRetainFields(dateTimeZone21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str26 = dateTimeZone24.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now(dateTimeZone24);
//        mutableDateTime27.addWeekyears((int) (byte) -1);
//        int int32 = dateTimeFormatter23.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime27, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
//        org.joda.time.MutableDateTime mutableDateTime35 = mutableDateTime27.toMutableDateTime((org.joda.time.Chronology) gregorianChronology33);
//        java.lang.String str36 = mutableDateTime27.toString();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) mutableDateTime27);
//        try {
//            org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((java.lang.Object) 11, dateTimeZone21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str20.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Coordinated Universal Time" + "'", str26.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-98) + "'", int32 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1969-01-02T00:00:00.739Z" + "'", str36.equals("1969-01-02T00:00:00.739Z"));
//        org.junit.Assert.assertNotNull(gJChronology37);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2018-06-13T12:59:21.232Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        java.lang.String str3 = gregorianChronology0.toString();
//        try {
//            long long11 = gregorianChronology0.getDateTimeMillis(21561, (-1), 57621, (int) (byte) 0, 0, (int) (short) 10, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology10, locale11, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology10.weekOfWeekyear();
//        boolean boolean17 = gregorianChronology10.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str20 = dateTimeZone18.getName((long) 1);
//        org.joda.time.Chronology chronology21 = gregorianChronology10.withZone(dateTimeZone18);
//        org.joda.time.Chronology chronology22 = iSOChronology8.withZone(dateTimeZone18);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((-98), 57621, (int) ' ', 0, 59, (int) (byte) -1, 1000, dateTimeZone18);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter0.parseMutableDateTime("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 0, (-98));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-98) + "'", int2 == (-98));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1970-W01-3");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 1, (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1969-01-02T00:00:00.739Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        mutableDateTime12.setMillisOfDay((int) (byte) 10);
//        mutableDateTime12.addDays((int) 'a');
//        mutableDateTime12.setYear(359);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((int) '#', (-28800000), 2, (int) (short) 0, 21560, 1000, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21560 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        mutableDateTime6.addWeeks((int) '#');
//        try {
//            java.lang.String str10 = mutableDateTime6.toString("UTC");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-28800000), 4, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 76 + "'", int3 == 76);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 359);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        java.util.Locale locale12 = null;
        try {
            dateTimeParserBucket5.saveField(dateTimeFieldType10, "Pacific Standard Time", locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        try {
//            long long15 = gJChronology7.getDateTimeMillis(1, 0, 4, (int) (short) -1, (-98), 10, 59);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 960);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        boolean boolean6 = dateTimeZone1.isStandardOffset((long) ' ');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
        try {
            java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2440588L, 21559);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52616636692L + "'", long2 == 52616636692L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) 100, 'a', (int) (short) 0, 100, 2000, false, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("Coordinated Universal Time", 21559);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("ZonedChronology[ISOChronology[UTC], UTC]", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        mutableDateTime1.setMillisOfDay((int) '#');
        mutableDateTime1.setMinuteOfDay((int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            mutableDateTime1.set(dateTimeFieldType7, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 359);
        java.lang.Integer int10 = dateTimeParserBucket5.getOffsetInteger();
        org.joda.time.Chronology chronology11 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 359 + "'", int10.equals(359));
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology8 = gJChronology7.withUTC();
//        try {
//            long long16 = gJChronology7.getDateTimeMillis(0, 21560, (int) (byte) 0, 2000, (int) (short) 10, (int) (byte) -1, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime0.yearOfEra();
//        try {
//            org.joda.time.DateTime dateTime8 = property6.setCopy("Coordinated Universal Time");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for yearOfEra is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText((long) 4, locale7);
//        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getDurationField();
//        try {
//            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField10 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4" + "'", str8.equals("4"));
//        org.junit.Assert.assertNotNull(durationField9);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime7 = property6.roundFloor();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime9 = property6.set(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullDate();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("Pacific Standard Time", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.lang.String str7 = iSOChronology6.toString();
//        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
//        boolean boolean10 = dateTimeZone8.isStandardOffset((long) (byte) 1);
//        java.lang.String str12 = dateTimeZone8.getName((long) 21561);
//        try {
//            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) '4', 1, 1000, (-98), 359, dateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withFieldAdded(durationFieldType6, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy((int) 'a');
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withFieldAdded(durationFieldType6, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.roundHalfEven();
        int int5 = property2.get();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusMinutes((int) (short) 100);
        org.joda.time.DateTime dateTime8 = dateTime1.withHourOfDay((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
        java.lang.Number number6 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", number6, (java.lang.Number) 10.0d, (java.lang.Number) 100L);
        java.lang.Number number10 = illegalFieldValueException9.getUpperBound();
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.String str12 = illegalFieldValueException9.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100L + "'", number10.equals(100L));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 21562, 359, 1000, 0, 57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime4.secondOfMinute();
//        java.lang.String str11 = property10.toString();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[secondOfMinute]" + "'", str11.equals("Property[secondOfMinute]"));
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        mutableDateTime1.setMillisOfDay((int) '#');
        mutableDateTime1.addMillis(59);
        org.joda.time.Instant instant7 = mutableDateTime1.toInstant();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        boolean boolean8 = delegatedDateTimeField4.isSupported();
//        int int9 = delegatedDateTimeField4.getMaximumValue();
//        java.lang.String str10 = delegatedDateTimeField4.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType11, (-1), 1000, (-98));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfHalfday must be in the range [1000,-98]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hourOfHalfday" + "'", str10.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        mutableDateTime1.setMillisOfDay((int) '#');
        mutableDateTime1.setMinuteOfDay((int) (byte) 1);
        mutableDateTime1.setMillis((-14378440L));
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        long long11 = gJChronology7.add(readablePeriod8, (long) (byte) 10, (int) (byte) 100);
//        try {
//            long long19 = gJChronology7.getDateTimeMillis((int) (short) 0, (int) '#', 100, 960, (-25200000), 100, 1541);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str7 = dateTimeZone5.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone5);
//        try {
//            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(4, (-98), 11, (int) (byte) 0, 57600, dateTimeZone5);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        mutableDateTime12.setMillisOfDay((int) (byte) 10);
//        mutableDateTime12.addDays((int) 'a');
//        try {
//            mutableDateTime12.setDayOfMonth(21561);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21561 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10.0f, (java.lang.Number) 1128L, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime11.toLocalDateTime();
//        int[] intArray15 = iSOChronology1.get((org.joda.time.ReadablePartial) localDateTime13, 1560344362544L);
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime17 = instant16.toDateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay(100);
//        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.Instant instant21 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime22 = instant21.toDateTime();
//        org.joda.time.DateTime dateTime24 = dateTime22.withMillis((long) (byte) 1);
//        org.joda.time.ReadablePeriod readablePeriod25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime22.minus(readablePeriod25);
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.ReadableDateTime) dateTime17, (org.joda.time.ReadableDateTime) dateTime22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 739L + "'", long20 == 739L);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField7 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        long long7 = iSOChronology1.add((long) (byte) -1, (long) 1000, 21559);
        org.joda.time.DurationField durationField8 = iSOChronology1.minutes();
        org.joda.time.DurationField durationField9 = iSOChronology1.days();
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) durationField9, chronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 21558999L + "'", long7 == 21558999L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.io.Writer writer2 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        org.joda.time.LocalDateTime localDateTime6 = dateTime4.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) localDateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
//        org.joda.time.DurationField durationField7 = gregorianChronology1.halfdays();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str11 = dateTimeZone9.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone9);
//        org.joda.time.Chronology chronology14 = gregorianChronology1.withZone(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = delegatedDateTimeField4.getWrappedField();
        try {
            long long8 = delegatedDateTimeField4.set((long) (byte) 0, "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        long long7 = iSOChronology1.add((long) (byte) -1, (long) 1000, 21559);
        org.joda.time.DurationField durationField8 = iSOChronology1.minutes();
        org.joda.time.DurationField durationField9 = iSOChronology1.days();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField9, durationFieldType10, 21561);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 21558999L + "'", long7 == 21558999L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 1, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = delegatedDateTimeField11.getAsText((long) 4, locale13);
//        boolean boolean15 = delegatedDateTimeField11.isSupported();
//        mutableDateTime5.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField11);
//        try {
//            mutableDateTime5.setTime(3, 739, 0, 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 739 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4" + "'", str14.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1L, (long) (-28800000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime1.withWeekOfWeekyear((int) (byte) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.plus(readablePeriod6);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        long long13 = mutableDateTime4.getMillis();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31449599261L) + "'", long13 == (-31449599261L));
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(1000, 739, 3, 76, 21560, 2000, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 76 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.months();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
//        int int3 = dateTime2.getMillisOfSecond();
//        org.joda.time.DateTime dateTime5 = dateTime2.plus((long) 2);
//        try {
//            java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 739 + "'", int3 == 739);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (-57599906L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("UTC");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = delegatedDateTimeField4.getAsShortText((long) '4', locale9);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField4, (-98), 57600, 3);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for hourOfHalfday must be in the range [57600,3]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4" + "'", str10.equals("4"));
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = delegatedDateTimeField7.getAsText((long) 4, locale9);
//        boolean boolean11 = delegatedDateTimeField7.isSupported();
//        int int12 = delegatedDateTimeField7.getMaximumValue();
//        java.lang.String str13 = delegatedDateTimeField7.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField7.getType();
//        org.joda.time.DateTime dateTime16 = dateTime1.withField(dateTimeFieldType14, 4);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType14, (int) (byte) 10, 2, (-25200000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for hourOfHalfday must be in the range [2,-25200000]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4" + "'", str10.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 11 + "'", int12 == 11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hourOfHalfday" + "'", str13.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        try {
            mutableDateTime0.setDayOfWeek(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(100);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        int int5 = dateTime1.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 739L + "'", long4 == 739L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (byte) 100);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        boolean boolean2 = dateTimeZone0.isStandardOffset((long) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, 1L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
//        int int6 = dateTime0.getSecondOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime0.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600 + "'", int6 == 57600);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy("hourOfHalfday");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hourOfHalfday\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = iSOChronology1.get(readablePeriod4, 1560344362544L, (long) 739);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        try {
            mutableDateTime1.setWeekOfWeekyear((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.minusMillis((int) (short) 100);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        mutableDateTime6.setDate(0L);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(21562, 19, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 40 + "'", int3 == 40);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = delegatedDateTimeField6.getAsText((long) 4, locale8);
//        boolean boolean10 = delegatedDateTimeField6.isSupported();
//        int int11 = delegatedDateTimeField6.getMaximumValue();
//        java.lang.String str12 = delegatedDateTimeField6.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField6.getType();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6, 0);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = delegatedDateTimeField22.getAsText((long) 4, locale24);
//        boolean boolean26 = delegatedDateTimeField22.isSupported();
//        org.joda.time.ReadablePartial readablePartial27 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale31 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology30, locale31, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket34.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket34.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale39 = dateTimeParserBucket34.getLocale();
//        java.lang.String str40 = delegatedDateTimeField22.getAsShortText(readablePartial27, (int) (short) 100, locale39);
//        try {
//            long long41 = skipDateTimeField15.set(0L, "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")", locale39);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")\" for hourOfHalfday is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4" + "'", str9.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hourOfHalfday" + "'", str12.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "4" + "'", str25.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(locale39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "100" + "'", str40.equals("100"));
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology3, locale4, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.weekOfWeekyear();
//        boolean boolean10 = gregorianChronology3.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str13 = dateTimeZone11.getName((long) 1);
//        org.joda.time.Chronology chronology14 = gregorianChronology3.withZone(dateTimeZone11);
//        org.joda.time.Chronology chronology15 = iSOChronology1.withZone(dateTimeZone11);
//        java.util.TimeZone timeZone16 = dateTimeZone11.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 'a', (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 93L + "'", long2 == 93L);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.hourOfDay();
//        try {
//            mutableDateTime5.setMonthOfYear(2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        java.lang.Class<?> wildcardClass4 = dateTime1.getClass();
//        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime1.era();
//        try {
//            org.joda.time.DateTime dateTime8 = property6.setCopy(19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21576 + "'", int2 == 21576);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology1.getZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("Property[secondOfMinute]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[secondOfMinute]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 100, 21562);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        int int6 = dateTimeParserBucket5.getOffset();
        dateTimeParserBucket5.setPivotYear((java.lang.Integer) 0);
        dateTimeParserBucket5.setPivotYear((java.lang.Integer) 3);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getDurationField();
//        try {
//            long long11 = delegatedDateTimeField4.set((-14378440L), 1000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertNotNull(durationField8);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.setYear((int) (short) 100);
//        int int6 = mutableDateTime3.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        boolean boolean3 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        long long7 = iSOChronology1.add((long) (byte) -1, (long) 1000, 21559);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        boolean boolean9 = iSOChronology1.equals((java.lang.Object) dateTimeFormatter8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = delegatedDateTimeField15.getAsText((long) 4, locale17);
//        boolean boolean19 = delegatedDateTimeField15.isSupported();
//        int int20 = delegatedDateTimeField15.getMaximumValue();
//        java.lang.String str21 = delegatedDateTimeField15.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = delegatedDateTimeField15.getType();
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField10, dateTimeFieldType22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 21558999L + "'", long7 == 21558999L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "4" + "'", str18.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hourOfHalfday" + "'", str21.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
//        java.lang.String str9 = zonedChronology8.toString();
//        try {
//            long long14 = zonedChronology8.getDateTimeMillis(10, 76, 59, 57600);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 76 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(100);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        java.lang.Class<?> wildcardClass5 = dateTime1.getClass();
//        int int6 = dateTime1.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560344377285L + "'", long4 == 1560344377285L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis(11, 100, (-98), (int) (byte) 10, 960, 16, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology7);
//        java.lang.String str10 = gregorianChronology7.toString();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(57600, 4, 76, 21560, 57600, 10, (int) (short) 1, (org.joda.time.Chronology) gregorianChronology7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21560 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str10.equals("GregorianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.parse("Coordinated Universal Time", dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear((int) (byte) 1);
//        java.lang.String str4 = dateTime1.toString();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T05:59:37.619-07:00" + "'", str4.equals("2019-06-12T05:59:37.619-07:00"));
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.hours();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        boolean boolean1 = instant0.isBeforeNow();
//        org.joda.time.Instant instant2 = new org.joda.time.Instant();
//        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
//        org.joda.time.Instant instant5 = instant2.withMillis((long) (byte) 100);
//        boolean boolean7 = instant5.isEqual((long) (byte) 1);
//        org.joda.time.Instant instant9 = instant5.withMillis((long) 21562);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(instant9);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-1), '#', 57621, (int) (byte) 10, 1541, true, 21561);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder8.addRecurringSavings("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")", 3, 960, 59, '4', 10, (int) (short) 10, 0, false, 0);
        java.io.OutputStream outputStream21 = null;
        try {
            dateTimeZoneBuilder8.writeTo("1969-01-02T00:00:00.739Z", outputStream21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology3, locale4);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 76);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "21561");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-1), '#', 57621, (int) (byte) 10, 1541, true, 21561);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder8.addRecurringSavings("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")", 3, 960, 59, '4', 10, (int) (short) 10, 0, false, 0);
        java.io.DataOutput dataOutput21 = null;
        try {
            dateTimeZoneBuilder19.writeTo("Coordinated Universal Time", dataOutput21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        int int8 = gJChronology7.getMinimumDaysInFirstWeek();
//        java.lang.String str9 = gJChronology7.toString();
//        try {
//            long long17 = gJChronology7.getDateTimeMillis((int) (byte) 1, 21562, 0, 21560, 3, 3, (-98));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21560 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str9.equals("GJChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
        int[] intArray17 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
        int[] intArray19 = delegatedDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localDateTime9, 57600, intArray17, 0);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField4.getAsText(21561, locale21);
        try {
            long long25 = delegatedDateTimeField4.set((-210866760000000L), "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "21561" + "'", str22.equals("21561"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.Instant instant4 = new org.joda.time.Instant((java.lang.Object) instant2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField7 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.monthOfYear();
        try {
            long long14 = gregorianChronology1.getDateTimeMillis(28800010L, 0, 0, 57600, 57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone6.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone6);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
//        org.joda.time.LocalDateTime localDateTime14 = dateTime12.toLocalDateTime();
//        boolean boolean15 = dateTimeZone6.isLocalDateTimeGap(localDateTime14);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
//        java.lang.String str22 = delegatedDateTimeField21.toString();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        int[] intArray34 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
//        int[] intArray36 = delegatedDateTimeField21.addWrapPartial((org.joda.time.ReadablePartial) localDateTime26, 57600, intArray34, 0);
//        try {
//            int[] intArray38 = delegatedDateTimeField4.add((org.joda.time.ReadablePartial) localDateTime14, 0, intArray36, 76);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str22.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertNotNull(intArray36);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(4, (int) '4', 11, (int) '#', 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        boolean boolean4 = dateTime2.isEqual((long) 10);
        java.util.GregorianCalendar gregorianCalendar5 = dateTime2.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("ZonedChronology[ISOChronology[UTC], UTC]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ZonedChronology[ISOChronology[UTC], UTC]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
        java.lang.Number number6 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", number6, (java.lang.Number) 10.0d, (java.lang.Number) 100L);
        java.lang.Number number10 = illegalFieldValueException9.getUpperBound();
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.DurationFieldType durationFieldType12 = illegalFieldValueException9.getDurationFieldType();
        java.lang.Number number13 = illegalFieldValueException9.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100L + "'", number10.equals(100L));
        org.junit.Assert.assertNull(durationFieldType12);
        org.junit.Assert.assertNull(number13);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
//        int int8 = delegatedDateTimeField4.getMinimumValue();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
//        try {
//            long long13 = offsetDateTimeField10.set((long) (byte) -1, 19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for hourOfHalfday must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-1L), "");
        java.lang.Number number4 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("", number4, (java.lang.Number) 10.0d, (java.lang.Number) 100L);
        java.lang.Number number8 = illegalFieldValueException7.getUpperBound();
        java.lang.Number number9 = illegalFieldValueException7.getUpperBound();
        java.lang.String str10 = illegalFieldValueException7.getIllegalStringValue();
        org.joda.time.IllegalInstantException illegalInstantException13 = new org.joda.time.IllegalInstantException((-1L), "");
        illegalFieldValueException7.addSuppressed((java.lang.Throwable) illegalInstantException13);
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException13);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100L + "'", number9.equals(100L));
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = delegatedDateTimeField4.getAsShortText((long) '4', locale9);
//        long long12 = delegatedDateTimeField4.roundHalfEven((-210862267200000L));
//        long long14 = delegatedDateTimeField4.roundCeiling((long) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str17 = dateTimeZone15.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now(dateTimeZone15);
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now(dateTimeZone15);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
//        org.joda.time.LocalDateTime localDateTime23 = dateTime21.toLocalDateTime();
//        boolean boolean24 = dateTimeZone15.isLocalDateTimeGap(localDateTime23);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
//        java.lang.String str31 = delegatedDateTimeField30.toString();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime34 = dateTime33.toDateTime();
//        org.joda.time.LocalDateTime localDateTime35 = dateTime33.toLocalDateTime();
//        int[] intArray43 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
//        int[] intArray45 = delegatedDateTimeField30.addWrapPartial((org.joda.time.ReadablePartial) localDateTime35, 57600, intArray43, 0);
//        try {
//            int[] intArray47 = delegatedDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localDateTime23, 641, intArray43, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 641");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4" + "'", str10.equals("4"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210862267622000L) + "'", long12 == (-210862267622000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str31.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDateTime35);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertNotNull(intArray45);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        boolean boolean8 = delegatedDateTimeField4.isSupported();
//        int int9 = delegatedDateTimeField4.getMaximumValue();
//        java.lang.String str10 = delegatedDateTimeField4.getName();
//        boolean boolean12 = delegatedDateTimeField4.isLeap((long) 21561);
//        long long15 = delegatedDateTimeField4.add((long) 59, 1541);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hourOfHalfday" + "'", str10.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5547600059L + "'", long15 == 5547600059L);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("2018-06-13T12:59:21.232Z");
        org.junit.Assert.assertNotNull(instant1);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        long long8 = dateTimeZone0.convertLocalToUTC((long) 1, false, (long) 57621);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        boolean boolean8 = delegatedDateTimeField4.isSupported();
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale13 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology12, locale13, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket16.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket16.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale21 = dateTimeParserBucket16.getLocale();
//        java.lang.String str22 = delegatedDateTimeField4.getAsShortText(readablePartial9, (int) (short) 100, locale21);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider27 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = delegatedDateTimeField32.getAsText((long) 4, locale34);
//        boolean boolean36 = delegatedDateTimeField32.isSupported();
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket44 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology40, locale41, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket44.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket44.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale49 = dateTimeParserBucket44.getLocale();
//        java.lang.String str50 = delegatedDateTimeField32.getAsShortText(readablePartial37, (int) (short) 100, locale49);
//        java.lang.String str53 = defaultNameProvider27.getShortName(locale49, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
//        java.lang.String str54 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDateTime26, locale49);
//        long long56 = delegatedDateTimeField4.roundHalfEven((-1L));
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(locale21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "100" + "'", str22.equals("100"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "4" + "'", str35.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(locale49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "100" + "'", str50.equals("100"));
//        org.junit.Assert.assertNull(str53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "4" + "'", str54.equals("4"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        boolean boolean3 = instant0.isAfterNow();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds(76);
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withYearOfEra((-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.roundHalfEven();
        int int5 = property2.getLeapAmount();
        int int6 = property2.getMaximumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = dateTimeParserBucket5.restoreState(obj6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale10 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology9, locale10, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.weekOfWeekyear();
//        boolean boolean16 = gregorianChronology9.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str19 = dateTimeZone17.getName((long) 1);
//        org.joda.time.Chronology chronology20 = gregorianChronology9.withZone(dateTimeZone17);
//        dateTimeParserBucket5.setZone(dateTimeZone17);
//        org.joda.time.Instant instant22 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime23 = instant22.toDateTime();
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillis((long) 0);
//        org.joda.time.DateTime.Property property26 = dateTime23.minuteOfDay();
//        org.joda.time.DateTime dateTime28 = dateTime23.plusMinutes((int) (short) 100);
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime23.minus(readableDuration29);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (org.joda.time.ReadableInstant) dateTime30, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 12");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordinated Universal Time" + "'", str19.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.lang.String str7 = iSOChronology6.toString();
//        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField13);
//        try {
//            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(16, 960, (int) (short) 10, (int) (byte) 100, (int) 'a', (org.joda.time.Chronology) iSOChronology6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.Chronology chronology3 = iSOChronology1.withUTC();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant4.isBeforeNow();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant4.isBefore((org.joda.time.ReadableInstant) instant6);
        org.joda.time.DateTimeZone dateTimeZone8 = instant6.getZone();
        org.joda.time.Chronology chronology9 = iSOChronology1.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        long long10 = delegatedDateTimeField4.add(1L, 0);
//        int int11 = delegatedDateTimeField4.getMinimumValue();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        int int5 = mutableDateTime4.getWeekOfWeekyear();
//        mutableDateTime4.setMillisOfSecond(0);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = delegatedDateTimeField12.getAsText((long) 4, locale14);
//        boolean boolean16 = delegatedDateTimeField12.isSupported();
//        int int17 = delegatedDateTimeField12.getMaximumValue();
//        java.lang.String str18 = delegatedDateTimeField12.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField12.getType();
//        mutableDateTime4.set(dateTimeFieldType19, 0);
//        try {
//            mutableDateTime4.setWeekOfWeekyear(21577513);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21577513 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4" + "'", str15.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 11 + "'", int17 == 11);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hourOfHalfday" + "'", str18.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long5 = julianChronology0.getDateTimeMillis(11, (int) (short) 100, 57621, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            mutableDateTime1.add(durationFieldType2, 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime4.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (short) 0);
//        int int13 = property10.compareTo((org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime12.hourOfDay();
//        long long15 = property14.remainder();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        java.lang.String str18 = iSOChronology17.toString();
//        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology17.getZone();
//        org.joda.time.DurationField durationField20 = iSOChronology17.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
//        java.lang.String str23 = iSOChronology22.toString();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology22.getZone();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology26.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology22, dateTimeField29);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime33 = dateTime32.toDateTime();
//        org.joda.time.LocalDateTime localDateTime34 = dateTime32.toLocalDateTime();
//        int[] intArray36 = iSOChronology22.get((org.joda.time.ReadablePartial) localDateTime34, 1560344362544L);
//        int[] intArray38 = iSOChronology17.get((org.joda.time.ReadablePartial) localDateTime34, 0L);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((java.lang.Object) property14, (org.joda.time.Chronology) iSOChronology17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str18.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str23.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(localDateTime34);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertNotNull(intArray38);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = julianChronology2.toString();
//        long long7 = julianChronology2.add((-210866846400000L), (long) 5, (int) (byte) -1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-210866846400005L) + "'", long7 == (-210866846400005L));
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) (short) 100, 359, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("4");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 739);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(100);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        java.lang.Class<?> wildcardClass5 = dateTime1.getClass();
//        org.joda.time.DateTime dateTime7 = dateTime1.plusMillis(3);
//        org.joda.time.DateTime dateTime10 = dateTime1.withDurationAdded(8741L, 0);
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560344382416L + "'", long4 == 1560344382416L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology2, locale3, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket6.setOffset((java.lang.Integer) 1);
        int int9 = dateTimeParserBucket6.getOffset();
        dateTimeParserBucket6.setOffset((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeParserBucket6.getZone();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.era();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        boolean boolean2 = dateTimeZone0.isStandardOffset((long) (short) 0);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: GJChronology[America/Los_Angeles]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "4");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(100, 21561, (int) (short) 100, (int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        long long8 = dateTimeZone0.convertLocalToUTC(0L, true, 10L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds(76);
        org.joda.time.DateTime dateTime5 = dateTime1.plusYears((int) 'a');
        org.joda.time.DateTime dateTime7 = dateTime1.plus((-210866846400005L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("2019-06-12T05:59:37.619-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05:59:37.619-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        int int5 = gregorianChronology2.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str9 = dateTimeZone7.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone7);
//        mutableDateTime10.addWeekyears((int) (byte) -1);
//        int int15 = dateTimeFormatter6.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime10.toMutableDateTime((org.joda.time.Chronology) gregorianChronology16);
//        mutableDateTime18.setMillisOfDay((int) (byte) 10);
//        mutableDateTime18.addDays((int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        java.lang.String str26 = iSOChronology25.toString();
//        org.joda.time.DateTimeZone dateTimeZone27 = iSOChronology25.getZone();
//        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone27);
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime30 = property29.getMutableDateTime();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology31 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.ReadableDateTime) mutableDateTime18, (org.joda.time.ReadableDateTime) mutableDateTime30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-98) + "'", int15 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str26.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("21561", "2018-06-13T12:59:21.232Z", 57621, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(10L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57621 + "'", int6 == 57621);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        boolean boolean8 = delegatedDateTimeField4.isSupported();
//        int int9 = delegatedDateTimeField4.getMaximumValue();
//        java.lang.String str10 = delegatedDateTimeField4.getName();
//        boolean boolean12 = delegatedDateTimeField4.isLeap((long) 21561);
//        long long14 = delegatedDateTimeField4.remainder((-210866760000000L));
//        long long16 = delegatedDateTimeField4.roundHalfEven(21560L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hourOfHalfday" + "'", str10.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 422000L + "'", long14 == 422000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 1560344381419L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(641);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-641) + "'", int1 == (-641));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        mutableDateTime3.setWeekyear(21560);
//        mutableDateTime3.add((-28799999L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(100);
        org.joda.time.DateTime dateTime5 = dateTime1.minusSeconds(24);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime7 = property6.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.set((int) (short) 10);
//        java.lang.String str10 = property6.toString();
//        org.joda.time.MutableDateTime mutableDateTime11 = property6.roundHalfCeiling();
//        int int12 = property6.get();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[dayOfMonth]" + "'", str10.equals("Property[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        int int8 = gJChronology7.getMinimumDaysInFirstWeek();
//        try {
//            long long13 = gJChronology7.getDateTimeMillis((-98), 20, 2018, 12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime4.centuryOfEra();
//        try {
//            mutableDateTime4.setDateTime(57600, (-1), 0, (int) '#', (-98), (int) (byte) 1, 57621);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 'a');
        boolean boolean2 = instant1.isEqualNow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        int int5 = mutableDateTime4.getRoundingMode();
//        try {
//            mutableDateTime4.setDateTime(2000, 19, 3, 21560, (int) '4', 4, 21560);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21560 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        boolean boolean11 = skipUndoDateTimeField9.isLeap(0L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime3 = instant2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) (byte) 1);
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
        try {
            java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        mutableDateTime12.add(readablePeriod13);
//        mutableDateTime12.setSecondOfMinute(10);
//        org.joda.time.DateTimeField dateTimeField17 = mutableDateTime12.getRoundingField();
//        int int18 = mutableDateTime12.getEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str21 = dateTimeZone19.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now(dateTimeZone19);
//        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now(dateTimeZone19);
//        int int24 = mutableDateTime23.getWeekOfWeekyear();
//        mutableDateTime23.setMillisOfSecond(0);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = delegatedDateTimeField31.getAsText((long) 4, locale33);
//        boolean boolean35 = delegatedDateTimeField31.isSupported();
//        int int36 = delegatedDateTimeField31.getMaximumValue();
//        java.lang.String str37 = delegatedDateTimeField31.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField31.getType();
//        mutableDateTime23.set(dateTimeFieldType38, 0);
//        try {
//            mutableDateTime12.set(dateTimeFieldType38, 739);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 739 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "4" + "'", str34.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 11 + "'", int36 == 11);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hourOfHalfday" + "'", str37.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 0);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.dayOfMonth();
//        mutableDateTime2.setMillisOfDay((int) '#');
//        mutableDateTime2.addMillis(59);
//        java.lang.String str8 = mutableDateTime2.toString();
//        int int11 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime2, "", 359);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T00:00:00.094-08:00" + "'", str8.equals("1969-12-31T00:00:00.094-08:00"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-360) + "'", int11 == (-360));
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.hourOfDay();
//        try {
//            mutableDateTime5.setTime(31, 960, 57621, 960);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
//        boolean boolean18 = delegatedDateTimeField14.isSupported();
//        int int19 = delegatedDateTimeField14.getMaximumValue();
//        java.lang.String str20 = delegatedDateTimeField14.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
//        int int24 = dividedDateTimeField23.getMaximumValue();
//        try {
//            long long26 = dividedDateTimeField23.roundFloor((long) 21561);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for clockhourOfDay must be in the range [1,24]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
        long long8 = iSOChronology2.add((long) (byte) -1, (long) 1000, 21559);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) iSOChronology2, locale9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(21562);
        dateTimeParserBucket10.setZone(dateTimeZone12);
        long long16 = dateTimeZone12.adjustOffset((long) (-360), true);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21558999L + "'", long8 == 21558999L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-360L) + "'", long16 == (-360L));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime5 = dateTime1.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime6 = dateTime5.withLaterOffsetAtOverlap();
        boolean boolean7 = dateTime5.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((long) 100);
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = property2.set((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(5, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
//        int int8 = delegatedDateTimeField4.getMinimumValue();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
//        long long12 = offsetDateTimeField10.roundHalfEven(0L);
//        try {
//            long long15 = offsetDateTimeField10.set((long) 76, 960);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfHalfday must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime4.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (short) 0);
//        int int13 = property10.compareTo((org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        boolean boolean15 = instant14.isBeforeNow();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.Instant instant19 = instant14.plus((long) 10);
//        org.joda.time.Instant instant22 = instant14.withDurationAdded((long) (byte) 1, 1000);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str25 = dateTimeZone23.getName((long) 1);
//        boolean boolean26 = instant22.equals((java.lang.Object) 1);
//        long long27 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) instant22);
//        int int28 = property10.getMinimumValue();
//        org.joda.time.Instant instant29 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime30 = instant29.toDateTime();
//        org.joda.time.DateTime dateTime32 = dateTime30.withMillis((long) (byte) 1);
//        org.joda.time.DateTime dateTime34 = dateTime30.minusHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str37 = dateTimeZone35.getName((long) 1);
//        org.joda.time.DateTime dateTime38 = dateTime30.toDateTime(dateTimeZone35);
//        org.joda.time.DateTime dateTime40 = dateTime30.minusMinutes(3);
//        int int41 = property10.compareTo((org.joda.time.ReadableInstant) dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordinated Universal Time" + "'", str25.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31449601L) + "'", long27 == (-31449601L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Coordinated Universal Time" + "'", str37.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime4.centuryOfEra();
//        int int11 = mutableDateTime4.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.yearOfEra();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.weekyear();
//        int int7 = mutableDateTime4.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 46786439 + "'", int7 == 46786439);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
//        java.lang.String str9 = zonedChronology8.toString();
//        org.joda.time.Chronology chronology10 = zonedChronology8.withUTC();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology10);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology8 = gJChronology7.withUTC();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        try {
//            int[] intArray12 = gJChronology7.get(readablePeriod9, (long) (-25200000), (long) 739);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(57600);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str4 = dateTimeZone2.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        int int7 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) mutableDateTime6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.minuteOfHour();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        mutableDateTime6.add(readablePeriod9);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.minus(readableDuration4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", number1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) -1);
        java.lang.Number number8 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("GJChronology[America/Los_Angeles]", (java.lang.Number) 21559, (java.lang.Number) (-28799999L), number8);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
//        long long3 = instant2.getMillis();
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560344387238L + "'", long3 == 1560344387238L);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1560344381419L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime8 = dateTime1.withDate(59, (int) (byte) 1, 1);
        org.joda.time.DateTime.Property property9 = dateTime1.minuteOfDay();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property9.setCopy("2018-06-13T12:59:36.021Z", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2018-06-13T12:59:36.021Z\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
//        int int8 = delegatedDateTimeField4.getMinimumValue();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
//        int int12 = offsetDateTimeField10.getLeapAmount(0L);
//        int int13 = offsetDateTimeField10.getOffset();
//        try {
//            long long16 = offsetDateTimeField10.set(739L, 2018);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2018 for hourOfHalfday must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology8 = gJChronology7.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfWeek();
//        boolean boolean12 = gJChronology7.equals((java.lang.Object) dateTimeField11);
//        org.joda.time.DurationField durationField13 = gJChronology7.weekyears();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply((-28800000), 21581);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: -28800000 * 21581");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        boolean boolean8 = delegatedDateTimeField4.isSupported();
//        int int9 = delegatedDateTimeField4.getMaximumValue();
//        java.lang.String str10 = delegatedDateTimeField4.getName();
//        long long12 = delegatedDateTimeField4.roundHalfFloor((long) ' ');
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hourOfHalfday" + "'", str10.equals("hourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
//        mutableDateTime1.setMillisOfDay((int) '#');
//        mutableDateTime1.addMillis(59);
//        int int7 = mutableDateTime1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
//        boolean boolean18 = delegatedDateTimeField14.isSupported();
//        int int19 = delegatedDateTimeField14.getMaximumValue();
//        java.lang.String str20 = delegatedDateTimeField14.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis(57600);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str28 = dateTimeZone26.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime29 = org.joda.time.MutableDateTime.now(dateTimeZone26);
//        org.joda.time.MutableDateTime mutableDateTime30 = org.joda.time.MutableDateTime.now(dateTimeZone26);
//        int int31 = dateTimeZone25.getOffset((org.joda.time.ReadableInstant) mutableDateTime30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone25);
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime32.toYearMonthDay();
//        int[] intArray37 = new int[] { 20, 12 };
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str42 = dateTimeZone40.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now(dateTimeZone40);
//        mutableDateTime43.addWeekyears((int) (byte) -1);
//        int int48 = dateTimeFormatter39.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime43, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone50 = gregorianChronology49.getZone();
//        org.joda.time.MutableDateTime mutableDateTime51 = mutableDateTime43.toMutableDateTime((org.joda.time.Chronology) gregorianChronology49);
//        java.lang.String str52 = mutableDateTime43.toString();
//        int int53 = mutableDateTime43.getHourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale56 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket59 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology55, locale56, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket59.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket59.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale64 = dateTimeParserBucket59.getLocale();
//        java.util.Calendar calendar65 = mutableDateTime43.toCalendar(locale64);
//        try {
//            int[] intArray66 = dividedDateTimeField23.set((org.joda.time.ReadablePartial) yearMonthDay33, 0, intArray37, "1969-12-31T00:00:00.094-08:00", locale64);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T00:00:00.094-08:00\" for hourOfHalfday is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordinated Universal Time" + "'", str28.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 57600 + "'", int31 == 57600);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Coordinated Universal Time" + "'", str42.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime43);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-98) + "'", int48 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2067-11-23T01:59:28.521Z" + "'", str52.equals("2067-11-23T01:59:28.521Z"));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology55);
//        org.junit.Assert.assertNotNull(locale64);
//        org.junit.Assert.assertNotNull(calendar65);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        long long5 = iSOChronology1.add(1560344387238L, (long) 2, 19);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560344387276L + "'", long5 == 1560344387276L);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        mutableDateTime1.add(readablePeriod2);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.secondOfMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.Chronology chronology6 = dateTimeFormatter5.getChronology();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.dayOfWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gregorianChronology7);
//        java.lang.String str10 = mutableDateTime1.toString(dateTimeFormatter9);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withZoneUTC();
//        java.lang.Appendable appendable12 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str16 = dateTimeZone14.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now(dateTimeZone14);
//        mutableDateTime17.addWeekyears((int) (byte) -1);
//        int int22 = dateTimeFormatter13.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime17, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.MutableDateTime.Property property23 = mutableDateTime17.centuryOfEra();
//        try {
//            dateTimeFormatter9.printTo(appendable12, (org.joda.time.ReadableInstant) mutableDateTime17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNull(chronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970-W01-3" + "'", str10.equals("1970-W01-3"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-98) + "'", int22 == (-98));
//        org.junit.Assert.assertNotNull(property23);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology3, locale4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
//        org.joda.time.LocalDateTime localDateTime18 = dateTime16.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
//        java.lang.String str25 = delegatedDateTimeField24.toString();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime28 = dateTime27.toDateTime();
//        org.joda.time.LocalDateTime localDateTime29 = dateTime27.toLocalDateTime();
//        int[] intArray37 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
//        int[] intArray39 = delegatedDateTimeField24.addWrapPartial((org.joda.time.ReadablePartial) localDateTime29, 57600, intArray37, 0);
//        int[] intArray41 = skipUndoDateTimeField14.addWrapPartial((org.joda.time.ReadablePartial) localDateTime18, 0, intArray39, 57600);
//        long long44 = skipUndoDateTimeField14.addWrapField((long) 31, 16);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4" + "'", str13.equals("4"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localDateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str25.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 14400031L + "'", long44 == 14400031L);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("4", "Coordinated Universal Time", 0, 739);
        int int6 = fixedDateTimeZone4.getOffset(21558999L);
        int int8 = fixedDateTimeZone4.getOffset((-31449601L));
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        java.lang.String str11 = fixedDateTimeZone4.getNameKey((long) 2066);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.weekOfWeekyear();
//        boolean boolean8 = gregorianChronology1.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str11 = dateTimeZone9.getName((long) 1);
//        org.joda.time.Chronology chronology12 = gregorianChronology1.withZone(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = delegatedDateTimeField17.getAsText((long) 4, locale19);
//        boolean boolean21 = delegatedDateTimeField17.isSupported();
//        int int22 = delegatedDateTimeField17.getMaximumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField17, 4);
//        int int26 = skipDateTimeField24.getLeapAmount(2440588L);
//        try {
//            long long29 = skipDateTimeField24.set(1558036781373L, 16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for hourOfHalfday must be in the range [-1,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4" + "'", str20.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
//        boolean boolean14 = delegatedDateTimeField10.isSupported();
//        int int15 = delegatedDateTimeField10.getMaximumValue();
//        java.lang.String str16 = delegatedDateTimeField10.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField10.getType();
//        org.joda.time.DateTime.Property property18 = dateTime0.property(dateTimeFieldType17);
//        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
//        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(93L);
//        try {
//            org.joda.time.DateTime dateTime23 = dateTime19.withSecondOfMinute((-28800000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4" + "'", str13.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 11 + "'", int15 == 11);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hourOfHalfday" + "'", str16.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        jodaTimePermission1.checkGuard((java.lang.Object) (byte) 100);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime4.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((long) (short) 0);
//        int int13 = property10.compareTo((org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        boolean boolean15 = instant14.isBeforeNow();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.Instant instant19 = instant14.plus((long) 10);
//        org.joda.time.Instant instant22 = instant14.withDurationAdded((long) (byte) 1, 1000);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str25 = dateTimeZone23.getName((long) 1);
//        boolean boolean26 = instant22.equals((java.lang.Object) 1);
//        long long27 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) instant22);
//        org.joda.time.DateTime dateTime28 = instant22.toDateTimeISO();
//        java.lang.String str29 = dateTime28.toString();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(instant22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordinated Universal Time" + "'", str25.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31449601L) + "'", long27 == (-31449601L));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2068-11-20T17:59:31.203-08:00" + "'", str29.equals("2068-11-20T17:59:31.203-08:00"));
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.weekOfWeekyear();
//        try {
//            long long14 = zonedChronology8.getDateTimeMillis(21562, (int) 'a', (-25200000), 47);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(100L);
//        int int2 = dateTime1.getSecondOfDay();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        java.lang.String str7 = delegatedDateTimeField4.getAsShortText(100L);
//        int int8 = delegatedDateTimeField4.getMinimumValue();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, (int) (byte) 1);
//        long long12 = offsetDateTimeField10.roundHalfFloor(1558036781373L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1558036800000L + "'", long12 == 1558036800000L);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-57599906L), 2440588L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-140577639384728L) + "'", long2 == (-140577639384728L));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology2, locale3, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.weekOfWeekyear();
//        boolean boolean9 = gregorianChronology2.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str12 = dateTimeZone10.getName((long) 1);
//        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone10);
//        java.util.Locale locale14 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 641, chronology13, locale14, (java.lang.Integer) 11);
//        dateTimeParserBucket16.setOffset((java.lang.Integer) 1541);
//        org.joda.time.Chronology chronology19 = dateTimeParserBucket16.getChronology();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology8.getZone();
//        try {
//            long long16 = zonedChronology8.getDateTimeMillis((long) 57600, 100, 40, 2, 359);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        int int5 = mutableDateTime4.getWeekOfWeekyear();
//        mutableDateTime4.setMillisOfDay(0);
//        try {
//            mutableDateTime4.setWeekOfWeekyear(21559);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21559 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 47 + "'", int5 == 47);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-12) + "'", int1 == (-12));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) 100, 21561, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("Property[secondOfMinute]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[secondOfMinute]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("1969");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        mutableDateTime1.setMillisOfDay((int) '#');
        mutableDateTime1.setMinuteOfDay((int) (byte) 1);
        int int7 = mutableDateTime1.getMinuteOfHour();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("4", "Coordinated Universal Time", 0, 739);
//        int int6 = fixedDateTimeZone4.getOffset(21558999L);
//        int int8 = fixedDateTimeZone4.getOffset((-31449601L));
//        boolean boolean9 = fixedDateTimeZone4.isFixed();
//        boolean boolean10 = fixedDateTimeZone4.isFixed();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str13 = dateTimeZone11.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone11);
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now(dateTimeZone11);
//        int int16 = mutableDateTime15.getWeekOfWeekyear();
//        mutableDateTime15.setMillisOfDay(0);
//        boolean boolean19 = fixedDateTimeZone4.equals((java.lang.Object) 0);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
//        java.lang.String str23 = iSOChronology22.toString();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology22.getZone();
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        boolean boolean27 = dateTimeFormatter26.isPrinter();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        java.lang.String str30 = iSOChronology29.toString();
//        org.joda.time.DateTimeZone dateTimeZone31 = iSOChronology29.getZone();
//        boolean boolean33 = dateTimeZone31.isStandardOffset((long) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter26.withZone(dateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        mutableDateTime25.setZone(dateTimeZone35);
//        long long38 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone35, 0L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str23.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str30.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28800000L + "'", long38 == 28800000L);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1969-12-31T00:00:00.094-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1969-12-31T00:00:00.094-08:00' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        org.joda.time.DateTime dateTime5 = dateTime1.withMonthOfYear(2);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekyear();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64771 + "'", int2 == 64771);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        int int7 = delegatedDateTimeField4.getLeapAmount(739L);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        java.lang.String str11 = iSOChronology10.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology10.getZone();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = delegatedDateTimeField23.getAsText((long) 4, locale25);
//        boolean boolean27 = delegatedDateTimeField23.isSupported();
//        int int28 = delegatedDateTimeField23.getMaximumValue();
//        java.lang.String str29 = delegatedDateTimeField23.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField23.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType30, 21562);
//        boolean boolean33 = dividedDateTimeField32.isLenient();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
//        java.lang.String str36 = iSOChronology35.toString();
//        org.joda.time.DateTimeZone dateTimeZone37 = iSOChronology35.getZone();
//        org.joda.time.DurationField durationField38 = iSOChronology35.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        java.lang.String str41 = iSOChronology40.toString();
//        org.joda.time.DateTimeZone dateTimeZone42 = iSOChronology40.getZone();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology44.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology44.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology40, dateTimeField47);
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime51 = dateTime50.toDateTime();
//        org.joda.time.LocalDateTime localDateTime52 = dateTime50.toLocalDateTime();
//        int[] intArray54 = iSOChronology40.get((org.joda.time.ReadablePartial) localDateTime52, 1560344362544L);
//        int[] intArray56 = iSOChronology35.get((org.joda.time.ReadablePartial) localDateTime52, 0L);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider57 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField61);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = delegatedDateTimeField62.getAsText((long) 4, locale64);
//        boolean boolean66 = delegatedDateTimeField62.isSupported();
//        org.joda.time.ReadablePartial readablePartial67 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale71 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology70, locale71, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket74.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket74.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale79 = dateTimeParserBucket74.getLocale();
//        java.lang.String str80 = delegatedDateTimeField62.getAsShortText(readablePartial67, (int) (short) 100, locale79);
//        java.lang.String str83 = defaultNameProvider57.getShortName(locale79, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
//        java.lang.String str84 = dividedDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDateTime52, locale79);
//        java.lang.String str85 = delegatedDateTimeField4.getAsText(359, locale79);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "4" + "'", str26.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hourOfHalfday" + "'", str29.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str36.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str41.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(iSOChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(localDateTime52);
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertNotNull(intArray56);
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "4" + "'", str65.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(locale79);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "100" + "'", str80.equals("100"));
//        org.junit.Assert.assertNull(str83);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "4" + "'", str84.equals("4"));
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "359" + "'", str85.equals("359"));
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 57600, dateTimeZone1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("2018-06-13T12:59:38.810Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2018-06-13T12:59:38.810Z");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) 0);
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime1.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str10 = dateTimeZone8.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone8);
//        mutableDateTime11.addWeekyears((int) (byte) -1);
//        int int16 = dateTimeFormatter7.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        org.joda.time.MutableDateTime mutableDateTime19 = mutableDateTime11.toMutableDateTime((org.joda.time.Chronology) gregorianChronology17);
//        java.lang.String str20 = mutableDateTime11.toString();
//        int int21 = mutableDateTime11.getHourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale24 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology23, locale24, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket27.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket27.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale32 = dateTimeParserBucket27.getLocale();
//        java.util.Calendar calendar33 = mutableDateTime11.toCalendar(locale32);
//        try {
//            org.joda.time.DateTime dateTime34 = property5.setCopy("ZonedChronology[ISOChronology[UTC], UTC]", locale32);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[ISOChronology[UTC], UTC]\" for dayOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-98) + "'", int16 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2067-11-23T01:59:31.891Z" + "'", str20.equals("2067-11-23T01:59:31.891Z"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(locale32);
//        org.junit.Assert.assertNotNull(calendar33);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        try {
            long long7 = julianChronology2.getDateTimeMillis(0, 641, (int) (byte) 10, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        int int9 = delegatedDateTimeField4.get((long) 1);
//        org.joda.time.DurationField durationField10 = delegatedDateTimeField4.getRangeDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime7 = property6.roundFloor();
//        mutableDateTime7.addMonths(2);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
//        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) 2440587.5d);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        java.lang.String str6 = iSOChronology5.toString();
//        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology5.getZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology5, dateTimeField12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = delegatedDateTimeField18.getAsText((long) 4, locale20);
//        boolean boolean22 = delegatedDateTimeField18.isSupported();
//        int int23 = delegatedDateTimeField18.getMaximumValue();
//        java.lang.String str24 = delegatedDateTimeField18.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField18.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType25, 21562);
//        int int28 = dividedDateTimeField27.getMaximumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField27);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        java.lang.String str33 = iSOChronology32.toString();
//        org.joda.time.DateTimeZone dateTimeZone34 = iSOChronology32.getZone();
//        org.joda.time.DateTime dateTime35 = dateTime30.withZoneRetainFields(dateTimeZone34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology37.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = delegatedDateTimeField40.getAsText((long) 4, locale42);
//        boolean boolean44 = delegatedDateTimeField40.isSupported();
//        int int45 = delegatedDateTimeField40.getMaximumValue();
//        java.lang.String str46 = delegatedDateTimeField40.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = delegatedDateTimeField40.getType();
//        org.joda.time.DateTime.Property property48 = dateTime30.property(dateTimeFieldType47);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField29, dateTimeFieldType47);
//        jodaTimePermission1.checkGuard((java.lang.Object) remainderDateTimeField29);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str6.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "4" + "'", str21.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hourOfHalfday" + "'", str24.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str33.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "4" + "'", str43.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 11 + "'", int45 == 11);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hourOfHalfday" + "'", str46.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(property48);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology2, locale3, (java.lang.Integer) 1, (int) (short) 0);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.weekOfWeekyear();
//        boolean boolean9 = gregorianChronology2.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str12 = dateTimeZone10.getName((long) 1);
//        org.joda.time.Chronology chronology13 = gregorianChronology2.withZone(dateTimeZone10);
//        java.util.Locale locale14 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 641, chronology13, locale14, (java.lang.Integer) 11);
//        java.lang.Integer int17 = dateTimeParserBucket16.getOffsetInteger();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNull(int17);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        java.lang.Object obj6 = null;
        boolean boolean7 = dateTimeParserBucket5.restoreState(obj6);
        org.joda.time.Chronology chronology8 = dateTimeParserBucket5.getChronology();
        java.lang.Integer int9 = dateTimeParserBucket5.getOffsetInteger();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNull(int9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        long long4 = buddhistChronology0.add((long) (short) 1, 10L, 0);
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        long long8 = dateTimeZone4.adjustOffset(1560344362544L, false);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str12 = dateTimeZone10.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0L, dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime16.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology18.getZone();
//        org.joda.time.Chronology chronology20 = gJChronology18.withUTC();
//        try {
//            long long25 = gJChronology18.getDateTimeMillis(2018, 11, 2019, 31);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560344362544L + "'", long8 == 1560344362544L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology20);
//    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        boolean boolean1 = instant0.isBeforeNow();
//        org.joda.time.Instant instant2 = new org.joda.time.Instant();
//        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
//        boolean boolean5 = instant0.isAfter((long) 10);
//        boolean boolean7 = instant0.isAfter((long) '4');
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
//        java.lang.String str9 = dateTimeZone7.toString();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, 0L, 2);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        try {
//            int[] intArray15 = gJChronology12.get(readablePartial13, 2664021560L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertNotNull(gJChronology12);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("4");
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 1560344387238L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("4", "Coordinated Universal Time", 0, 739);
//        int int6 = fixedDateTimeZone4.getOffset(21558999L);
//        int int8 = fixedDateTimeZone4.getOffset((-31449601L));
//        boolean boolean9 = fixedDateTimeZone4.isFixed();
//        boolean boolean10 = fixedDateTimeZone4.isFixed();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str13 = dateTimeZone11.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone11);
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now(dateTimeZone11);
//        int int16 = mutableDateTime15.getWeekOfWeekyear();
//        mutableDateTime15.setMillisOfDay(0);
//        boolean boolean19 = fixedDateTimeZone4.equals((java.lang.Object) 0);
//        boolean boolean20 = fixedDateTimeZone4.isFixed();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        java.lang.String str3 = gregorianChronology0.toString();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField4);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeFormatter0.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withZoneUTC();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        int int5 = mutableDateTime4.getWeekOfWeekyear();
//        int int6 = mutableDateTime4.getYear();
//        int int7 = mutableDateTime4.getYear();
//        try {
//            mutableDateTime4.setSecondOfMinute(21562);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21562 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 47 + "'", int5 == 47);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2068 + "'", int6 == 2068);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2068 + "'", int7 == 2068);
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str9 = dateTimeZone7.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone7);
//        mutableDateTime10.addWeekyears((int) (byte) -1);
//        int int15 = dateTimeFormatter6.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime10.toMutableDateTime((org.joda.time.Chronology) gregorianChronology16);
//        java.lang.String str19 = mutableDateTime10.toString();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime10.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime22 = property21.roundHalfCeiling();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
//        java.lang.String str27 = iSOChronology26.toString();
//        org.joda.time.DateTimeZone dateTimeZone28 = iSOChronology26.getZone();
//        org.joda.time.DateTime dateTime29 = dateTime24.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str33 = dateTimeZone31.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime34 = org.joda.time.MutableDateTime.now(dateTimeZone31);
//        mutableDateTime34.addWeekyears((int) (byte) -1);
//        int int39 = dateTimeFormatter30.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime34, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology40.getZone();
//        org.joda.time.MutableDateTime mutableDateTime42 = mutableDateTime34.toMutableDateTime((org.joda.time.Chronology) gregorianChronology40);
//        java.lang.String str43 = mutableDateTime34.toString();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, (org.joda.time.ReadableInstant) mutableDateTime34);
//        org.joda.time.MutableDateTime.Property property45 = mutableDateTime34.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime46 = property45.roundHalfCeiling();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale49 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology48, locale49, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket52.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket52.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale57 = dateTimeParserBucket52.getLocale();
//        int int58 = property45.getMaximumShortTextLength(locale57);
//        try {
//            java.lang.String str59 = mutableDateTime22.toString("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")", locale57);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-98) + "'", int15 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2067-11-23T01:59:33.811Z" + "'", str19.equals("2067-11-23T01:59:33.811Z"));
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str27.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Coordinated Universal Time" + "'", str33.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-98) + "'", int39 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2067-11-23T01:59:33.822Z" + "'", str43.equals("2067-11-23T01:59:33.822Z"));
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(mutableDateTime46);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(locale57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 3 + "'", int58 == 3);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
//        try {
//            long long13 = zonedChronology8.getDateTimeMillis((int) (short) 10, 40, (-1), 7171390);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 40 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) -1);
        boolean boolean4 = instant3.isBeforeNow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        boolean boolean3 = dateTime1.isEqual((long) 0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(76);
//        org.joda.time.DateTime dateTime9 = dateTime5.plusYears((int) 'a');
//        int int10 = dateTime9.getYearOfEra();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology11 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2066 + "'", int10 == 2066);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(100);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        java.lang.Class<?> wildcardClass5 = dateTime1.getClass();
//        org.joda.time.DateTime dateTime7 = dateTime1.plusMillis(3);
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime7.withWeekOfWeekyear((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3120688774102L + "'", long4 == 3120688774102L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        int int2 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
//        org.joda.time.DateTime dateTime5 = dateTime1.withMonthOfYear(2);
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime1.withYearOfCentury(64773051);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 64773051 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64774 + "'", int2 == 64774);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) 100, 'a', (int) (short) 0, 100, 2000, false, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("Coordinated Universal Time", 21559);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.setFixedSavings("", 57621);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeZoneBuilder0.toDateTimeZone("Property[secondOfMinute]", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
//        boolean boolean18 = delegatedDateTimeField14.isSupported();
//        int int19 = delegatedDateTimeField14.getMaximumValue();
//        java.lang.String str20 = delegatedDateTimeField14.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
//        int int24 = dividedDateTimeField23.getMaximumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
//        java.lang.String str29 = iSOChronology28.toString();
//        org.joda.time.DateTimeZone dateTimeZone30 = iSOChronology28.getZone();
//        org.joda.time.DateTime dateTime31 = dateTime26.withZoneRetainFields(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = delegatedDateTimeField36.getAsText((long) 4, locale38);
//        boolean boolean40 = delegatedDateTimeField36.isSupported();
//        int int41 = delegatedDateTimeField36.getMaximumValue();
//        java.lang.String str42 = delegatedDateTimeField36.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = delegatedDateTimeField36.getType();
//        org.joda.time.DateTime.Property property44 = dateTime26.property(dateTimeFieldType43);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType43);
//        long long47 = remainderDateTimeField25.roundFloor(1560344362544L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str29.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "4" + "'", str39.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hourOfHalfday" + "'", str42.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560340800000L + "'", long47 == 1560340800000L);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.toDateTimeISO();
//        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        org.joda.time.DateTime dateTime7 = instant6.toDateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay(100);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        java.lang.Class<?> wildcardClass11 = dateTime7.getClass();
//        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime2, (org.joda.time.ReadableDateTime) dateTime7);
//        try {
//            long long20 = limitChronology12.getDateTimeMillis(960, (-1), (-641), 76, (-1), 10, 4);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 76 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3120688775049L + "'", long10 == 3120688775049L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(limitChronology12);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        mutableDateTime4.addWeekyears((int) (byte) -1);
//        int int9 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "Coordinated Universal Time", (int) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime4.toMutableDateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        mutableDateTime12.add(readablePeriod13);
//        mutableDateTime12.setTime((long) (byte) 1);
//        java.lang.Class<?> wildcardClass17 = mutableDateTime12.getClass();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-98) + "'", int9 == (-98));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", number1, (java.lang.Number) 10.0d, (java.lang.Number) 100L);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.Throwable throwable6 = null;
        try {
            illegalFieldValueException4.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 17, (long) 57621);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-57604L) + "'", long2 == (-57604L));
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology3, locale4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        java.util.Locale locale15 = null;
//        int int16 = skipUndoDateTimeField14.getMaximumTextLength(locale15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
//        java.lang.String str19 = iSOChronology18.toString();
//        org.joda.time.DateTimeZone dateTimeZone20 = iSOChronology18.getZone();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField25);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
//        org.joda.time.LocalDateTime localDateTime30 = dateTime28.toLocalDateTime();
//        int[] intArray32 = iSOChronology18.get((org.joda.time.ReadablePartial) localDateTime30, 1560344362544L);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        java.lang.String str35 = iSOChronology34.toString();
//        org.joda.time.DateTimeZone dateTimeZone36 = iSOChronology34.getZone();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology38.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField41);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime45 = dateTime44.toDateTime();
//        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
//        int[] intArray48 = iSOChronology34.get((org.joda.time.ReadablePartial) localDateTime46, 1560344362544L);
//        int int49 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDateTime30, intArray48);
//        java.lang.String str51 = skipUndoDateTimeField14.getAsText((long) 16);
//        org.joda.time.ReadablePartial readablePartial52 = null;
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider53 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone54);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology55.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField57 = iSOChronology55.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField57);
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = delegatedDateTimeField58.getAsText((long) 4, locale60);
//        boolean boolean62 = delegatedDateTimeField58.isSupported();
//        org.joda.time.ReadablePartial readablePartial63 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale67 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket70 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology66, locale67, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket70.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket70.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale75 = dateTimeParserBucket70.getLocale();
//        java.lang.String str76 = delegatedDateTimeField58.getAsShortText(readablePartial63, (int) (short) 100, locale75);
//        java.lang.String str79 = defaultNameProvider53.getShortName(locale75, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
//        try {
//            java.lang.String str80 = skipUndoDateTimeField14.getAsText(readablePartial52, locale75);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4" + "'", str13.equals("4"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str19.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDateTime30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str35.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "4" + "'", str51.equals("4"));
//        org.junit.Assert.assertNotNull(iSOChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "4" + "'", str61.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(locale75);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "100" + "'", str76.equals("100"));
//        org.junit.Assert.assertNull(str79);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
//        boolean boolean18 = delegatedDateTimeField14.isSupported();
//        int int19 = delegatedDateTimeField14.getMaximumValue();
//        java.lang.String str20 = delegatedDateTimeField14.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
//        boolean boolean24 = dividedDateTimeField23.isLenient();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
//        java.lang.String str27 = iSOChronology26.toString();
//        org.joda.time.DateTimeZone dateTimeZone28 = iSOChronology26.getZone();
//        org.joda.time.DurationField durationField29 = iSOChronology26.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.lang.String str32 = iSOChronology31.toString();
//        org.joda.time.DateTimeZone dateTimeZone33 = iSOChronology31.getZone();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology31, dateTimeField38);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime42 = dateTime41.toDateTime();
//        org.joda.time.LocalDateTime localDateTime43 = dateTime41.toLocalDateTime();
//        int[] intArray45 = iSOChronology31.get((org.joda.time.ReadablePartial) localDateTime43, 1560344362544L);
//        int[] intArray47 = iSOChronology26.get((org.joda.time.ReadablePartial) localDateTime43, 0L);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider48 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology50.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = delegatedDateTimeField53.getAsText((long) 4, locale55);
//        boolean boolean57 = delegatedDateTimeField53.isSupported();
//        org.joda.time.ReadablePartial readablePartial58 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale62 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology61, locale62, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket65.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket65.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale70 = dateTimeParserBucket65.getLocale();
//        java.lang.String str71 = delegatedDateTimeField53.getAsShortText(readablePartial58, (int) (short) 100, locale70);
//        java.lang.String str74 = defaultNameProvider48.getShortName(locale70, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
//        java.lang.String str75 = dividedDateTimeField23.getAsText((org.joda.time.ReadablePartial) localDateTime43, locale70);
//        int int76 = dividedDateTimeField23.getMinimumValue();
//        int int77 = dividedDateTimeField23.getMinimumValue();
//        try {
//            long long79 = dividedDateTimeField23.roundHalfEven(1560340800000L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for clockhourOfDay must be in the range [1,24]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str27.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str32.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(localDateTime43);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "4" + "'", str56.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(locale70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "100" + "'", str71.equals("100"));
//        org.junit.Assert.assertNull(str74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "4" + "'", str75.equals("4"));
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = julianChronology2.toString();
//        try {
//            long long9 = julianChronology2.getDateTimeMillis((long) (byte) 0, 57621, 12, 46786439, 21561);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57621 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")", (-28800000), 57600, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for (\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\") must be in the range [57600,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        long long6 = delegatedDateTimeField4.roundHalfFloor((long) (byte) 10);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        mutableDateTime5.add(readableDuration6, 24);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology3, locale4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = delegatedDateTimeField10.getAsText((long) 4, locale12);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        java.util.Locale locale15 = null;
//        int int16 = skipUndoDateTimeField14.getMaximumTextLength(locale15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
//        java.lang.String str19 = iSOChronology18.toString();
//        org.joda.time.DateTimeZone dateTimeZone20 = iSOChronology18.getZone();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField25);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
//        org.joda.time.LocalDateTime localDateTime30 = dateTime28.toLocalDateTime();
//        int[] intArray32 = iSOChronology18.get((org.joda.time.ReadablePartial) localDateTime30, 1560344362544L);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        java.lang.String str35 = iSOChronology34.toString();
//        org.joda.time.DateTimeZone dateTimeZone36 = iSOChronology34.getZone();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology38.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField41);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime45 = dateTime44.toDateTime();
//        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
//        int[] intArray48 = iSOChronology34.get((org.joda.time.ReadablePartial) localDateTime46, 1560344362544L);
//        int int49 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDateTime30, intArray48);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter50.withPivotYear(11);
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str55 = dateTimeZone53.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime56 = org.joda.time.MutableDateTime.now(dateTimeZone53);
//        org.joda.time.MutableDateTime mutableDateTime57 = org.joda.time.MutableDateTime.now(dateTimeZone53);
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime60 = dateTime59.toDateTime();
//        org.joda.time.LocalDateTime localDateTime61 = dateTime59.toLocalDateTime();
//        boolean boolean62 = dateTimeZone53.isLocalDateTimeGap(localDateTime61);
//        java.lang.String str63 = dateTimeFormatter50.print((org.joda.time.ReadablePartial) localDateTime61);
//        int int64 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localDateTime61);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4" + "'", str13.equals("4"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str19.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDateTime30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str35.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Coordinated Universal Time" + "'", str55.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertNotNull(mutableDateTime57);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(localDateTime61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1969" + "'", str63.equals("1969"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.roundHalfEven();
        long long5 = property2.remainder();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = property2.set(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1541);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1, (int) (short) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1);
        int int8 = dateTimeParserBucket5.getOffset();
        java.lang.Integer int9 = dateTimeParserBucket5.getOffsetInteger();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.lang.String str15 = delegatedDateTimeField14.toString();
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsShortText((int) (short) 0, locale17);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) delegatedDateTimeField14, (int) (short) 100);
        try {
            long long23 = dateTimeParserBucket5.computeMillis(false, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Cannot parse \"America/Los_Angeles\": Value 100 for hourOfHalfday must be in the range [0,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9.equals(1));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str15.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        long long8 = dateTimeZone4.adjustOffset(1560344362544L, false);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str12 = dateTimeZone10.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0L, dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime16.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology18.getZone();
//        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560344362544L + "'", long8 == 1560344362544L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.weekOfWeekyear();
//        try {
//            long long15 = zonedChronology8.getDateTimeMillis((long) (short) 0, 0, 76, 11, (-28800000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 76 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        long long5 = cachedDateTimeZone3.previousTransition(0L);
//        java.lang.String str7 = cachedDateTimeZone3.getNameKey(2440588L);
//        int int9 = cachedDateTimeZone3.getOffset((long) 40);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("4", "Coordinated Universal Time", 0, 739);
        int int6 = fixedDateTimeZone4.getStandardOffset(28800010L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 739 + "'", int6 == 739);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-1), '#', 57621, (int) (byte) 10, 1541, true, 21561);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(100, '#', 13, 21561, 57600, false, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(57621);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(641);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
//        java.lang.String str3 = property2.getAsShortText();
//        org.joda.time.DurationField durationField4 = property2.getRangeDurationField();
//        java.lang.String str5 = property2.getAsString();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31" + "'", str3.equals("31"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31" + "'", str5.equals("31"));
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str7 = dateTimeZone5.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.Chronology chronology11 = julianChronology2.withZone(dateTimeZone10);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-14378440L));
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(57600);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str4 = dateTimeZone2.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        int int7 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) mutableDateTime6);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.minus(readableDuration10);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
//        org.junit.Assert.assertNotNull(yearMonthDay9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        boolean boolean8 = delegatedDateTimeField4.isSupported();
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale13 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology12, locale13, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket16.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket16.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale21 = dateTimeParserBucket16.getLocale();
//        java.lang.String str22 = delegatedDateTimeField4.getAsShortText(readablePartial9, (int) (short) 100, locale21);
//        try {
//            long long25 = delegatedDateTimeField4.set(10L, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(locale21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "100" + "'", str22.equals("100"));
//    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        boolean boolean8 = delegatedDateTimeField4.isSupported();
//        java.lang.String str9 = delegatedDateTimeField4.getName();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hourOfHalfday" + "'", str9.equals("hourOfHalfday"));
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        boolean boolean1 = instant0.isBeforeNow();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.Instant instant4 = instant2.toInstant();
        org.joda.time.Instant instant6 = instant2.withMillis(21560L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("DateTimeField[hourOfHalfday]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: DateTimeField[hourOfHalfday]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isPrinter();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.lang.String str4 = iSOChronology3.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime10.yearOfEra();
//        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
//        int int14 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withHourOfDay(4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology8 = gJChronology7.withUTC();
//        java.lang.String str9 = gJChronology7.toString();
//        try {
//            long long14 = gJChronology7.getDateTimeMillis(739, 3, 0, 2068);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str9.equals("GJChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        mutableDateTime1.add(readablePeriod2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.secondOfMinute();
        mutableDateTime1.addMonths(13);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName((long) 1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.yearOfEra();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
//        int int7 = property6.get();
//        org.joda.time.DateTimeField dateTimeField8 = property6.getField();
//        int int9 = property6.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText((long) 4, locale6);
//        boolean boolean8 = delegatedDateTimeField4.isSupported();
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale13 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology12, locale13, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket16.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket16.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale21 = dateTimeParserBucket16.getLocale();
//        java.lang.String str22 = delegatedDateTimeField4.getAsShortText(readablePartial9, (int) (short) 100, locale21);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider27 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology29.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = delegatedDateTimeField32.getAsText((long) 4, locale34);
//        boolean boolean36 = delegatedDateTimeField32.isSupported();
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket44 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology40, locale41, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket44.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket44.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale49 = dateTimeParserBucket44.getLocale();
//        java.lang.String str50 = delegatedDateTimeField32.getAsShortText(readablePartial37, (int) (short) 100, locale49);
//        java.lang.String str53 = defaultNameProvider27.getShortName(locale49, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
//        java.lang.String str54 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDateTime26, locale49);
//        long long57 = delegatedDateTimeField4.addWrapField(2440588L, 2000);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4" + "'", str7.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(locale21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "100" + "'", str22.equals("100"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "4" + "'", str35.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(locale49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "100" + "'", str50.equals("100"));
//        org.junit.Assert.assertNull(str53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "4" + "'", str54.equals("4"));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-11959412L) + "'", long57 == (-11959412L));
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology3, locale4);
        java.lang.Object obj6 = dateTimeParserBucket5.saveState();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "0", (int) (byte) 0, 21560);
        long long6 = fixedDateTimeZone4.nextTransition((long) '4');
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        java.io.Writer writer1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology3);
//        java.util.Locale locale6 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, chronology5, locale6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = delegatedDateTimeField12.getAsText((long) 4, locale14);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, (org.joda.time.DateTimeField) delegatedDateTimeField12);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime19 = dateTime18.toDateTime();
//        org.joda.time.LocalDateTime localDateTime20 = dateTime18.toLocalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
//        java.lang.String str27 = delegatedDateTimeField26.toString();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime30 = dateTime29.toDateTime();
//        org.joda.time.LocalDateTime localDateTime31 = dateTime29.toLocalDateTime();
//        int[] intArray39 = new int[] { (byte) 0, (-98), (-98), 1, '4', (byte) 100 };
//        int[] intArray41 = delegatedDateTimeField26.addWrapPartial((org.joda.time.ReadablePartial) localDateTime31, 57600, intArray39, 0);
//        int[] intArray43 = skipUndoDateTimeField16.addWrapPartial((org.joda.time.ReadablePartial) localDateTime20, 0, intArray41, 57600);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDateTime20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4" + "'", str15.equals("4"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str27.equals("DateTimeField[hourOfHalfday]"));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertNotNull(intArray43);
//    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 0);
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
//        java.lang.String str3 = property2.getAsShortText();
//        org.joda.time.DurationField durationField4 = property2.getRangeDurationField();
//        long long7 = durationField4.subtract((-14378440L), (int) (byte) -1);
//        long long10 = durationField4.subtract((long) 21562, 12);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "31" + "'", str3.equals("31"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2664021560L + "'", long7 == 2664021560L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31535978438L) + "'", long10 == (-31535978438L));
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (-641));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.lang.String str7 = iSOChronology6.toString();
//        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField13);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
//        org.joda.time.LocalDateTime localDateTime18 = dateTime16.toLocalDateTime();
//        int[] intArray20 = iSOChronology6.get((org.joda.time.ReadablePartial) localDateTime18, 1560344362544L);
//        int[] intArray22 = iSOChronology1.get((org.joda.time.ReadablePartial) localDateTime18, 0L);
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology1.millisOfDay();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime26 = dateTime25.toDateTime();
//        org.joda.time.DateTime dateTime27 = dateTime25.toDateTimeISO();
//        org.joda.time.DateTime dateTime29 = dateTime25.withMinuteOfHour(0);
//        org.joda.time.DateTime dateTime31 = dateTime29.withYear((int) (byte) 100);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        java.lang.String str35 = iSOChronology34.toString();
//        org.joda.time.DateTimeZone dateTimeZone36 = iSOChronology34.getZone();
//        org.joda.time.DateTime dateTime37 = dateTime32.withZoneRetainFields(dateTimeZone36);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology39.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField41);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = delegatedDateTimeField42.getAsText((long) 4, locale44);
//        boolean boolean46 = delegatedDateTimeField42.isSupported();
//        int int47 = delegatedDateTimeField42.getMaximumValue();
//        java.lang.String str48 = delegatedDateTimeField42.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = delegatedDateTimeField42.getType();
//        org.joda.time.DateTime.Property property50 = dateTime32.property(dateTimeFieldType49);
//        int int51 = dateTime31.get(dateTimeFieldType49);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType49, 5);
//        long long55 = offsetDateTimeField53.roundHalfEven((long) 7171390);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localDateTime18);
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str35.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "4" + "'", str45.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 11 + "'", int47 == 11);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hourOfHalfday" + "'", str48.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 7171390L + "'", long55 == 7171390L);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21559);
        org.joda.time.DateTime dateTime2 = dateTime1.toDateTime();
        org.joda.time.DateTime.Property property3 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTime();
        org.joda.time.DateTime dateTime7 = dateTime4.withWeekyear(163);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isPrinter();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.lang.String str4 = iSOChronology3.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withPivotYear(16);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        java.lang.String str15 = iSOChronology14.toString();
//        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology14.getZone();
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone16);
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 5, dateTimeZone16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.shortTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter21.withZoneUTC();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = delegatedDateTimeField27.getAsText((long) 4, locale29);
//        boolean boolean31 = delegatedDateTimeField27.isSupported();
//        org.joda.time.ReadablePartial readablePartial32 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale36 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket39 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology35, locale36, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket39.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket39.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale44 = dateTimeParserBucket39.getLocale();
//        java.lang.String str45 = delegatedDateTimeField27.getAsShortText(readablePartial32, (int) (short) 100, locale44);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime48 = dateTime47.toDateTime();
//        org.joda.time.LocalDateTime localDateTime49 = dateTime47.toLocalDateTime();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider50 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology52.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField54);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = delegatedDateTimeField55.getAsText((long) 4, locale57);
//        boolean boolean59 = delegatedDateTimeField55.isSupported();
//        org.joda.time.ReadablePartial readablePartial60 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale64 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket67 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 10, (org.joda.time.Chronology) gregorianChronology63, locale64, (java.lang.Integer) 1, (int) (short) 0);
//        dateTimeParserBucket67.setOffset((java.lang.Integer) 1);
//        dateTimeParserBucket67.setOffset((java.lang.Integer) 359);
//        java.util.Locale locale72 = dateTimeParserBucket67.getLocale();
//        java.lang.String str73 = delegatedDateTimeField55.getAsShortText(readablePartial60, (int) (short) 100, locale72);
//        java.lang.String str76 = defaultNameProvider50.getShortName(locale72, "4:00:00 PM PST", "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")");
//        java.lang.String str77 = delegatedDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) localDateTime49, locale72);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter78 = dateTimeFormatter21.withLocale(locale72);
//        java.text.DateFormatSymbols dateFormatSymbols79 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale72);
//        java.lang.String str80 = dateTimeZone16.getName((long) 2066, locale72);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter81 = dateTimeFormatter10.withLocale(locale72);
//        java.text.DateFormatSymbols dateFormatSymbols82 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale72);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str15.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "4" + "'", str30.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(locale44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "100" + "'", str45.equals("100"));
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "4" + "'", str58.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(locale72);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "100" + "'", str73.equals("100"));
//        org.junit.Assert.assertNull(str76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "4" + "'", str77.equals("4"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter78);
//        org.junit.Assert.assertNotNull(dateFormatSymbols79);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "Pacific Standard Time" + "'", str80.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter81);
//        org.junit.Assert.assertNotNull(dateFormatSymbols82);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) 100, 'a', (int) (short) 0, 100, 2000, false, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("Coordinated Universal Time", 21559);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.setFixedSavings("", 57621);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 10);
        java.io.OutputStream outputStream18 = null;
        try {
            dateTimeZoneBuilder16.writeTo("2018-06-13T12:59:21.232Z", outputStream18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        long long11 = gJChronology7.add(readablePeriod8, (long) (byte) 10, (int) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology7.secondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        long long16 = gJChronology7.add(readablePeriod13, 2664021560L, 2018);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2664021560L + "'", long16 == 2664021560L);
//    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        boolean boolean1 = instant0.isBeforeNow();
//        org.joda.time.Instant instant2 = new org.joda.time.Instant();
//        boolean boolean3 = instant0.isBefore((org.joda.time.ReadableInstant) instant2);
//        boolean boolean5 = instant2.isAfter(0L);
//        org.joda.time.MutableDateTime mutableDateTime6 = instant2.toMutableDateTime();
//        int int7 = mutableDateTime6.getEra();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.clockhourOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText((long) 4, locale16);
//        boolean boolean18 = delegatedDateTimeField14.isSupported();
//        int int19 = delegatedDateTimeField14.getMaximumValue();
//        java.lang.String str20 = delegatedDateTimeField14.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField9, dateTimeFieldType21, 21562);
//        int int24 = dividedDateTimeField23.getMaximumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
//        try {
//            long long28 = dividedDateTimeField23.addWrapField(1128L, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfHalfday" + "'", str20.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
        long long8 = iSOChronology2.add((long) (byte) -1, (long) 1000, 21559);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) iSOChronology2, locale9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(21562);
        dateTimeParserBucket10.setZone(dateTimeZone12);
        java.lang.String str15 = dateTimeZone12.getName(28800000L);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21558999L + "'", long8 == 21558999L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:21.562" + "'", str15.equals("+00:00:21.562"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Chronology chronology3 = instant0.getChronology();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(43200010L, dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone4);
//        mutableDateTime6.addWeeks((int) '#');
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.era();
//        int int10 = mutableDateTime6.getMonthOfYear();
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 21559, (-360L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21919L + "'", long2 == 21919L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(100);
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withDate((int) (short) 1, 2068, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2068 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str2 = iSOChronology1.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
//        boolean boolean5 = dateTimeZone3.isStandardOffset((long) (byte) 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
//        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.millisOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
        long long8 = iSOChronology2.add((long) (byte) -1, (long) 1000, 21559);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) iSOChronology2, locale9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = iSOChronology2.add(readablePeriod11, 1L, 21562);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21558999L + "'", long8 == 21558999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("21561", "2018-06-13T12:59:21.232Z", 57621, (int) (byte) 10);
        long long6 = fixedDateTimeZone4.previousTransition(21577513L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 21577513L + "'", long6 == 21577513L);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isPrinter();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.lang.String str4 = iSOChronology3.toString();
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 21559);
//        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime10.yearOfEra();
//        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
//        int int14 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime13);
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime13.withYearOfCentury(21577513);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21577513 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//    }
//}

