import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10, (int) (byte) 1, (int) (short) 10, (int) (byte) 10, 100, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test004");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        try {
            long long6 = durationField3.subtract((long) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-1), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0, 0, 0, (int) '4', 100, (int) (byte) 0, (int) (short) -1, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, 0, (int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.lang.Class<?> wildcardClass2 = chronology1.getClass();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        java.lang.Appendable appendable3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, readableInstant4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.DateTime.Property property5 = dateTime3.property(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        try {
            long long6 = durationField3.subtract((long) 100, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.ReadWritableInstant readWritableInstant2 = null;
        try {
            int int5 = dateTimeFormatter0.parseInto(readWritableInstant2, "hi!", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        boolean boolean7 = dateTime5.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField5 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        int int5 = dateTime4.getSecondOfMinute();
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime4.withDate((int) (byte) 0, (int) 'a', 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long4 = gregorianChronology0.add((long) (byte) 1, (long) (byte) 10, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        boolean boolean7 = dateTime3.isBefore((long) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatterBuilder0.toFormatter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Both printing and parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (byte) 0, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279096 for yearOfEra must be in the range [100,292279092]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter2.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendPattern("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withDate(0, (int) (byte) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime11 = dateTime5.withMillisOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParser3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 881, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8810L + "'", long2 == 8810L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 100);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        org.joda.time.DateTime dateTime13 = property12.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType14, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
        org.joda.time.DateTime dateTime10 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) '4');
        int int17 = dateTime16.getCenturyOfEra();
        int int18 = property6.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 21 + "'", int17 == 21);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        try {
            long long3 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 100, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 0, 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime5.plusMinutes((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime13 = dateTime5.withMonthOfYear((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime6.year();
//        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay10);
//        java.io.Writer writer12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        try {
//            dateTimeFormatter0.printTo(writer12, readableInstant13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(timeOfDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "T14:41:08.691" + "'", str11.equals("T14:41:08.691"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(8810L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8845L + "'", long2 == 8845L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 0, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(10L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "T14:41:06.304");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100.0f, (java.lang.Number) 0L, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        int int4 = dateTime3.getCenturyOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
//        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        int int9 = property6.getDifference(readableInstant8);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[year]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfHalfday(21);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (byte) -1, 0, 0, 15, (int) (short) 10, 21, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "����");
        java.lang.String str3 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"����\" for  is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"����\" for  is not supported"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYearOfCentury((int) 'a');
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withSecondOfMinute((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        int int8 = property6.getMinimumValueOverall();
        int int9 = property6.getMinimumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property6.getFieldType();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        int int7 = property6.getLeapAmount();
        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
        java.util.Locale locale10 = null;
        try {
            org.joda.time.DateTime dateTime11 = property6.setCopy("T14:41:06.304", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T14:41:06.304\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(durationField8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay9 = dateTime8.toTimeOfDay();
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(timeOfDay9);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime14.secondOfDay();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
//        int int17 = property6.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        java.util.Locale locale19 = null;
//        try {
//            org.joda.time.DateTime dateTime20 = property6.setCopy("Property[year]", locale19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[year]\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        int int7 = property6.getLeapAmount();
        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
        java.lang.String str9 = property6.toString();
        org.joda.time.DurationField durationField10 = property6.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[year]" + "'", str9.equals("Property[year]"));
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        try {
            long long6 = durationField3.subtract(6L, 62L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 'a');
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "org.joda.time.IllegalFieldValueException: Value \"����\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (-1.0f), "hi!");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withOffsetParsed();
        java.lang.StringBuffer stringBuffer8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.year();
        org.joda.time.DateTime dateTime17 = dateTime14.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer8, (org.joda.time.ReadableInstant) dateTime17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withOffsetParsed();
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("T14:41:11.128", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T14:41:11.128\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.util.Locale locale4 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNull(locale4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("����", "����");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DurationField durationField8 = gregorianChronology6.eras();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.hourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.millisOfSecond();
        boolean boolean11 = gregorianChronology1.equals((java.lang.Object) dateTimeField10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        try {
            int[] intArray14 = gregorianChronology1.get(readablePeriod12, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", "", false, (int) (short) 0, 881);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 100, 6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 10, 20, 6, (int) (short) 10, 1, 53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
        org.joda.time.DateTime dateTime10 = property6.roundHalfEvenCopy();
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withWeekOfWeekyear(881);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 881 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.centuryOfEra();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property14 = dateTime13.year();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusMonths((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime16.toTimeOfDay();
//        java.lang.String str18 = dateTimeFormatter7.print((org.joda.time.ReadablePartial) timeOfDay17);
//        try {
//            int int19 = property6.compareTo((org.joda.time.ReadablePartial) timeOfDay17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "T16:00:00.097" + "'", str18.equals("T16:00:00.097"));
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes((-1));
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime8.toYearMonthDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long20 = fixedDateTimeZone16.convertLocalToUTC((long) (-1), true, (long) ' ');
        boolean boolean22 = fixedDateTimeZone16.equals((java.lang.Object) 100.0f);
        org.joda.time.DateTime dateTime23 = dateTime8.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((int) ' ', (int) (short) 10, (int) (short) 0, 53, (int) '#', (org.joda.time.DateTimeZone) fixedDateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
        org.joda.time.DateTime dateTime14 = property13.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) (-1.0f), "hi!");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType15, (-1), 271);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 21");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.centuryOfEra();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.DateTime dateTime12 = dateTime9.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay13 = dateTime12.toTimeOfDay();
        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay13);
        try {
            org.joda.time.LocalDateTime localDateTime16 = dateTimeFormatter0.parseLocalDateTime("T14:41:06.304");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T14:41:06.304\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(timeOfDay13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "����" + "'", str14.equals("����"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        int int6 = dateTime5.getCenturyOfEra();
        int int7 = dateTime5.getMillisOfSecond();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) int7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter19.getParser();
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter19.withLocale(locale21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTime dateTime28 = dateTime26.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property29 = dateTime28.year();
        org.joda.time.DateTime dateTime31 = dateTime28.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay32 = dateTime31.toTimeOfDay();
        java.lang.String str33 = dateTimeFormatter19.print((org.joda.time.ReadablePartial) timeOfDay32);
        int[] intArray37 = new int[] { (byte) 1, '#', 6 };
        try {
            int int38 = unsupportedDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay32, intArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(timeOfDay32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����" + "'", str33.equals("����"));
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.DurationField durationField19 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter19.getParser();
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter19.withLocale(locale21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTime dateTime28 = dateTime26.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property29 = dateTime28.year();
        org.joda.time.DateTime dateTime31 = dateTime28.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay32 = dateTime31.toTimeOfDay();
        java.lang.String str33 = dateTimeFormatter19.print((org.joda.time.ReadablePartial) timeOfDay32);
        int[] intArray34 = new int[] {};
        try {
            int int35 = unsupportedDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay32, intArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(timeOfDay32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "����" + "'", str33.equals("����"));
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long6 = fixedDateTimeZone4.previousTransition((long) 6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC(10L, false, (long) 21);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6L + "'", long6 == 6L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-1727999119L), 271);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        try {
            int int20 = unsupportedDateTimeField18.getMinimumValue(readablePartial19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
//        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.centuryOfEra();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTime dateTime25 = dateTime23.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property26 = dateTime25.year();
//        org.joda.time.DateTime dateTime28 = dateTime25.plusMonths((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
//        java.lang.String str30 = dateTimeFormatter19.print((org.joda.time.ReadablePartial) timeOfDay29);
//        int[] intArray33 = new int[] { 'a' };
//        try {
//            int[] intArray35 = unsupportedDateTimeField18.addWrapField((org.joda.time.ReadablePartial) timeOfDay29, (int) (short) 1, intArray33, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(timeOfDay29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T16:00:00.097" + "'", str30.equals("T16:00:00.097"));
//        org.junit.Assert.assertNotNull(intArray33);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("T14:41:06.304", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        try {
            int int20 = unsupportedDateTimeField18.getLeapAmount(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = unsupportedDateTimeField18.getAsShortText((int) '4', locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMinuteOfHour((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (short) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        try {
            int int19 = unsupportedDateTimeField18.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField8 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType6, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone6 = fixedDateTimeZone5.toTimeZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(100L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, (int) (byte) 1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay9 = dateTime8.toTimeOfDay();
        org.joda.time.DateTime.Property property10 = dateTime8.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(timeOfDay9);
        org.junit.Assert.assertNotNull(property10);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 0);
//        java.lang.String str6 = dateTimeFormatter4.print(0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-W01-3T16:00:00-08:00" + "'", str6.equals("1970-W01-3T16:00:00-08:00"));
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.LocalDate localDate21 = dateTimeFormatter19.parseLocalDate("16:00");
        int[] intArray26 = new int[] { (short) 10, 21, 271 };
        java.util.Locale locale28 = null;
        try {
            int[] intArray29 = unsupportedDateTimeField18.set((org.joda.time.ReadablePartial) localDate21, 6, intArray26, "16:00", locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology1.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = unsupportedDateTimeField18.getAsShortText(0, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond((int) '4');
        boolean boolean6 = dateTimeFormatterBuilder3.canBuildFormatter();
        boolean boolean7 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("T14:41:11.128");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"T14:41:11.128\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology0.add(readablePeriod3, (long) (short) -1, 2);
        org.joda.time.DurationField durationField7 = gregorianChronology0.eras();
        try {
            long long10 = durationField7.subtract((long) (byte) -1, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendSecondOfMinute(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendPattern("����");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendFraction(dateTimeFieldType20, (int) (short) 100, 15);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder26.appendTimeZoneOffset("T14:41:11.128", "", true, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime5.withYearOfEra((int) '#');
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
        org.joda.time.DurationField durationField14 = gregorianChronology12.eras();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        long long18 = gregorianChronology12.add(readablePeriod15, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology12.secondOfMinute();
        int int21 = dateTime5.get(dateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        java.util.Locale locale24 = null;
        try {
            long long25 = unsupportedDateTimeField18.set(0L, "", locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.halfdays();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withLocale(locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.DateTime dateTime18 = dateTime15.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay19 = dateTime18.toTimeOfDay();
        java.lang.String str20 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) timeOfDay19);
        int[] intArray21 = new int[] {};
        try {
            gregorianChronology1.validate((org.joda.time.ReadablePartial) timeOfDay19, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(timeOfDay19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����" + "'", str20.equals("����"));
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("16:00", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(0, 'a', 10, (int) (byte) -1, 0, true, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        java.util.Locale locale19 = null;
        try {
            int int20 = unsupportedDateTimeField18.getMaximumTextLength(locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.centuryOfEra();
        org.joda.time.DurationField durationField22 = gregorianChronology20.eras();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.hourOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology20.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter25.getParser();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter25.withLocale(locale27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.DateTime dateTime34 = dateTime32.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property35 = dateTime34.year();
        org.joda.time.DateTime dateTime37 = dateTime34.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay38 = dateTime37.toTimeOfDay();
        java.lang.String str39 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) timeOfDay38);
        int[] intArray41 = gregorianChronology20.get((org.joda.time.ReadablePartial) timeOfDay38, 10L);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.centuryOfEra();
        org.joda.time.DurationField durationField45 = gregorianChronology43.eras();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.hourOfDay();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology43.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser49 = dateTimeFormatter48.getParser();
        java.util.Locale locale50 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter48.withLocale(locale50);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone52);
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology53.centuryOfEra();
        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology53);
        org.joda.time.DateTime dateTime57 = dateTime55.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property58 = dateTime57.year();
        org.joda.time.DateTime dateTime60 = dateTime57.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay61 = dateTime60.toTimeOfDay();
        java.lang.String str62 = dateTimeFormatter48.print((org.joda.time.ReadablePartial) timeOfDay61);
        int[] intArray64 = gregorianChronology43.get((org.joda.time.ReadablePartial) timeOfDay61, 10L);
        try {
            int int65 = unsupportedDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay38, intArray64);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeParser26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(timeOfDay38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "����" + "'", str39.equals("����"));
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertNotNull(dateTimeParser49);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(timeOfDay61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "����" + "'", str62.equals("����"));
        org.junit.Assert.assertNotNull(intArray64);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(271, '4', 271, 271, (int) (short) -1, true, (int) '4');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addRecurringSavings("����", 271, 0, 15, ' ', 21, 12, (int) (short) 10, false, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType9, 21);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 0.0d, "����");
        java.lang.String str15 = illegalFieldValueException14.getFieldName();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "secondOfDay" + "'", str15.equals("secondOfDay"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) '4');
        int int13 = property6.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateMidnight dateMidnight15 = dateTime10.toDateMidnight();
        boolean boolean17 = dateMidnight15.isBefore((long) 12);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 8845L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true, (long) ' ');
        java.lang.String str10 = fixedDateTimeZone4.getName((long) 10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.centuryOfEra();
        org.joda.time.DurationField durationField7 = gregorianChronology5.eras();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter10.withLocale(locale12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.centuryOfEra();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property20 = dateTime19.year();
        org.joda.time.DateTime dateTime22 = dateTime19.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        java.lang.String str24 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) timeOfDay23);
        int[] intArray26 = gregorianChronology5.get((org.joda.time.ReadablePartial) timeOfDay23, 10L);
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (org.joda.time.ReadablePartial) timeOfDay23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "����" + "'", str24.equals("����"));
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        int int5 = dateTime4.getSecondOfMinute();
        org.joda.time.DateTime.Property property6 = dateTime4.weekyear();
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        java.util.Locale locale20 = null;
        try {
            long long21 = remainderDateTimeField17.set((long) 'a', "1970-W01-3T16:00:00-08:00", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-W01-3T16:00:00-08:00\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) '#');
        org.joda.time.DateTime dateTime9 = property6.roundHalfCeilingCopy();
        int int10 = property6.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 86399 + "'", int10 == 86399);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        try {
            int int24 = unsupportedDateTimeField18.getMaximumValue((-1727999119L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("16:00", true);
        long long7 = dateTimeZone3.convertLocalToUTC(1L, true, (long) '4');
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 2, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter2.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        int int19 = remainderDateTimeField17.get((long) (byte) -1);
        java.util.Locale locale20 = null;
        int int21 = remainderDateTimeField17.getMaximumTextLength(locale20);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Property[year]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
//        long long19 = remainderDateTimeField17.remainder(52L);
//        boolean boolean20 = remainderDateTimeField17.isSupported();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.centuryOfEra();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property28 = dateTime27.year();
//        org.joda.time.DateTime dateTime30 = dateTime27.plusMonths((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.String str32 = dateTimeFormatter21.print((org.joda.time.ReadablePartial) timeOfDay31);
//        boolean boolean33 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay31);
//        java.util.Locale locale34 = null;
//        try {
//            java.lang.String str35 = remainderDateTimeField17.getAsText((org.joda.time.ReadablePartial) timeOfDay31, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "T14:41:25.190" + "'", str32.equals("T14:41:25.190"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        try {
            int int22 = unsupportedDateTimeField18.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) '4');
        int int13 = property6.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.withLaterOffsetAtOverlap();
        boolean boolean16 = dateTime10.isAfter((long) 70);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter18.withPivotYear((java.lang.Integer) 10);
        org.joda.time.MutableDateTime mutableDateTime22 = dateTimeFormatter20.parseMutableDateTime("1970-12-30T16:00:00.097-08:00");
        boolean boolean23 = gregorianChronology17.equals((java.lang.Object) mutableDateTime22);
        boolean boolean24 = dateTime10.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "T14:41:06.304");
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.Chronology chronology33 = gregorianChronology30.withUTC();
        org.joda.time.DurationField durationField34 = gregorianChronology30.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField34);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField34);
        long long39 = durationField34.subtract((long) (byte) -1, (int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-97001L) + "'", long39 == (-97001L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime9 = property6.addToCopy((long) 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 21);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter2.parseLocalTime("org.joda.time.IllegalFieldValueException: Value \"����\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) (byte) 0, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) -1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.append(dateTimeParser12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.append(dateTimeParser16);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser12, dateTimeParser16 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder6.append(dateTimePrinter7, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfYear(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatterBuilder23.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10L, "����");
        java.lang.String str15 = illegalFieldValueException14.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime6.year();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.centuryOfEra();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property14 = dateTime13.year();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusMonths((int) (byte) 10);
//        org.joda.time.DateTime.Property property17 = dateTime13.minuteOfHour();
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime13);
//        java.lang.String str19 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime6.plus(readableDuration20);
//        java.util.Date date22 = dateTime6.toDate();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "14:41" + "'", str19.equals("14:41"));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(date22);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay((int) '4', 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder6.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 97L, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType9, 21);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder0.appendDayOfMonth(27);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYearOfCentury((int) 'a');
        org.joda.time.DateTime dateTime13 = dateTime5.plusMinutes(100);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime13.toMutableDateTime(chronology14);
        int int16 = mutableDateTime15.getEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DurationField durationField12 = gregorianChronology10.eras();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology10.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology10.dayOfYear();
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatter0, (java.lang.Object) gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) ' ', 6, 881, 0, 25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 881 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay((int) '4', 15);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendDayOfMonth((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        java.lang.String str8 = dateTime5.toString("+00:00");
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = unsupportedDateTimeField18.getAsText((long) 28799, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay(25);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withEra(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        int int19 = remainderDateTimeField17.get((long) (byte) -1);
        boolean boolean20 = remainderDateTimeField17.isLenient();
        long long23 = remainderDateTimeField17.set(97L, 2);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 120097L + "'", long23 == 120097L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(8810L);
        int int20 = remainderDateTimeField17.getMaximumValue();
        java.util.Locale locale23 = null;
        try {
            long long24 = remainderDateTimeField17.set((long) 27, "T14:41:11.128", locale23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T14:41:11.128\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8810L + "'", long19 == 8810L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
        long long12 = durationField9.subtract((long) 881, (long) 20);
        long long15 = durationField9.subtract(8845L, 2);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1727999119L) + "'", long12 == (-1727999119L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-172791155L) + "'", long15 == (-172791155L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYearOfCentury((int) 'a');
        org.joda.time.DateTime dateTime13 = dateTime5.plusMinutes(100);
        org.joda.time.DateTime dateTime15 = dateTime5.minusSeconds(1);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMinutes(70);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) '4', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime14.secondOfDay();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
//        int int17 = property6.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime20 = dateTime16.withDurationAdded((long) 0, (int) (short) 100);
//        org.joda.time.DateTime.Property property21 = dateTime16.dayOfWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "16:00:00.010-08:00" + "'", str2.equals("16:00:00.010-08:00"));
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.DurationField durationField26 = gregorianChronology24.eras();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.hourOfDay();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology24.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter29.getParser();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter29.withLocale(locale31);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.centuryOfEra();
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology34);
        org.joda.time.DateTime dateTime38 = dateTime36.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property39 = dateTime38.year();
        org.joda.time.DateTime dateTime41 = dateTime38.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay42 = dateTime41.toTimeOfDay();
        java.lang.String str43 = dateTimeFormatter29.print((org.joda.time.ReadablePartial) timeOfDay42);
        int[] intArray45 = gregorianChronology24.get((org.joda.time.ReadablePartial) timeOfDay42, 10L);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone47);
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.centuryOfEra();
        org.joda.time.DurationField durationField50 = gregorianChronology48.eras();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology48.hourOfDay();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology48.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser54 = dateTimeFormatter53.getParser();
        java.util.Locale locale55 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter53.withLocale(locale55);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone57);
        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology58.centuryOfEra();
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology58);
        org.joda.time.DateTime dateTime62 = dateTime60.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property63 = dateTime62.year();
        org.joda.time.DateTime dateTime65 = dateTime62.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay66 = dateTime65.toTimeOfDay();
        java.lang.String str67 = dateTimeFormatter53.print((org.joda.time.ReadablePartial) timeOfDay66);
        int[] intArray69 = gregorianChronology48.get((org.joda.time.ReadablePartial) timeOfDay66, 10L);
        try {
            int[] intArray71 = unsupportedDateTimeField18.set((org.joda.time.ReadablePartial) timeOfDay42, (int) (byte) -1, intArray69, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(timeOfDay42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "����" + "'", str43.equals("����"));
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeParser54);
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(timeOfDay66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "����" + "'", str67.equals("����"));
        org.junit.Assert.assertNotNull(intArray69);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.secondOfDay();
        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType17, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendHourOfHalfday((int) (byte) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder22.appendPattern("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(15, (int) (short) 100, 9, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "����");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("T14:41:11.128", "T14:41:11.128");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "T14:41:11.128" + "'", str3.equals("T14:41:11.128"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        try {
            int int20 = unsupportedDateTimeField18.get((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 21);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("16:00", true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        try {
            int int24 = unsupportedDateTimeField18.getMaximumValue(60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
//        org.joda.time.DateTime dateTime8 = dateTime5.withDayOfMonth(6);
//        int int9 = dateTime5.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = dateTime5.withLaterOffsetAtOverlap();
//        int int11 = dateTime5.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 881 + "'", int11 == 881);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYearOfCentury((int) 'a');
        org.joda.time.DateTime dateTime13 = dateTime5.plusMinutes(100);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime13.toMutableDateTime(chronology14);
        java.util.Date date16 = mutableDateTime15.toDate();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology1.add(readablePeriod4, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology1.yearOfCentury();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField11, 27, 9, 881);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.centuryOfEra();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime dateTime29 = dateTime27.plusMinutes((-1));
        org.joda.time.YearMonthDay yearMonthDay30 = dateTime27.toYearMonthDay();
        int[] intArray36 = new int[] { (byte) 100, (byte) 100, 9, 21 };
        java.util.Locale locale38 = null;
        try {
            int[] intArray39 = unsupportedDateTimeField18.set((org.joda.time.ReadablePartial) yearMonthDay30, 100, intArray36, "1970-12-30T16:00:00.097-08:00", locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(yearMonthDay30);
        org.junit.Assert.assertNotNull(intArray36);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendSecondOfMinute(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendPattern("����");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "T14:41:06.304");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.append(dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder30.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.centuryOfEra();
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology40);
        org.joda.time.DateTime dateTime44 = dateTime42.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property45 = dateTime44.secondOfDay();
        org.joda.time.DateTime dateTime46 = property45.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property45.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder38.appendFixedSignedDecimal(dateTimeFieldType47, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder11.appendSignedDecimal(dateTimeFieldType47, (int) (byte) 0, 21);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 10);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTimeFormatter4.parseMutableDateTime("1970-12-30T16:00:00.097-08:00");
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) mutableDateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 1, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField18.getRangeDurationField();
        try {
            long long25 = unsupportedDateTimeField18.roundCeiling(52L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readableDuration7);
//        java.lang.String str9 = dateTime5.toString();
//        org.joda.time.LocalTime localTime10 = dateTime5.toLocalTime();
//        boolean boolean11 = dateTime5.isEqualNow();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2020-06-13T14:41:34.754-07:00" + "'", str9.equals("2020-06-13T14:41:34.754-07:00"));
//        org.junit.Assert.assertNotNull(localTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("T14:41:24.486", "Property[year]");
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "16:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.DurationField durationField19 = unsupportedDateTimeField18.getLeapDurationField();
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = unsupportedDateTimeField18.getAsText((long) 86399, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((java.lang.Integer) 10);
        org.joda.time.MutableDateTime mutableDateTime12 = dateTimeFormatter10.parseMutableDateTime("1970-12-30T16:00:00.097-08:00");
        boolean boolean13 = gregorianChronology7.equals((java.lang.Object) mutableDateTime12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 1, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.append(dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder15.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.centuryOfEra();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime dateTime29 = dateTime27.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder23.appendFixedSignedDecimal(dateTimeFieldType32, 6);
        org.joda.time.DateTime dateTime39 = dateTime14.withField(dateTimeFieldType32, (int) (short) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType32, (int) (byte) -1, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTime39);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        int int5 = dateTime4.getYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) ' ');
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime25 = property24.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType26);
        long long36 = zeroIsMaxDateTimeField33.getDifferenceAsLong((long) 0, 10L);
        int int39 = zeroIsMaxDateTimeField33.getDifference((long) '#', (-1727999119L));
        int int42 = zeroIsMaxDateTimeField33.getDifference((-1L), (long) '#');
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.centuryOfEra();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology44);
        org.joda.time.DateTime dateTime48 = dateTime46.plusMinutes((-1));
        org.joda.time.YearMonthDay yearMonthDay49 = dateTime46.toYearMonthDay();
        java.util.Locale locale50 = null;
        try {
            java.lang.String str51 = zeroIsMaxDateTimeField33.getAsText((org.joda.time.ReadablePartial) yearMonthDay49, locale50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 28799 + "'", int39 == 28799);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(yearMonthDay49);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) '4');
        int int13 = property6.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.withLaterOffsetAtOverlap();
        int int15 = dateTime14.getMillisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 32 + "'", int15 == 32);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        int int7 = dateTime5.getSecondOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        org.joda.time.DateTime dateTime9 = dateTime5.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            int int11 = dateTime9.get(dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        try {
            long long22 = offsetDateTimeField19.set((long) (short) 100, 25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 25 for secondOfDay must be in the range [1,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.clockhourOfDay();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime9 = property6.setCopy((int) (byte) -1);
        java.lang.String str10 = property6.getName();
        java.util.Locale locale12 = null;
        try {
            org.joda.time.DateTime dateTime13 = property6.setCopy("Property[year]", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[year]\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekyear" + "'", str10.equals("weekyear"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(57600);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1.0d, number2, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true, (long) ' ');
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) 100.0f);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYearOfCentury((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder16.appendFixedSignedDecimal(dateTimeFieldType25, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField15, dateTimeFieldType25, 10);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.centuryOfEra();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology31);
        org.joda.time.DateTime dateTime35 = dateTime33.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
        org.joda.time.DateTime dateTime37 = property36.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType38);
        int int46 = dateTime11.get(dateTimeFieldType38);
        int int47 = dateTime11.getDayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 31 + "'", int47 == 31);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal(6L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.Chronology chronology13 = gregorianChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology10.era();
        boolean boolean15 = iSOChronology8.equals((java.lang.Object) dateTimeField14);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.LocalTime localTime10 = dateTimeFormatter8.parseLocalTime("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1970, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1970L) + "'", long2 == (-1970L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long14 = fixedDateTimeZone10.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTime dateTime15 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        int int16 = dateTime15.getYearOfEra();
        org.joda.time.DateTime dateTime18 = dateTime15.minusHours(86399);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(52L);
        boolean boolean20 = remainderDateTimeField17.isSupported();
        long long22 = remainderDateTimeField17.roundHalfFloor(0L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = remainderDateTimeField17.getAsText(8810L, locale24);
        int int27 = remainderDateTimeField17.getMinimumValue((long) 70);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0, 881, 53, 2020, (int) '#', 881, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2020 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.centuryOfEra();
        org.joda.time.DurationField durationField6 = gregorianChronology4.eras();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology4.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withLocale(locale11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.centuryOfEra();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTime dateTime18 = dateTime16.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property19 = dateTime18.year();
        org.joda.time.DateTime dateTime21 = dateTime18.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay22 = dateTime21.toTimeOfDay();
        java.lang.String str23 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) timeOfDay22);
        int[] intArray25 = gregorianChronology4.get((org.joda.time.ReadablePartial) timeOfDay22, 10L);
        int[] intArray27 = new int[] { 271 };
        try {
            gregorianChronology0.validate((org.joda.time.ReadablePartial) timeOfDay22, intArray27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 271 for hourOfDay must not be larger than 23");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(timeOfDay22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "����" + "'", str23.equals("����"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, 60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 60");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.centuryOfEra();
        org.joda.time.DurationField durationField27 = gregorianChronology25.eras();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology25.hourOfDay();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology25.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        java.util.Locale locale32 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter30.withLocale(locale32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.centuryOfEra();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology35);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property40 = dateTime39.year();
        org.joda.time.DateTime dateTime42 = dateTime39.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay43 = dateTime42.toTimeOfDay();
        java.lang.String str44 = dateTimeFormatter30.print((org.joda.time.ReadablePartial) timeOfDay43);
        int[] intArray46 = gregorianChronology25.get((org.joda.time.ReadablePartial) timeOfDay43, 10L);
        try {
            int int47 = unsupportedDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(timeOfDay43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "����" + "'", str44.equals("����"));
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        java.lang.Number number12 = illegalFieldValueException11.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(2, 27, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 76 + "'", int3 == 76);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "T14:41:06.304");
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.Chronology chronology33 = gregorianChronology30.withUTC();
        org.joda.time.DurationField durationField34 = gregorianChronology30.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField34);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField34);
        try {
            int int38 = unsupportedDateTimeField36.getLeapAmount(97L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long14 = fixedDateTimeZone10.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTime dateTime15 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        int int16 = dateTime15.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DurationField durationField20 = gregorianChronology18.eras();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.millisOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology18.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology18.getZone();
        org.joda.time.DateTime dateTime25 = dateTime15.toDateTime((org.joda.time.Chronology) gregorianChronology18);
        boolean boolean27 = dateTime25.isEqual((long) 100);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "T14:41:06.304");
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.Chronology chronology33 = gregorianChronology30.withUTC();
        org.joda.time.DurationField durationField34 = gregorianChronology30.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField34);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter37.getParser();
        java.util.Locale locale39 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter37.withLocale(locale39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.centuryOfEra();
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.DateTime dateTime46 = dateTime44.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property47 = dateTime46.year();
        org.joda.time.DateTime dateTime49 = dateTime46.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay50 = dateTime49.toTimeOfDay();
        java.lang.String str51 = dateTimeFormatter37.print((org.joda.time.ReadablePartial) timeOfDay50);
        int[] intArray53 = null;
        try {
            int[] intArray55 = unsupportedDateTimeField36.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay50, 33, intArray53, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(timeOfDay50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "����" + "'", str51.equals("����"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long14 = fixedDateTimeZone10.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTime dateTime15 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        int int16 = dateTime15.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime15.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        try {
            int int24 = dateTime22.get(dateTimeFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.DateTime dateTime15 = dateTime12.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime12.minuteOfHour();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime19 = dateTime5.minusWeeks(60);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.centuryOfEra();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTime dateTime25 = dateTime23.plusMinutes((-1));
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime23.toYearMonthDay();
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = remainderDateTimeField17.getAsText((org.joda.time.ReadablePartial) yearMonthDay26, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.millisOfSecond();
        try {
            long long13 = gregorianChronology1.getDateTimeMillis(0, (int) (short) 1, 0, (int) (short) -1, 25, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendSecondOfMinute(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendPattern("����");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendFraction(dateTimeFieldType20, (int) (short) 100, 15);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.centuryOfEra();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology33);
        org.joda.time.DateTime dateTime37 = dateTime35.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTime dateTime39 = property38.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder31.appendFixedSignedDecimal(dateTimeFieldType40, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dateTimeField30, dateTimeFieldType40, 10);
        long long46 = remainderDateTimeField44.roundHalfEven((long) 53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone48);
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.centuryOfEra();
        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology49);
        org.joda.time.DateTime dateTime53 = dateTime51.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property54 = dateTime53.secondOfDay();
        org.joda.time.DateTime dateTime55 = property54.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property54.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder47.appendFixedSignedDecimal(dateTimeFieldType56, 21);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone59);
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology60.centuryOfEra();
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology60);
        org.joda.time.DateTime dateTime64 = dateTime62.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property65 = dateTime64.secondOfDay();
        org.joda.time.DateTime dateTime66 = property65.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property65.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder47.appendText(dateTimeFieldType67);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField72 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField44, dateTimeFieldType67);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder7.appendFraction(dateTimeFieldType67, 6, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology77 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone76);
        org.joda.time.DateTimeField dateTimeField78 = gregorianChronology77.centuryOfEra();
        org.joda.time.DateTime dateTime79 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology77);
        org.joda.time.DateTime dateTime81 = dateTime79.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property82 = dateTime81.secondOfDay();
        org.joda.time.DateTime dateTime83 = property82.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType84 = property82.getFieldType();
        org.joda.time.DurationField durationField85 = property82.getRangeDurationField();
        long long88 = durationField85.subtract((long) 881, (long) 20);
        org.joda.time.DateTimeZone dateTimeZone89 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology90 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone89);
        org.joda.time.DateTimeField dateTimeField91 = gregorianChronology90.centuryOfEra();
        org.joda.time.DateTime dateTime92 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology90);
        org.joda.time.Chronology chronology93 = gregorianChronology90.withUTC();
        org.joda.time.DurationField durationField94 = gregorianChronology90.months();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField95 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType67, durationField85, durationField94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
        org.junit.Assert.assertNotNull(gregorianChronology77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(property82);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTimeFieldType84);
        org.junit.Assert.assertNotNull(durationField85);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + (-1727999119L) + "'", long88 == (-1727999119L));
        org.junit.Assert.assertNotNull(gregorianChronology90);
        org.junit.Assert.assertNotNull(dateTimeField91);
        org.junit.Assert.assertNotNull(dateTime92);
        org.junit.Assert.assertNotNull(chronology93);
        org.junit.Assert.assertNotNull(durationField94);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        java.util.Locale locale23 = null;
        try {
            int int24 = unsupportedDateTimeField18.getMaximumTextLength(locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "T14:41:06.304");
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.Chronology chronology33 = gregorianChronology30.withUTC();
        org.joda.time.DurationField durationField34 = gregorianChronology30.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField34);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField34);
        long long39 = unsupportedDateTimeField36.add((long) 881, 120097L);
        try {
            long long41 = unsupportedDateTimeField36.roundHalfCeiling((long) 271);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 120097881L + "'", long39 == 120097881L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(8810L);
        long long21 = remainderDateTimeField17.roundCeiling((long) 'a');
        int int23 = remainderDateTimeField17.getMaximumValue((-35L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8810L + "'", long19 == 8810L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 60000L + "'", long21 == 60000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendSecondOfMinute(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendPattern("����");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "T14:41:06.304");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendHourOfDay((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "T14:41:06.304");
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.Chronology chronology33 = gregorianChronology30.withUTC();
        org.joda.time.DurationField durationField34 = gregorianChronology30.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField34);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField34);
        long long39 = unsupportedDateTimeField36.add((long) 881, 120097L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatter40.getParser();
        java.util.Locale locale42 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter40.withLocale(locale42);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.centuryOfEra();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology45);
        org.joda.time.DateTime dateTime49 = dateTime47.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property50 = dateTime49.year();
        org.joda.time.DateTime dateTime52 = dateTime49.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay53 = dateTime52.toTimeOfDay();
        java.lang.String str54 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) timeOfDay53);
        java.util.Locale locale55 = null;
        try {
            java.lang.String str56 = unsupportedDateTimeField36.getAsText((org.joda.time.ReadablePartial) timeOfDay53, locale55);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 120097881L + "'", long39 == 120097881L);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(timeOfDay53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "����" + "'", str54.equals("����"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        boolean boolean7 = dateTime5.isAfterNow();
        org.joda.time.DateTime dateTime9 = dateTime5.plusDays((int) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "T14:41:06.304");
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.Chronology chronology33 = gregorianChronology30.withUTC();
        org.joda.time.DurationField durationField34 = gregorianChronology30.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField34);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField34);
        long long39 = unsupportedDateTimeField36.add((long) 881, 120097L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.centuryOfEra();
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.DateTime dateTime46 = dateTime44.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property47 = dateTime46.year();
        org.joda.time.DateTime dateTime49 = dateTime46.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay50 = dateTime49.toTimeOfDay();
        java.lang.String str51 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) timeOfDay50);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone53);
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology54.centuryOfEra();
        org.joda.time.DurationField durationField56 = gregorianChronology54.eras();
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology54.hourOfDay();
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology54.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser60 = dateTimeFormatter59.getParser();
        java.util.Locale locale61 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = dateTimeFormatter59.withLocale(locale61);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone63);
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology64.centuryOfEra();
        org.joda.time.DateTime dateTime66 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology64);
        org.joda.time.DateTime dateTime68 = dateTime66.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property69 = dateTime68.year();
        org.joda.time.DateTime dateTime71 = dateTime68.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay72 = dateTime71.toTimeOfDay();
        java.lang.String str73 = dateTimeFormatter59.print((org.joda.time.ReadablePartial) timeOfDay72);
        int[] intArray75 = gregorianChronology54.get((org.joda.time.ReadablePartial) timeOfDay72, 10L);
        try {
            int[] intArray77 = unsupportedDateTimeField36.add((org.joda.time.ReadablePartial) timeOfDay50, (int) (byte) 10, intArray75, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 120097881L + "'", long39 == 120097881L);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(timeOfDay50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T00:00:00.032" + "'", str51.equals("T00:00:00.032"));
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTimeParser60);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(timeOfDay72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "����" + "'", str73.equals("����"));
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.DurationField durationField19 = unsupportedDateTimeField18.getLeapDurationField();
        java.util.Locale locale20 = null;
        try {
            int int21 = unsupportedDateTimeField18.getMaximumShortTextLength(locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime5.plusYears((int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.yearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime5.withChronology((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime dateTime16 = dateTime5.minusYears((int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField17 = null;
        try {
            int int18 = dateTime5.get(dateTimeField17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal(6L);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone4.getShortName((-172791155L), locale10);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        int int7 = property6.getLeapAmount();
        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
        java.lang.String str9 = property6.toString();
        org.joda.time.DateTime dateTime10 = property6.getDateTime();
        boolean boolean12 = property6.equals((java.lang.Object) "T14:41:11.128");
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[year]" + "'", str9.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 881);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(52L);
        long long21 = remainderDateTimeField17.remainder(24L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24L + "'", long21 == 24L);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
//        long long19 = remainderDateTimeField17.remainder(52L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTime dateTime26 = dateTime24.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property27 = dateTime26.year();
//        org.joda.time.DateTime dateTime29 = dateTime26.plusMonths((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay30 = dateTime29.toTimeOfDay();
//        java.lang.String str31 = dateTimeFormatter20.print((org.joda.time.ReadablePartial) timeOfDay30);
//        boolean boolean32 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay30);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = remainderDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) timeOfDay30, (-1), locale34);
//        long long37 = remainderDateTimeField17.roundCeiling((long) 25);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(timeOfDay30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "T21:41:45.233" + "'", str31.equals("T21:41:45.233"));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-1" + "'", str35.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 60000L + "'", long37 == 60000L);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long14 = fixedDateTimeZone10.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTime dateTime15 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        int int16 = dateTime15.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime15.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        long long26 = fixedDateTimeZone21.convertLocalToUTC((long) (byte) 100, false, (long) 15);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType9, 21);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 0.0d, "����");
        java.lang.String str15 = illegalFieldValueException14.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.0" + "'", str15.equals("0.0"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.DateTime dateTime15 = dateTime12.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property16 = dateTime12.minuteOfHour();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime19 = dateTime12.plusMinutes((int) ' ');
        org.joda.time.DateTime.Property property20 = dateTime12.dayOfWeek();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException("����", "����");
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = illegalFieldValueException23.getDateTimeFieldType();
        boolean boolean25 = property20.equals((java.lang.Object) dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime25 = property24.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType26);
        org.joda.time.DurationField durationField34 = zeroIsMaxDateTimeField33.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNull(durationField34);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
        org.joda.time.DateTime dateTime11 = dateTime5.minusWeeks(53);
        boolean boolean12 = dateTime11.isAfterNow();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withFieldAdded(durationFieldType13, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYearOfCentury((int) 'a');
        org.joda.time.DateTime dateTime13 = dateTime5.plusMinutes(100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long20 = fixedDateTimeZone18.nextTransition(0L);
        org.joda.time.DateTime dateTime21 = dateTime5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        try {
            org.joda.time.DateTime dateTime23 = dateTime21.withSecondOfMinute((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.Instant instant7 = dateTime5.toInstant();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
        org.joda.time.DateTime dateTime10 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
        java.lang.String str13 = dateTimeZone11.getShortName(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property7 = dateTime6.year();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.centuryOfEra();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property14 = dateTime13.year();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusMonths((int) (byte) 10);
//        org.joda.time.DateTime.Property property17 = dateTime13.minuteOfHour();
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime13);
//        java.lang.String str19 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime6);
//        try {
//            org.joda.time.DateTime dateTime21 = dateTime6.withEra(53);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "21:41" + "'", str19.equals("21:41"));
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        try {
            long long24 = unsupportedDateTimeField18.roundHalfEven((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        long long21 = offsetDateTimeField19.remainder((long) 24);
        long long24 = offsetDateTimeField19.addWrapField((long) 'a', 25);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.centuryOfEra();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.DateTime dateTime30 = dateTime28.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property31 = dateTime30.year();
        org.joda.time.DateTime dateTime33 = dateTime30.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        int[] intArray36 = null;
        try {
            int[] intArray38 = offsetDateTimeField19.add((org.joda.time.ReadablePartial) timeOfDay34, 0, intArray36, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24L + "'", long21 == 24L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 300097L + "'", long24 == 300097L);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime9 = property6.setCopy((int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withTime(15, (int) (byte) 100, 0, 57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        int int5 = dateTime4.getSecondOfMinute();
//        org.joda.time.DateTime.Property property6 = dateTime4.weekyear();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property6.getAsText(locale7);
//        int int9 = property6.get();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 47 + "'", int5 == 47);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.centuryOfEra();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology20);
        org.joda.time.DateTime dateTime24 = dateTime22.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
        org.joda.time.DateTime dateTime26 = property25.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder18.appendFixedSignedDecimal(dateTimeFieldType27, 21);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.centuryOfEra();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology31);
        org.joda.time.DateTime dateTime35 = dateTime33.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
        org.joda.time.DateTime dateTime37 = property36.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder18.appendText(dateTimeFieldType38);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType38, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField18.getRangeDurationField();
        java.util.Locale locale25 = null;
        try {
            int int26 = unsupportedDateTimeField18.getMaximumTextLength(locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNull(durationField24);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
//        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
//        org.joda.time.DateTime dateTime11 = dateTime5.plusYears((int) (byte) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.yearOfCentury();
//        org.joda.time.DateTime dateTime14 = dateTime5.withChronology((org.joda.time.Chronology) gregorianChronology12);
//        int int15 = dateTime14.getYearOfEra();
//        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
//        long long17 = property16.remainder();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property24 = dateTime23.year();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusMonths((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay27 = dateTime26.toTimeOfDay();
//        boolean boolean28 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay27);
//        try {
//            int int29 = property16.compareTo((org.joda.time.ReadablePartial) timeOfDay27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2020 + "'", int15 == 2020);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1114907889L + "'", long17 == 1114907889L);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(timeOfDay27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime25 = property24.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType26);
        long long36 = zeroIsMaxDateTimeField33.getDifferenceAsLong((long) 0, 10L);
        int int39 = zeroIsMaxDateTimeField33.getDifference((long) '#', (-1727999119L));
        int int42 = zeroIsMaxDateTimeField33.getDifference((-1L), (long) '#');
        boolean boolean44 = zeroIsMaxDateTimeField33.isLeap((long) 0);
        long long47 = zeroIsMaxDateTimeField33.add((long) (byte) 10, 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 28799 + "'", int39 == 28799);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.secondOfDay();
        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType17, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMillis(2);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField18.getRangeDurationField();
        try {
            long long26 = unsupportedDateTimeField18.roundFloor(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNull(durationField24);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology0.add(readablePeriod3, (long) (short) -1, 2);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.Chronology chronology6 = dateTime3.getChronology();
//        int int7 = dateTime3.getHourOfDay();
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime3.withDayOfMonth(76);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 76 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 21 + "'", int7 == 21);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        int int7 = property6.getLeapAmount();
        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
        java.lang.String str9 = property6.toString();
        boolean boolean11 = property6.equals((java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[year]" + "'", str9.equals("Property[year]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        int int7 = property6.getLeapAmount();
        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
        org.joda.time.DateTime dateTime9 = property6.withMinimumValue();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond((int) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime9.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
//        int int8 = dateTime7.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
//        org.joda.time.DurationField durationField12 = gregorianChronology10.eras();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
//        int int14 = dateTime13.getSecondOfMinute();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime18 = dateTime13.plus((long) (short) -1);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 49 + "'", int14 == 49);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(8810L);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) remainderDateTimeField17, (int) (byte) 100, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfDay must be in the range [35,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8810L + "'", long19 == 8810L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter1.getParser();
        try {
            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("����", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 100);
        try {
            long long4 = dateTimeFormatter0.parseMillis("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.DurationField durationField19 = unsupportedDateTimeField18.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.centuryOfEra();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.DateTime dateTime30 = dateTime28.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DateTime dateTime32 = property31.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property31.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType33, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dateTimeField23, dateTimeFieldType33, 10);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.centuryOfEra();
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology39);
        org.joda.time.DateTime dateTime43 = dateTime41.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property44 = dateTime43.secondOfDay();
        org.joda.time.DateTime dateTime45 = property44.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property44.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType46, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType46, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField23, dateTimeFieldType46);
        long long56 = zeroIsMaxDateTimeField53.getDifferenceAsLong((long) 0, 10L);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone57);
        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology58.centuryOfEra();
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology58);
        org.joda.time.DateTime dateTime62 = dateTime60.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property63 = dateTime62.year();
        org.joda.time.DateTime dateTime65 = dateTime62.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay66 = dateTime65.toTimeOfDay();
        int[] intArray67 = null;
        int int68 = zeroIsMaxDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay66, intArray67);
        int[] intArray73 = new int[] { 0, 76, 10 };
        try {
            int[] intArray75 = unsupportedDateTimeField18.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay66, 86399, intArray73, 881);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(timeOfDay66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 60 + "'", int68 == 60);
        org.junit.Assert.assertNotNull(intArray73);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(8810L);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = remainderDateTimeField17.getType();
        boolean boolean21 = remainderDateTimeField17.isSupported();
        long long23 = remainderDateTimeField17.roundHalfCeiling((long) 15);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.DateTime dateTime34 = dateTime32.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property35 = dateTime34.secondOfDay();
        org.joda.time.DateTime dateTime36 = property35.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property35.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder28.appendFixedSignedDecimal(dateTimeFieldType37, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dateTimeField27, dateTimeFieldType37, 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField42 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, dateTimeFieldType37);
        long long44 = remainderDateTimeField17.roundHalfEven(52L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8810L + "'", long19 == 8810L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) -1, 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-33) + "'", int2 == (-33));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 21, (long) 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 294 + "'", int2 == 294);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) '4');
        int int13 = property6.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime15 = property6.addToCopy((long) 21);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withDate(9, 76, 33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 76 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(8810L);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = remainderDateTimeField17.getType();
        long long22 = remainderDateTimeField17.roundHalfCeiling((long) 100);
        int int23 = remainderDateTimeField17.getMinimumValue();
        java.util.Locale locale25 = null;
        java.lang.String str26 = remainderDateTimeField17.getAsShortText((long) 32, locale25);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8810L + "'", long19 == 8810L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime9 = property6.setCopy((int) (byte) -1);
        java.lang.String str10 = property6.getName();
        java.lang.String str11 = property6.getAsText();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekyear" + "'", str10.equals("weekyear"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((long) 881, 0, 271, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 271 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        int int7 = property6.getLeapAmount();
        int int8 = property6.get();
        org.joda.time.DateTime dateTime9 = property6.withMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2020 + "'", int8 == 2020);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfEvenCopy();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property6.getAsText(locale11);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "78111" + "'", str12.equals("78111"));
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime9 = property6.setCopy((int) (byte) -1);
        java.lang.String str10 = property6.getName();
        org.joda.time.DateTime dateTime11 = property6.withMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekyear" + "'", str10.equals("weekyear"));
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone15 = fixedDateTimeZone14.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime5.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(iSOChronology18);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(8810L);
        long long21 = remainderDateTimeField17.roundCeiling((long) 'a');
        java.util.Locale locale22 = null;
        int int23 = remainderDateTimeField17.getMaximumShortTextLength(locale22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = remainderDateTimeField17.getAsText((long) 881, locale25);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8810L + "'", long19 == 8810L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 60000L + "'", long21 == 60000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (byte) -1);
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
//        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
//        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
//        org.joda.time.DateTime dateTime11 = dateTime5.plusMinutes((int) (short) -1);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis((int) 'a');
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(gregorianCalendar7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1592084452452L + "'", long14 == 1592084452452L);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DurationField durationField8 = gregorianChronology6.eras();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.hourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.millisOfSecond();
        boolean boolean11 = gregorianChronology1.equals((java.lang.Object) dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology1.yearOfEra();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.parse("1970-W01-3T16:00:00-08:00");
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        int[] intArray16 = new int[] {};
        try {
            gregorianChronology1.validate((org.joda.time.ReadablePartial) localDate15, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime7 = dateTime3.withTimeAtStartOfDay();
        int int8 = dateTime7.getCenturyOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.DurationField durationField13 = gregorianChronology11.eras();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology11.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime7.toMutableDateTime((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean18 = dateTime7.isEqualNow();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 21 + "'", int8 == 21);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology0.getZone();
        java.lang.String str4 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.append(dateTimeParser12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.append(dateTimeParser16);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser12, dateTimeParser16 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder6.append(dateTimePrinter7, dateTimeParserArray18);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withPivotYear((java.lang.Integer) 10);
        org.joda.time.MutableDateTime mutableDateTime26 = dateTimeFormatter24.parseMutableDateTime("1970-12-30T16:00:00.097-08:00");
        boolean boolean27 = gregorianChronology21.equals((java.lang.Object) mutableDateTime26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 1, (org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.append(dateTimeParser31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder29.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.centuryOfEra();
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology39);
        org.joda.time.DateTime dateTime43 = dateTime41.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property44 = dateTime43.secondOfDay();
        org.joda.time.DateTime dateTime45 = property44.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property44.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType46, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder37.appendFixedSignedDecimal(dateTimeFieldType46, 6);
        org.joda.time.DateTime dateTime53 = dateTime28.withField(dateTimeFieldType46, (int) (short) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder19.appendFixedDecimal(dateTimeFieldType46, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTime53);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime5.plusYears((int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.yearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime5.withChronology((org.joda.time.Chronology) gregorianChronology12);
        int int15 = dateTime14.getYearOfEra();
        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
        org.joda.time.DurationField durationField17 = property16.getDurationField();
        org.joda.time.DurationField durationField18 = property16.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2020 + "'", int15 == 2020);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfEvenCopy();
//        int int11 = property6.get();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
//        org.joda.time.DurationField durationField15 = gregorianChronology13.eras();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology13.millisOfSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
//        java.util.Locale locale20 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter18.withLocale(locale20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.centuryOfEra();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property28 = dateTime27.year();
//        org.joda.time.DateTime dateTime30 = dateTime27.plusMonths((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay31 = dateTime30.toTimeOfDay();
//        java.lang.String str32 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) timeOfDay31);
//        int[] intArray34 = gregorianChronology13.get((org.joda.time.ReadablePartial) timeOfDay31, 10L);
//        try {
//            int int35 = property6.compareTo((org.joda.time.ReadablePartial) timeOfDay31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78113 + "'", int11 == 78113);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeParser19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(timeOfDay31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "����" + "'", str32.equals("����"));
//        org.junit.Assert.assertNotNull(intArray34);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("16:00", true);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeZoneBuilder4.toDateTimeZone("", false);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime3.toMutableDateTime(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField18.getRangeDurationField();
        try {
            long long25 = unsupportedDateTimeField18.roundHalfEven((long) 76);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
//        org.joda.time.DateTime.Property property9 = dateTime5.minuteOfHour();
//        int int10 = dateTime5.getDayOfMonth();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        boolean boolean10 = dateTime5.isAfterNow();
        org.joda.time.DateTime.Property property11 = dateTime5.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal(6L);
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) 881);
        java.lang.String str11 = fixedDateTimeZone4.getShortName((long) 100);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 25");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(8810L);
        long long21 = remainderDateTimeField17.roundCeiling((long) 'a');
        int int23 = remainderDateTimeField17.get((long) 6);
        long long25 = remainderDateTimeField17.roundHalfCeiling((long) (-1));
        java.util.Locale locale26 = null;
        int int27 = remainderDateTimeField17.getMaximumTextLength(locale26);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8810L + "'", long19 == 8810L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 60000L + "'", long21 == 60000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.weekyear();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
        try {
            long long12 = gregorianChronology1.getDateTimeMillis(0, 20, 1970, (int) (short) 0, 0, 20, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property15 = dateTime14.secondOfDay();
//        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
//        int int17 = property6.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        java.lang.String str18 = property6.toString();
//        org.joda.time.DurationField durationField19 = property6.getDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[secondOfDay]" + "'", str18.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNotNull(durationField19);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        int int20 = offsetDateTimeField19.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes((-1));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long15 = fixedDateTimeZone11.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTime dateTime16 = dateTime4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        int int17 = dateTime16.getMonthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        org.joda.time.DateTime dateTime23 = dateTime16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.DateTimeZone) fixedDateTimeZone22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "78111");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GregorianChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GregorianChronology[]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        long long21 = offsetDateTimeField19.remainder((long) 24);
        long long24 = offsetDateTimeField19.addWrapField((long) 'a', 25);
        long long26 = offsetDateTimeField19.roundHalfFloor((long) 20);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField19.getAsText((int) ' ', locale28);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24L + "'", long21 == 24L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 300097L + "'", long24 == 300097L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "32" + "'", str29.equals("32"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        long long21 = offsetDateTimeField19.remainder((long) 24);
        long long24 = offsetDateTimeField19.addWrapField((long) 'a', 25);
        long long26 = offsetDateTimeField19.roundHalfFloor((long) 20);
        boolean boolean28 = offsetDateTimeField19.isLeap((long) '#');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24L + "'", long21 == 24L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 300097L + "'", long24 == 300097L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("21:41");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"21:41\" is malformed at \":41\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withDefaultYear((int) (short) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long16 = fixedDateTimeZone14.nextTransition(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        boolean boolean20 = fixedDateTimeZone14.equals((java.lang.Object) dateTimeFormatter19);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(0, (int) (byte) 10, (int) ' ', 24, 60, (int) (byte) 0, 53, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology4 = gregorianChronology1.withUTC();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology1.getZone();
        try {
            long long14 = gregorianChronology1.getDateTimeMillis(2020, 20, (int) (byte) 100, 271, 60, 24, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 271 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.weekyear();
        org.joda.time.DateTime dateTime6 = dateTime4.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) (short) 1);
        org.joda.time.DateTime dateTime10 = dateTime6.minusDays(78114000);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded(readableDuration9, 86399);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[year]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField18.getAsShortText(60, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, 57600, 12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 9, 24, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime25 = property24.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType26);
        long long36 = zeroIsMaxDateTimeField33.getDifferenceAsLong((long) 0, 10L);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.centuryOfEra();
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.DateTime dateTime42 = dateTime40.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property43 = dateTime42.year();
        org.joda.time.DateTime dateTime45 = dateTime42.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay46 = dateTime45.toTimeOfDay();
        int[] intArray47 = null;
        int int48 = zeroIsMaxDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay46, intArray47);
        long long50 = zeroIsMaxDateTimeField33.roundCeiling((long) 60);
        long long52 = zeroIsMaxDateTimeField33.roundHalfFloor((long) ' ');
        long long55 = zeroIsMaxDateTimeField33.getDifferenceAsLong((long) 47, (-172791155L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(timeOfDay46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 60 + "'", int48 == 60);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 60000L + "'", long50 == 60000L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2879L + "'", long55 == 2879L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(20, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.centuryOfEra();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime13.year();
        org.joda.time.DateTime dateTime16 = dateTime13.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property17 = dateTime13.minuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone23 = fixedDateTimeZone22.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime13.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.Chronology chronology26 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        int int8 = dateTime7.getYearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292278993 + "'", int8 == 292278993);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime5.withFieldAdded(durationFieldType10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        java.util.Locale locale23 = null;
        try {
            int int24 = unsupportedDateTimeField18.getMaximumShortTextLength(locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.centuryOfEra();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime dateTime29 = dateTime27.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property30 = dateTime29.secondOfDay();
        org.joda.time.DateTime dateTime31 = property30.roundHalfEvenCopy();
        int int32 = dateTime31.getYearOfCentury();
        java.util.GregorianCalendar gregorianCalendar33 = dateTime31.toGregorianCalendar();
        org.joda.time.LocalDateTime localDateTime34 = dateTime31.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.centuryOfEra();
        org.joda.time.DurationField durationField39 = gregorianChronology37.eras();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.hourOfDay();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter42.getParser();
        java.util.Locale locale44 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = dateTimeFormatter42.withLocale(locale44);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone46);
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.centuryOfEra();
        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology47);
        org.joda.time.DateTime dateTime51 = dateTime49.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property52 = dateTime51.year();
        org.joda.time.DateTime dateTime54 = dateTime51.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay55 = dateTime54.toTimeOfDay();
        java.lang.String str56 = dateTimeFormatter42.print((org.joda.time.ReadablePartial) timeOfDay55);
        int[] intArray58 = gregorianChronology37.get((org.joda.time.ReadablePartial) timeOfDay55, 10L);
        try {
            int[] intArray60 = unsupportedDateTimeField18.set((org.joda.time.ReadablePartial) localDateTime34, 27, intArray58, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
        org.junit.Assert.assertNotNull(gregorianCalendar33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(timeOfDay55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "����" + "'", str56.equals("����"));
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("0", "10", 2020, 53);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendTimeZoneOffset("T14:41:11.128", "16:00", false, (int) (short) 10, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(52L);
        boolean boolean20 = remainderDateTimeField17.isSupported();
        int int23 = remainderDateTimeField17.getDifference((long) 271, (long) '4');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        java.util.Locale locale20 = null;
        int int21 = remainderDateTimeField17.getMaximumShortTextLength(locale20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter23.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.append(dateTimeParser24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendFractionOfDay((int) '4', 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendMinuteOfHour(0);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.centuryOfEra();
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTime dateTime36 = dateTime34.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property37 = dateTime36.secondOfDay();
        org.joda.time.DateTime dateTime38 = property37.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder28.appendFixedDecimal(dateTimeFieldType39, 20);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField17, dateTimeFieldType39);
        long long44 = dividedDateTimeField42.remainder((long) 2);
        int int45 = dividedDateTimeField42.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2L + "'", long44 == 2L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 0.0d, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        int int8 = dateTime7.getYearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfDay();
        org.joda.time.DateTime dateTime18 = property17.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        org.joda.time.DateTime dateTime21 = dateTime7.withField(dateTimeFieldType19, 15);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime25 = property24.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType26);
        long long36 = zeroIsMaxDateTimeField33.getDifferenceAsLong((long) 0, 10L);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.centuryOfEra();
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.DateTime dateTime42 = dateTime40.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property43 = dateTime42.year();
        org.joda.time.DateTime dateTime45 = dateTime42.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay46 = dateTime45.toTimeOfDay();
        int[] intArray47 = null;
        int int48 = zeroIsMaxDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay46, intArray47);
        org.joda.time.DurationField durationField49 = zeroIsMaxDateTimeField33.getRangeDurationField();
        int int51 = zeroIsMaxDateTimeField33.get(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(timeOfDay46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 60 + "'", int48 == 60);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 60 + "'", int51 == 60);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        int int8 = dateTime7.getYearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.DateTime.Property property10 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime7.minusYears(78114000);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 9, (long) 271);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2439 + "'", int2 == 2439);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.centuryOfEra();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property10 = dateTime9.year();
//        org.joda.time.DateTime dateTime12 = dateTime9.plusMonths((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay13 = dateTime12.toTimeOfDay();
//        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.centuryOfEra();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.DateTime dateTime21 = dateTime19.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property22 = dateTime21.year();
//        org.joda.time.DateTime dateTime24 = dateTime21.plusMonths((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay25 = dateTime24.toTimeOfDay();
//        java.lang.String str26 = dateTimeFormatter15.print((org.joda.time.ReadablePartial) timeOfDay25);
//        boolean boolean27 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay25);
//        java.lang.String str28 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) timeOfDay25);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter0.withDefaultYear((int) '4');
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeParser1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(timeOfDay13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "����" + "'", str14.equals("����"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(timeOfDay25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "T21:41:57.888" + "'", str26.equals("T21:41:57.888"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "����" + "'", str28.equals("����"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        try {
            int int19 = unsupportedDateTimeField18.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        java.util.Locale locale20 = null;
        int int21 = remainderDateTimeField17.getMaximumShortTextLength(locale20);
        long long23 = remainderDateTimeField17.roundCeiling((long) 76);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 60000L + "'", long23 == 60000L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.DurationField durationField19 = unsupportedDateTimeField18.getLeapDurationField();
        try {
            int int21 = unsupportedDateTimeField18.getMaximumValue((-1970L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendTimeZoneOffset("T14:41:11.128", "16:00", false, (int) (short) 10, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder0.appendTimeZoneOffset("Property[year]", false, 9, 14);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long14 = fixedDateTimeZone10.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTime dateTime15 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendTimeZoneOffset("T14:41:11.128", "16:00", false, (int) (short) 10, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendTwoDigitWeekyear(1970, false);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField23 = unsupportedDateTimeField18.getRangeDurationField();
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField18.getRangeDurationField();
        try {
            long long26 = unsupportedDateTimeField18.roundFloor((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNull(durationField24);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime3.withEra(0);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) (byte) 100, (java.lang.Number) 0L, (java.lang.Number) (-1.0d));
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(120097881L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.secondOfDay();
        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType17, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendHourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendFractionOfDay((int) ' ', 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter2.parseMutableDateTime("1970-12-30T16:00:00.097-08:00");
        try {
            long long6 = dateTimeFormatter2.parseMillis("Property[secondOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[secondOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(0L);
        int int13 = fixedDateTimeZone4.getOffset((-1727999119L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
//        int int8 = dateTime7.getYearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
//        org.joda.time.DurationField durationField12 = gregorianChronology10.eras();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
//        int int14 = dateTime13.getSecondOfMinute();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime18 = dateTime13.plus((long) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter20.withPivotYear((java.lang.Integer) 10);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTimeFormatter22.parseMutableDateTime("1970-12-30T16:00:00.097-08:00");
//        boolean boolean25 = gregorianChronology19.equals((java.lang.Object) mutableDateTime24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime13.toMutableDateTime((org.joda.time.Chronology) gregorianChronology19);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField6 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology0.add(readablePeriod3, (long) (short) -1, 2);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("T14:41:06.304", (java.lang.Number) 100, number2, (java.lang.Number) (-35L));
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "T14:41:06.304" + "'", str5.equals("T14:41:06.304"));
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("Property[secondOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[secondOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long14 = fixedDateTimeZone10.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTime dateTime15 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        int int16 = dateTime15.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DurationField durationField20 = gregorianChronology18.eras();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.millisOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology18.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology18.getZone();
        org.joda.time.DateTime dateTime25 = dateTime15.toDateTime((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.Chronology chronology26 = dateTime15.getChronology();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((-1));
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime5.toYearMonthDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long17 = fixedDateTimeZone13.convertLocalToUTC((long) (-1), true, (long) ' ');
        boolean boolean19 = fixedDateTimeZone13.equals((java.lang.Object) 100.0f);
        org.joda.time.DateTime dateTime20 = dateTime5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(yearMonthDay8);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear((java.lang.Integer) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTimeFormatter5.parseMutableDateTime("1970-12-30T16:00:00.097-08:00");
        boolean boolean8 = gregorianChronology2.equals((java.lang.Object) mutableDateTime7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime9 = property6.setCopy((int) (byte) -1);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime11 = property10.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond(0);
        org.joda.time.DateTime.Property property14 = dateTime11.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 100);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime25 = property24.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType26);
        long long36 = zeroIsMaxDateTimeField33.getDifferenceAsLong((long) 0, 10L);
        int int39 = zeroIsMaxDateTimeField33.getDifference((long) '#', (-1727999119L));
        org.joda.time.DateTimeField dateTimeField40 = zeroIsMaxDateTimeField33.getWrappedField();
        java.util.Locale locale42 = null;
        java.lang.String str43 = zeroIsMaxDateTimeField33.getAsShortText((int) (byte) 10, locale42);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 28799 + "'", int39 == 28799);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10" + "'", str43.equals("10"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime5.plus(readableDuration10);
        boolean boolean13 = dateTime5.isAfter((long) 271);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(271, '4', 271, 271, (int) (short) -1, true, (int) '4');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("Property[secondOfDay]", 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfHalfday(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        int int8 = dateTime7.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DurationField durationField12 = gregorianChronology10.eras();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        int int14 = dateTime13.getSecondOfMinute();
        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime18 = dateTime13.plus((long) (short) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.secondOfDay();
        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType17, 6);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTime dateTime28 = dateTime26.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property29 = dateTime28.secondOfDay();
        org.joda.time.DateTime dateTime30 = property29.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "T14:41:06.304");
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 100, "T14:41:11.128");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendShortText(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime5.plusMinutes((int) (short) -1);
        org.joda.time.DateTime dateTime13 = dateTime5.withMillisOfDay(13);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        java.lang.String str8 = property6.getAsShortText();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970" + "'", str8.equals("1970"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.weekyear();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime5.toGregorianCalendar();
        boolean boolean9 = dateTime5.isEqual((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime5.withYearOfCentury((int) 'a');
        org.joda.time.DateTime dateTime13 = dateTime5.plusMinutes(100);
        org.joda.time.DateTime dateTime15 = dateTime5.minusSeconds(1);
        org.joda.time.DateTime dateTime18 = dateTime5.withDurationAdded(0L, 1);
        int int19 = dateTime5.getYearOfCentury();
        try {
            org.joda.time.DateTime dateTime24 = dateTime5.withTime(0, 76, (int) (byte) 0, 86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 76 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 70 + "'", int19 == 70);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str12 = fixedDateTimeZone5.getNameKey(8845L);
        org.joda.time.Chronology chronology13 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime25 = property24.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType26);
        long long36 = zeroIsMaxDateTimeField33.getDifferenceAsLong((long) 0, 10L);
        long long39 = zeroIsMaxDateTimeField33.getDifferenceAsLong((-35L), 35L);
        org.joda.time.DurationField durationField40 = zeroIsMaxDateTimeField33.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNull(durationField40);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("21:41", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"21:41/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField18.getDurationField();
        java.util.Locale locale23 = null;
        try {
            int int24 = unsupportedDateTimeField18.getMaximumShortTextLength(locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        int int5 = dateTime4.getSecondOfMinute();
        org.joda.time.DateTime.Property property6 = dateTime4.weekyear();
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        int int7 = property6.getLeapAmount();
        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
        java.lang.String str9 = property6.toString();
        org.joda.time.DateTime dateTime10 = property6.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.centuryOfEra();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTime dateTime21 = dateTime19.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime23 = property22.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendFixedSignedDecimal(dateTimeFieldType24, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField14, dateTimeFieldType24, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, 1);
        long long32 = offsetDateTimeField30.remainder((long) 24);
        boolean boolean33 = dateTime10.equals((java.lang.Object) offsetDateTimeField30);
        java.util.Locale locale34 = null;
        int int35 = offsetDateTimeField30.getMaximumTextLength(locale34);
        boolean boolean37 = offsetDateTimeField30.isLeap(2879L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[year]" + "'", str9.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 24L + "'", long32 == 24L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.DurationField durationField4 = gregorianChronology2.eras();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((java.lang.Integer) 0);
        java.io.Writer writer10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMinutes((-1));
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime14.toYearMonthDay();
        try {
            dateTimeFormatter9.printTo(writer10, (org.joda.time.ReadablePartial) yearMonthDay17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 10);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter3.parseMutableDateTime("1970-12-30T16:00:00.097-08:00");
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) mutableDateTime5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        int int4 = dateTime3.getMinuteOfDay();
        org.joda.time.DateMidnight dateMidnight5 = dateTime3.toDateMidnight();
        boolean boolean7 = dateTime3.isEqual((long) 271);
        try {
            org.joda.time.DateTime dateTime9 = dateTime3.withEra((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "T14:41:06.304");
        java.lang.String str17 = illegalFieldValueException16.getFieldName();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "secondOfDay" + "'", str17.equals("secondOfDay"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("32");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"32\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology1.add(readablePeriod4, (long) (byte) 100, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        int int8 = dateTime7.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DurationField durationField12 = gregorianChronology10.eras();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        int int14 = dateTime13.getSecondOfMinute();
        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime13);
        try {
            org.joda.time.DateTime dateTime18 = dateTime13.withEra((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.DateTime dateTime7 = dateTime5.plusMillis((int) (short) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfYear((int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1970");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        try {
            java.lang.String str23 = unsupportedDateTimeField18.getAsShortText((long) 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        java.util.Locale locale20 = null;
        int int21 = remainderDateTimeField17.getMaximumShortTextLength(locale20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter23.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.append(dateTimeParser24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendFractionOfDay((int) '4', 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendMinuteOfHour(0);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.centuryOfEra();
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTime dateTime36 = dateTime34.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property37 = dateTime36.secondOfDay();
        org.joda.time.DateTime dateTime38 = property37.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder28.appendFixedDecimal(dateTimeFieldType39, 20);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField17, dateTimeFieldType39);
        long long45 = dividedDateTimeField42.addWrapField(6L, 76);
        try {
            long long48 = dividedDateTimeField42.set((long) 2019, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for secondOfDay must be in the range [0,5]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2400006L + "'", long45 == 2400006L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        int int7 = property6.getLeapAmount();
        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
        java.lang.String str9 = property6.toString();
        org.joda.time.DateTime dateTime10 = property6.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.centuryOfEra();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTime dateTime21 = dateTime19.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTime dateTime23 = property22.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendFixedSignedDecimal(dateTimeFieldType24, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField14, dateTimeFieldType24, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, 1);
        long long32 = offsetDateTimeField30.remainder((long) 24);
        boolean boolean33 = dateTime10.equals((java.lang.Object) offsetDateTimeField30);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField30, 2439, 10000, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2439 for secondOfDay must be in the range [10000,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[year]" + "'", str9.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 24L + "'", long32 == 24L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 70, (java.lang.Number) 10000, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.append(dateTimeParser12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.append(dateTimeParser16);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser12, dateTimeParser16 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder6.append(dateTimePrinter7, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitYear(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendSecondOfMinute((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendTwoDigitWeekyear(2020);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.roundHalfEven((long) 53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime26 = dateTime24.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTime dateTime28 = property27.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder20.appendFixedSignedDecimal(dateTimeFieldType29, 21);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.centuryOfEra();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology33);
        org.joda.time.DateTime dateTime37 = dateTime35.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTime dateTime39 = property38.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder20.appendText(dateTimeFieldType40);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, dateTimeFieldType40);
        int int46 = remainderDateTimeField17.getMinimumValue();
        long long48 = remainderDateTimeField17.roundHalfEven(0L);
        long long51 = remainderDateTimeField17.getDifferenceAsLong((long) 20, (long) 15);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long7 = fixedDateTimeZone4.nextTransition((long) 31);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31L + "'", long7 == 31L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        long long5 = dateTimeZone1.convertLocalToUTC(0L, false, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readableDuration7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime12.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.centuryOfEra();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTime dateTime21 = dateTime19.plusWeeks((int) '4');
        int int22 = property15.getDifference((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime23 = dateTime19.withLaterOffsetAtOverlap();
        org.joda.time.DateMidnight dateMidnight24 = dateTime19.toDateMidnight();
        int int25 = dateTime8.compareTo((org.joda.time.ReadableInstant) dateMidnight24);
        org.joda.time.DateTime dateTime27 = dateTime8.withMillis(78114294L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateMidnight24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1970-W01-3T16:00:00-08:00");
        org.joda.time.LocalDate localDate2 = dateTime1.toLocalDate();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) (byte) 100, (java.lang.Number) 0L, (java.lang.Number) (-1.0d));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone10 = fixedDateTimeZone9.toTimeZone();
        int int12 = fixedDateTimeZone9.getOffsetFromLocal(6L);
        java.lang.String str14 = fixedDateTimeZone9.getNameKey((long) 881);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) "hi!", (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime5.plusYears((int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.yearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime5.withChronology((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
        try {
            org.joda.time.DateTime dateTime17 = dateTime14.withHourOfDay(78114000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78114000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendTimeZoneOffset("T14:41:11.128", "16:00", false, (int) (short) 10, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendTwoDigitYear(271);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.append(dateTimeParser18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder16.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder16.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder16.appendMinuteOfHour((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder16.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.centuryOfEra();
        org.joda.time.DurationField durationField31 = gregorianChronology29.eras();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.format.DateTimePrinter dateTimePrinter34 = dateTimeFormatter27.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatter35.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.append(dateTimeParser39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter41.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray45 = new org.joda.time.format.DateTimeParser[] { dateTimeParser36, dateTimeParser39, dateTimeParser44 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder16.append(dateTimePrinter34, dateTimeParserArray45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser49 = dateTimeFormatter48.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.append(dateTimeParser49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder47.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder47.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder47.appendMinuteOfHour((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder47.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone59);
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology60.centuryOfEra();
        org.joda.time.DurationField durationField62 = gregorianChronology60.eras();
        org.joda.time.DateTime dateTime63 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology60);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter58.withChronology((org.joda.time.Chronology) gregorianChronology60);
        org.joda.time.format.DateTimePrinter dateTimePrinter65 = dateTimeFormatter58.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser67 = dateTimeFormatter66.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser70 = dateTimeFormatter69.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder68.append(dateTimeParser70);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = dateTimeFormatter72.withPivotYear((java.lang.Integer) 10);
        org.joda.time.format.DateTimeParser dateTimeParser75 = dateTimeFormatter72.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray76 = new org.joda.time.format.DateTimeParser[] { dateTimeParser67, dateTimeParser70, dateTimeParser75 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder47.append(dateTimePrinter65, dateTimeParserArray76);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder13.append(dateTimePrinter34, dateTimeParserArray76);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimePrinter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeParser44);
        org.junit.Assert.assertNotNull(dateTimeParserArray45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertNotNull(dateTimeParser49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertNotNull(dateTimePrinter65);
        org.junit.Assert.assertNotNull(dateTimeFormatter66);
        org.junit.Assert.assertNotNull(dateTimeParser67);
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
        org.junit.Assert.assertNotNull(dateTimeParser70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(dateTimeFormatter74);
        org.junit.Assert.assertNotNull(dateTimeParser75);
        org.junit.Assert.assertNotNull(dateTimeParserArray76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        long long21 = unsupportedDateTimeField18.add((long) 70, 100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.centuryOfEra();
        org.joda.time.DurationField durationField25 = gregorianChronology23.eras();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.hourOfDay();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology23.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
        java.util.Locale locale30 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter28.withLocale(locale30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.centuryOfEra();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology33);
        org.joda.time.DateTime dateTime37 = dateTime35.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property38 = dateTime37.year();
        org.joda.time.DateTime dateTime40 = dateTime37.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay41 = dateTime40.toTimeOfDay();
        java.lang.String str42 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) timeOfDay41);
        int[] intArray44 = gregorianChronology23.get((org.joda.time.ReadablePartial) timeOfDay41, 10L);
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = unsupportedDateTimeField18.getAsText((org.joda.time.ReadablePartial) timeOfDay41, 59, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100070L + "'", long21 == 100070L);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(timeOfDay41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "����" + "'", str42.equals("����"));
        org.junit.Assert.assertNotNull(intArray44);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendSecondOfMinute(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendPattern("����");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "T14:41:06.304");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType20);
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatterBuilder11.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes((-1));
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime9.toYearMonthDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (-1), true, (long) ' ');
        boolean boolean23 = fixedDateTimeZone17.equals((java.lang.Object) 100.0f);
        org.joda.time.DateTime dateTime24 = dateTime9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(1, (int) (short) -1, (-33), 78114000, (int) '#', 10, (org.joda.time.DateTimeZone) fixedDateTimeZone17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78114000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
        java.lang.Object obj10 = null;
        boolean boolean11 = property6.equals(obj10);
        java.lang.String str12 = property6.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withLocale(locale15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.year();
        org.joda.time.DateTime dateTime25 = dateTime22.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay26 = dateTime25.toTimeOfDay();
        java.lang.String str27 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) timeOfDay26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.DateTime dateTime34 = dateTime32.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property35 = dateTime34.year();
        org.joda.time.DateTime dateTime37 = dateTime34.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay38 = dateTime37.toTimeOfDay();
        java.lang.String str39 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) timeOfDay38);
        boolean boolean40 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay38);
        java.lang.String str41 = dateTimeFormatter13.print((org.joda.time.ReadablePartial) timeOfDay38);
        try {
            int int42 = property6.compareTo((org.joda.time.ReadablePartial) timeOfDay38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfDay" + "'", str12.equals("secondOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(timeOfDay26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "����" + "'", str27.equals("����"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(timeOfDay38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "T00:00:00.100" + "'", str39.equals("T00:00:00.100"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "����" + "'", str41.equals("����"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) '4');
        int int13 = property6.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.withLaterOffsetAtOverlap();
        boolean boolean16 = dateTime10.isAfter((long) 70);
        boolean boolean18 = dateTime10.isBefore((long) (-1));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendSecondOfMinute(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendPattern("����");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTime dateTime19 = property18.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-35L), "Property[year]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType20, (int) (byte) 1, 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap30 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder7.appendTimeZoneName(strMap30);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendTimeZoneOffset("T14:41:11.128", "16:00", false, (int) (short) 10, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.append(dateTimeParser15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendYearOfCentury(21, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendSecondOfMinute(20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder20.appendPattern("����");
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.centuryOfEra();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.DateTime dateTime30 = dateTime28.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DateTime dateTime32 = property31.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType33, (int) (short) 100, 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.roundHalfEven((long) 53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime26 = dateTime24.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTime dateTime28 = property27.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder20.appendFixedSignedDecimal(dateTimeFieldType29, 21);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.centuryOfEra();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology33);
        org.joda.time.DateTime dateTime37 = dateTime35.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTime dateTime39 = property38.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder20.appendText(dateTimeFieldType40);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, dateTimeFieldType40);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = remainderDateTimeField17.getType();
        long long48 = remainderDateTimeField17.roundHalfCeiling((long) 24);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(52L);
        boolean boolean20 = remainderDateTimeField17.isSupported();
        long long22 = remainderDateTimeField17.roundHalfFloor(0L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = remainderDateTimeField17.getAsText(8810L, locale24);
        long long27 = remainderDateTimeField17.roundHalfCeiling((long) 27);
        int int29 = remainderDateTimeField17.getMaximumValue((long) 59);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long6 = fixedDateTimeZone4.nextTransition(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int9 = fixedDateTimeZone4.getStandardOffset(52L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes((-1));
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.DurationField durationField9 = gregorianChronology7.eras();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.hourOfDay();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime12 = dateTime5.withChronology((org.joda.time.Chronology) gregorianChronology7);
        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-59900L) + "'", long13 == (-59900L));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(271, '4', 271, 271, (int) (short) -1, true, (int) '4');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset(53);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder21 = dateTimeZoneBuilder0.addRecurringSavings("T14:41:24.486", (int) 'a', 0, 1, 'a', 6, 24, 70, true, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTime dateTime25 = property24.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 10L, "����");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType26);
        long long36 = zeroIsMaxDateTimeField33.getDifferenceAsLong((long) 0, 10L);
        int int39 = zeroIsMaxDateTimeField33.getDifference((long) '#', (-1727999119L));
        org.joda.time.DateTimeField dateTimeField40 = zeroIsMaxDateTimeField33.getWrappedField();
        long long43 = zeroIsMaxDateTimeField33.add((-172791155L), (long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.centuryOfEra();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology45);
        org.joda.time.DateTime dateTime49 = dateTime47.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property50 = dateTime49.secondOfDay();
        org.joda.time.DateTime dateTime51 = property50.roundHalfEvenCopy();
        int int52 = dateTime51.getYearOfCentury();
        java.util.GregorianCalendar gregorianCalendar53 = dateTime51.toGregorianCalendar();
        org.joda.time.LocalDateTime localDateTime54 = dateTime51.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone56);
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology57.centuryOfEra();
        org.joda.time.DurationField durationField59 = gregorianChronology57.eras();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology57.hourOfDay();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology57.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser63 = dateTimeFormatter62.getParser();
        java.util.Locale locale64 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = dateTimeFormatter62.withLocale(locale64);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology67.centuryOfEra();
        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology67);
        org.joda.time.DateTime dateTime71 = dateTime69.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property72 = dateTime71.year();
        org.joda.time.DateTime dateTime74 = dateTime71.plusMonths((int) (byte) 10);
        org.joda.time.TimeOfDay timeOfDay75 = dateTime74.toTimeOfDay();
        java.lang.String str76 = dateTimeFormatter62.print((org.joda.time.ReadablePartial) timeOfDay75);
        int[] intArray78 = gregorianChronology57.get((org.joda.time.ReadablePartial) timeOfDay75, 10L);
        try {
            int[] intArray80 = zeroIsMaxDateTimeField33.addWrapField((org.joda.time.ReadablePartial) localDateTime54, (int) 'a', intArray78, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 28799 + "'", int39 == 28799);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-172731155L) + "'", long43 == (-172731155L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 70 + "'", int52 == 70);
        org.junit.Assert.assertNotNull(gregorianCalendar53);
        org.junit.Assert.assertNotNull(localDateTime54);
        org.junit.Assert.assertNotNull(gregorianChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNotNull(dateTimeParser63);
        org.junit.Assert.assertNotNull(dateTimeFormatter65);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(timeOfDay75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "����" + "'", str76.equals("����"));
        org.junit.Assert.assertNotNull(intArray78);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField17);
        org.joda.time.DurationField durationField19 = unsupportedDateTimeField18.getLeapDurationField();
        boolean boolean20 = unsupportedDateTimeField18.isLenient();
        try {
            long long23 = unsupportedDateTimeField18.set(2879L, "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField18);
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("21:41");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"21:41\" is malformed at \":41\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(70, 2019, (int) (byte) -1, 76, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 76 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.remainder(52L);
        boolean boolean20 = remainderDateTimeField17.isSupported();
        long long22 = remainderDateTimeField17.remainder(120097L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField6 = gregorianChronology1.halfdays();
        long long9 = durationField6.subtract(0L, 2020);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-87264000000L) + "'", long9 == (-87264000000L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime5.plusYears((int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.yearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime5.withChronology((org.joda.time.Chronology) gregorianChronology12);
        int int15 = dateTime14.getYearOfEra();
        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 100);
        try {
            long long4 = dateTimeFormatter0.parseMillis("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology0.add(readablePeriod3, (long) (short) -1, 2);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.millisOfSecond();
        java.lang.String str9 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withDayOfMonth(292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 10L, "����");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "T14:41:06.304");
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.centuryOfEra();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.Chronology chronology33 = gregorianChronology30.withUTC();
        org.joda.time.DurationField durationField34 = gregorianChronology30.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField34);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType8, durationField34);
        try {
            long long38 = unsupportedDateTimeField36.roundCeiling((long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay((int) '4', 15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour(0);
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildFormatter();
        dateTimeFormatterBuilder8.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTwoDigitYear(86399);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime5.plusYears((int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.yearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime5.withChronology((org.joda.time.Chronology) gregorianChronology12);
        int int15 = dateTime14.getYearOfEra();
        org.joda.time.DateTime.Property property16 = dateTime14.monthOfYear();
        long long17 = property16.remainder();
        org.joda.time.DateTime dateTime19 = property16.addToCopy(0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2592000100L + "'", long17 == 2592000100L);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        long long19 = remainderDateTimeField17.roundHalfEven((long) 53);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime26 = dateTime24.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
        org.joda.time.DateTime dateTime28 = property27.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder20.appendFixedSignedDecimal(dateTimeFieldType29, 21);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.centuryOfEra();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology33);
        org.joda.time.DateTime dateTime37 = dateTime35.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property38 = dateTime37.secondOfDay();
        org.joda.time.DateTime dateTime39 = property38.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) (-1.0f), "hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder20.appendText(dateTimeFieldType40);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, dateTimeFieldType40);
        long long47 = zeroIsMaxDateTimeField45.remainder(120097881L);
        long long49 = zeroIsMaxDateTimeField45.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 37881L + "'", long47 == 37881L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long15 = fixedDateTimeZone11.convertLocalToUTC((long) (-1), true, (long) ' ');
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(70, 49, 14, (int) 'a', 78114000, 24, 86399, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long6 = fixedDateTimeZone4.previousTransition((long) 6);
        long long8 = fixedDateTimeZone4.nextTransition((-97001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6L + "'", long6 == 6L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-97001L) + "'", long8 == (-97001L));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) '4');
        int int13 = property6.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.centuryOfEra();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTime dateTime19 = dateTime17.plusMinutes((-1));
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime17.toYearMonthDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        long long29 = fixedDateTimeZone25.convertLocalToUTC((long) (-1), true, (long) ' ');
        boolean boolean31 = fixedDateTimeZone25.equals((java.lang.Object) 100.0f);
        org.joda.time.DateTime dateTime32 = dateTime17.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        int int33 = property6.getDifference((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime.Property property34 = dateTime32.yearOfEra();
        org.joda.time.DateTime dateTime35 = property34.withMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long7 = fixedDateTimeZone4.previousTransition((long) '4');
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("16:00", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 0);
        java.lang.StringBuffer stringBuffer5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTime dateTime14 = dateTime11.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime17 = property15.addToCopy(32);
        try {
            dateTimeFormatter4.printTo(stringBuffer5, (org.joda.time.ReadableInstant) dateTime17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.minuteOfHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType13, 21);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField17 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType13, 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField17, 1);
        long long21 = offsetDateTimeField19.remainder((long) 24);
        long long24 = offsetDateTimeField19.addWrapField((long) 'a', 25);
        int int25 = offsetDateTimeField19.getMaximumValue();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.centuryOfEra();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.DateTime dateTime32 = dateTime30.plusWeeks((int) '4');
        org.joda.time.DateTime.Property property33 = dateTime32.secondOfDay();
        org.joda.time.DateTime dateTime34 = property33.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder26.appendFixedSignedDecimal(dateTimeFieldType35, 21);
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) 0.0d, "����");
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField41 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, dateTimeFieldType35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24L + "'", long21 == 24L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 300097L + "'", long24 == 300097L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (byte) 0, (int) (short) 1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicDate();
        boolean boolean8 = gregorianChronology6.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DurationField durationField9 = gregorianChronology6.days();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
    }
}

