import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test01");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        java.lang.String str29 = unsupportedDateTimeField28.toString();
//        long long32 = unsupportedDateTimeField28.getDifferenceAsLong(0L, (long) 24);
//        try {
//            long long35 = unsupportedDateTimeField28.set((long) 100, "");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test02");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipDateTimeField6.getAsText(0, locale10);
//        long long13 = skipDateTimeField6.remainder((long) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap15 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTimeZoneShortName(strMap15);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendMinuteOfDay((int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond(57600010);
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField23 = julianChronology21.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology21, dateTimeField26);
//        int int29 = skipDateTimeField27.get(0L);
//        org.joda.time.Chronology chronology30 = null;
//        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = julianChronology31.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField(chronology30, dateTimeField32);
//        java.lang.String str35 = skipUndoDateTimeField33.getAsText(10L);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = skipUndoDateTimeField33.getAsShortText((int) (byte) 0, locale37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = skipUndoDateTimeField33.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, dateTimeFieldType39);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder18.appendFixedSignedDecimal(dateTimeFieldType39, 100);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType39, (int) 'a');
//        int int46 = remainderDateTimeField44.getMinimumValue((long) 100);
//        long long48 = remainderDateTimeField44.roundHalfEven((long) (-1));
//        long long51 = remainderDateTimeField44.add((long) 96, 100L);
//        org.joda.time.DurationField durationField52 = null;
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField55 = julianChronology54.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology53, dateTimeField55);
//        java.lang.String str58 = skipUndoDateTimeField56.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField59 = skipUndoDateTimeField56.getWrappedField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField61 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField59, dateTimeFieldType60);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap63 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendTimeZoneShortName(strMap63);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder62.appendMinuteOfDay((int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder66.appendMillisOfSecond(57600010);
//        org.joda.time.chrono.JulianChronology julianChronology69 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField70 = julianChronology69.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField71 = julianChronology69.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int73 = gregorianChronology72.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology72.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField75 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology69, dateTimeField74);
//        int int77 = skipDateTimeField75.get(0L);
//        org.joda.time.Chronology chronology78 = null;
//        org.joda.time.chrono.JulianChronology julianChronology79 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField80 = julianChronology79.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField81 = new org.joda.time.field.SkipUndoDateTimeField(chronology78, dateTimeField80);
//        java.lang.String str83 = skipUndoDateTimeField81.getAsText(10L);
//        java.util.Locale locale85 = null;
//        java.lang.String str86 = skipUndoDateTimeField81.getAsShortText((int) (byte) 0, locale85);
//        org.joda.time.DateTimeFieldType dateTimeFieldType87 = skipUndoDateTimeField81.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField88 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField75, dateTimeFieldType87);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder90 = dateTimeFormatterBuilder66.appendFixedSignedDecimal(dateTimeFieldType87, 100);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField91 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField59, dateTimeFieldType87);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException94 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType87, (java.lang.Number) 25200032L, "0");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField95 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField44, durationField52, dateTimeFieldType87);
//        int int96 = dividedDateTimeField95.getMaximumValue();
//        int int97 = dividedDateTimeField95.getDivisor();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "AM" + "'", str35.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "AM" + "'", str38.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 6000096L + "'", long51 == 6000096L);
//        org.junit.Assert.assertNotNull(julianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "AM" + "'", str58.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//        org.junit.Assert.assertNotNull(julianChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 4 + "'", int73 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology79);
//        org.junit.Assert.assertNotNull(dateTimeField80);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "AM" + "'", str83.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "AM" + "'", str86.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType87);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder90);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 14 + "'", int96 == 14);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 97 + "'", int97 == 97);
//    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test03");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        org.joda.time.DurationField durationField7 = skipDateTimeField6.getDurationField();
//        java.lang.String str9 = skipDateTimeField6.getAsShortText(18166L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
//    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test04");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2);
//        java.lang.String str5 = skipUndoDateTimeField3.getAsText(10L);
//        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField3.getWrappedField();
//        java.lang.String str8 = skipUndoDateTimeField3.getAsText((long) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendMinuteOfDay((int) 'a');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMillisOfSecond(57600010);
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology16.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int20 = gregorianChronology19.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology16, dateTimeField21);
//        int int24 = skipDateTimeField22.get(0L);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = julianChronology26.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField(chronology25, dateTimeField27);
//        java.lang.String str30 = skipUndoDateTimeField28.getAsText(10L);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipUndoDateTimeField28.getAsShortText((int) (byte) 0, locale32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipUndoDateTimeField28.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, dateTimeFieldType34);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder13.appendFixedSignedDecimal(dateTimeFieldType34, 100);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField3, dateTimeFieldType34, 960);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AM" + "'", str5.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AM" + "'", str8.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "AM" + "'", str30.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AM" + "'", str33.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((-62167391999903L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear(166);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test07");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate localDate4 = localDate0.withYear((int) (short) 10);
//        org.joda.time.LocalDate localDate6 = localDate4.withDayOfMonth(4);
//        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtMidnight();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate();
//        java.lang.String str9 = localDate8.toString();
//        int int10 = localDate8.getDayOfMonth();
//        org.joda.time.LocalDate.Property property11 = localDate8.era();
//        org.joda.time.LocalDate localDate12 = property11.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField13 = property11.getLeapDurationField();
//        org.joda.time.LocalDate localDate14 = property11.withMinimumValue();
//        org.joda.time.LocalDate localDate16 = localDate14.minusWeeks((int) (byte) 10);
//        int int17 = localDate16.getYear();
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        int int21 = dateTimeZone19.getOffsetFromLocal((long) 100);
//        org.joda.time.DateTime dateTime22 = localDate16.toDateTimeAtStartOfDay(dateTimeZone19);
//        java.lang.String str23 = dateTimeZone19.getID();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19, 4);
//        org.joda.time.DateMidnight dateMidnight26 = localDate4.toDateMidnight(dateTimeZone19);
//        java.util.Date date27 = dateMidnight26.toDate();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01" + "'", str9.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNull(durationField13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1971) + "'", int17 == (-1971));
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateMidnight26);
//        org.junit.Assert.assertNotNull(date27);
//    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test08");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear((-1949));
//        org.joda.time.ReadWritableInstant readWritableInstant5 = null;
//        try {
//            int int8 = dateTimeFormatter4.parseInto(readWritableInstant5, "-28800000", 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "19700101" + "'", str2.equals("19700101"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test09");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField5);
//        int int8 = skipDateTimeField6.get(0L);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField12.getAsText(10L);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField12.getAsShortText((int) (byte) 0, locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField12.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1561680000001L, (java.lang.Number) (-1), (java.lang.Number) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = julianChronology24.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = buddhistChronology26.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField27);
//        int int31 = unsupportedDateTimeField28.getDifference(32L, 1L);
//        try {
//            long long34 = unsupportedDateTimeField28.set((long) 3, "UTC");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test10");
//        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
//        java.lang.String str1 = localDate0.toString();
//        int int2 = localDate0.getDayOfMonth();
//        org.joda.time.LocalDate.Property property3 = localDate0.era();
//        org.joda.time.LocalDate localDate4 = property3.roundHalfCeilingCopy();
//        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
//        org.joda.time.LocalDate localDate6 = property3.withMinimumValue();
//        org.joda.time.LocalDate localDate8 = localDate6.minusWeeks((int) (byte) 10);
//        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks((int) (byte) 1);
//        org.joda.time.LocalDate.Property property11 = localDate8.yearOfEra();
//        org.joda.time.DateMidnight dateMidnight12 = localDate8.toDateMidnight();
//        int int13 = localDate8.getWeekyear();
//        int int14 = localDate8.getYearOfCentury();
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        org.joda.time.LocalDate localDate16 = localDate8.withFields(readablePartial15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        java.lang.String str18 = buddhistChronology17.toString();
//        org.joda.time.DurationField durationField19 = buddhistChronology17.hours();
//        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology20.getZone();
//        org.joda.time.Chronology chronology22 = buddhistChronology17.withZone(dateTimeZone21);
//        org.joda.time.Chronology chronology23 = buddhistChronology17.withUTC();
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(0L);
//        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate25);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = partial26.getFormatter();
//        boolean boolean28 = buddhistChronology17.equals((java.lang.Object) partial26);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = partial26.getFieldType(0);
//        boolean boolean31 = localDate16.isAfter((org.joda.time.ReadablePartial) partial26);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1970-01-01" + "'", str1.equals("1970-01-01"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateMidnight12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1971) + "'", int13 == (-1971));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 71 + "'", int14 == 71);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "BuddhistChronology[UTC]" + "'", str18.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(julianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        int int3 = dateTime2.getMillisOfSecond();
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = dateTime2.toCalendar(locale4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.minus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(calendar5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        boolean boolean2 = localDate0.equals((java.lang.Object) "2019-W24-6");
        org.joda.time.LocalDate localDate4 = localDate0.withCenturyOfEra(6);
        org.joda.time.LocalDate.Property property5 = localDate0.dayOfMonth();
        org.joda.time.LocalDate.Property property6 = localDate0.weekyear();
        org.joda.time.LocalDate localDate7 = property6.getLocalDate();
        org.joda.time.LocalDate localDate9 = localDate7.minusMonths((-101));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
    }
}

